import { type EntryChange, EntryTree, EntryGroup, type SourceLocation } from '@deepseek-ai/cordis-plugin-loader';
import { Context, Service } from '@deepseek-ai/cordis';
import { type PatchOptions } from './patch.ts';
/** Shared patch semantics used by config dumps and mounting. */
export { applyPatches as applyEntryPatches } from './patch.ts';
/** Serialized entry patch options and the composed result of applying them. */
export type { PatchOptions, PatchResult } from './patch.ts';
/** Options for {@link stringifyEntryYaml}. */
export interface EntryYamlStringifyOptions {
    /** Column at which long scalars are folded; `-1` disables folding. Defaults to 80. */
    lineWidth?: number;
}
/**
 * Parse text in Include's YAML dialect: YAML 1.2 under the core schema, plus `!!js`. A `!!js` scalar becomes a
 * child-owned JavaScript expression node that stays literal until its owning Loader entry evaluates it. Include
 * reads its own file with the same options.
 * @param content - YAML source text.
 * @returns the parsed value, or `undefined` for an empty document.
 * @throws the first parse error, or the first warning such as an unknown tag; {@link entryYamlErrorPosition} reads its location.
 */
export declare function parseEntryYaml(content: string): unknown;
/**
 * Serialize a value in Include's YAML dialect. JavaScript expression nodes are written as `!!js` scalars. The output
 * never contains anchors or aliases: repeated object references are written out in full, and no option changes this.
 * @param value - entry list, patch list, or entry fragment to serialize.
 * @param options - output formatting.
 * @returns YAML text ending with a newline.
 */
export declare function stringifyEntryYaml(value: unknown, options?: EntryYamlStringifyOptions): string;
/**
 * Locate a parse error thrown by {@link parseEntryYaml}.
 * @param error - any caught value; only a parse error thrown by {@link parseEntryYaml} yields a position.
 * @returns the one-based line and column of the error, or `undefined` when the error carries no source location.
 */
export declare function entryYamlErrorPosition(error: unknown): {
    line: number;
    column: number;
} | undefined;
type ConfigStage = 'read' | 'parse' | 'validate';
export interface ConfigIssue {
    message: string;
    location: SourceLocation;
}
export declare class ConfigFileError extends Error {
    stage: ConfigStage;
    issues: ConfigIssue[];
    name: string;
    constructor(stage: ConfigStage, path: string, cause: unknown, issues?: ConfigIssue[]);
}
export declare namespace Include {
    interface Config {
        path: string;
        initial?: any[];
        patches?: PatchOptions[];
        enableLogs?: boolean;
    }
}
export declare class Include extends EntryTree {
    config: Include.Config;
    static inject: string[];
    static readonly [EntryGroup.key] = true;
    filename: string;
    private type;
    /** The last file state we read or wrote. */
    private cache?;
    /** Tree-side changes that have not reached the file yet. */
    private journal;
    /** Where the entries of the applied tree come from. */
    private index?;
    /** Ids we assigned to entries the file leaves anonymous. */
    private anonymous;
    private dirtyRead;
    private dirtyWrite;
    private _draining?;
    /** Only the latest intended tree is ever applied; older ones are skipped. */
    private _pendingTree?;
    private _applyTask?;
    private _disposed;
    private _seq;
    private persistenceError;
    constructor(ctx: Context, config: Include.Config);
    private warn;
    [Service.init](): AsyncGenerator<() => Promise<void>, void, unknown>;
    stop(): Promise<void>;
    /**
     * Resolves once every pending read and write has been processed and the
     * tree reflects the outcome. Retries pending writes and rejects while changes remain unsaved.
     */
    flush(): Promise<void>;
    /** Re-read the file and reconcile the tree with it. */
    refresh(): Promise<void>;
    /** Called synchronously by the loader once a tree-side change is in place. */
    commit(change: EntryChange): void;
    private _drain;
    private _loop;
    private _read;
    private _write;
    /**
     * Write through a temp file and a rename, so that no reader ever sees a
     * truncated file. When `expected` is given, the rename (and every retry of
     * it) only goes ahead while the file still holds that content.
     */
    private _writeText;
    private dump;
    getLocation(id: string, path: PropertyKey[]): SourceLocation | undefined;
    private _locate;
    /**
     * Entries the file leaves anonymous get an id here, before the loader sees
     * them. One that looks exactly like an entry we named on the previous read
     * keeps that id, unless it is already explicitly owned, so editing a
     * neighbor does not restart it; anything else gets a fresh id. Assigned
     * ids stay in memory until the next write.
     */
    private _assignIds;
    private _scheduleApply;
}
export default Include;
//# sourceMappingURL=index.d.ts.map