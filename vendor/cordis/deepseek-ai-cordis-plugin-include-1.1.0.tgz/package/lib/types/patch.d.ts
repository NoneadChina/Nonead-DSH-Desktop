import type { EntryOptions } from '@deepseek-ai/cordis-plugin-loader';
import { type Journal } from './journal.ts';
export interface PatchOptions {
    id?: string;
    insert?: EntryOptions[];
    name?: string;
    config?: any;
    group?: boolean | null;
    disabled?: boolean | null;
    inject?: any;
    intercept?: any;
    isolate?: any;
    [key: string]: any;
}
export type Warn = (format: string, ...args: any[]) => void;
/** Give every entry (nested groups included) an id, in place. */
export declare function ensureIds(entries: EntryOptions[], used: (id: string) => boolean): void;
/** Runtime changes are routed back to an inserted entry by its id, so every insert needs one. */
export declare function ensureInsertIds(patches: PatchOptions[] | undefined, used: (id: string) => boolean): void;
/**
 * Who supplies an entry, or one key of it, in the patched tree: the file, a
 * patch that overrides that key, or the patch the entry is written in.
 */
export type EntryOwner = EntryOwner.File | EntryOwner.Patch | EntryOwner.Embedded;
export declare namespace EntryOwner {
    interface File {
        type: 'file';
    }
    interface Patch {
        type: 'patch';
        /** Index into the patch list. */
        index: number;
    }
    /** An entry written in `patches[index][key]`. */
    interface Embedded {
        type: 'embedded';
        /** Index into the patch list. */
        index: number;
        key: 'insert' | 'config';
    }
}
/** Where every entry and key of a patched tree comes from. */
export declare class PatchIndex {
    private owners;
    private keys;
    constructor(owners: Map<string, EntryOwner.File | EntryOwner.Embedded>, keys: Map<string, Map<string, number>>);
    /** Owner of the entry as a whole. */
    entry(id: string | null): EntryOwner.File | EntryOwner.Embedded;
    /** Owner of one key of an entry. */
    key(id: string, key: string): EntryOwner;
    fileOwned(id: string, key: string | null): boolean;
}
export interface PatchResult {
    data: EntryOptions[];
    index: PatchIndex;
}
/**
 * Overlay `patches` onto a fresh clone of `data`. Entry lists from patches
 * are cloned too, so the tree owns every entry it mounts. The index is built
 * in the same pass, so a patch that does not apply owns nothing.
 */
export declare function applyPatches(data: EntryOptions[], patches: PatchOptions[] | undefined, warn?: Warn): PatchResult;
/**
 * Route a journal to its owners: file-owned changes are applied to `data`,
 * patch-owned ones to `patches`. Both are mutated in place, so pass clones.
 * Returns whether any patch changed.
 */
export declare function routeJournal(journal: Journal, data: EntryOptions[], patches: PatchOptions[], warn: Warn): boolean;
//# sourceMappingURL=patch.d.ts.map