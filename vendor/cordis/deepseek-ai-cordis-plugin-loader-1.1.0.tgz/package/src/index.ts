import { Context, FiberState, Inject, Service, ValidationError, type Fiber } from '@deepseek-ai/cordis'
import { defineProperty, isNullable, type Awaitable, type Dict } from '@deepseek-ai/cosmokit'
import { ModuleLoader } from './internal.ts'
import { Entry, type EntryOptions } from './config/entry.ts'
import { EntryGroup } from './config/group.ts'
import isolate from './config/isolate.ts'
import { EntryTree, type EntryChange } from './config/tree.ts'
import { interpolate } from './config/utils.ts'

/** Re-export entry node APIs. */
export * from './config/entry.ts'
/** Re-export nested entry group APIs. */
export * from './config/group.ts'
/** Re-export service isolation helpers. */
export * from './config/isolate.ts'
/** Re-export entry tree persistence APIs. */
export * from './config/tree.ts'
/** Re-export loader config expression helpers. */
export * from './config/utils.ts'
/** Re-export Node internal module loader compatibility types. */
export * from './internal.ts'

declare module '@deepseek-ai/cordis' {
  interface Events {
    'exit'(signal: NodeJS.Signals): Promise<void>
    'loader/config-update'(): void
    'loader/entry-init'(entry: Entry): void
    'loader/partial-dispose'(entry: Entry, legacy: Partial<EntryOptions>, active: boolean): void
    /**
     * Volatile config values were committed into the running fiber without a remount; dispatched to the owning fiber only.
     * @param paths - changed config paths as key arrays; every value is committed before dispatch.
     * @mode emit
     */
    'loader/volatile-update'(paths: readonly (readonly string[])[]): void
    /**
     * Refresh entry context before applying config.
     * @param entry - entry containing the new raw config and optional current fiber.
     * @param next - continue context refresh and Loader's config update.
     * @mode waterfall
     */
    'loader/patch-context'(entry: Entry, next: () => Awaitable<void>): Awaitable<void>
  }

  interface Context {
    loader: Loader
  }

  interface EnvData {
    startTime?: number
  }

  interface Fiber {
    entry?: Entry
  }
}

/** Loader config and dependency intercept namespace. */
export namespace Loader {
  /** Root loader configuration. */
  export interface Config {
    /** Base URL used to resolve relative plugin specifiers and config paths. */
    baseUrl?: string
  }

  /** Intercept config used when other plugins depend on `loader`. */
  export interface Intercept {
    /** Keep dependent plugins pending while loader entries are still loading. */
    await?: boolean
  }
}

/**
 * Service that owns a loader entry tree and imports configured plugins.
 *
 * Subclasses provide persistence by implementing `commit(change)` on `EntryTree`.
 */
export class Loader extends EntryTree {
  declare [Service.metadata]: Loader.Intercept

  public envData = process.env.CORDIS_SHARED
    ? JSON.parse(process.env.CORDIS_SHARED)
    : { startTime: Date.now() }

  public name = 'loader'
  public internal = ModuleLoader.fromInternal()

  public builtins: Dict<any> = Object.create(null)

  constructor(ctx: Context, public config: Loader.Config = {}) {
    super(ctx)
    if (config.baseUrl) {
      this.ctx.baseUrl = config.baseUrl
    }
    const self = this

    defineProperty(this, Service.tracker, {
      associate: 'loader',
      property: 'ctx',
      noShadow: true,
    })

    ctx.reflect.provide('loader', this, this[Service.check])

    // the source config each entry fiber last resolved
    const sources = new WeakMap<Fiber, any>()

    // Registered before the built-in validation listener, so validation
    // failures can be traced to the config source. A config passed in at
    // runtime is not written anywhere yet, so its failures are left as is.
    ctx.on('internal/config', (fiber, next) => {
      if (!fiber.entry || fiber.parent.fiber?.entry === fiber.entry) return next()
      try {
        return next()
      } catch (error) {
        if (ValidationError.is(error) && sources.get(fiber) === fiber.entry.options.config) {
          fiber.entry.traceValidation(error)
        }
        throw error
      }
    }, { prepend: true })

    // Registered after the built-in validation listener, so interpolation runs
    // on the source config and validation sees the interpolated result.
    ctx.on('internal/config', (fiber, next) => {
      const config = next()
      if (!fiber.entry || fiber.parent.fiber?.entry === fiber.entry) return config
      sources.set(fiber, config)
      // Tree carriers preserve the expressions owned by their child entries.
      if (fiber.runtime?.callback[EntryGroup.key]) return config
      return interpolate(fiber.ctx, config)
    })

    ctx.on('internal/commit', (fiber, config) => {
      if (!fiber.entry || fiber.parent.fiber?.entry === fiber.entry) return
      const schema = fiber.runtime?.Config
      const unparse = schema?.['simplify']
      const { entry } = fiber
      const legacy = { ...entry.options }
      entry.options.config = unparse ? unparse.call(schema, config) : config
      entry.parent.tree.commit({ id: entry.options.id, group: entry.parent, options: entry.options, legacy })
    })

    ctx.on('internal/update', function (config, next) {
      if (!this.entry || this.parent.fiber?.entry === this.entry) return next()
      self.showLog(this.entry, 'reload')
      return next()
    }, { global: true })

    ctx.on('internal/plugin', (fiber) => {
      // 1. set `fiber.entry`
      if (fiber.parent[Entry.key] && !fiber.entry) {
        fiber.entry = fiber.parent[Entry.key]
        // FIXME merge config
        Inject.resolve(fiber.entry!.options.inject, fiber.inject)
      }

      // 2. handle self-dispose
      // We only care about `ctx.fiber.dispose()`, so we need to filter out other cases.

      // case 1: fiber is created
      if (fiber.uid) return

      // case 2: fiber is not tracked by loader
      if (!fiber.entry) return

      // case 3: fiber is a child plugin under the entry (not the entry's root fiber)
      if (fiber.parent.fiber?.entry === fiber.entry) return

      // case 4: fiber is disposed on behalf of plugin deletion (such as plugin hmr)
      // self-dispose: ctx.fiber.dispose() -> fiber / runtime dispose -> delete(plugin)
      // plugin hmr: delete(plugin) -> runtime dispose -> fiber dispose
      if (!ctx.registry.has(fiber.runtime!.callback)) return

      // case 5: the entry's tree is being disposed
      if (!fiber.entry.parent.tree.ctx.fiber.uid) return

      const { entry } = fiber
      this.showLog(entry, 'unload')

      // case 6: the entry's parent is being unloaded, which takes the entry with it
      // (the parent may still be registered, e.g. when it has lost a dependency)
      if (fiber.parent.fiber.state === FiberState.UNLOADING) return

      // case 7: the entry is being removed by the loader (`EntryGroup.remove`
      // unregisters it before disposing the fiber)
      if (entry.parent.tree.store[entry.options.id] !== entry) return

      // case 8: fiber is disposed by loader behavior
      // such as inject checker, config file update, ancestor group disable
      if (entry.disabled) return

      const legacy = { ...entry.options }
      entry.options.disabled = true
      entry.parent.tree.commit({ id: entry.options.id, group: entry.parent, options: entry.options, legacy })
    })

    ctx.plugin(isolate)
  }

  commit(_change: EntryChange) {
    // Loader's root tree is in-memory; commits are no-ops.
  }

  [Service.check]() {
    const config: Loader.Intercept = Service.prototype[Service.resolveIntercept].call(this)
    if (config.await && this.getTasks().length) return false
    return true
  }

  showLog(entry: Entry, type: string) {
    if (entry.options.group || !entry.parent.tree.enableLogs) return
    this.ctx[Context.root].logger?.('loader').info('%s plugin %C', type, entry.options.name)
  }

  /** Return the loader entry id that owns `fiber`, if any. */
  locate(fiber = this.ctx.fiber) {
    while (1) {
      if (fiber.entry) return fiber.entry.id
      const next = fiber.parent.fiber
      if (fiber === next) return
      fiber = next
    }
  }

  /** Hook for hosts that can restart the process on full-reload requests. */
  exit() {
  }

  /** Normalize ESM/CJS/default export shapes before applying a plugin. */
  unwrapExports(exports: any) {
    if (isNullable(exports)) return exports
    exports = exports.default ?? exports
    // https://github.com/evanw/esbuild/issues/2623
    // https://esbuild.github.io/content-types/#default-interop
    if (!exports.__esModule) return exports
    return exports.default ?? exports
  }
}

export default Loader
