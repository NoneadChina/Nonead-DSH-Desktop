import type { Context } from '@deepseek-ai/cordis';
import type { UiRendererService } from './index.ts';
/** Owns the current application root and its document styles. */
export declare class UiRenderer implements UiRendererService {
    private readonly ctx;
    private current;
    private disposed;
    constructor(ctx: Context);
    mount(container: HTMLElement): () => void;
    /** Close the renderer and release its current root and styles. */
    dispose(): void;
    private unmount;
}
//# sourceMappingURL=renderer.d.ts.map