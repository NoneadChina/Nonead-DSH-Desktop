/** @returns the decorative account-menu logout glyph. */
export declare function LogoutIcon(): import("react").JSX.Element;
//# sourceMappingURL=LogoutIcon.d.ts.map