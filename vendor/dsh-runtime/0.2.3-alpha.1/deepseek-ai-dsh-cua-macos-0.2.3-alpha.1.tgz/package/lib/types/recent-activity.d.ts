/** Window-specific input notices for an already scheduled model step. */
import type { Context } from '@deepseek-ai/cordis';
import type { CuaBackend } from '@deepseek-ai/dsh-cua';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /** Activity detected since the Agent last observed a window. */
        'cua-activity': {
            kind: 'cua-activity';
            form: 'notice';
            summary: string;
        };
    }
}
/**
 * Collect recent input on a naturally scheduled model step during the observing turn.
 * @param ctx - macOS provider owning the listeners.
 * @returns Callback for successful window reads on an authorized connection.
 */
export declare function watchWindowActivity(ctx: Context): NonNullable<CuaBackend['windowRead']>;
//# sourceMappingURL=recent-activity.d.ts.map