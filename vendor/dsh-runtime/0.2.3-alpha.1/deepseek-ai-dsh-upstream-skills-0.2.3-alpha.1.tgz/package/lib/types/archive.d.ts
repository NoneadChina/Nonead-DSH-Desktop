/** Download one upstream skill set from a GitHub commit archive: kept files, path checks, the size bound, and the digest. */
import { Readable } from 'node:stream';
import type { UpstreamSkillSelection, UpstreamSkillSet } from './types.ts';
/**
 * Read the kept files of a commit archive whose entries all sit under one top-level directory.
 * @param archive - the gzip tarball.
 * @param selection - which files to keep.
 * @param maxBytes - the most bytes the kept files may hold; reading stops at the entry that exceeds it.
 * @returns the kept files keyed by their path relative to the repository root.
 * @throws when an entry path is empty, `.`, `..`, or holds a backslash (on Windows node-tar has already turned backslashes
 *   into slashes, so the segments they separate are checked instead), entries sit under more than one top-level
 *   directory, a kept path is not a regular file or appears twice, the kept files exceed `maxBytes`, the license file is
 *   missing, or the archive is malformed.
 */
export declare function readArchive(archive: Readable, selection: UpstreamSkillSelection, maxBytes: number): Promise<Map<string, Buffer>>;
/**
 * Digest files by their sorted paths and their contents; the digest covers the files, not the archive bytes, which a
 * host may compress differently.
 * @param files - the files keyed by their path relative to the repository root.
 * @returns the lowercase hexadecimal SHA-256 digest.
 */
export declare function digestFiles(files: ReadonlyMap<string, Uint8Array>): string;
/**
 * Write files under a directory at their repository paths.
 * @param files - the files keyed by their path relative to the repository root.
 * @param into - the existing directory that receives them.
 * @returns after every file is written.
 */
export declare function writeFiles(files: ReadonlyMap<string, Uint8Array>, into: string): Promise<void>;
/**
 * The archive URL of a selection's commit under one download prefix.
 * @param base - the prefix, with or without trailing slashes.
 * @param selection - the repository and commit.
 * @returns `<prefix>/<owner>/<repository>/tar.gz/<commit>`.
 */
export declare function archiveUrl(base: string, selection: UpstreamSkillSelection): string;
/**
 * Download an archive and read its kept files.
 * @param url - the archive URL.
 * @param selection - which files to keep.
 * @param maxBytes - the most bytes the kept files may hold.
 * @param signal - aborts the download.
 * @returns the kept files keyed by their path relative to the repository root.
 * @throws when the response is not successful or has no body, or when {@link readArchive} refuses the archive.
 */
export declare function fetchArchive(url: string, selection: UpstreamSkillSelection, maxBytes: number, signal: AbortSignal): Promise<Map<string, Buffer>>;
/**
 * Download the archive of the pinned commit from the first prefix whose kept files match the pinned size and digest.
 * @param set - the pinned selection.
 * @param urls - archive download prefixes tried in order; each serves `<owner>/<repository>/tar.gz/<commit>`.
 * @param timeoutMs - how long one prefix may take to deliver the whole archive.
 * @param signal - aborts the download without trying the next prefix.
 * @param warn - receives one message and error for each prefix that fails.
 * @returns the verified kept files.
 * @throws the abort reason, or an error naming the set when every prefix fails.
 */
export declare function downloadSkillSet(set: UpstreamSkillSet, urls: readonly string[], timeoutMs: number, signal: AbortSignal, warn: (message: string, error: unknown) => void): Promise<Map<string, Buffer>>;
//# sourceMappingURL=archive.d.ts.map