import type { DshClientModuleManifest } from '@deepseek-ai/dsh-package-manifest';
/**
 * Supply shared third-party identities and package-generated manifests through one protocol.
 * @returns Initial module registrations; JavaScript and metadata factories are not evaluated here.
 */
export declare function getStaticModules(): readonly DshClientModuleManifest[];
//# sourceMappingURL=seed.d.ts.map