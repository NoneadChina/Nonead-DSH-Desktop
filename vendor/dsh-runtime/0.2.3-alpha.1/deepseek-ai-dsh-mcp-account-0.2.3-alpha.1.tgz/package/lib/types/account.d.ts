import type { Context } from '@deepseek-ai/cordis';
import type { ConnectorAccountCopy, ConnectorAccountDisplay, ConnectorAccountSource, ConnectorAccountView, ConnectorOperationId } from '@deepseek-ai/dsh-client-ui-connector-account/types';
import type { McpOAuthAttemptView } from '@deepseek-ai/dsh-mcp-client/types';
import type { McpManagedServerView } from '@deepseek-ai/dsh-mcp-manager/types';
import type { McpAccountCopy } from './types.ts';
/** The page's operations: authorize the server, sign out of it, and restart it. */
export type McpAccountKind = 'connect' | 'sign-out' | 'retry';
/** The phases of an authorization that has not finished. */
type Running = Exclude<McpOAuthAttemptView['phase'], 'authorized' | 'cancelled' | 'failed'>;
/** The server as the manager lists it, absent until the manager lists it; a running authorization is the operation. */
export type McpAccountView = ConnectorAccountView<McpManagedServerView | undefined, McpAccountKind, Running>;
/** Reads one server's account from the MCP manager and runs the page's operations through it. */
export declare class ServerAccount implements ConnectorAccountSource<McpAccountView> {
    private readonly ctx;
    private readonly server;
    /** The latest sign-out or restart the page ran, until the next authorization starts. */
    private finished;
    private readonly listeners;
    /**
     * @param ctx - the context carrying the MCP manager.
     * @param server - the server's name with the manager.
     */
    constructor(ctx: Context, server: string);
    /** @returns the server's view, with a running authorization as the operation and the latest finished operation. */
    snapshot(): McpAccountView;
    /**
     * @param listener - called after each change of the server's status or authorization, and after the page's sign-out
     *   or restart.
     * @returns a disposer that stops the calls.
     */
    observe(listener: () => void): () => void;
    /** The manager publishes every change of the server, so there is nothing to check. */
    refresh(): void;
    /**
     * @param kind - the page operation.
     * @returns the authorization attempt's identity, or a new identity once a sign-out or restart has finished.
     * @throws what the manager throws, such as for a server without OAuth or whose configuration is changing.
     */
    start(kind: McpAccountKind): Promise<ConnectorOperationId>;
    /**
     * @param id - the authorization to cancel; the manager ignores any other identity.
     * @returns after the authorization's work drains.
     */
    cancel(id: ConnectorOperationId): Promise<void>;
    private finish;
}
/**
 * What the section shows for one server: the manager's status and the latest authorization, in the shared copy and the
 * connector's text. A server that needs authorization again shows as disconnected, with the reason in its detail; a
 * connected server can authorize again without signing out first.
 * @param view - the server as the manager lists it.
 * @param copy - the connector's text.
 * @returns the section's display.
 */
export declare function present(view: McpAccountView, copy: McpAccountCopy): ConnectorAccountDisplay;
/**
 * The section's fixed text: the connector's title and activation prompt, under the shared line on where authorization
 * completes.
 * @param copy - the connector's text.
 * @returns the registry's copy.
 */
export declare function sectionCopy(copy: McpAccountCopy): ConnectorAccountCopy;
export {};
//# sourceMappingURL=account.d.ts.map