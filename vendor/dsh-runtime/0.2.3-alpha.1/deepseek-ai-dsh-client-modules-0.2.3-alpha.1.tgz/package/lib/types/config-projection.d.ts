import type { SyncedConfigValues } from '@deepseek-ai/dsh-client-config/types';
/** Schemastery node fields the projection reads; a Schemastery schema satisfies it structurally. */
export interface SchemaNode {
    type: string;
    meta: {
        role?: unknown;
        volatile?: unknown;
    };
    dict?: Record<string, SchemaNode>;
    inner?: SchemaNode;
    list?: SchemaNode[];
}
/**
 * Whether a Config schema declares a top-level volatile field, the only fields synced to the browser.
 * @param schema - the plugin's Host Config schema.
 * @returns true when at least one top-level field is volatile.
 */
export declare function hasSyncedFields(schema: SchemaNode): boolean;
/**
 * Project a running plugin's effective Config onto its browser-synced values.
 * @param schema - the plugin's Host Config schema.
 * @param effective - the fiber's effective Config, whose volatile fields are references.
 * @param id - package name, used in diagnostics.
 * @returns the synced values, or undefined when the schema declares no top-level volatile field.
 * @throws TypeError when a synced value is not lossless JSON.
 */
export declare function syncedValues(schema: SchemaNode, effective: unknown, id: string): SyncedConfigValues | undefined;
//# sourceMappingURL=config-projection.d.ts.map