/** The DingTalk account section the Plugins page shows for each Host view. */
import type { CliAccountText } from '@deepseek-ai/dsh-cli-account/types';
import type { ConnectorAccountCopy, ConnectorAccountDisplay, ConnectorAccountOperation } from '@deepseek-ai/dsh-client-ui-connector-account/types';
import type { DingtalkTextKey } from './locales.ts';
import type { DingtalkOperationKind, DingtalkState } from './types.ts';
type Text = CliAccountText<DingtalkTextKey>;
/** The npm package whose bundle page carries the account section. */
export declare const DINGTALK_PACKAGE = "@deepseek-ai/dsh-dingtalk";
/**
 * List the operations the section's buttons start; signing in and out report a notice in the browser that started them.
 * @param text - writes a key of the DingTalk text in every shipped language.
 * @returns the operations with their notices.
 */
export declare function operations(text: Text): readonly ConnectorAccountOperation<DingtalkOperationKind>[];
/**
 * Write the section's title and hint, and the prompt after the bundle is switched on while signed out.
 * @param text - writes a key of the DingTalk text in every shipped language.
 * @returns the section's fixed text.
 */
export declare function copy(text: Text): ConnectorAccountCopy;
/**
 * The account section for one Host view.
 * @param view - the current dws account, the operation in progress, and the last result.
 * @param text - writes a key of the DingTalk text in every shipped language.
 * @returns the phase, status, tag, buttons, detail, and failure; the Service adds a failed command and its exit code.
 */
export declare function presentAccount(view: DingtalkState, text: Text): ConnectorAccountDisplay;
export {};
//# sourceMappingURL=presentation.d.ts.map