/**
 * Persona prefix and suffix overrides as a composable row.
 *
 * Registers prefix and suffix as ordinary scoped system sections. Disposing
 * the plugin reveals any inherited or earlier same-scope persona definitions.
 * @module @deepseek-ai/dsh-persona
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { PERSONA_PREFIX_SECTION, PERSONA_SUFFIX_SECTION } from '@deepseek-ai/dsh-system-prompt';
export { PERSONA_PREFIX_SECTION, PERSONA_SUFFIX_SECTION };
/** Cordis plugin name. */
export declare const name = "persona";
/** The prompt registry this row contributes to. */
export declare const inject: string[];
/** Plugin config: the persona text this composition contributes. */
export interface Config {
    /**
     * Persona prose rendered as the `deployment:persona-prefix` section. A template:
     * complete `{{…}}` groups interpolate strictly against registered prompt
     * variables. Empty text drops the section at render, matching the registry.
     */
    prefix: string;
    /**
     * Persona suffix template rendered after first-party guidance. Omitted or empty
     * text shadows the deployment suffix away; interpolation is strict.
     */
    suffix?: string;
    /** Make the prefix the complete system prompt, suppressing the suffix and every other section. */
    complete?: boolean;
    /** Suppress dynamic runtime-context snapshots for this persona's agent scope. */
    includeRuntimeContext?: boolean;
}
/** Runtime schema for the persona row. */
export declare const Config: z<Config>;
/**
 * Register persona prefix and suffix overrides in the mounting context.
 * @param ctx - context owning the registrations and their scope visibility.
 * @param config - the prefix, suffix, and complete-prompt policy.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map