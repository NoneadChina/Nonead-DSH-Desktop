/** Visible main-view acknowledgements over Host reading state. */
import type { Context } from '@deepseek-ai/cordis';
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SessionReadModel } from './model.ts';
/**
 * Acknowledge loaded content after a rendering frame in the visible, focused main view.
 * Switching the main view to a Session, including the first selection after a page load, clears that Session's
 * manual reminder once its body arrives; window focus and a replaced binding for the same Session preserve it.
 * Without a document there is no view to acknowledge, so nothing is installed.
 * @param ctx - owning Client plugin Context.
 * @param sessions - Session catalog and binding owner.
 * @param reading - shared Host-confirmed reading state.
 */
export declare function installReadingAcknowledgements(ctx: Context, sessions: Pick<ISessions, 'list' | 'binding'>, reading: Pick<SessionReadModel, 'state' | 'acknowledge'>): void;
//# sourceMappingURL=acknowledge.d.ts.map