/** Host-authoritative Session reading records, kept in memory, and their Remote service. */
import { Context, Service } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { SessionReadAction, SessionReadFrame } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Host owner of the in-memory Session reading records behind the `sessionStatus` Remote namespace. */
        sessionStatus: SessionStatusService;
    }
}
/** Shared owner reading records; no reading operation changes model history. */
export declare class SessionStatusService extends TypertRemoteService {
    static inject: string[];
    private readonly records;
    private closing;
    private readonly followers;
    /** @param ctx - Host services supplying Session events and metadata. */
    constructor(ctx: Context);
    protected [Service.init](): void;
    /**
     * Update one Session; read positions advance only through Client-observed completions.
     * @param sessionId - Session identity.
     * @param action - Explicit reminder change or automatic read-position acknowledgement.
     * @throws RemoteError when closing, the Session is missing, or its metadata cannot be read.
     */
    mark(sessionId: SessionId, action: SessionReadAction): Promise<void>;
    /**
     * Follow accessible reading records; every connection starts with a complete baseline.
     * @param signal - generation cancellation.
     * @returns the baseline and whole-record changes, filtered by Session access.
     * @throws RemoteError when the service is closing.
     */
    follow(signal: AbortSignal): AsyncIterable<SessionReadFrame>;
    private followAccess;
    private assertOpen;
    private complete;
    private view;
    private publish;
    private unavailable;
}
export default SessionStatusService;
//# sourceMappingURL=index.d.ts.map