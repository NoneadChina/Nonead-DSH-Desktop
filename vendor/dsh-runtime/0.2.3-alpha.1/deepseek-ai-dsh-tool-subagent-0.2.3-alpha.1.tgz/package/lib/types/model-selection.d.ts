/** Child LLM route selection for the subagent tool. */
import type { LlmRuntime } from '@deepseek-ai/dsh-llm';
import type { AgentOptions } from '@deepseek-ai/dsh-agent';
import z from '@deepseek-ai/schemastery';
/** One exact child LLM route authorized by a user setting. */
export interface AllowedModelRoute {
    /** Registered LLM provider id. */
    readonly provider: string;
    /** Provider-owned exact model id. */
    readonly model: string;
}
/** Schema shared by the Host setting and its deployment base. */
export declare const AllowedModelRouteSchema: z<AllowedModelRoute>;
/** Exact routes the Host setting currently authorizes. */
export interface ModelSelectionPolicy {
    /** Exact provider/model routes authorized for explicit selection. */
    readonly routes: readonly AllowedModelRoute[];
}
/**
 * Stable identity for one provider/model pair.
 * @param route - Exact provider/model route.
 * @returns Opaque key for equality checks.
 */
export declare function modelRouteKey(route: AllowedModelRoute): string;
/**
 * Reject malformed or duplicate route policy entries at a durable or configuration boundary.
 * @param routes - Candidate exact routes to validate.
 * @returns an assertion that the candidate is a validated exact-route array.
 * @throws {SubagentError} `INVALID_MODEL_SELECTION_SETTINGS` for malformed or repeated routes.
 */
export declare function assertAllowedModelRoutes(routes: unknown): asserts routes is readonly AllowedModelRoute[];
/** Model-facing child LLM route fields. */
export interface DelegationModelRequest {
    readonly provider?: string;
    readonly model?: string;
    readonly reasoning_effort?: string;
}
/**
 * Whether an optional string tool argument carries a value. Some models send
 * `""` for optional fields they leave unset.
 * @param value - Parsed argument value.
 * @returns Whether the value is present and non-empty.
 */
export declare function hasText(value: string | undefined): value is string;
/**
 * Read model-facing route fields from tool arguments, treating an empty string as an omitted field.
 * @param args - Parsed tool arguments carrying the route fields.
 * @returns The non-empty route fields.
 */
export declare function delegationModelRequest(args: DelegationModelRequest): DelegationModelRequest;
/**
 * Whether a call explicitly selects any child LLM value.
 * @param request - Route fields read by {@link delegationModelRequest}.
 * @returns Whether at least one route or effort field is present.
 */
export declare function hasDelegationModelRequest(request: DelegationModelRequest): boolean;
/**
 * Validate explicit selection against the current Host setting and merge it over child defaults.
 * Explicit selection requires both provider and model; an omitted effort then
 * uses the selected model's default, even when the route is unchanged.
 * @param configured - Tool-instance child defaults.
 * @param request - Route fields read by {@link delegationModelRequest}.
 * @param enabled - Whether this tool instance permits model-facing selection.
 * @param policy - Current Host allowlist; omission permits only the current parent route.
 * @param parentOptions - Current parent route used when the Host setting is disabled or absent.
 * @param routeDiscoveryVisible - Whether the caller can call `list_subagent_models`; rejections then point to it.
 * @returns Child Agent options, preserving omission when no layer contributes one.
 * @throws {SubagentError} `MODEL_SELECTION_DISABLED` when this tool instance
 *   forbids selection, or `MODEL_ROUTE_NOT_ALLOWED` when the allowlist excludes the route.
 * @throws {ToolArgsError} when `provider` and `model` are not supplied together.
 */
export declare function requestedAgentOptions(configured: AgentOptions | undefined, request: DelegationModelRequest, enabled: boolean, policy: ModelSelectionPolicy | undefined, parentOptions: AgentOptions, routeDiscoveryVisible: boolean): AgentOptions | undefined;
/**
 * Enforce Host authorization for a complete, explicitly selected child route.
 * @param policy - Current Host allowlist; omission permits only the current parent route.
 * @param parentOptions - Current parent route used when the Host setting is disabled or absent.
 * @param route - Validated provider/model pair from the tool call.
 * @param routeDiscoveryVisible - Whether the caller can call `list_subagent_models`; the rejection then points to it.
 * @throws {SubagentError} `MODEL_ROUTE_NOT_ALLOWED` when the allowlist excludes the route.
 */
export declare function assertAllowedModelSelection(policy: ModelSelectionPolicy | undefined, parentOptions: AgentOptions, route: AllowedModelRoute, routeDiscoveryVisible: boolean): void;
/**
 * Whether configured Agent options require route validation before delegation.
 * @param options - Tool-instance child defaults.
 * @returns Whether configured provider, model, or effort values must be resolved.
 */
export declare function hasConfiguredLlmSelection(options: AgentOptions | undefined): boolean;
/**
 * Resolve an effective child route through its live adapter before the child is
 * created. The LLM runtime owns provider lookup, exact-model metadata, effort
 * validation, and adapter defaults.
 * @param llm - Live LLM runtime.
 * @param parentOptions - Current parent values whose compatible fields the child inherits.
 * @param requested - Per-child options after request/config merging.
 * @param signal - Tool-call cancellation signal.
 * @param inheritParentReasoningEffort - Whether an omitted effort may inherit from the parent route; false for explicit model selection.
 */
export declare function preflightChildLlmRoute(llm: LlmRuntime, parentOptions: AgentOptions, requested: AgentOptions | undefined, signal: AbortSignal, inheritParentReasoningEffort?: boolean): Promise<void>;
//# sourceMappingURL=model-selection.d.ts.map