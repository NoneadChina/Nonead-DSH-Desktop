/** Host-owned opt-in setting for model-selectable subagent delegation. */
import type { Volatile } from '@deepseek-ai/cordis';
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import './model-selection-state.ts';
import { type AllowedModelRoute } from './model-selection.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** User preference read for explicit child route selection and route discovery. */
        subagentModelSelection: SubagentModelSelectionConfig;
    }
}
/** Optional deployment base for the preference; the shipped composition defaults it off. */
export interface Config {
    /** Whether Agents may select a child route from `allowedModels`; inherited when the user document does not override it. */
    enabled: Volatile<boolean>;
    /** Initial route list inherited when the user document does not override it. */
    allowedModels: Volatile<AllowedModelRoute[]>;
}
/** Host settings owner whose current value authorizes explicit child routes in every Session. */
export declare class SubagentModelSelectionConfig extends Service {
    private config;
    static Config: z<Schemastery.ObjectS<NoInfer<{
        enabled: z<boolean, boolean, "volatile-defined">;
        allowedModels: z<NoInfer<AllowedModelRoute[]>, NoInfer<AllowedModelRoute[]>, "volatile-defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        enabled: z<boolean, boolean, "volatile-defined">;
        allowedModels: z<NoInfer<AllowedModelRoute[]>, NoInfer<AllowedModelRoute[]>, "volatile-defined">;
    }>>, "plain">;
    constructor(ctx: Context, config: Config);
    /**
     * Read the routes the setting currently authorizes. Each call samples the
     * live setting, so an edit applies to the next delegation in every Session.
     * @returns a detached route list, or undefined when the setting is disabled.
     * @throws {SubagentError} `INVALID_MODEL_SELECTION_SETTINGS` when the enabled setting has no route,
     *   or its routes are malformed or repeated. Disabled settings do not read or validate routes.
     */
    allowedRoutes(): AllowedModelRoute[] | undefined;
}
export declare const name = "subagent-model-selection-settings";
export default SubagentModelSelectionConfig;
//# sourceMappingURL=model-selection-settings.d.ts.map