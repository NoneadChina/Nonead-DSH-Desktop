/** Model-facing discovery of LLM routes available to child Agents. */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Register discovery of the child models the Host setting authorizes.
 * @param ctx - Context carrying the tool registry, LLM service, and optional Host model-selection setting.
 */
export declare function registerListSubagentModels(ctx: Context): void;
//# sourceMappingURL=list-models.d.ts.map