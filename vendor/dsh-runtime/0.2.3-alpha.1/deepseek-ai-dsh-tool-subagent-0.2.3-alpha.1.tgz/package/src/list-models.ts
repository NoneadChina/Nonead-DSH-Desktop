/** Model-facing discovery of LLM routes available to child Agents. */

import type { Context } from '@deepseek-ai/cordis'
import type LlmRuntime from '@deepseek-ai/dsh-llm'
import type { LlmProviderInfo } from '@deepseek-ai/dsh-llm'
import { defineTool, ToolArgsError, ToolContextUnavailableError } from '@deepseek-ai/dsh-tools'
import { parentAgentOptionsForDelegation, SubagentError } from '@deepseek-ai/dsh-subagent'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { ModelSelectionPolicy } from './model-selection.ts'
import type {} from './model-selection-settings.ts'
import { hasText } from './model-selection.ts'

interface ListSubagentModelsRequest {
  readonly provider?: string
  readonly model?: string
}

/** Resolve one registered provider with a model-correctable diagnostic. */
function registeredProvider(
  llm: LlmRuntime,
  policy: ModelSelectionPolicy,
  providerId: string,
): LlmProviderInfo {
  const providers = llm.listProviders()
  const provider = providers.find(candidate => candidate.id === providerId)
  if (provider !== undefined) return provider
  const available = providers
    .filter(candidate => policy.routes.some(route => route.provider === candidate.id))
    .map(candidate => candidate.id)
    .join(', ') || '(none)'
  throw new SubagentError(`LLM provider "${providerId}" is not registered; available providers: ${available}`, 'LLM_PROVIDER_NOT_FOUND')
}

/** Render one advertised or resolved model. */
function modelLine(provider: string, model: { id: string; name: string; description?: string }): string {
  return `${provider}/${model.id} — ${model.name}${model.description === undefined ? '' : `: ${model.description}`}`
}

/** Read the requested provider, allowed models, or exact-model efforts. */
async function listSubagentModels(
  ctx: Context,
  request: ListSubagentModelsRequest,
  exec: ToolRunContext,
): Promise<string> {
  if (exec.agent === undefined) throw new ToolContextUnavailableError('list_subagent_models requires a calling agent')
  const routes = ctx.get('subagentModelSelection')?.allowedRoutes()
  let policy = routes === undefined ? undefined : { routes }
  const selectionEnabled = policy !== undefined
  if (policy === undefined) {
    const { provider, model } = parentAgentOptionsForDelegation(exec.agent)
    if (provider === undefined || model === undefined) {
      throw new ToolContextUnavailableError('cannot discover child LLM routes without a parent provider and model')
    }
    policy = { routes: [{ provider, model }] }
  }
  const { signal } = exec
  const llm = ctx.get('llm')
  if (llm === undefined) {
    throw new ToolContextUnavailableError('cannot discover child LLM routes because the `llm` service is unavailable')
  }
  if (request.model !== undefined && request.provider === undefined) {
    throw new ToolArgsError(['`model` requires `provider`'])
  }
  if (request.provider === undefined) {
    const providers = llm.listProviders()
      .filter(provider => policy.routes.some(route => route.provider === provider.id))
    return providers.length === 0
      ? '(no LLM providers)'
      : providers.map(provider => `${provider.id} — ${provider.name}`).join('\n')
  }
  const allowedRoutes = policy.routes.filter(route => route.provider === request.provider)
  const [firstRoute] = allowedRoutes
  if (firstRoute === undefined) {
    throw new SubagentError(`LLM provider "${request.provider}" is not allowed by the current subagent model selection setting`, 'MODEL_ROUTE_NOT_ALLOWED')
  }
  const provider = registeredProvider(llm, policy, request.provider)
  if (request.model === undefined) {
    const models = selectionEnabled
      ? (await llm.listModels(provider.id)).filter(model => allowedRoutes.some(route => route.model === model.id))
      : [await llm.resolveModelInfo(provider.id, firstRoute.model, signal)]
    signal.throwIfAborted()
    return models.length === 0
      ? `(no advertised models for ${provider.id})`
      : models.map(model => modelLine(provider.id, model)).join('\n')
  }
  if (!allowedRoutes.some(route => route.model === request.model)) {
    throw new SubagentError(`child LLM route "${provider.id}/${request.model}" is not allowed by the current subagent model selection setting`, 'MODEL_ROUTE_NOT_ALLOWED')
  }
  const model = await llm.resolveModelInfo(provider.id, request.model, signal)
  const efforts = model.reasoning?.efforts.map(effort => (
    `${effort.id}${model.reasoning?.defaultEffort === effort.id ? ' (default)' : ''} — ${effort.name}`
    + (effort.description === undefined ? '' : `: ${effort.description}`)
  )).join('\n') || '(no advertised reasoning efforts)'
  return `${modelLine(provider.id, model)}\nReasoning efforts:\n${efforts}`
}

/**
 * Register discovery of the child models the Host setting authorizes.
 * @param ctx - Context carrying the tool registry, LLM service, and optional Host model-selection setting.
 */
export function registerListSubagentModels(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'list_subagent_models',
    description:
      'Inspect the routes available for explicit subagent model selection. No arguments: authorized providers. '
      + '`provider`: that provider\'s authorized models. `provider` + `model`: that model and its reasoning efforts.',
    parameters: {
      provider: {
        type: 'string',
        description: 'Provider id from the no-argument listing.',
      },
      model: {
        type: 'string',
        description: 'Exact model id; requires provider.',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, result) => [{ type: 'text', text: result }],
    },
    // Route and model metadata reads do not mutate parent-agent state.
    isConcurrencySafe: () => true,
    execute(args, exec) {
      return listSubagentModels(ctx, {
        ...hasText(args.provider) ? { provider: args.provider } : {},
        ...hasText(args.model) ? { model: args.model } : {},
      }, exec)
    },
  }))
}
