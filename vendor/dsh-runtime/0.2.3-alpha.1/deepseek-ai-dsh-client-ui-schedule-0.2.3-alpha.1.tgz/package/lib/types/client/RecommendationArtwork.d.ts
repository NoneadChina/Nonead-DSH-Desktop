/**
 * Tile glyphs for recommended tasks: a 20px grid drawn 1:1 at 20px with 1.25px
 * `currentColor` strokes, the shared icons' Regular weight (one unit on their
 * 16-unit grid) at this size, with round caps and round joins. Each glyph marks
 * its main shape with `data-fill`; the page stylesheet supplies that fill color.
 */
import type { ReactNode } from 'react';
/** Props every tile glyph accepts. */
export interface TileGlyphProps {
    readonly className?: string | undefined;
}
/**
 * Half sun over a horizon: a morning brief.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function SunriseGlyph(props: TileGlyphProps): ReactNode;
/**
 * Calendar page with a check: a week in review.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function CalendarCheckGlyph(props: TileGlyphProps): ReactNode;
/**
 * Open-issue mark: a ring with a center dot.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function IssueGlyph(props: TileGlyphProps): ReactNode;
/**
 * Puzzle piece with a check: plugins that still fit.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function PluginCheckGlyph(props: TileGlyphProps): ReactNode;
/**
 * Newspaper page: an image block, short headlines and a body line.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function NewspaperGlyph(props: TileGlyphProps): ReactNode;
/**
 * Branch: a trunk with a side branch joining it.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function BranchGlyph(props: TileGlyphProps): ReactNode;
/**
 * Sun partly behind a cloud: weather.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function CloudSunGlyph(props: TileGlyphProps): ReactNode;
/**
 * Dumbbell: a bar between two plates and two collars.
 * @param props - class of the root SVG.
 * @returns the glyph.
 */
export declare function DumbbellGlyph(props: TileGlyphProps): ReactNode;
//# sourceMappingURL=RecommendationArtwork.d.ts.map