/** This page's client plugin synchronization: an ongoing line while it runs, and the failures with a retry. */
import type { ReactNode } from 'react';
import type { ClientEntryState } from '@deepseek-ai/dsh-client-modules/client';
import type { Translate } from './presentation.ts';
/**
 * Show what the page's module system reports; it is independent of the Host's bundle list.
 * @param props - the latest synchronization state, the page copy, and the retry.
 * @returns the status line, the failure notice, both, or nothing.
 */
export declare function ClientSyncNotice({ sync, t, retry }: {
    readonly sync: ClientEntryState;
    readonly t: Translate;
    readonly retry: () => void;
}): ReactNode;
//# sourceMappingURL=ClientSyncNotice.d.ts.map