/**
 * Global plugin management: grouped cards for official configuration and
 * optional bundles, the Installed group's cards for the profile's bundles,
 * their row switches, the install dialog with its guide and folded pnpm
 * output, the uninstall confirmation, and the toasts an action's outcome
 * becomes. A bundle's page lists the rows it contributes as the Host runs
 * them; a plugin's configuration renders on its own page through the slots
 * the page declares.
 */
import { type ReactNode } from 'react';
import type { ClientEntryState } from '@deepseek-ai/dsh-client-modules/client';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsLocale, PropsRenderFactories, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createNavigationStore } from './navigation-store.ts';
import type { PluginHeaderLayoutFace } from './header-scroll.ts';
import { type PluginManagerFace } from './manager-store.ts';
/** Full component props assembled by the main slot renderer. */
export type PluginManagerPageProps = PropsRuntime<'main'> & PropsLocale<'pluginManager'> & PropsRenderSlots<'plugins.item' | 'plugins.bundle.config' | 'plugins.row.config' | 'plugins.bundle.activation' | 'plugins.add.actions' | 'plugins.tab' | 'plugins.detail.actions' | 'plugins.detail.badge' | 'plugins.detail.section'> & PropsRenderFactories & InjectFace<PluginManagerFace & PluginHeaderLayoutFace> & InjectFace<ClientSyncFace> & PropsStore<ReturnType<typeof createNavigationStore>>;
/** This page's client plugin synchronization, read from the page's module system. */
export interface ClientSyncFace {
    readonly hooks: {
        readonly clientSync: ObservableSnapshot<ClientEntryState>;
    };
    /** Retry the latest client graph without changing the Host composition. */
    readonly retryClient: () => void;
}
/** Render the plugin manager: the official plugins and installed bundles, their pages, the install dialog, and the confirmation. */
export declare function PluginManagerPage(props: PluginManagerPageProps): ReactNode;
//# sourceMappingURL=PluginManagerPage.d.ts.map