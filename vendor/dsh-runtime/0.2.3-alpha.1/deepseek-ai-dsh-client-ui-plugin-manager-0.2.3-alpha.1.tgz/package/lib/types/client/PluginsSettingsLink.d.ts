/** The Settings navigation entry that leaves Settings for the Plugins page. */
import { type ReactNode } from 'react';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** What the entry receives from the plugin manager. */
export interface PluginsSettingsLinkInjected {
    /** Show the Plugins page's main list. */
    readonly openPlugins: () => void;
}
/** Full component props assembled by the settings shell. */
export type PluginsSettingsLinkProps = PropsRuntime<'settings.section'> & InjectFace<PluginsSettingsLinkInjected>;
/**
 * Selecting the entry closes Settings and opens the Plugins page; the entry has no page of its own.
 * @param props - the shell's close action and the injected navigation.
 * @returns nothing; the entry renders no content.
 */
export declare function PluginsSettingsLink({ close, openPlugins }: PluginsSettingsLinkProps): ReactNode;
//# sourceMappingURL=PluginsSettingsLink.d.ts.map