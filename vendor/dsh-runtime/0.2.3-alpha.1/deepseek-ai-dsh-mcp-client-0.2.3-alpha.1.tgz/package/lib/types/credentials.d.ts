/** Runtime template resolution and secret redaction for one MCP instance. */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './index.ts';
/**
 * The transport strings that may carry `${credential:…}` tokens, with their configuration paths.
 * @param config - server configuration.
 * @returns each templated value with its path relative to the configuration.
 */
export declare function templatedFields(config: Config): Array<[value: string, field: string]>;
/** Resolves raw configuration through the current credential provider and redacts every secret the instance sent. */
export declare class McpTemplateBinding<T extends Config = Config> {
    private readonly ctx;
    private readonly config;
    /** Enabled credential references from raw configuration, including currently unconfigured references. */
    readonly refs: ReadonlySet<string>;
    /** Resolved values and their URL-encoded forms, retained for the instance lifetime. */
    private readonly secrets;
    constructor(ctx: Context, config: T);
    /**
     * Retain a secret obtained outside template resolution, such as an OAuth access token.
     * @param value - secret sent by this instance; empty or absent values are ignored.
     * @returns the same value, for use inline.
     */
    remember<V extends string | undefined>(value: V): V;
    /** Whether this instance sends secrets: templates are expanded or OAuth is configured. */
    get redacting(): boolean;
    /**
     * Replace every secret this binding resolved or remembered, including earlier rotations.
     * @param text - diagnostic or upstream text.
     * @returns the text with those secrets replaced by `[redacted]`.
     */
    redact(text: string): string;
    /**
     * Format a failure, naming the operation and redacting secrets when templates or OAuth are enabled.
     * @param error - caught operation failure.
     * @param operation - local operation name for the diagnostic.
     * @returns diagnostic text safe for the configured template mode.
     */
    diagnostic(error: unknown, operation: string): string;
    /**
     * Resolve transport strings without changing the plugin's raw configuration.
     * @param signal - cancellation checked before and after template resolution.
     * @returns resolved transport configuration, or the raw configuration when expansion is disabled.
     * @throws when a credential or the credentials provider is unavailable.
     */
    resolve(signal: AbortSignal): Promise<T>;
}
//# sourceMappingURL=credentials.d.ts.map