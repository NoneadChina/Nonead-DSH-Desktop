/**
 * Publish connection-owned MCP resources, literal server instructions, and an
 * on-demand server's tool catalog.
 *
 * @module @deepseek-ai/dsh-mcp-client
 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpResourceProvider } from '@deepseek-ai/dsh-mcp-resources';
import type { ScopeKey } from '@deepseek-ai/dsh-scope';
/** Connection-owned values used by the resource and prompt consumers. */
export interface ServerContext {
    /** Resource access through the current connection generation. */
    resources: McpResourceProvider;
    /**
     * Read the last successfully connected server's attributed instructions.
     * @returns literal prompt text, or an empty string when no server instructions are active.
     */
    instructions(): string;
    /**
     * Render an on-demand server's tool catalog for one prompt assembly.
     * @param scope - the assembling agent, or undefined for the global view.
     * @returns literal prompt text, or an empty string when the scope has nothing to load.
     */
    catalog?: (scope: ScopeKey | undefined) => string;
}
/**
 * Contribute server context to the services enabled by this composition.
 * @param ctx - server plugin's registration scope and effect owner.
 * @param server - configured server identity.
 * @param connection - live resource operations, successful instruction snapshot, and an on-demand server's tool catalog.
 */
export declare function registerServerContext(ctx: Context, server: string, connection: ServerContext): void;
//# sourceMappingURL=server-context.d.ts.map