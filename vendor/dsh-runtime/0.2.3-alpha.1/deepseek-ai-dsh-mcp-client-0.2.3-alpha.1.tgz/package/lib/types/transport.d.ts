/**
 * Transport factory: creates the appropriate MCP transport based on the
 * plugin's resolved config. Stdio spawns a child process (with credential
 * scrubbing); Streamable HTTP connects to a URL.
 *
 * @module
 */
import type { AuthProvider, FetchLike, Transport } from '@modelcontextprotocol/client';
import type { Config } from './index.ts';
/**
 * Create an MCP transport from the resolved plugin config.
 *
 * @param config - Resolved plugin config discriminated on `transport`.
 * @param fetch - optional OAuth request wrapper that binds each request to the active grant.
 * @param authProvider - optional passive OAuth token and refresh callbacks.
 * @returns an unstarted MCP transport (stdio or Streamable HTTP).
 */
export declare function createTransport(config: Config, fetch?: FetchLike, authProvider?: AuthProvider): Transport;
//# sourceMappingURL=transport.d.ts.map