/**
 * On-demand tool loading for one MCP server: the server's tools stay out of the
 * tool registry, a system prompt section lists them, and the server's loader
 * tool registers the selected ones in the calling agent's own scope.
 *
 * @module
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ScopeKey } from '@deepseek-ai/dsh-scope';
import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
/** Raw name of the loader tool inside the server's `mcp__<serverName>__` namespace. */
export declare const LOADER_RAW_NAME = "load_tools";
/**
 * Owns one on-demand server's loader tool, its prompt catalog, and each agent's
 * loaded tools. A published generation registers the loader and re-registers
 * every agent's loaded tools that the generation still offers.
 */
export declare class McpToolLoader {
    private readonly ctx;
    private readonly serverName;
    private readonly descriptionMaxLength;
    /** Model-facing name of this server's loader tool. */
    readonly name: string;
    private readonly tool;
    /** The published generation's tools by raw name; empty while none is published. */
    private offered;
    private readonly loads;
    /**
     * Define the loader and release each agent's loaded tools with the agent.
     * @param ctx - the server plugin's context; it owns the loader and the agents' scopes.
     * @param serverName - the server's tool namespace.
     * @param descriptionMaxLength - maximum characters of each tool's catalog summary.
     */
    constructor(ctx: Context, serverName: string, descriptionMaxLength: number);
    /** Number of tools the published generation offers. */
    get size(): number;
    /**
     * Publish one generation: register the loader, then re-register each agent's loaded tools the generation still offers.
     * @param tools - the generation's tool definitions by raw name, without a tool named like the loader.
     * @returns the withdrawal, which unregisters the loader and the loaded tools while keeping the loaded names for the next generation.
     * @throws when the loader name is already registered; nothing is published then.
     */
    publish(tools: ReadonlyMap<string, ToolDefinition>): () => void;
    /**
     * Render the system prompt catalog for one assembly.
     * @param scope - the assembling agent, or undefined for the global view.
     * @returns the catalog, or an empty string when no generation is published or the scope cannot see the loader.
     */
    catalog(scope: ScopeKey | undefined): string;
    /** First description line with whitespace collapsed, capped at the configured length. */
    private summary;
    /** Validate every requested name before registering any in the agent's own scope. */
    private load;
    /** Register one loaded tool for one agent; a failure drops only that tool for that agent. */
    private register;
}
//# sourceMappingURL=tool-loading.d.ts.map