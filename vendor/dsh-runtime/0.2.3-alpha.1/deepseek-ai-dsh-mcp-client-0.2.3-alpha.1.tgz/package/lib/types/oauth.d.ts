import type { Context } from '@deepseek-ai/cordis';
import type { StreamableHttpConfig } from './index.ts';
import type { McpOAuthConfig } from './oauth-options.ts';
import type { McpCloseResult, McpOAuthAttemptId, McpOAuthAttemptView } from './types.ts';
/** Reuses registration, retains the active grant until commit, and drains cancelled attempts before retry. */
export declare class McpOAuthAuthorization {
    private readonly ctx;
    private readonly config;
    private readonly changed;
    private readonly credentials;
    /** Resolves templates and redacts every resolved or received secret from failure logs for the owner lifetime. */
    private readonly binding;
    private attempt;
    private closed;
    constructor(ctx: Context, config: StreamableHttpConfig & {
        oauth: McpOAuthConfig;
    }, changed: () => void);
    /**
     * Read authorization progress without starting a flow.
     * @returns a detached view, or undefined before the first attempt.
     */
    current(): McpOAuthAttemptView | undefined;
    /**
     * Start explicit authorization or return the active attempt, requiring Authorization and WebServer.
     * Waiting for previous cleanup is bounded by closeTimeoutMs.
     * @returns the attempt view; retired owners reject, and previous cleanup rejects with `MCP OAuth cleanup failed`
     * when it fails or `MCP OAuth cleanup did not settle` when closeTimeoutMs elapses first.
     */
    start(): Promise<McpOAuthAttemptView>;
    /** Reject new starts immediately, including retries waiting for previous cleanup, and withdraw active work. */
    retire(): void;
    /**
     * Cancel a matching attempt and await cleanup; a commit already admitted by Authorization completes.
     * Cleanup rejects with `MCP OAuth cleanup failed` when it fails or `MCP OAuth cleanup did not settle` when closeTimeoutMs elapses first.
     * @param id - selected attempt; stale ids have no effect on later attempts.
     */
    cancel(id: McpOAuthAttemptId): Promise<void>;
    /**
     * Retire the owner and await its callback, flow, and request cleanup within closeTimeoutMs.
     * @returns confirmed closure, since the owner holds no transport, with `cleanupError` set to
     * `MCP OAuth cleanup failed` when cleanup settles with a failure or to `MCP OAuth cleanup did not settle`
     * when closeTimeoutMs elapses first.
     */
    dispose(): Promise<McpCloseResult>;
    private update;
    /**
     * Replace a failure with its safe attempt text, logging the redacted cause whenever that text omits it.
     * @param error - attempt failure from the flow or the Authorization service.
     * @returns the fixed or local message the attempt view may expose.
     */
    private safeFailure;
    private run;
}
//# sourceMappingURL=oauth.d.ts.map