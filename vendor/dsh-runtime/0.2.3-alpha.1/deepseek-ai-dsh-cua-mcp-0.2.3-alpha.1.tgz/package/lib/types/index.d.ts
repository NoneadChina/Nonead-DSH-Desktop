import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { ConsentMode } from './consent.ts';
/** Cordis frontend identity. */
export declare const name = "cua-mcp";
/** Launcher facts and the Agent, preset, tool, prompt, and attachment services a served connection uses. */
export declare const inject: string[];
/** Connection policy configurable from the profile patch. */
export interface Config {
    /**
     * Who grants application and pointer consent for the connection's Agent: `allow` grants every request for
     * this session without a human; `elicit` forwards each request to the MCP client as a form elicitation.
     */
    consent: ConsentMode;
    /**
     * Absolute directory the connection's Agent works in: its programs start there, and it is their
     * `workspace-write` root. Startup creates it when missing; a relative path or a directory that cannot be
     * created is reported on stderr and ends the process with exit code 1.
     */
    workspace: string;
}
/** Validate the consent mode and require a workspace; the bundle patch maps `DSH_CUA_CONSENT` and `DSH_CUA_WORKSPACE` onto them. */
export declare const Config: Schema<Partial<Config>, Config>;
/**
 * Accept the profile invocation and, once the launcher commits readiness, create the workspace and serve MCP over
 * stdio; help exits before anything starts. A startup failure, including a relative workspace path or a workspace
 * directory that cannot be created, is reported on stderr and ends the process with exit code 1. Stdin EOF ends the
 * process through the launcher's bounded shutdown.
 * @param ctx - Profile context carrying the command line, readiness, exit request, and profile identity.
 * @param config - Validated consent mode and workspace directory.
 * @throws Error when the plugin runs outside the dsh profile launcher.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map