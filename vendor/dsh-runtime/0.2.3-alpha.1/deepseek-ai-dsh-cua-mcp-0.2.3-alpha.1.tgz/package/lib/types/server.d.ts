import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { Server } from '@modelcontextprotocol/server';
import { type ConsentMode } from './consent.ts';
/** Connection policy and lifetime. */
export interface CuaMcpServerOptions {
    /** Who decides application and pointer consent for the connection's Agent. */
    readonly consent: ConsentMode;
    /** Absolute working directory recorded on the connection's Session. */
    readonly cwd: string;
    /** Server lifetime; abort cancels every in-flight program before disposal. */
    readonly signal: AbortSignal;
}
/** The protocol server, the Agent it serves, and the disposer that releases both. */
export interface CuaMcpServer {
    /** Low-level protocol server, not yet connected to a transport. */
    readonly server: Server;
    /** The connection's Agent: owner of the program environment, native connection, and session grants. */
    readonly agent: Agent;
    /**
     * Close the protocol connection, let a reset in progress and in-flight calls settle, and dispose the
     * connection's Agent, which releases its program environment, native connections, and session-scoped
     * application grants.
     * @returns After the Agent and its retained resources are released.
     */
    dispose(): Promise<void>;
}
/**
 * Create the MCP server for one stdio connection. The connection's Agent is created first, mounts the profile's
 * default preset, and lives until disposal; the provider registers `cua_run_code` for it, and each `tools/list`
 * re-reads that registration beside the two tools defined here. A call names a listed tool or fails as an unknown
 * tool before it reaches the executor, so a tool another row registers for the Agent is never callable without
 * being listed. `cua_get_api_reference` returns the provider's `cua` guidance for the Agent and keeps no state.
 * `cua_run_code` calls pass their arguments to the ordinary tool executor unchanged, one at a time in arrival
 * order, each as the Agent's maintenance activity: argument validation is answered by DSH, and disposing the Agent
 * cancels the running call and waits for it to settle. `cua_reset` bypasses the queue: it cancels the running program,
 * releases the Agent's program environment through `ctx.cuaPrograms`, answers after the cancelled program has settled,
 * and holds back programs that arrive meanwhile; the Agent, its native connection, and its application grants stay,
 * and the next program starts a fresh process. Concurrent resets share one release.
 * Consent questions of that Agent are answered by the configured mode. A call the executor cannot settle,
 * including a cancelled one, fails as a protocol error.
 * @param ctx - Profile context with Agents, presets, tools, the system prompt, and the attachment store.
 * @param options - Consent mode, working directory, and lifetime.
 * @returns The protocol server, not yet connected to a transport, its Agent, and its disposer.
 * @throws Error when the Agent cannot be created; nothing is served then.
 */
export declare function createCuaMcpServer(ctx: Context, options: CuaMcpServerOptions): Promise<CuaMcpServer>;
//# sourceMappingURL=server.d.ts.map