/**
 * The directory one Session works in, as the Client knows it: the projected
 * `workingDirectory`. Pure reads with type-only imports, so client plugins
 * inline this module instead of requesting a module-table row this package
 * does not publish.
 * @module @deepseek-ai/dsh-api-session-controller/client/directories
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ISessions } from '../contract/sessions.ts';
import type { SessionListState } from './service.ts';
/**
 * Select a Session's directory from a list snapshot, for `useSessions` selectors. File views, address
 * bases, and relative paths all use it; the header directory stays the original project.
 * @param state - the sessions list snapshot.
 * @param sessionId - the Session whose directory is selected.
 * @returns the projected `workingDirectory`, else the header directory, else undefined for an unknown row.
 */
export declare function selectSessionDirectory(state: SessionListState, sessionId: SessionId): string | undefined;
/**
 * Read a Session's directory at gesture time: the connected Session's projection face first, then the list snapshot.
 * @param sessions - the sessions service.
 * @param sessionId - the Session whose directory is read.
 * @returns the directory, or undefined when unknown.
 */
export declare function sessionDirectory(sessions: ISessions, sessionId: SessionId): string | undefined;
//# sourceMappingURL=directories.d.ts.map