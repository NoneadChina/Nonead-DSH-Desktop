/** Per-generation reference counts: sources, owner-declared facets, and the event connection. */
import type { SessionRetainInfo, SessionRetainOptions } from '../contract/sessions.ts';
import type { SessionReferenceSource, SessionRetainFacet } from '../index.ts';
/**
 * The facet keys a retain request sets to `true`.
 * @param facets - the request's facet record.
 * @returns the facets one reference retains for its lifetime.
 */
export declare function heldFacets(facets: SessionRetainOptions['facets']): readonly SessionRetainFacet[];
/** What one reference counts while it lives. */
export interface RetainedUse {
    readonly source: SessionReferenceSource;
    readonly facets: readonly SessionRetainFacet[];
    readonly connected: boolean;
}
/** Retain info of a generation that no reference holds. */
export declare const EMPTY_RETAIN_INFO: SessionRetainInfo;
/**
 * Count one reference in or out of a generation's retain info.
 * @param info - the generation's current retain info.
 * @param use - what the retained or released reference counts.
 * @param delta - `1` when the reference is retained, `-1` when it is released.
 * @returns the frozen next retain info; {@link EMPTY_RETAIN_INFO} once no reference remains.
 */
export declare function shiftRetention(info: SessionRetainInfo, use: RetainedUse, delta: 1 | -1): SessionRetainInfo;
//# sourceMappingURL=facets.d.ts.map