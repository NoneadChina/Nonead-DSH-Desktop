/**
 * The `session` resource kind's default identity extraction: the Session one
 * Remote call names, read from its validated wire arguments.
 * @module @deepseek-ai/dsh-api-session-controller/session-resource
 */
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { TypertResourceResolveInput } from '@deepseek-ai/dsh-typert-protocol';
/**
 * Extract the Session resource from an ID or a history address.
 *
 * Registers as the `session` kind default, so it applies to every Remote method of
 * every namespace: a top-level `sessionId` parameter, otherwise the first object
 * parameter carrying `sessionId` or an `address`. A new request type whose first
 * object parameter has an unrelated `address` field would be read as an address.
 * @param input - validated wire arguments and their ordered parameter descriptions.
 * @returns the named Session identity, otherwise the first object's Session identity or history address.
 * @throws Error when the request object supplies both sessionId and address.
 */
export declare function resolveSessionResource(input: TypertResourceResolveInput): SessionId | undefined;
//# sourceMappingURL=session-resource.d.ts.map