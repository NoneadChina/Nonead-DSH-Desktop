/** Binds change requests to the Session that created, pushed, or tracked them, and watches the bound ones. */

import { Context, FiberState, Service } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { changeRequestKey } from '@deepseek-ai/dsh-experimental-forge'
import type { ChangeRequestKey, ChangeRequestRef, ChangeRequestWatchOptions, ForgeRepository } from '@deepseek-ai/dsh-experimental-forge'
import { appendPluginRecord, pluginRecordOf } from '@deepseek-ai/dsh-session'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import type { ProjectionHandle } from '@deepseek-ai/dsh-session-projection'
import { deadline, MAX_TIMER_DELAY_MS } from '@deepseek-ai/dsh-timeout'
import { compileRules, sameChangeRequestUrl, validateRule } from './commands.ts'
import type { CommandRules } from './commands.ts'
import { BINDING_RECORD, forgeChangeRequestsProjection } from './projection.ts'
import { observeReferences } from './reference-lookup.ts'
import type {
  BindingState,
  Config,
  ForgeChangeRequestsState,
  ForgeCommandRule,
  SessionChangeRequest,
  SessionChangeRequestsListener,
} from './types.ts'

export type * from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    forgeSession: ForgeSessionService
  }
}

/** Watchers of one Session and the change request watches they share. */
interface SessionWatch {
  readonly session: Session
  readonly listeners: Set<SessionChangeRequestsListener>
  /** How fresh a status the Session's first watcher asked for, which every forge watch of the Session asks for. */
  readonly options: ChangeRequestWatchOptions
  /** Projection bindings that `forgeWatches` and the last notification reflect. */
  bindings: readonly BindingState[]
  readonly forgeWatches: Map<ChangeRequestKey, () => void>
}

/**
 * Session-scoped change request bindings. The `forgeChangeRequests`
 * projection derives them from the results of the creation and reference
 * commands that forge providers register through `registerCommands`,
 * from `git push` results, including those of shell calls inside PTC
 * programs, and from `plugin:forge-session/binding` records. After each push
 * result, and when a caller reports the branch a Session works on, the
 * service looks up open change requests whose head is that branch and
 * records the unbound ones as discovered. Watching a Session polls its
 * visible change requests through `ctx.forge`.
 */
export class ForgeSessionService extends Service {
  static inject = ['forge', 'sessions', 'sessionProjections']

  static Config: z<Config> = z.object({
    discoveryTimeoutMs: z.number().default(30_000),
  })

  private readonly home: Context
  private readonly discoveryTimeoutMs: number
  private readonly watches = new Map<Session, SessionWatch>()
  private readonly discoveries = new Set<Promise<void>>()
  private readonly sessionLifetimes = new WeakMap<Session, AbortController>()
  /** Epoch milliseconds of the latest tool result of each Session's current turn. */
  private readonly toolResults = new WeakMap<Session, number>()
  private readonly lifetime = new AbortController()
  /** Rules whose registration is live. */
  private readonly rules = new Map<string, ForgeCommandRule>()
  /** Rules the projection folds with: every rule registered in this service's lifetime, the latest per id and executable. */
  private readonly recognized = new Map<string, ForgeCommandRule>()
  private compiled: CommandRules = compileRules([])
  /** The live rules, which alone run reference lookups. */
  private live: CommandRules = compileRules([])
  /** Registered handle of {@link compiled}; assigned during initialization. */
  private projection!: ProjectionHandle<ForgeChangeRequestsState>
  private initialized = false
  /** The running projection rebuild, which also folds rules registered while it runs. */
  private rebuilding: Promise<void> | undefined
  private stale = false

  constructor(ctx: Context, config: Config) {
    super(ctx, 'forgeSession')
    const { discoveryTimeoutMs } = config as Required<Config>
    if (!Number.isSafeInteger(discoveryTimeoutMs) || discoveryTimeoutMs <= 0 || discoveryTimeoutMs > MAX_TIMER_DELAY_MS) {
      throw new Error(`forge-session: discoveryTimeoutMs must be a positive integer no greater than ${MAX_TIMER_DELAY_MS}`)
    }
    this.home = ctx
    this.discoveryTimeoutMs = discoveryTimeoutMs
    ctx.effect(() => async () => {
      this.lifetime.abort(new Error('forge-session service disposed'))
      await Promise.allSettled([...this.discoveries, this.rebuilding])
    }, 'forge-session: stop discovery')
  }

  /**
   * Register the commands of one forge CLI as an effect on the calling fiber.
   * A rule that changes the recognized rule set re-registers the
   * `forgeChangeRequests` projection at the new set's state version, so every
   * Session refolds its log with the new rules when next read, including
   * commands that ran before the registration, and watchers receive the
   * refolded bindings. Disposal does not change the recognized set: the rule
   * keeps recognizing commands until the service restarts or another rule
   * replaces its id or executable, so unloading a provider, including at
   * shutdown, leaves the checkpointed state version unchanged. Only live
   * registrations run reference lookups, so a disposed rule starts no CLI
   * process; lookups that started before a change finish with the rules they
   * started with.
   * @param rule - the CLI's executable, subcommands, change request page path, and selection.
   * @returns the disposer that ends the registration.
   * @throws when the rule is malformed, or a live registration has its id or executable.
   */
  registerCommands(rule: ForgeCommandRule): () => void {
    validateRule(rule)
    const dispose = this.ctx.effect(() => {
      for (const existing of this.rules.values()) {
        if (existing.id === rule.id || existing.executable === rule.executable) {
          throw new Error(`forge-session: command rule ${JSON.stringify(rule.id)} conflicts with the registered rule ${JSON.stringify(existing.id)}`)
        }
      }
      this.rules.set(rule.id, rule)
      this.live = compileRules([...this.rules.values()])
      for (const [id, existing] of this.recognized) {
        if (id === rule.id || existing.executable === rule.executable) this.recognized.delete(id)
      }
      this.recognized.set(rule.id, rule)
      this.scheduleRebuild()
      return () => {
        this.rules.delete(rule.id)
        this.live = compileRules([...this.rules.values()])
      }
    }, 'forgeSession.registerCommands()')
    return () => void dispose()
  }

  /**
   * List the change requests bound to a Session and not dismissed.
   * @param session - Session whose bindings are read.
   * @returns visible bindings in first-recorded order, each with its latest polling result.
   */
  changeRequests(session: Session): SessionChangeRequest[] {
    return this.entries(this.state(session).bindings)
  }

  /**
   * Bind a change request to a Session by URL, or restore a dismissed binding.
   * Appends a `track` record with the provider's canonical URL unless the
   * change request is already visible.
   * @param session - Session that receives the binding.
   * @param url - web URL of the change request.
   * @throws when no registered provider recognizes the URL.
   */
  track(session: Session, url: string): void {
    const ref = this.home.forge.changeRequestFromUrl(url)
    if (ref === undefined) throw new Error(`forge-session: no forge provider recognizes ${JSON.stringify(url)}`)
    const canonical = this.home.forge.changeRequestUrl(ref)
    const existing = this.state(session).bindings.find(binding => sameChangeRequestUrl(binding.url, canonical))
    if (existing === undefined || existing.dismissed) appendPluginRecord(session, BINDING_RECORD, { action: 'track', url: canonical })
  }

  /**
   * Look up open change requests whose head is a branch the Session works on,
   * and record the unbound ones as discovered, as after a push of that branch.
   * A remote that no provider recognizes changes nothing; a failed lookup is
   * logged and changes nothing.
   * @param session - Session that receives the bindings.
   * @param remote - URL of the remote that holds the branch.
   * @param branch - branch name on that remote.
   * @returns resolves once the lookup has recorded its bindings or failed.
   */
  discoverBranch(session: Session, remote: string, branch: string): Promise<void> {
    return this.discover(session, remote, branch)
  }

  /**
   * Hide a visible binding. Appends a `dismiss` record; a URL that is not
   * visibly bound leaves the log unchanged. Discovery never restores a
   * dismissed binding; `track` does.
   * @param session - Session that owns the binding.
   * @param url - web URL of the change request.
   */
  dismiss(session: Session, url: string): void {
    const existing = this.state(session).bindings.find(binding => !binding.dismissed && sameChangeRequestUrl(binding.url, url))
    if (existing !== undefined) appendPluginRecord(session, BINDING_RECORD, { action: 'dismiss', url: existing.url })
  }

  /**
   * Watch a Session's visible change requests as an effect on the calling
   * fiber. Every visible change request that a provider recognizes is polled
   * for its snapshot through `ctx.forge` while the Session has a watcher. Listeners receive the
   * complete list after each later binding or provider change, or polling result; read the
   * current list with {@link changeRequests}. Listeners must not throw; a
   * thrown error is logged and skipped.
   * @param session - Session to watch.
   * @param listener - receives the complete visible list.
   * @param options - when the Session's first watcher needs a status newer than the latest one; a later watcher's
   * options change nothing.
   * @returns the disposer that stops this watch.
   */
  watch(session: Session, listener: SessionChangeRequestsListener, options: ChangeRequestWatchOptions = {}): () => void {
    const dispose = this.ctx.effect(() => {
      let watch = this.watches.get(session)
      if (watch === undefined) {
        watch = { session, listeners: new Set(), options, bindings: this.state(session).bindings, forgeWatches: new Map() }
        this.watches.set(session, watch)
        this.sync(watch)
      }
      const owned = watch
      owned.listeners.add(listener)
      return () => {
        owned.listeners.delete(listener)
        if (owned.listeners.size > 0) return
        this.watches.delete(session)
        for (const unwatch of owned.forgeWatches.values()) unwatch()
        owned.forgeWatches.clear()
      }
    }, 'forgeSession.watch()')
    return () => void dispose()
  }

  protected async [Service.init](): Promise<void> {
    this.compiled = compileRules([...this.recognized.values()])
    this.projection = await this.home.sessionProjections.register(forgeChangeRequestsProjection(this.compiled))
    // Events react against the projection, so the listener starts once its reader is ready.
    this.home.on('session/event', (session: Session, event: SessionEvent) => {
      this.react(session, event)
    })
    observeReferences(this.home, this.discoveryTimeoutMs, () => this.live, (session, url) => {
      if (!this.state(session).bindings.some(binding => sameChangeRequestUrl(binding.url, url))) {
        appendPluginRecord(session, BINDING_RECORD, { action: 'reference', url })
      }
    })
    this.home.on('session/disposed', (session: Session) => {
      this.sessionLifetimes.get(session)?.abort(new Error('forge-session: Session was disposed'))
      this.sessionLifetimes.delete(session)
    })
    this.home.on('forge/providers-changed', () => {
      this.refresh(() => true)
    })
    this.initialized = true
    // Folds any rule registered while the projection registered; a rule set already compiled leaves the projection as is.
    this.scheduleRebuild()
  }

  /**
   * Re-register the projection after the rules registered in the current microtask. Only one rebuild runs at a time; a
   * registration during a rebuild runs one more.
   */
  private scheduleRebuild(): void {
    this.stale = true
    if (!this.initialized || this.rebuilding !== undefined) return
    this.rebuilding = this.rebuild().finally(() => { this.rebuilding = undefined })
  }

  private async rebuild(): Promise<void> {
    await Promise.resolve()
    while (this.stale) {
      this.stale = false
      const compiled = compileRules([...this.recognized.values()])
      if (compiled.version === this.compiled.version) continue
      try {
        // A key registers at one state version at a time; the released handle stays readable until the swap.
        await this.projection.dispose()
        this.projection = await this.home.sessionProjections.register(forgeChangeRequestsProjection(compiled))
        this.compiled = compiled
      } catch (error: unknown) {
        // A registration during service disposal fails because the fiber is no longer active.
        if (this.home.fiber.state === FiberState.ACTIVE) await this.restore(error)
        return
      }
      this.refresh((watch) => {
        const { bindings } = this.state(watch.session)
        if (bindings === watch.bindings) return false
        watch.bindings = bindings
        return true
      })
    }
  }

  /**
   * Register the projection again with the rules it had, after registering it with new ones failed, so clients keep
   * its view; the failure is logged, and an error when the projection could not be restored either.
   */
  private async restore(failure: unknown): Promise<void> {
    const reason = (error: unknown): string => error instanceof Error ? error.message : String(error)
    try {
      this.projection = await this.home.sessionProjections.register(forgeChangeRequestsProjection(this.compiled))
      this.home.logger.warn(`forge-session: re-registering the forgeChangeRequests projection with new command rules failed, so it keeps the earlier rules: ${reason(failure)}`)
    } catch (error: unknown) {
      this.home.logger.error(`forge-session: the forgeChangeRequests projection is unregistered, so clients no longer see bindings: ${reason(failure)}; restoring it failed: ${reason(error)}`)
    }
  }

  /** Re-poll and notify the watches that `changed` selects. */
  private refresh(changed: (watch: SessionWatch) => boolean): void {
    for (const [session, watch] of [...this.watches]) {
      if (this.watches.get(session) !== watch || !changed(watch)) continue
      this.sync(watch)
      this.notify(watch)
    }
  }

  private state(session: Session): ForgeChangeRequestsState {
    return this.projection.stateOf(session)
  }

  private entries(bindings: readonly BindingState[]): SessionChangeRequest[] {
    const entries: SessionChangeRequest[] = []
    for (const binding of bindings) {
      if (binding.dismissed) continue
      const ref = this.home.forge.changeRequestFromUrl(binding.url) ?? null
      const update = ref === null ? null : this.home.forge.latest(ref) ?? null
      entries.push({ url: binding.url, origin: binding.origin, ref, update })
    }
    return entries
  }

  /**
   * Discover change requests for this result's pushes, refresh watchers after binding changes, and poll a Session's
   * change requests once a turn that ran a tool ends.
   */
  private react(session: Session, event: SessionEvent): void {
    if (event.type === 'turn/end') {
      this.turnEnded(session)
      return
    }
    if (event.type !== 'tool/result' && event.type !== 'tool/ptc-dispatch' && pluginRecordOf(event)?.type !== BINDING_RECORD) return
    if (event.type === 'tool/result' || event.type === 'tool/ptc-dispatch') this.toolResults.set(session, Date.now())
    const state = this.state(session)
    for (const push of state.pushes) {
      if (push.seq !== event.seq) continue
      this.expectChanges(state.bindings, push.remote)
      void this.discover(session, push.remote, push.branch)
    }
    const watch = this.watches.get(session)
    if (watch === undefined || watch.bindings === state.bindings) return
    watch.bindings = state.bindings
    this.sync(watch)
    this.notify(watch)
  }

  /**
   * Poll the watched change requests a Session shows once a turn of it that ran a tool ended, unless a poll of them
   * started after the turn's last tool result: a command of the turn may have merged, closed, or updated one.
   */
  private turnEnded(session: Session): void {
    const since = this.toolResults.get(session)
    if (since === undefined) return
    this.toolResults.delete(session)
    const maxAgeMs = Date.now() - since
    for (const { ref } of this.entries(this.state(session).bindings)) {
      if (ref !== null) this.home.forge.refresh(ref, { maxAgeMs })
    }
  }

  /** Announce to the registry that the visible change requests in the repository of a pushed remote are about to change. */
  private expectChanges(bindings: readonly BindingState[], remote: string): void {
    const repository = this.home.forge.repositoryFromRemote(remote)
    if (repository === undefined) return
    for (const { ref } of this.entries(bindings)) {
      // Keys compare repositories without case.
      if (ref !== null && changeRequestKey(ref) === changeRequestKey({ repository, number: ref.number })) this.home.forge.expectChange(ref)
    }
  }

  /** Poll exactly the visible change requests that a provider recognizes. */
  private sync(watch: SessionWatch): void {
    const wanted = new Map<ChangeRequestKey, ChangeRequestRef>()
    for (const entry of this.entries(watch.bindings)) {
      if (entry.ref !== null) wanted.set(changeRequestKey(entry.ref), entry.ref)
    }
    for (const [key, unwatch] of watch.forgeWatches) {
      if (wanted.has(key)) continue
      unwatch()
      watch.forgeWatches.delete(key)
    }
    for (const [key, ref] of wanted) {
      if (!watch.forgeWatches.has(key)) watch.forgeWatches.set(key, this.home.forge.watch(ref, () => { this.notify(watch) }, watch.options))
    }
  }

  private notify(watch: SessionWatch): void {
    const changeRequests = this.entries(watch.bindings)
    for (const listener of [...watch.listeners]) {
      try {
        listener(changeRequests)
      } catch (error) {
        this.home.logger.warn(`forge-session: change request listener failed: ${String(error)}`)
      }
    }
  }

  private discover(session: Session, remote: string, branch: string): Promise<void> {
    const repository = this.home.forge.repositoryFromRemote(remote)
    if (repository === undefined) return Promise.resolve()
    let lifetime = this.sessionLifetimes.get(session)
    if (lifetime === undefined) {
      lifetime = new AbortController()
      this.sessionLifetimes.set(session, lifetime)
    }
    const signal = AbortSignal.any([this.lifetime.signal, lifetime.signal])
    const task = this.lookup(session, repository, branch, signal).catch((error: unknown) => {
      if (signal.aborted) return
      this.home.logger.warn(`forge-session: change request lookup for ${branch} failed: ${error instanceof Error ? error.message : String(error)}`)
    })
    this.discoveries.add(task)
    void task.then(() => this.discoveries.delete(task))
    return task
  }

  private async lookup(session: Session, repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<void> {
    using timeout = deadline(signal, this.discoveryTimeoutMs, 'FORGE_DISCOVERY_TIMEOUT')
    const refs = await this.home.forge.findByHead(repository, branch, timeout.signal)
    for (const ref of refs) {
      if (signal.aborted || this.home.sessions.get(session.id) !== session) return
      const url = this.home.forge.changeRequestUrl(ref)
      if (this.state(session).bindings.some(binding => sameChangeRequestUrl(binding.url, url))) continue
      appendPluginRecord(session, BINDING_RECORD, { action: 'discover', url })
    }
  }
}

export default ForgeSessionService
