/** Literal simple commands of a shell command line, with shell quoting and command separators preserved. */
/** One simple command of a command line: variable assignments, an executable, and its words. */
export interface SimpleCommand {
    /** Variable assignments before the executable as written, such as `GH_HOST=ghe.example`. */
    readonly assignments: readonly string[];
    /** Executable word. */
    readonly executable: string;
    /** Words after the executable, with shell quoting removed. */
    readonly words: readonly string[];
    /**
     * Whether the command is the first of a command line that runs nothing else but an output filter (`head`, `tail`,
     * `cat`), so a lookup in the same shell sees the environment the command saw.
     */
    readonly standalone: boolean;
}
/**
 * Split a command line into its literal simple commands. Shell expansion, multiline scripts, substitutions, unbalanced
 * quotes, and operators other than separators and `2>&1` are excluded: a line with an expansion or substitution yields
 * no command, and a simple command with another operator is left out.
 * @param command - logged shell command text.
 * @param named - executables worth splitting for; a line that names none yields no command without tokenizing.
 * @returns the simple commands in command order; no process or environment is read.
 */
export declare function simpleCommands(command: string, named: RegExp): SimpleCommand[];
//# sourceMappingURL=references.d.ts.map