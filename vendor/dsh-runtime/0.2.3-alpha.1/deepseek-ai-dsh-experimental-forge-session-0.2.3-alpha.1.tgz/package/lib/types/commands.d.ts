/** Recognition of shell commands and output that bind change requests to a Session, by the registered command rules. */
import type { CommandEvidence, ForgeCommandArguments, ForgeCommandRule } from './types.ts';
/** One branch a `git push` output reported as updated. */
export interface PushedRef {
    /** Remote as `git push` printed it after `To`. */
    readonly remote: string;
    /** Branch name on the remote. */
    readonly branch: string;
}
/** One change request a command names: its URL, or the command line of its lookup. */
export interface NamedChangeRequest {
    /** Change request URL when the command names its host, otherwise null. */
    readonly url: string | null;
    /**
     * Command line of the rule's lookup, with the command's own variable assignments, for a standalone command that names
     * the change request without its host; otherwise null.
     */
    readonly lookup: string | null;
    /** Id of the rule that selected the change request. */
    readonly rule: string;
    /** Whether the command is a reference command, whose output names its change request too, or an API request. */
    readonly kind: ForgeCommandArguments['kind'];
}
/** The registered command rules, compiled once per rule set and shared by the projection and the lookups. */
export interface CommandRules {
    /**
     * The `forgeChangeRequests` projection's state version for this rule set: {@link FORGE_CHANGE_REQUESTS_VERSION}
     * times 2^32 plus a 32-bit hash of the sorted `id@version` pairs, so every rule set folds and checkpoints apart.
     */
    readonly version: number;
    /** Matches the raw arguments of a shell call that may name a rule's executable or `git push`. */
    readonly hint: RegExp;
    /**
     * Classify the binding evidence a command and its output can carry. A rule's create subcommands print the change
     * request URL; its reference subcommands act on one change request, which their words or output can name; its API
     * requests bind only the change request their words name, since their output can list others. `git push`,
     * with or without leading `-C`, `-c`, and long options, prints the updated refs. When a command does both, the URLs a
     * result prints bind as created. The subcommand match is textual, so quoted mentions also classify; the output
     * readers then find no evidence.
     */
    evidence(command: string): CommandEvidence | undefined;
    /** The change requests the literal simple commands of `command` name through a rule's `select`. */
    named(command: string): NamedChangeRequest[];
    /**
     * Find the change request URLs a result prints for its evidence: every page URL of a matched rule after a creation,
     * else the URLs a reference command prints for its own change request.
     */
    printed(text: string, evidence: CommandEvidence): string[];
    /** Whether `text`, a lookup's whole output, is one change request URL of rule `rule`. */
    lookupUrl(text: string, rule: string): string | undefined;
}
/** Base of the `forgeChangeRequests` state version; raise it when forge-session's own folding changes. */
export declare const FORGE_CHANGE_REQUESTS_VERSION = 5;
/**
 * Check one rule's declaration before it joins a rule set.
 * @param rule - the rule a provider registers.
 * @throws when a member is empty or malformed, an option is in both lists of a group, or its page path is not a regular expression.
 */
export declare function validateRule(rule: ForgeCommandRule): void;
/**
 * Compile a rule set, which callers have validated with {@link validateRule}.
 * @param rules - the registered rules, ids and executables distinct.
 * @returns the compiled rules.
 */
export declare function compileRules(rules: readonly ForgeCommandRule[]): CommandRules;
/**
 * Read the command string of a `bash` or `pwsh` tool call.
 * @param argumentsJson - raw tool-call arguments as the model produced them.
 * @returns the command, or undefined when the arguments are not JSON or carry no string `command`.
 */
export declare function commandOf(argumentsJson: string): string | undefined;
/**
 * Read the command string of parsed `bash` or `pwsh` arguments, such as the
 * arguments a program dispatch logs.
 * @param args - parsed tool arguments.
 * @returns the command, or undefined when the arguments carry no string `command`.
 */
export declare function commandIn(args: unknown): string | undefined;
/**
 * Find branches that `git push` output reports as created, updated, forced,
 * or already up to date. Each ref line belongs to the nearest preceding
 * `To <remote>` line. Rejected and deleted refs, new tags, and explicit refs
 * outside `refs/heads/` are excluded. Unqualified tag updates cannot be
 * distinguished from branch updates and are included.
 * @param text - rendered shell result, stdout and stderr.
 * @returns distinct pushed branches in order of first appearance.
 */
export declare function pushedBranches(text: string): PushedRef[];
/**
 * Compare two change request URLs ignoring scheme, letter case, query,
 * fragment, and trailing slashes.
 * @param left - one URL.
 * @param right - the other URL.
 * @returns whether both name the same web page.
 */
export declare function sameChangeRequestUrl(left: string, right: string): boolean;
//# sourceMappingURL=commands.d.ts.map