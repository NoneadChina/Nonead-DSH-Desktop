/** Binds change requests to the Session that created, pushed, or tracked them, and watches the bound ones. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ChangeRequestWatchOptions } from '@deepseek-ai/dsh-experimental-forge';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Config, ForgeCommandRule, SessionChangeRequest, SessionChangeRequestsListener } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        forgeSession: ForgeSessionService;
    }
}
/**
 * Session-scoped change request bindings. The `forgeChangeRequests`
 * projection derives them from the results of the creation and reference
 * commands that forge providers register through `registerCommands`,
 * from `git push` results, including those of shell calls inside PTC
 * programs, and from `plugin:forge-session/binding` records. After each push
 * result, and when a caller reports the branch a Session works on, the
 * service looks up open change requests whose head is that branch and
 * records the unbound ones as discovered. Watching a Session polls its
 * visible change requests through `ctx.forge`.
 */
export declare class ForgeSessionService extends Service {
    static inject: string[];
    static Config: z<Config>;
    private readonly home;
    private readonly discoveryTimeoutMs;
    private readonly watches;
    private readonly discoveries;
    private readonly sessionLifetimes;
    /** Epoch milliseconds of the latest tool result of each Session's current turn. */
    private readonly toolResults;
    private readonly lifetime;
    /** Rules whose registration is live. */
    private readonly rules;
    /** Rules the projection folds with: every rule registered in this service's lifetime, the latest per id and executable. */
    private readonly recognized;
    private compiled;
    /** The live rules, which alone run reference lookups. */
    private live;
    /** Registered handle of {@link compiled}; assigned during initialization. */
    private projection;
    private initialized;
    /** The running projection rebuild, which also folds rules registered while it runs. */
    private rebuilding;
    private stale;
    constructor(ctx: Context, config: Config);
    /**
     * Register the commands of one forge CLI as an effect on the calling fiber.
     * A rule that changes the recognized rule set re-registers the
     * `forgeChangeRequests` projection at the new set's state version, so every
     * Session refolds its log with the new rules when next read, including
     * commands that ran before the registration, and watchers receive the
     * refolded bindings. Disposal does not change the recognized set: the rule
     * keeps recognizing commands until the service restarts or another rule
     * replaces its id or executable, so unloading a provider, including at
     * shutdown, leaves the checkpointed state version unchanged. Only live
     * registrations run reference lookups, so a disposed rule starts no CLI
     * process; lookups that started before a change finish with the rules they
     * started with.
     * @param rule - the CLI's executable, subcommands, change request page path, and selection.
     * @returns the disposer that ends the registration.
     * @throws when the rule is malformed, or a live registration has its id or executable.
     */
    registerCommands(rule: ForgeCommandRule): () => void;
    /**
     * List the change requests bound to a Session and not dismissed.
     * @param session - Session whose bindings are read.
     * @returns visible bindings in first-recorded order, each with its latest polling result.
     */
    changeRequests(session: Session): SessionChangeRequest[];
    /**
     * Bind a change request to a Session by URL, or restore a dismissed binding.
     * Appends a `track` record with the provider's canonical URL unless the
     * change request is already visible.
     * @param session - Session that receives the binding.
     * @param url - web URL of the change request.
     * @throws when no registered provider recognizes the URL.
     */
    track(session: Session, url: string): void;
    /**
     * Look up open change requests whose head is a branch the Session works on,
     * and record the unbound ones as discovered, as after a push of that branch.
     * A remote that no provider recognizes changes nothing; a failed lookup is
     * logged and changes nothing.
     * @param session - Session that receives the bindings.
     * @param remote - URL of the remote that holds the branch.
     * @param branch - branch name on that remote.
     * @returns resolves once the lookup has recorded its bindings or failed.
     */
    discoverBranch(session: Session, remote: string, branch: string): Promise<void>;
    /**
     * Hide a visible binding. Appends a `dismiss` record; a URL that is not
     * visibly bound leaves the log unchanged. Discovery never restores a
     * dismissed binding; `track` does.
     * @param session - Session that owns the binding.
     * @param url - web URL of the change request.
     */
    dismiss(session: Session, url: string): void;
    /**
     * Watch a Session's visible change requests as an effect on the calling
     * fiber. Every visible change request that a provider recognizes is polled
     * for its snapshot through `ctx.forge` while the Session has a watcher. Listeners receive the
     * complete list after each later binding or provider change, or polling result; read the
     * current list with {@link changeRequests}. Listeners must not throw; a
     * thrown error is logged and skipped.
     * @param session - Session to watch.
     * @param listener - receives the complete visible list.
     * @param options - when the Session's first watcher needs a status newer than the latest one; a later watcher's
     * options change nothing.
     * @returns the disposer that stops this watch.
     */
    watch(session: Session, listener: SessionChangeRequestsListener, options?: ChangeRequestWatchOptions): () => void;
    protected [Service.init](): Promise<void>;
    /**
     * Re-register the projection after the rules registered in the current microtask. Only one rebuild runs at a time; a
     * registration during a rebuild runs one more.
     */
    private scheduleRebuild;
    private rebuild;
    /**
     * Register the projection again with the rules it had, after registering it with new ones failed, so clients keep
     * its view; the failure is logged, and an error when the projection could not be restored either.
     */
    private restore;
    /** Re-poll and notify the watches that `changed` selects. */
    private refresh;
    private state;
    private entries;
    /**
     * Discover change requests for this result's pushes, refresh watchers after binding changes, and poll a Session's
     * change requests once a turn that ran a tool ends.
     */
    private react;
    /**
     * Poll the watched change requests a Session shows once a turn of it that ran a tool ended, unless a poll of them
     * started after the turn's last tool result: a command of the turn may have merged, closed, or updated one.
     */
    private turnEnded;
    /** Announce to the registry that the visible change requests in the repository of a pushed remote are about to change. */
    private expectChanges;
    /** Poll exactly the visible change requests that a provider recognizes. */
    private sync;
    private notify;
    private discover;
    private lookup;
}
export default ForgeSessionService;
//# sourceMappingURL=index.d.ts.map