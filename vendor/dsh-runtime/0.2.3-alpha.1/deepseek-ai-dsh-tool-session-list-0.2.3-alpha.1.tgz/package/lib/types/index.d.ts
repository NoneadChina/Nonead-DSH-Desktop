/**
 * Opt-in read-only Workspace and Session metadata tools for the mounted runtime.
 * @module @deepseek-ai/dsh-tool-session-list
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis plugin identity. */
export declare const name = "tool-session-list";
/** Services needed for header-only listing and live metadata. */
export declare const inject: string[];
/**
 * Grant tools access to all Workspace and Session metadata in this runtime.
 * @param ctx - scoped context granting these tools to its callers.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map