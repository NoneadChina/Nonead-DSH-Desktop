/** Header-only selection and cached metadata for the read-only listing tools. */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-session';
import { WorkspaceId } from '@deepseek-ai/dsh-workspace';
/** Optional model pagination arguments. */
export interface PageInput {
    readonly limit?: number;
    readonly offset?: number;
}
/** Optional Session selection arguments. */
export interface SessionListInput extends PageInput {
    readonly workspace_id?: string;
    readonly archived?: boolean;
}
interface WorkspaceListItem {
    workspace_id: WorkspaceId;
    title: string;
    path: string;
    created_at: string;
    updated_at: string;
}
interface SessionListItem {
    session_id: SessionId;
    title: string | null;
    created_at: string;
    updated_at: string;
}
/** Entries per page when the model passes no `limit`; part of the model-visible schema. */
export declare const DEFAULT_PAGE_LIMIT = 20;
/** Largest accepted `limit`; part of the model-visible schema. */
export declare const MAX_PAGE_LIMIT = 100;
/**
 * Resolve pagination before reading any registry or persistence data.
 * @param input - model pagination arguments.
 * @returns the validated count and starting index.
 */
export declare function resolvePage(input: PageInput): {
    limit: number;
    offset: number;
};
/**
 * Read one page of the authoritative Workspace order, including empty records.
 * @param ctx - context providing the Workspace registry.
 * @param input - pagination arguments.
 * @param signal - caller cancellation.
 * @returns Workspace metadata with ISO timestamps.
 */
export declare function listWorkspaces(ctx: Context, input: PageInput, signal: AbortSignal): WorkspaceListItem[];
/**
 * List live and persisted Session metadata without opening cold logs or activating Agents.
 * A Workspace selection reads only its members' indexed headers; an unscoped call enumerates
 * the corpus headers. Subagent Sessions are excluded.
 * @param ctx - context providing query, Workspace, and projection services.
 * @param input - filters and pagination arguments.
 * @param signal - caller cancellation, forwarded to the corpus listing.
 * @returns filtered Session metadata ordered by activity, then identity.
 */
export declare function listSessions(ctx: Context, input: SessionListInput, signal: AbortSignal): Promise<SessionListItem[]>;
export {};
//# sourceMappingURL=list.d.ts.map