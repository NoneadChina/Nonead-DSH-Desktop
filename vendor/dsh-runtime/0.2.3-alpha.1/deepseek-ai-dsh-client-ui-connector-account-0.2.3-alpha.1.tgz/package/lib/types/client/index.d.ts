/**
 * Connector account surfaces, browser half: follows the accounts CLI app plugins and MCP connectors register on the Host,
 * and shows each bundle's section, title tag, and activation prompt on its Plugins page, with the notices of the
 * operations this browser started. The surfaces read the shared copy from this package's dictionary and each
 * registrant's text from the Host.
 */
import type { Context } from '@deepseek-ai/cordis';
export type { ConnectorAccountKey } from './locales.ts';
export type { ConnectorAccountFace, ConnectorAccountNotice, ConnectorAccountsState, ConnectorBundleAccountFace, } from './types.ts';
/** The `connectorAccounts` Remote that `dsh-api-remotes` mounts, and the services the slot registrations need. */
export declare const inject: string[];
/**
 * Show the registered connector accounts for one plugin lifetime: one tag and one notice entry for the page, and a
 * section and activation prompt for each bundle that owns an account.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map