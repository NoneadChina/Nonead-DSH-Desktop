/**
 * The page's one subscription to the registered accounts, and what only this browser knows about them: the operations
 * it started, whose authorization pages open here, and the notice to show.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ClientRemote } from '@deepseek-ai/dsh-api-remotes/client';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { ConnectorOperationId } from '../types.ts';
import type { ConnectorAccountsState } from './types.ts';
/**
 * Open an authorization page in a new tab when it is HTTPS, or HTTP on a loopback address such as a local
 * authorization server.
 * @param url - the page an operation waits on; other values open nothing.
 */
export declare function openAuthorizationPage(url: string | undefined): void;
/** One Host subscription per browser, shared by every account surface on the page. */
export declare class BrowserAccounts {
    private readonly ctx;
    /** The accounts, stream state, and notice every surface on the page reads. */
    readonly state: SnapshotStore<ConnectorAccountsState>;
    /**
     * The operation each account's latest start in this browser returned, with the pages already opened for it. It lasts
     * until the stream delivers its result or the account leaves.
     */
    private readonly followed;
    private seq;
    private disposed;
    private readonly stream;
    private readonly observing;
    /**
     * @param ctx - the browser context carrying the Remote client.
     * @param remote - the `connectorAccounts` Remote.
     */
    constructor(ctx: Context, remote: Pick<ClientRemote['connectorAccounts'], 'watch'>);
    /**
     * Follow an operation this browser started, replacing the account's previous one.
     * @param key - the account key.
     * @param id - the operation the Host started.
     */
    follow(key: string, id: ConnectorOperationId): void;
    /** Report that a Remote call this browser made did not finish; the Host keeps the diagnostic. */
    failed(): void;
    /** Clear the notice once it has been shown. */
    dismissNotice(): void;
    /**
     * Stop observing the Host; afterwards the page opens no page and reports nothing more. Host-owned operations keep
     * running.
     * @returns after the stream closes.
     */
    dispose(): Promise<void>;
    private observe;
    private show;
    /** Open each new page of the account's followed operation once, and report its success once its result arrives. */
    private track;
    private notify;
    private patch;
}
//# sourceMappingURL=state.d.ts.map