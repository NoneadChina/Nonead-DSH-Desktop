/**
 * Connector account surfaces, Host half. CLI app plugins and MCP connectors register their accounts with
 * `ctx.connectorAccounts`; the Plugins page follows every registered account through the `connectorAccounts` Remote and
 * starts or cancels operations through it, so the browser never learns how an account connects.
 * @module @deepseek-ai/dsh-client-ui-connector-account
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { AnyConnectorAccountView, ConnectorAccountRegistration, ConnectorAccountsView, ConnectorOperationId } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Connector accounts on the Plugins page. */
        connectorAccounts: ConnectorAccounts;
    }
}
/** Holds the registered accounts and serves them to the Plugins page. */
export default class ConnectorAccounts extends TypertRemoteService {
    private readonly accounts;
    private readonly listeners;
    private readonly lifetime;
    private subscribers;
    /** @param ctx - the Host context the registry serves the page from. */
    constructor(ctx: Context);
    /**
     * Show one account on the Plugins page for as long as the returned disposer has not run.
     * @param registration - the account key, its bundle package, the account source, the page operations, and the
     *   presentation.
     * @returns an idempotent disposer that withdraws the account.
     * @throws when another account already uses the key or the package.
     */
    register<View extends AnyConnectorAccountView>(registration: ConnectorAccountRegistration<View>): () => void;
    /**
     * Follow every registered account; each new subscriber starts a check of each account that runs no operation.
     * @param signal - the Client's observation lifetime; disposal also ends the stream.
     * @returns the current accounts, then each changed set, coalescing changes that arrive before the next read.
     */
    watch(signal: AbortSignal): AsyncIterable<ConnectorAccountsView>;
    /**
     * Start one of the operations the account registered as page actions.
     * @param key - the account key.
     * @param operation - the operation kind.
     * @returns the operation identity once the account's source has started it.
     * @throws for an unknown account or operation, or whatever the account's source refuses, such as a second operation.
     */
    start(key: string, operation: string): Promise<ConnectorOperationId>;
    /**
     * Cancel one operation while its phase is cancellable, and wait for it to settle.
     * @param key - the account key.
     * @param id - the operation to cancel; a finished one or a phase that is not cancellable is ignored.
     * @returns after the operation settles, or at once when nothing is cancelled.
     * @throws for an unknown account.
     */
    cancel(key: string, id: ConnectorOperationId): Promise<void>;
    private account;
    private changed;
}
//# sourceMappingURL=index.d.ts.map