/** The signed-in user's viewed marks on pull request files through GraphQL, pinned to one head commit. */
import type { ChangeRequestRef, ForgeActionFailure, ForgeFailure, ForgeViewedFiles, ForgeViewedRequest } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
import type { GraphqlWriter } from './mutation.ts';
/** One page of a pull request's files with the viewer's marks and its head; `cursor` continues after the previous page. */
export declare const VIEWED_QUERY = "query($owner: String!, $name: String!, $number: Int!, $first: Int!, $cursor: String) {\n  repository(owner: $owner, name: $name) {\n    pullRequest(number: $number) {\n      headRefOid\n      files(first: $first, after: $cursor) { totalCount pageInfo { hasNextPage endCursor } nodes { path viewerViewedState } }\n    }\n  }\n}";
/** Mark one file viewed; variables `id` (pull request node id) and `path`, sent on standard input. */
export declare const MARK_VIEWED_MUTATION = "mutation($id: ID!, $path: String!) {\n  markFileAsViewed(input: { pullRequestId: $id, path: $path }) { clientMutationId }\n}";
/** Clear one file's viewed mark; variables `id` (pull request node id) and `path`, sent on standard input. */
export declare const UNMARK_VIEWED_MUTATION = "mutation($id: ID!, $path: String!) {\n  unmarkFileAsViewed(input: { pullRequestId: $id, path: $path }) { clientMutationId }\n}";
/**
 * Read the viewer's marks on a pull request's files, at most `limit`, reading pages until the limit or the last file.
 * Every page must name `headSha` as the head, so the marks never mix two pushes, and a cursor no earlier page returned,
 * so the listing ends. A state GitHub adds later reads as `unviewed`.
 * @param read - runs one GraphQL request.
 * @param ref - pull request address.
 * @param headSha - head commit the marks must be read at.
 * @param limit - most files listed.
 * @param signal - cancellation of every page.
 * @returns the marks at `headSha`, `stale` once the head is another commit, or why GitHub did not list them.
 * @throws when `headSha` is not a full commit object name.
 */
export declare function readViewed(read: GraphqlReader, ref: ChangeRequestRef, headSha: string, limit: number, signal: AbortSignal): Promise<ForgeViewedFiles | ForgeFailure>;
/**
 * Set or clear the viewer's mark on one file. GitHub's mutations take no head commit, so the pull request head is read
 * first and the write is refused once it is another commit; a push between that read and the write leaves the mark on
 * the file as the new head has it.
 * @param read - runs one GraphQL query.
 * @param write - runs one GraphQL mutation.
 * @param ref - pull request address.
 * @param request - the file, its mark, and the head commit the user saw.
 * @param signal - cancellation of both requests.
 * @returns undefined once GitHub saved the mark, `stale` when the head moved, or why GitHub refused.
 * @throws when `request.headSha` is not a full commit object name.
 */
export declare function writeViewed(read: GraphqlReader, write: GraphqlWriter, ref: ChangeRequestRef, request: ForgeViewedRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
//# sourceMappingURL=viewed.d.ts.map