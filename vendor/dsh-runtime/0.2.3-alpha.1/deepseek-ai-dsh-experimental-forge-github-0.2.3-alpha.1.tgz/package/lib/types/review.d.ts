/** GitHub review writes with commit checks and explicit treatment of uncertain outcomes. */
import type { ChangeRequestRef, ForgeReviewRequest, ForgeReviewResult } from '@deepseek-ai/dsh-experimental-forge';
import { type GhRunner } from './gh.ts';
/**
 * Send one review mutation using JSON on stdin, never shell or argument interpolation.
 * @param gh - bounded, cancellable GitHub CLI runner.
 * @param ref - validated pull request address.
 * @param request - frozen commit and comment ranges.
 * @param signal - cancellation of preflight and mutation.
 * @returns a confirmed receipt, refusal, stale commit, or uncertain outcome; never retries a write.
 */
export declare function submitGitHubReview(gh: GhRunner, ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
//# sourceMappingURL=review.d.ts.map