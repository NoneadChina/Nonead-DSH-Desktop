/** GitHub writes and reads of the change request overview: review requests, reviewer candidates, and branch updates. */
import type { BranchUpdateRequest, ChangeRequestRef, ForgeActionFailure, ForgeFailure, ForgeReviewerCandidate, ForgeReviewersRequest } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
import type { GraphqlWriter } from './mutation.ts';
/**
 * Add review requests from users and teams by node id; variable `input` is a `RequestReviewsInput`. Every supported
 * host has it, while GitHub Enterprise Server 3.19 and 3.20 lack `requestReviewsByLogin`.
 */
export declare const REQUEST_REVIEWS_MUTATION = "mutation($input: RequestReviewsInput!) {\n  requestReviews(input: $input) { clientMutationId }\n}";
/** Add review requests from bots by login, which only this mutation accepts; variable `input` is a `RequestReviewsByLoginInput`. */
export declare const REQUEST_BOT_REVIEWS_MUTATION = "mutation($input: RequestReviewsByLoginInput!) {\n  requestReviewsByLogin(input: $input) { clientMutationId }\n}";
/** Merge or rebase the base branch into the head branch; variable `input` is an `UpdatePullRequestBranchInput`. */
export declare const UPDATE_BRANCH_MUTATION = "mutation($input: UpdatePullRequestBranchInput!) {\n  updatePullRequestBranch(input: $input) { clientMutationId }\n}";
/** Accounts that can review and GitHub's suggestions; variables `owner`, `name`, and `search` are strings, `number` is an integer. */
export declare const CANDIDATES_QUERY = "query($owner: String!, $name: String!, $number: Int!, $search: String!) {\n  repository(owner: $owner, name: $name) {\n    assignableUsers(first: 20, query: $search) { nodes { login name avatarUrl } }\n    pullRequest(number: $number) { author { login } suggestedReviewers { reviewer { login name avatarUrl } } }\n  }\n}";
/**
 * Request reviews, adding to the requests GitHub holds. Users and teams are resolved to node ids in one query and asked
 * with `requestReviews`; bots, named with or without GitHub's `[bot]` suffix, are asked with `requestReviewsByLogin`
 * afterwards, which hosts without it refuse. A team is named `organization/slug`.
 * @param read - runs one GraphQL query.
 * @param write - runs one GraphQL mutation.
 * @param ref - pull request address.
 * @param request - the reviewers to ask.
 * @param signal - cancellation of every request.
 * @returns undefined once GitHub accepted every request, or why it refused; a refused bot request follows an accepted
 * request of the users and teams.
 */
export declare function requestGitHubReviews(read: GraphqlReader, write: GraphqlWriter, ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
/**
 * Update the head branch with `updatePullRequestBranch`. The head is read first and the update is refused once it is
 * another commit; GitHub also checks `expectedHeadOid` itself.
 * @param read - runs one GraphQL query.
 * @param write - runs one GraphQL mutation.
 * @param ref - pull request address.
 * @param request - update method and the head commit the user confirmed.
 * @param signal - cancellation of both requests.
 * @returns undefined once GitHub accepted the update, `stale` when the head moved, or why GitHub refused.
 * @throws when `request.headSha` is not a full commit object name.
 */
export declare function updateGitHubBranch(read: GraphqlReader, write: GraphqlWriter, ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
/**
 * List accounts a review can be requested from: GitHub's suggestions for the pull request when `query` is empty, then
 * the accounts that can be assigned in the repository whose login or name matches `query`, without the author.
 * @param read - runs one GraphQL query.
 * @param ref - pull request address.
 * @param query - text the login or name contains.
 * @param signal - cancellation of the read.
 * @returns at most 20 accounts, each once, or why GitHub did not list them.
 */
export declare function gitHubReviewerCandidates(read: GraphqlReader, ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
//# sourceMappingURL=overview.d.ts.map