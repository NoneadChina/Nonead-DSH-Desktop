/** The node id of a pull request that a GraphQL mutation names, read together with the head the write must still find. */
import type { ChangeRequestRef, ForgeActionFailure } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
/** Node id and head commit of one pull request; variables `owner` and `name` are strings, `number` is an integer. */
export declare const PULL_REQUEST_NODE_QUERY = "query($owner: String!, $name: String!, $number: Int!) {\n  repository(owner: $owner, name: $name) { pullRequest(number: $number) { id headRefOid } }\n}";
/**
 * Read a pull request's node id before a write, refusing once its head is not `headSha`.
 * @param read - runs one GraphQL query.
 * @param ref - pull request address.
 * @param headSha - head commit the write must still find, or null for a write that does not depend on the head.
 * @param signal - cancellation of the read.
 * @returns the node id, `stale` when the head moved, or why the write must not proceed.
 */
export declare function pullRequestNode(read: GraphqlReader, ref: ChangeRequestRef, headSha: string | null, signal: AbortSignal): Promise<string | ForgeActionFailure>;
//# sourceMappingURL=pull-request-node.d.ts.map