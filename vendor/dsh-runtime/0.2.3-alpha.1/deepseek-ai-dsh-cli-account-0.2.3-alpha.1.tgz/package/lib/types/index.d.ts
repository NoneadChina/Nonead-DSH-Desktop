/**
 * Host Service of CLI app plugins: a plugin registers its third-party CLI, which owns the user's account, once. The
 * Service tells the model the CLI's absolute path in runtime context, runs the plugin's account operations one at a
 * time, and shows the account on the Plugins page. Each plugin keeps its own commands, parsing, and states.
 * @module @deepseek-ai/dsh-cli-account
 */
import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { CliAccountHandle, CliAccountRegistration } from './types.ts';
export type { CliPathContext } from './context.ts';
export type { CliCommandResult, CliRunOptions } from './executor.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The vendor CLIs and accounts CLI app plugins register. */
        cliAccounts: CliAccounts;
    }
}
/** Settings that apply to every registered CLI. */
export interface Config {
    /** Deadline in milliseconds for a command that does not wait for the user, including executable lookup. */
    commandTimeoutMs: number;
}
/**
 * Holds what CLI app plugins register: for each plugin, the CLI path the model reads in runtime context, the account
 * operations that run one at a time, and the account the Plugins page shows.
 */
export default class CliAccounts extends Service {
    private readonly config;
    static inject: string[];
    static Config: z<Partial<Config>, Config>;
    constructor(ctx: Context, config: Config);
    /**
     * Register the calling plugin's CLI and account: add the CLI's absolute path to required runtime context, run the
     * plugin's account operations one at a time, and show the account on the Plugins page while `connectorAccounts` is
     * loaded. The registration belongs to the calling plugin: unloading that plugin withdraws it, after the active
     * operation and the CLI processes it started have stopped.
     * @param registration - the plugin's CLI, account operations, and Plugins page text.
     * @returns the handle for the plugin's own reads and updates of the account.
     * @throws when the runtime-context name `<name>:cli` is already registered.
     */
    register<Account, Kind extends string, Phase extends string, Command extends string, Key extends string>(registration: CliAccountRegistration<Account, Kind, Phase, Command, Key>): CliAccountHandle<Account, Kind, Phase, Command>;
}
//# sourceMappingURL=index.d.ts.map