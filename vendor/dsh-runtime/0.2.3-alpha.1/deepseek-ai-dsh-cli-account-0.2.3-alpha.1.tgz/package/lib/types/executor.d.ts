/** Bounded execution of one CLI executable through a subprocess runtime, with subprocess lifetime ownership. */
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** The program a plugin runs and its deadline for commands that do not wait for the user. */
export interface CliCommandExecutorOptions {
    /** Name the CLI's guides run it by, used in diagnostics. */
    readonly program: string;
    /** Absolute path of the executable. */
    readonly executable: string;
    /** Deadline in milliseconds, including executable lookup. */
    readonly commandTimeoutMs: number;
}
/** One command that ran to exit; a nonzero exit is the caller's to interpret. */
export interface CliCommandResult {
    readonly exitCode: number | null;
    /** At most 1 MiB of stdout, in UTF-8 bytes. */
    readonly stdout: string;
    /** The last 4 KiB of stderr, in UTF-8 bytes, cut at a character boundary. */
    readonly stderr: string;
}
/** How long one command may run and who observes its output. */
export interface CliRunOptions {
    /** Whether the command waits for the user in a browser; it then gets a fixed 10-minute deadline instead of the command deadline. */
    readonly awaitsUser?: boolean;
    /**
     * Receives each output line, without its terminator, as the command writes it, and the unterminated rest at exit.
     * `\n`, `\r\n`, and a lone `\r` each end a line, so a line the CLI redraws with `\r` arrives when written. A line
     * longer than its stream's limit, 1 MiB for stdout and 4 KiB for stderr in UTF-8 bytes, is skipped. Every call
     * happens before `run` settles.
     */
    readonly onLine?: (stream: 'stdout' | 'stderr', line: string) => void;
}
/** Runs one plugin's CLI program and owns each command until its process exits. */
export declare class CliCommandExecutor {
    private readonly subprocess;
    private readonly options;
    private readonly lifetime;
    private readonly running;
    constructor(subprocess: SubprocessRuntime, options: CliCommandExecutorOptions);
    /**
     * Run one command to process exit and return its output whatever the exit code. Its pipes are read until they close,
     * at most until 2 seconds after the subprocess runtime reports the exit, so the result does not wait for a descendant
     * that inherited them to close them; what the descendant writes after that is dropped.
     * @param args - native arguments without the executable.
     * @param signal - caller cancellation; an abort rejects with its reason after the process exits.
     * @param options - the deadline choice and an observer for output lines.
     * @returns the exit code, the stdout head, and the stderr tail.
     * @throws after disposal; with the subprocess runtime's error when executable lookup fails, such as
     *   `SubprocessExecutableNotFoundError`, or the process cannot spawn; with what `onLine` throws; otherwise, with a
     *   message naming the command, when the deadline elapses, the process ends by a signal, or stdout exceeds 1 MiB.
     */
    run(args: readonly string[], signal: AbortSignal, options?: CliRunOptions): Promise<CliCommandResult>;
    /**
     * Abort owned commands, wait for their processes to exit, and refuse later commands.
     * @returns settles once every owned command has settled.
     */
    dispose(): Promise<void>;
    /**
     * Name a command for diagnostics.
     * @param args - native arguments without the executable.
     * @returns the program and its arguments joined by spaces.
     */
    commandLine(args: readonly string[]): string;
    private execute;
    private collect;
}
//# sourceMappingURL=executor.d.ts.map