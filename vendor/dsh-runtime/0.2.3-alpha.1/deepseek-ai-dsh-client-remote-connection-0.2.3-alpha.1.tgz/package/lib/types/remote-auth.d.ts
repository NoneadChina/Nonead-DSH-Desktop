/** Persistent Remote browser credentials, independent of Token authentication and runtime Peers. */
import type { CredentialProvider } from '@deepseek-ai/dsh-credentials';
import type { ConnectionTrustRequest } from '@deepseek-ai/dsh-client-connection';
/** A durable signing key and fixed cookie lifetime for the Remote authentication provider. */
export declare class RemoteBrowserAuth {
    private readonly secret;
    private readonly lifetimeMs;
    private constructor();
    /**
     * Load or atomically create Remote's signing key without changing an existing key.
     * @param credentials - persistent provider storing Remote's browser-session grant.
     * @param cookieMaxAgeDays - positive whole days for each credential's absolute lifetime.
     * @returns issuer and verifier whose credentials remain valid across plugin and process restarts until expiry.
     * @throws when the stored record is invalid, the provider fails, or the lifetime exceeds supported timestamps.
     */
    static create(credentials: CredentialProvider, cookieMaxAgeDays: number): Promise<RemoteBrowserAuth>;
    /**
     * Sign a Remote browser credential after the caller validates its invitation or approval.
     * @param request - request whose Host selects the signed audience; source policy is checked by the caller's route.
     * @param secure - whether the receiving listener serves HTTPS; selects the audience and Secure attribute.
     * @returns Set-Cookie, or undefined when Host cannot identify an audience. This method does not authenticate the caller.
     */
    createSessionCookie(request: ConnectionTrustRequest, secure: boolean): string | undefined;
    /**
     * Verify one Remote credential without changing its fixed expiry or allocating a Peer.
     * @param request - request carrying Host and Cookie; unrelated cookies are ignored.
     * @param secure - whether the receiving listener serves HTTPS; HTTP and HTTPS credentials are isolated.
     * @returns true only for one unambiguous, authentic, unexpired credential for this listener authority.
     */
    isAuthenticated(request: ConnectionTrustRequest, secure: boolean): boolean;
}
//# sourceMappingURL=remote-auth.d.ts.map