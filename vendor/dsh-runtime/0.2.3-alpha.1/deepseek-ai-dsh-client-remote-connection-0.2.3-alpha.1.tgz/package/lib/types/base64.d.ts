/** Canonical URL-safe credentials for Node and Preview's Buffer implementation. */
/**
 * Encode bytes without padding, using Buffer encodings supported by Preview.
 * @param bytes - credential or signed payload bytes.
 * @returns canonical URL-safe base64 text.
 */
export declare function encodeBase64Url(bytes: Uint8Array): string;
/**
 * Decode only canonical, nonempty URL-safe base64 text.
 * @param value - untrusted credential or signed payload text.
 * @returns decoded bytes, or undefined for invalid alphabet, padding, or trailing bits.
 */
export declare function decodeBase64Url(value: string): Buffer | undefined;
//# sourceMappingURL=base64.d.ts.map