import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { LoginLinkFace } from './login-link-controller.ts';
/**
 * Present successful and failed clipboard writes outside the settings panel.
 * @param props - renderer-bound feedback, dismissal action, and localized copy.
 * @returns the latest clipboard toast, or nothing.
 */
export declare function LoginLinkToast({ useLoginLink, dismissCopyNotice, t }: PropsRuntime<'shell.overlay'> & InjectFace<LoginLinkFace> & PropsLocale<'remoteConnection'>): import("react").JSX.Element | null;
//# sourceMappingURL=LoginLinkToast.d.ts.map