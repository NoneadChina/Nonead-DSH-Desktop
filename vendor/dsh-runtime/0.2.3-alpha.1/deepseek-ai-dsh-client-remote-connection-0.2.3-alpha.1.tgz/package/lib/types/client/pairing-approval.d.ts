/** Owner decisions and their shell-wide notices survive a settings view closing. */
import type { Context } from '@deepseek-ai/cordis';
import type { PairingDecision, PairingRequestId } from '../types.ts';
/** Mutation state shared by approval controls and the persistent notice. */
export interface ApprovalState {
    readonly available: boolean;
    readonly busy: boolean;
    readonly notice: 'approved' | 'denied' | 'unavailable' | 'failed' | null;
    readonly sequence: number;
}
/** Serializes owner decisions and ignores results after access is withdrawn. */
export declare class PairingApproval {
    private readonly remote;
    private readonly confirmed;
    /** Framework-observed operation state; it contains no applicant credentials. */
    readonly state: import("@deepseek-ai/dsh-client-store").SnapshotStore<ApprovalState>;
    private controller;
    /**
     * @param remote - generated owner-only pairing mutations.
     * @param confirmed - removes a confirmed request from active resources before resolving; never rejects.
     */
    constructor(remote: Pick<Context['remote']['remoteConnection'], 'decidePairing'>, confirmed: (id: PairingRequestId) => Promise<void>);
    /** Activate approval controls for the current owner-access grant. */
    activate(): void;
    /**
     * Submit the owner decision and update active lists before announcing its confirmed outcome.
     * An unknown outcome retains the request for reconciliation.
     * @param id - selected request.
     * @param decision - allow or deny after comparing the displayed code.
     * @returns after the decision settles or access is withdrawn.
     */
    decide(id: PairingRequestId, decision: PairingDecision): Promise<void>;
    /** Dismiss only the notice currently displayed by the shell. */
    dismiss(): void;
    /** Abort the current operation and discard state when owner access ends. */
    dispose(): void;
}
//# sourceMappingURL=pairing-approval.d.ts.map