import type { PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
type Props = PropsRuntime<'settings.section'> & PropsRenderSlots<'settings.remoteConnection.content' | 'settings.remoteConnection.extensions'> & {
    onLeave: () => void;
};
/**
 * Render the selected panel followed by independently registered options.
 * @param props - Settings close action, page-leave cleanup, and the owned slot renderer.
 * @returns The active Remote connection panel and its extensions.
 */
export declare function RemoteConnectionSettings({ close, renderSlot, onLeave }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=RemoteConnectionSettings.d.ts.map