/** Mounted-only polling for the owner's pending pairing requests. */
import type { Context } from '@deepseek-ai/cordis';
import type { ResourceProvider } from '@deepseek-ai/dsh-client-resources/client';
import type { PairingRequestId, PairingRequestsValue } from '../types.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface ResourceProtocolMap {
        /** Pairing requests whose displayed codes require owner approval. */
        'device-pairing': PairingRequestsValue;
    }
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        /** The approval-list read failed before a response was received. */
        'pairing/read-failed': {};
    }
}
/**
 * Poll held request lists and remove confirmed decisions from live lists before their next read.
 * Failed reads wait for a confirmation or a newly opened retry and recover on a successful read.
 * @param remote - generated pairing Remote methods.
 * @returns the provider and a callback that waits for live lists to consume the removal or close.
 */
export declare function requestsResource(remote: Pick<Context['remote']['remoteConnection'], 'pairingRequests'>): {
    provider: ResourceProvider<'device-pairing'>;
    confirmed(id: PairingRequestId): Promise<void>;
};
//# sourceMappingURL=pairing-resource.d.ts.map