/** English dictionary and key authority. */
export declare const en: {
    title: string;
    qrTitle: string;
    addressTitle: string;
    addressDescription: string;
    copyLink: string;
    linkWarningTitle: string;
    linkWarning: string;
    linkCopied: string;
    copyFailed: string;
    generate: string;
    regenerate: string;
    cancel: string;
    retry: string;
    qr: string;
    warningTitle: string;
    warning: string;
    httpWarning: string;
    expires: string;
    used: string;
    expired: string;
    replaced: string;
    loading: string;
    creating: string;
    cancelling: string;
    /** Additional lines in this notice appear as numbered steps. */
    'unreachable-host': string;
    'untrusted-host': string;
    loadFailed: string;
    createFailed: string;
    cancelFailed: string;
    statusFailed: string;
    'pairing.title': "Pairing requests";
    'pairing.description': "Open this app on the other device and request pairing. Compare the codes before approving.";
    'pairing.permission': "Approval gives that browser full access to this app, including approving other devices.";
    'pairing.code': "Pairing code";
    'pairing.sourceIp': "Source IP";
    'pairing.sourceIpUnknown': "Unknown";
    'pairing.approve': "Approve";
    'pairing.deny': "Deny";
    'pairing.retry': "Retry";
    'pairing.loading': "Loading pairing requests";
    'pairing.readFailed': "Could not load requests. Retry to refresh the list.";
    'pairing.approved': "Request approved";
    'pairing.denied': "Request denied";
    'pairing.unavailable': "This request is no longer awaiting approval";
    'pairing.failed': "Could not confirm your decision. Refresh the list before trying again.";
};
/** Typed keys for all panel content and accessible names. */
export type RemoteConnectionLocaleKey = keyof typeof en;
/** Simplified Chinese dictionary. */
export declare const zh: Record<RemoteConnectionLocaleKey, string>;
/** Japanese dictionary. */
export declare const ja: Record<RemoteConnectionLocaleKey, string>;
/** Spanish dictionary. */
export declare const es: Record<RemoteConnectionLocaleKey, string>;
/** French dictionary. */
export declare const fr: Record<RemoteConnectionLocaleKey, string>;
/** German dictionary. */
export declare const de: Record<RemoteConnectionLocaleKey, string>;
/** Russian dictionary. */
export declare const ru: Record<RemoteConnectionLocaleKey, string>;
/** Portuguese dictionary. */
export declare const pt: Record<RemoteConnectionLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map