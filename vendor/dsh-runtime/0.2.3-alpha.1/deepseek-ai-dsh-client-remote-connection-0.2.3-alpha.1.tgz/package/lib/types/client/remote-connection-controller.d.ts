/** Transient QR login state; secrets remain in memory until the invitation settles. */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { TypertClientRemote } from '@deepseek-ai/dsh-typert-protocol';
import type { RemoteConnectionStatus, RemoteLoginTicket } from '../types.ts';
/** Client methods are generated from the Host service. */
export type RemoteConnectionApi = TypertClientRemote['remoteConnection'];
/** Settings panel state, including uncertain outcomes that hide the QR. */
export interface RemoteConnectionState {
    /** Advertised address and prerequisites; null until a deployment read succeeds. */
    deployment: RemoteConnectionStatus | null;
    /** Current operation or invitation outcome; only pending permits displaying the QR credential. */
    phase: 'loading' | 'ready' | 'creating' | 'pending' | 'cancelling' | 'used' | 'expired' | 'cancelled' | 'replaced' | 'error';
    /** Secret invitation, retained during uncertain outcomes for status recovery; never persist or log its URL. */
    ticket: RemoteLoginTicket | null;
    /** Failure owned by the panel; null after a successful read or new operation. */
    error: 'loadFailed' | 'createFailed' | 'cancelFailed' | 'statusFailed' | null;
    /** Remaining invitation lifetime in whole seconds, measured against the browser's monotonic clock. */
    remainingSeconds: number;
    /** Keep the countdown and warning visible during a QR operation; never permits displaying the retained credential. */
    retainDetails: boolean;
}
/** Registration-side data and actions for the settings section. */
export interface RemoteConnectionFace {
    /** Start a new invitation; operation outcomes arrive through the state source. */
    create: () => void;
    /** Cancel the retained invitation without revoking an already-issued browser session. */
    cancel: () => void;
    /** Refresh deployment availability and any retained invitation's state. */
    reload: () => void;
    /** Shared state source bound by the renderer to useRemoteConnection for every panel. */
    hooks: {
        remoteConnection: SnapshotStore<RemoteConnectionState>;
    };
}
/** Owns current invitation polling and ignores superseded replies. */
export declare class RemoteConnectionController {
    private readonly remote;
    /** Snapshot consumed by the settings section; credentials are discarded when it settles or unloads. */
    readonly store: SnapshotStore<RemoteConnectionState>;
    private readonly pending;
    private timer;
    private expiryTimer;
    private generation;
    private deadline;
    private live;
    /** @param remote - Generated owner-authenticated service methods. */
    constructor(remote: Pick<RemoteConnectionApi, 'status' | 'create' | 'cancel'>);
    /**
     * Bind stable actions and the private snapshot to the slot renderer.
     * @returns The settings section's injection values.
     */
    inject(): RemoteConnectionFace;
    /**
     * Withdraw the old connection's login address until the Host confirms its deployment again.
     * @returns after any outstanding QR gesture settles and the status read completes.
     */
    reconnect(): Promise<void>;
    /**
     * Refresh deployment availability and, when retained, the current invitation.
     * @returns After the read settles or immediately when another gesture owns the panel.
     */
    load(): Promise<void>;
    /**
     * Replace the previous code; an uncertain response never restores its QR.
     * @returns After the creation result has been presented.
     */
    create(): Promise<void>;
    /**
     * Cancel the retained invitation without affecting an already-issued login.
     * @returns After cancellation settles; an unknown outcome remains visible.
     */
    cancel(): Promise<void>;
    /** Stop polling, discard the QR secret, and await owned requests. */
    dispose(): Promise<void>;
    private busy;
    private begin;
    private current;
    private track;
    private fail;
    private runCreate;
    private runCancel;
    private read;
    private remainingSeconds;
    private schedule;
}
//# sourceMappingURL=remote-connection-controller.d.ts.map