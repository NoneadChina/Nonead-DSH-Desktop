/** Anonymous one-use credential exchange; application RPC remains authenticated. */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ConnectionTrustRequest } from '@deepseek-ai/dsh-client-connection';
interface LoginRoute {
    readonly root: string;
    readonly available: boolean;
    readonly consume: (token: string) => boolean;
    readonly issueCookie: (request: ConnectionTrustRequest) => string | undefined;
    readonly signal: AbortSignal;
}
/**
 * Identify the explicit QR mode without accepting mixed Token credentials.
 * @param url - application root URL whose query selects the login mode.
 * @returns whether exactly one login parameter selects QR exchange without a Token query.
 */
export declare function isQrLogin(url: URL): boolean;
/**
 * Redeem a raw base64url credential after anonymous source admission.
 * The POST is bound to the advertised authority; only a successful one-use
 * exchange receives a Remote browser cookie.
 * @param route - owning service's current availability and credential consumer.
 * @param request - incoming request with an at-most-43-byte credential body.
 * @param response - HTTP response owned through completion.
 */
export declare function handleLogin(route: LoginRoute, request: IncomingMessage, response: ServerResponse): Promise<void>;
export {};
//# sourceMappingURL=host-route.d.ts.map