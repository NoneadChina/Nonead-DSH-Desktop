/** Copy for Remote's anonymous pages, before Client plugins load. */
export declare const loginLocales: {
    en: {
        pending: string;
        invalid: string;
        forbidden: string;
        unavailable: string;
        failed: string;
        networkFailed: string;
        open: string;
        authenticationTitle: string;
        authenticationDescription: string;
        authenticationUnavailable: string;
        pairingScriptRequired: string;
        tokenLabel: string;
        tokenPlaceholder: string;
        tokenPlaceholderFallbackUrl: string;
        tokenHint: string;
        tokenInvalid: string;
        tokenFailed: string;
        tokenSubmit: string;
        tokenPending: string;
    };
    zh: {
        pending: string;
        invalid: string;
        forbidden: string;
        unavailable: string;
        failed: string;
        networkFailed: string;
        open: string;
        authenticationTitle: string;
        authenticationDescription: string;
        authenticationUnavailable: string;
        pairingScriptRequired: string;
        tokenLabel: string;
        tokenPlaceholder: string;
        tokenPlaceholderFallbackUrl: string;
        tokenHint: string;
        tokenInvalid: string;
        tokenFailed: string;
        tokenSubmit: string;
        tokenPending: string;
    };
};
//# sourceMappingURL=login-locales.d.ts.map