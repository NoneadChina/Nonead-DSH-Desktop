/** Remote-owned anonymous login document, without Client boot data. */
import { loginLocales } from './login-locales.ts';
/** Public capabilities shown by the anonymous login page. */
export interface AuthenticationPageOptions {
    /** Whether the default Token provider has published its login entry. */
    readonly tokenLoginEnabled: boolean;
    /** Whether the Remote provider accepts device-pairing requests. */
    readonly pairingEnabled?: boolean;
}
/**
 * Submit a Token through its own HTTP exchange without starting Client plugins.
 * Failed submissions remain on this page; page departure cancels an in-flight request.
 * @param locales - public copy embedded beside the entry.
 * @param exchangeQr - QR exchange initializer embedded with this function; defaults to the root-entry handler.
 */
export declare function enterAuthenticationPage(locales: typeof loginLocales, exchangeQr?: (locales: typeof loginLocales) => void): void;
/**
 * Render Remote's root login page, without a Token value or private boot data.
 * @param options - Token login and device-pairing availability.
 * @returns sign-in cards with titles and descriptions above controls, below the shared heading and QR feedback.
 */
export declare function renderAuthenticationPage(options: AuthenticationPageOptions): string;
/**
 * Exchange an invitation fragment while retaining the ordinary sign-in choices.
 * @param locales - copy embedded with the root-page initializer.
 */
export declare function enterBrowser(locales: typeof loginLocales): void;
//# sourceMappingURL=login-page.d.ts.map