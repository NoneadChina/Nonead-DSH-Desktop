import type { Context } from '@deepseek-ai/cordis';
/** Register the page planning skill behind the card switch, without a system-prompt section.
 * @param ctx - Owning plugin context with skill, plugin and card registries.
 */
export declare function registerCreationSkill(ctx: Context): void;
//# sourceMappingURL=skill.d.ts.map