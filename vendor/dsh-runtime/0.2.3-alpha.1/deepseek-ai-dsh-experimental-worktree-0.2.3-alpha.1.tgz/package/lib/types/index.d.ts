/**
 * Creates a new Git branch and checkout, then changes the calling Session's working directory; moves the
 * Session into an existing checkout of the pool; returns the Session to the source checkout; restores a
 * removed checkout.
 */
import { Context, Service, type Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { CreatedWorktree, CreateWorktreePhase, CreateWorktreeRequest, EnteredWorktree, EnterWorktreeRequest, RestoredWorktree, RestoreWorktreeRequest, WorktreeCleanup } from './types.ts';
export type { CreatedWorktree, CreateWorktreePhase, CreateWorktreeRequest, EnteredWorktree, EnterWorktreeRequest, RestoredWorktree, RestoreWorktreeRequest, WorktreeCleanup, WorktreeCreation, } from './types.ts';
export { generatedWorktreeName } from './name.ts';
export { CREATED_RECORD, createdWorktreeSchema, worktreeProjection } from './projection.ts';
export type { WorktreeProjectionState } from './projection.ts';
export { WorktreeError, type WorktreeErrorCode } from './error.ts';
/** Worktree location, generated names, executables, subprocess resource limits, and the archive cleanup switch. */
export interface Config {
    /** Keep every checkout when its Session is archived; editable live from the Plugins page. */
    retainOnArchive: Volatile<boolean>;
    /** Relative checkout pool inside the source repository. */
    directory?: string;
    /** Prefix for automatically generated branch and checkout names. */
    namePrefix?: string;
    /** Executable name or absolute execution-world path of a Git release that honors `GIT_NO_LAZY_FETCH`. */
    gitCommand?: string;
    /** Node executable used for sandboxed directory allocation. */
    nodeCommand?: string;
    /** Deadline in milliseconds for one command. */
    timeoutMs?: number;
    /** Subprocess termination grace in milliseconds. */
    graceMs?: number;
    /**
     * Maximum captured bytes per subprocess output stream; archive inspection
     * streams `git status`, and inspection and restoration stream the worktree
     * listing, so it bounds only their stderr.
     */
    maxOutputBytes?: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        worktrees: WorktreeService;
    }
}
/**
 * Creates retained Git worktrees under the mounted filesystem and sandbox
 * providers, moves Sessions into and out of them, records each creation and
 * entry in the Session log, and reclaims a clean, unreferenced checkout when
 * the Session that created it is archived.
 */
export declare class WorktreeService extends Service {
    static inject: string[];
    static Config: z<Schemastery.ObjectS<NoInfer<{
        retainOnArchive: z<boolean, boolean, "volatile-defined">;
        directory: z<string, string, "defined">;
        namePrefix: z<string, string, "defined">;
        gitCommand: z<string, string, "defined">;
        nodeCommand: z<string, string, "defined">;
        timeoutMs: z<number, number, "defined">;
        graceMs: z<number, number, "defined">;
        maxOutputBytes: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        retainOnArchive: z<boolean, boolean, "volatile-defined">;
        directory: z<string, string, "defined">;
        namePrefix: z<string, string, "defined">;
        gitCommand: z<string, string, "defined">;
        nodeCommand: z<string, string, "defined">;
        timeoutMs: z<number, number, "defined">;
        graceMs: z<number, number, "defined">;
        maxOutputBytes: z<number, number, "defined">;
    }>>, "plain">;
    private readonly config;
    private readonly lifetime;
    private readonly pending;
    private readonly checkouts;
    private projection;
    private reclamation;
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    /**
     * Create a fresh branch and checkout at a pinned local revision, then enter it. A request that asks to fetch
     * first fetches its remote-tracking branch, only that branch and without tags, then pins the fetched commit.
     * Existing branches or checkout paths fail. Uncommitted files stay in the source checkout.
     * Checkout disables configured clean, smudge, and process filters without changing Git config.
     * Repository-local replacement refs still apply; baseCommit reports the resolved object name.
     * The new checkout becomes current only after Git setup succeeds. Failures may retain newly
     * allocated Git/filesystem artifacts; no branch or checkout is removed automatically.
     * @param agent - caller whose current directory selects the source repository and file policy.
     * @param request - optional new name, local revision, and fetch switch; defaults are generated name, HEAD, and no fetch.
     * @param signal - cancellation of lookup, creation, and working-directory publication.
     * @param onPhase - receives each stage before it begins; it must not throw.
     * @returns canonical checkout path, branch name, pinned commit, and source repository root.
     * @throws {WorktreeError} for an invalid request, a fetch request whose `from` is not a remote-tracking branch of a
     *   configured remote, an existing branch or path, or a failed, oversized, or timed-out command, including the
     *   fetch; a failure after allocation keeps its `name` and `code` and adds retained-artifact context.
     */
    create(agent: Agent, request?: CreateWorktreeRequest, signal?: AbortSignal, onPhase?: (phase: CreateWorktreePhase) => void): Promise<CreatedWorktree>;
    /**
     * Check out a removed worktree again at its recorded directory: its branch
     * when the branch still exists, otherwise a new branch of the same name at
     * `baseCommit`. Only the missing target's unlocked registration is removed, and an
     * existing directory fails. Changes that were never committed are not
     * recovered. Checkout disables configured clean, smudge, and process filters,
     * as creation does. The calling Session's working directory does not change.
     * Failures may retain newly allocated Git/filesystem artifacts.
     * @param agent - caller whose sandbox policy confines the commands.
     * @param request - recorded directory, branch, base commit, and source repository root.
     * @param signal - cancellation of the restoration.
     * @param onPhase - receives each stage before it begins, never `fetch`; it must not throw.
     * @returns the directory and whether the branch was created again.
     * @throws {WorktreeError} for an invalid request, an existing path, a locked registration, or a failed, oversized,
     *   or timed-out command; a failure after allocation keeps its `name` and `code` and adds retained-artifact context.
     */
    restore(agent: Agent, request: RestoreWorktreeRequest, signal?: AbortSignal, onPhase?: (phase: Exclude<CreateWorktreePhase, 'fetch'>) => void): Promise<RestoredWorktree>;
    /**
     * Move the calling Session into an existing worktree in the pool of the checkout it works in. The
     * directory `name` selects must lie inside that pool and be a registered worktree of the repository;
     * neither Git state nor files change. The Session's log records the entry, so {@link exit} returns it to
     * the checkout it entered from. Archiving the Session never removes a checkout it only entered.
     * @param agent - caller whose current directory selects the checkout and its pool.
     * @param request - name of the worktree inside the pool.
     * @param signal - cancellation of lookup and of the working-directory change.
     * @returns the entered checkout, its branch, and the checkout the Session entered from.
     * @throws {WorktreeError} `WORKTREE_INVALID_ARGUMENT` for a name that is not a relative path inside the pool,
     *   `WORKTREE_NOT_FOUND` when the pool holds no registered worktree of that name, a command failure, and
     *   `WORKTREE_UNAVAILABLE` after service disposal; or the working-directory service's error when the
     *   registered directory no longer exists.
     */
    enter(agent: Agent, request: EnterWorktreeRequest, signal?: AbortSignal): Promise<EnteredWorktree>;
    /**
     * Return the calling Session from the worktree it works in to the checkout it entered that worktree
     * from: the source checkout of a creation, or the checkout whose pool holds an entered worktree. The
     * worktree is the recorded creation or entry, the Session's own or fork-inherited, with the longest
     * directory containing the Session's current directory. Its checkout and branch remain.
     * @param agent - caller whose current directory lies in a recorded worktree.
     * @param signal - cancellation of directory validation and of the working-directory change.
     * @returns the worktree the Session left; the Session now works in its `repositoryRoot`.
     * @throws {WorktreeError} `WORKTREE_NOT_ENTERED` when no recorded worktree contains the current directory and
     *   `WORKTREE_UNAVAILABLE` after service disposal, or the working-directory service's error when the source
     *   checkout no longer exists.
     */
    exit(agent: Agent, signal?: AbortSignal): Promise<CreatedWorktree | EnteredWorktree>;
    /**
     * Read the archive cleanup of a Session's created checkout; waiting never
     * starts one. Absent without the Workspace and query providers.
     * @param sessionId - archived Session whose cleanup is read; reading neither loads nor resumes it.
     * @param revision - null reads at once; a matching revision waits for that attempt to settle.
     * @returns the attempt state, or null when none exists, the revision was superseded, or the service is stopping.
     */
    cleanupOf(sessionId: SessionId, revision: number | null): Promise<WorktreeCleanup | null>;
    /**
     * Inspect a recorded checkout and, when eligible and admitted, remove it and
     * its registration without force or branch deletion. Archiving is the user's
     * authorization, so Git runs unconfined by any Session's sandbox policy; the
     * inspection bounds it to a clean checkout of the configured pool registered
     * on the recorded branch. A rejection can leave a partial directory; the branch stays.
     */
    private removeCheckout;
    private exclusiveCheckout;
    private resolve;
    private createCheckout;
    private enterCheckout;
    private restoreCheckout;
    /**
     * The policy restoration runs under: the Session's mode and grants, bounded by the source
     * checkout of the recorded worktree instead of the Session's own root, which may be the worktree
     * directory, removed or being removed.
     */
    private sourcePolicy;
    /** Confine Git commands to the caller's sandbox policy, collecting bounded stdout. */
    private gitRunner;
    /** Confine Git commands to the caller's sandbox policy, streaming stdout instead of collecting it. */
    private gitScanner;
    /** The configured Git executable with hooks and the filesystem monitor disabled, followed by `args`. */
    private gitArgv;
    /** Allocate the checkout directory exclusively inside the pool, creating a self-ignoring pool when it is new. */
    private prepareDirectory;
}
export default WorktreeService;
//# sourceMappingURL=index.d.ts.map