/** Browser entry of the official plugin card. */
export { apply, inject } from './mount.ts';
//# sourceMappingURL=index.d.ts.map