/** Address syntax for Git-backed market indexes, shared by the Host and Discover. */
/** A Git remote and the file it provides to a market index. */
export interface GitMarketIndexSource {
    readonly url: string;
    readonly repository: string;
    readonly path: string;
    readonly ref?: string;
}
/**
 * Recognize Git repository addresses without contacting the source.
 * @param input - pasted index address or repository link.
 * @returns whether the address identifies a Git repository. Other addresses use direct JSON validation.
 */
export declare function isGitMarketIndexSourceAddress(input: string): boolean;
/**
 * Parse a Git index address for use as a source key and a Git remote. The options belong to the index address.
 * @param input - an explicit `git+https` or `git+ssh` index address.
 * @returns the canonical address, the remote without index options, and the file location.
 * @throws {Error} for an unsupported remote, option, repository-relative path, or ref.
 */
export declare function parseGitMarketIndexSource(input: string): GitMarketIndexSource;
/**
 * Turn a pasted Git repository link into an explicit Git index address.
 * @param input - HTTPS or SSH repository URL, GitHub SSH shorthand, or an existing Git index address.
 * @param path - optional override for the repository-relative index file.
 * @param ref - optional override for the branch or full commit SHA.
 * @returns the canonical index address.
 * @throws {Error} when the address or options cannot be used by a Git index source.
 */
export declare function gitMarketIndexSource(input: string, path?: string, ref?: string): string;
//# sourceMappingURL=source.d.ts.map