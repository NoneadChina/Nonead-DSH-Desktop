/** Windows operation levels, application selectors, and input availability. */
export declare const PLATFORM_GUIDANCE = "Windows: accessibility tree operations are available only at window level. Simulated mouse and keyboard input are available at window level. Supported modifiers: ctrl, alt, shift, win. control is an alias for ctrl. Key and mouse holds use desktop input. Keep the target in front while holding inputs. Release through the same window. After focus changes, an up releases desktop input without restoring focus; the original window may not receive that event.";
/** Native operation instructions; the shared Host adds guidance for declared capabilities. */
export declare const GUIDANCE: string;
//# sourceMappingURL=guidance.d.ts.map