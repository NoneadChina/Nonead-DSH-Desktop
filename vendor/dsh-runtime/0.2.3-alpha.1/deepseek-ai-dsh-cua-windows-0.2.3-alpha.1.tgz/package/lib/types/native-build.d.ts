import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Architectures supported by the Windows helper payload. */
export type NativeArchitecture = 'arm64' | 'x64';
/** Package location, architecture and managed source-build lifetime. */
export interface NativeBuildSpec {
    packageRoot: string;
    architecture: NativeArchitecture;
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    timeoutMs: number;
    graceMs: number;
    signal: AbortSignal;
}
/**
 * Validate the native Windows runtime host.
 * @param platform Node host platform.
 * @param architecture Node process architecture.
 * @returns Supported Windows architecture.
 */
export declare function nativeHostArchitecture(platform: string, architecture: string): NativeArchitecture;
/**
 * Locate an installed package's helper, using Electron's unpacked payload when applicable.
 * @param packageRoot Directory containing the Windows provider manifest.
 * @param architecture Architecture of the process running the helper.
 * @returns Absolute payload path.
 */
export declare function nativeExecutablePath(packageRoot: string, architecture: NativeArchitecture): string;
/**
 * Publish the source helper with dotnet from PATH under the shared compiler lock.
 * @param spec Checkout, target architecture and managed process limits.
 * @returns Published executable after compiler cleanup; build or output validation failures reject.
 */
export declare function buildNativeExecutable(spec: NativeBuildSpec): Promise<string>;
/**
 * Build source helpers on activation; installed packages only resolve their payload.
 * @param spec Package location, architecture and cancellation/deadline limits.
 * @returns Existing executable after preparation; failures reject without fallback to another payload.
 */
export declare function prepareNativeExecutable(spec: NativeBuildSpec): Promise<string>;
//# sourceMappingURL=native-build.d.ts.map