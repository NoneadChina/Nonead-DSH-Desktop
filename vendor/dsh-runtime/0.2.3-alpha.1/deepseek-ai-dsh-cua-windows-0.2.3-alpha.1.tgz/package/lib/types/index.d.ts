import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { CuaConfig } from '@deepseek-ai/dsh-cua';
/** Loader identity of the Windows provider. */
export declare const name = "cua-windows";
/** Services required by shared CUA execution and managed native preparation. */
export declare const inject: string[];
/** Windows native waiting policy, alongside shared CUA resource limits. */
export interface Config extends CuaConfig {
    /** Windows PowerShell executable used to query WSL interoperation and the Windows architecture. */
    windowsPowerShellPath: string;
    /** Milliseconds between application-readiness and clipboard-release observations. */
    pollIntervalMs: number;
}
/** Validate platform configuration before locating and launching the helper. */
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    windowsPowerShellPath: Schema<string, string, "defined">;
    pollIntervalMs: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    requireSystemInputApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    standaloneRunCode: Schema<Partial<import("@deepseek-ai/dsh-cua/config").CuaStandaloneRunCodeConfig>, import("@deepseek-ai/dsh-cua/config").CuaStandaloneRunCodeConfig, "defined">;
    screenshotTarget: Schema<import("@deepseek-ai/dsh-cua/config").CuaScreenshotTargetConfig | undefined, import("@deepseek-ai/dsh-cua/config").CuaScreenshotTargetConfig | undefined, "plain">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    windowsPowerShellPath: Schema<string, string, "defined">;
    pollIntervalMs: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    requireSystemInputApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    standaloneRunCode: Schema<Partial<import("@deepseek-ai/dsh-cua/config").CuaStandaloneRunCodeConfig>, import("@deepseek-ai/dsh-cua/config").CuaStandaloneRunCodeConfig, "defined">;
    screenshotTarget: Schema<import("@deepseek-ai/dsh-cua/config").CuaScreenshotTargetConfig | undefined, import("@deepseek-ai/dsh-cua/config").CuaScreenshotTargetConfig | undefined, "plain">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
}>>, "plain">;
/**
 * Prepare the Windows payload and install the shared authorized operation pipeline.
 * @param ctx - Owning provider context.
 * @param config - Validated helper override, operation bounds, and application grants.
 * @returns Completion after preparation and reversible registrations.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map