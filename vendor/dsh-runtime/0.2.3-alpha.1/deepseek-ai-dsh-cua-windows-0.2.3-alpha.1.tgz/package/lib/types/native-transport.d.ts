import { Duplex } from 'node:stream';
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import { type NativeClientConfig } from '@deepseek-ai/dsh-cua/native-client';
/** Transport selected from the resolved Host environment. */
export type WindowsTransport = 'pipe' | 'stdio';
/** One connection owns its stream and, for WSL, a Windows bridge process. */
export interface WindowsConnection {
    stream: Duplex;
    connected: Promise<void>;
    dispose(): Promise<void>;
}
/**
 * Connect to a Windows desktop service without exposing a network listener.
 * @param subprocess Managed process owner for the WSL bridge.
 * @param config Helper executable and connection/cleanup limits.
 * @param endpoint Named pipe reported by the verified service lease.
 * @param runtimeKey Expected executable digest, verified again by the Windows bridge.
 * @param transport Native pipe or standard streams through WSL interoperation.
 * @returns Owned connection; disposal joins the bridge process after stream closure.
 */
export declare function connectWindowsPipe(subprocess: Pick<SubprocessRuntime, 'spawn'>, config: NativeClientConfig, endpoint: string, runtimeKey: string, transport: WindowsTransport): WindowsConnection;
//# sourceMappingURL=native-transport.d.ts.map