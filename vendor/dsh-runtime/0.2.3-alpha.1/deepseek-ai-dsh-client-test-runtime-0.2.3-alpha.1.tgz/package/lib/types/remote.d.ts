/** Test-owned Remote face: `$on` subscriptions with an explicit test event driver, and reconnecting streams. */
import type { Context } from '@deepseek-ai/cordis';
import { RemoteStream, type RemoteStreamOptions } from '@deepseek-ai/dsh-api-gateway/client';
export { RemoteError } from '@deepseek-ai/dsh-typert-protocol';
/**
 * Remote service test double for the forwarded-event path. Feature specs need
 * `ctx.remote.$on` to exist (their plugins inject `remote`) and need forwarded
 * Host events to reach those subscribers, but not the wire — so this double
 * implements subscription plus an explicit `emit` driver available only on the
 * concrete test object. A spec that also calls one namespace scripts it through
 * the constructor rather than reaching the real Client Remote service.
 * `$stream` wraps a scripted stream method in the production `RemoteStream`
 * over one Host generation that never changes.
 *
 * `$mount` rejects: a spec that needs a real generated contribution installed —
 * codecs, descriptors, and the wire — has outgrown this double and needs the
 * real Client Remote service.
 *
 * One deliberate asymmetry with production: a throwing listener propagates out
 * of the emit instead of being contained and logged, so a spec cannot lean on
 * this double for the containment guarantee `$on` documents — assert that
 * against the real service.
 */
export declare class TestRemote {
    private readonly ctx;
    private readonly subscriptions;
    /** One always-available Host generation; the double never loses or replaces its carrier. */
    private readonly connection;
    /**
     * Fixed Host facts mirrored from the production `ctx.remote.$host`. Plain
     * mutable field: a spec assigns it to script a non-loopback or homed Host.
     */
    $host: {
        home: string | undefined;
        isLoopback: boolean;
    };
    /**
     * Register the double as `ctx.remote`, plus one service per scripted
     * namespace so a plugin injecting `remote.<name>` also unparks.
     * @param ctx - the spec's root Context.
     * @param namespaces - scripted namespace faces reached as `ctx.remote.<name>`.
     */
    constructor(ctx: Context, namespaces?: Readonly<Record<string, object>>);
    /**
     * Add scripted namespace faces to this Remote service.
     * @param namespaces - scripted namespace faces reached as `ctx.remote.<name>`.
     */
    provideNamespaces(namespaces: Readonly<Record<string, object>>): void;
    private validateNamespaces;
    private installNamespaces;
    /**
     * Deliver one forwarded host event to its subscribers, standing in for the
     * carrier that owns the frame sink.
     * @param event - forwarded host event name.
     * @param args - the Host argument list, verbatim.
     */
    emit(event: string, args: readonly unknown[]): void;
    /**
     * Subscribe to one forwarded host event.
     * @param event - forwarded host event name.
     * @param listener - receives the Host argument list verbatim.
     * @returns disposer removing this subscription.
     */
    $on(event: string, listener: (...args: never[]) => void): () => void;
    /**
     * Open one production `RemoteStream` over the double's always-available Host generation, so a plugin's stream
     * lifecycle runs against a scripted namespace method.
     * @param options - domain stream opener, end classification, and diagnostics.
     * @returns the single-consumer reconnecting stream.
     */
    $stream<Item>(options: RemoteStreamOptions<Item>): RemoteStream<Item>;
    /**
     * Generated-namespace mount, unsupported by this double.
     * @returns never; always rejects.
     */
    $mount(): Promise<() => Promise<void>>;
}
//# sourceMappingURL=remote.d.ts.map