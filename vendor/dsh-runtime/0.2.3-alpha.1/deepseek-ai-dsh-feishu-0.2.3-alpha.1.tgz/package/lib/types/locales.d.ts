/** The Feishu text the Plugins page shows; the browser resolves it in its active language. */
/** Chinese dictionary and key source. */
export declare const zh: {
    'section.title': string;
    'status.checking': string;
    'status.disconnected': string;
    'status.unavailable': string;
    'status.connected': string;
    'step.configuring': string;
    'step.authorizing': string;
    'step.connecting': string;
    'step.signing-out': string;
    'detail.no-app': string;
    'detail.signed-out': string;
    'detail.unavailable': string;
    'detail.connected': string;
    'detail.connectedAs': string;
    'detail.configuring': string;
    'detail.authorizing': string;
    hint: string;
    'app.linked': string;
    failed: string;
    'failed.linkApp': string;
    'action.connect': string;
    'action.linkApp': string;
    'action.signIn': string;
    'action.open': string;
    'action.cancel': string;
    'action.signOut': string;
    'action.replaceApp': string;
    'action.retry': string;
    'badge.connected': string;
    'badge.disconnected': string;
    'badge.connecting': string;
    'badge.unavailable': string;
    'signOut.title': string;
    'signOut.body': string;
    'replaceApp.title': string;
    'replaceApp.body': string;
    'activation.title': string;
    'activation.body': string;
    'notice.app-linked': string;
    'notice.connected': string;
    'notice.signed-out': string;
};
/** Every key of the Feishu text. */
export type FeishuTextKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<FeishuTextKey, string>;
/** Japanese dictionary. */
export declare const ja: Record<FeishuTextKey, string>;
/** Spanish dictionary. */
export declare const es: Record<FeishuTextKey, string>;
/** French dictionary. */
export declare const fr: Record<FeishuTextKey, string>;
/** German dictionary. */
export declare const de: Record<FeishuTextKey, string>;
/** Russian dictionary. */
export declare const ru: Record<FeishuTextKey, string>;
/** Portuguese dictionary. */
export declare const pt: Record<FeishuTextKey, string>;
/** The dictionary of every shipped language. */
export declare const dictionaries: {
    zh: {
        'section.title': string;
        'status.checking': string;
        'status.disconnected': string;
        'status.unavailable': string;
        'status.connected': string;
        'step.configuring': string;
        'step.authorizing': string;
        'step.connecting': string;
        'step.signing-out': string;
        'detail.no-app': string;
        'detail.signed-out': string;
        'detail.unavailable': string;
        'detail.connected': string;
        'detail.connectedAs': string;
        'detail.configuring': string;
        'detail.authorizing': string;
        hint: string;
        'app.linked': string;
        failed: string;
        'failed.linkApp': string;
        'action.connect': string;
        'action.linkApp': string;
        'action.signIn': string;
        'action.open': string;
        'action.cancel': string;
        'action.signOut': string;
        'action.replaceApp': string;
        'action.retry': string;
        'badge.connected': string;
        'badge.disconnected': string;
        'badge.connecting': string;
        'badge.unavailable': string;
        'signOut.title': string;
        'signOut.body': string;
        'replaceApp.title': string;
        'replaceApp.body': string;
        'activation.title': string;
        'activation.body': string;
        'notice.app-linked': string;
        'notice.connected': string;
        'notice.signed-out': string;
    };
    en: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
    ja: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
    es: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
    fr: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
    de: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
    ru: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
    pt: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.configuring" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.no-app" | "detail.signed-out" | "detail.unavailable" | "detail.connected" | "detail.connectedAs" | "detail.configuring" | "detail.authorizing" | "hint" | "app.linked" | "failed" | "failed.linkApp" | "action.connect" | "action.linkApp" | "action.signIn" | "action.open" | "action.cancel" | "action.signOut" | "action.replaceApp" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "replaceApp.title" | "replaceApp.body" | "activation.title" | "activation.body" | "notice.app-linked" | "notice.connected" | "notice.signed-out", string>;
};
//# sourceMappingURL=locales.d.ts.map