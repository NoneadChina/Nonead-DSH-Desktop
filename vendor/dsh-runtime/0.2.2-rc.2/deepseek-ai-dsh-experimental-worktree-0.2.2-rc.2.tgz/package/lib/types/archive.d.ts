/**
 * Archive-triggered reclamation of checkouts this service created. Installed by
 * the service constructor, as the job and Agent registries install their own
 * archive-admission families, so it holds for every Session the Workspace archives.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Session, SessionId } from '@deepseek-ai/dsh-session';
import type { ProjectionHandle } from '@deepseek-ai/dsh-session-projection';
import type { WorktreeProjectionState } from './projection.ts';
import type { CreatedWorktree, WorktreeCleanup } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * A cleanup attempt changed state. Fires once at admission with
         * `scheduled` and once at settlement with the final status.
         * @param info - the archived Session, the checkout, and the attempt state.
         * @mode emit
         */
        'worktree/cleanup'(info: {
            sessionId: SessionId;
            path: string;
            cleanup: WorktreeCleanup;
        }): void;
    }
}
/** The service operations reclamation needs; kept narrow so the archive module never reaches Git directly. */
export interface ReclamationHost {
    /** Whether the deployment keeps every checkout on archive; read at each admission. */
    retainOnArchive(): boolean;
    /** Run `body` after every operation on `path` that was requested earlier, and before any requested later. */
    exclusiveCheckout<T>(path: string, body: () => Promise<T>): Promise<T>;
    /** Inspect and, when eligible and admitted, remove the checkout without force. Rejects on Git failure. */
    removeCheckout(session: Session, request: CreatedWorktree, signal: AbortSignal, admit: () => boolean): Promise<boolean>;
}
/** Owns pending cleanup, gates directory entry into a checkout being removed, and drains before the service is released. */
export declare class WorktreeReclamation {
    private readonly ctx;
    private readonly host;
    private readonly projection;
    private readonly attempts;
    private readonly removing;
    private readonly pending;
    private readonly lifetime;
    private revision;
    /**
     * @param ctx - scope injecting the Workspace registry, Session query, store, working-directory, and
     *   sandbox-policy providers; the projection cache is read when mounted.
     * @param host - the service operations the module runs through.
     * @param projection - the `worktree` unit, read live and through the persisted cache.
     */
    constructor(ctx: Context, host: ReclamationHost, projection: ProjectionHandle<WorktreeProjectionState>);
    /**
     * Read the most recent cleanup attempt of a Session; waiting never starts one.
     * @param session - archived Session whose attempt is read.
     * @param revision - null reads at once; a matching revision waits for that attempt to settle.
     * @returns the attempt state, or null when none exists, the revision was superseded, or the service is stopping.
     */
    cleanupOf(session: Session, revision: number | null): Promise<WorktreeCleanup | null>;
    /** Register attempts for the Session's own creations and return; every inspection runs in the background. */
    private schedule;
    private run;
    /**
     * Remove under the path lock; a second use check runs inside it, after
     * competing operations settled. A Session has one attempt and unarchiving
     * awaits it, so removals of one path never overlap.
     */
    private remove;
    /**
     * Whether no unarchived Session still refers to the checkout: by a recorded
     * creation, inherited or own, or by a working directory inside it. A Session
     * beneath an archived subagent ancestor counts as archived, as its own
     * archive admission does. Processes are not consulted: Git refuses a
     * removal that would discard changes, and an idle process in a removed
     * directory fails its next command.
     */
    private unused;
    /** The archived Session itself, prepared cold when not live, whose sandbox policy confines the Git commands. */
    private creatorSession;
    /** The recorded directory of a cold Session, null when its log recorded none: the persisted cache when it has one, else its log. */
    private directoryOf;
    /** The recorded creations of a cold Session: the persisted cache when it has one, else its log. */
    private creationsOf;
}
//# sourceMappingURL=archive.d.ts.map