/** Shared owner-facing share records read from the owner share-management Remote. */
import type { ViewerSessionMode } from './viewer-capabilities.ts';
import type { ShareCapabilityGroup, ViewerPluginPolicy } from '../share-api-types.ts';
/** One installed plugin's Remote methods the Host offers a share. */
export type OfferedPlugin = ShareCapabilityGroup;
export type { ViewerPluginPolicy };
/** One owner-created share listed by the global management UI. */
export interface OutgoingShare {
    readonly shareId: string;
    /** Primary source Session, kept for Hosts that predate `sessionIds`. */
    readonly sessionId?: string;
    /** Every source Session this share serves, primary first; the authoritative list. */
    readonly sessionIds?: readonly string[];
    readonly sessionTitle: string;
    readonly link: string;
    readonly createdAt: string;
    /**
     * The session permission the owner set for this share. Absent when the owner's Harness does not
     * report a mode at all, which is stated as unsupported rather than as the narrowest one.
     */
    readonly sessionMode?: ViewerSessionMode;
    /**
     * Whether this share lets an admitted viewer fork it.
     *
     * Independent of the tier: absent on a Host that does not report it, which reads as off.
     */
    readonly allowsFork?: boolean;
    /**
     * Per-plugin endpoint policies this share carries, as the owner's Harness reports them.
     *
     * Absent means no plugin endpoint reaches this share's viewers.
     */
    readonly viewerPlugins?: readonly ViewerPluginPolicy[];
    /** Global switch over every installed plugin's methods; absent reads as none. */
    readonly viewerPluginAccess?: 'all' | 'none' | 'custom';
    /** ISO time after which the Relay denies viewers; absent means it never expires. */
    readonly expiresAt?: string;
    readonly online: boolean;
    readonly access?: unknown;
}
/** One durable audit entry shown in the owner share history. */
export interface ShareAuditEntry {
    readonly id: string;
    readonly action: string;
    readonly createdAt: string;
    readonly actor?: string;
}
/** Browser-safe summary of the persisted ACL scope for one share. */
export interface ConfirmedShareAccess {
    readonly mode: 'open' | 'selected';
    readonly selectedCount: number;
    readonly deploymentCount: number;
}
/**
 * Normalize one share access payload into a browser-safe summary.
 * @param value Raw `access` field from the owner share list.
 * @returns Confirmed mode and counts, or undefined for legacy or malformed records.
 */
export declare function readAccess(value: unknown): ConfirmedShareAccess | undefined;
/**
 * Read one share's global plugin switch.
 * @param value Raw `viewerPluginAccess` field.
 * @returns The reported switch; an unknown or absent value reads as `none`.
 */
export declare function readPluginAccess(value: unknown): 'all' | 'none' | 'custom';
/**
 * Normalize the host-reported catalog into the plugins this page can present.
 *
 * A Host that reports nothing, or one malformed entry, leaves no offer for that entry: an unreadable
 * offer is not one the owner may tick.
 * @param value Raw `capabilities` field.
 * @returns The offered plugins, in the order the host reported them.
 */
export declare function readOfferedPlugins(value: unknown): readonly OfferedPlugin[];
/**
 * Normalize one share's stored policies into the entries this page can edit.
 *
 * A Host that reports nothing, or one malformed entry, leaves that plugin closed.
 * @param value Raw `viewerPlugins` field.
 * @returns The policies this page can present, in host order.
 */
export declare function readViewerPolicies(value: unknown): readonly ViewerPluginPolicy[];
//# sourceMappingURL=share-types.d.ts.map