/** Largest traversal budgets accepted by the macOS helper. */
export declare const AX_TRAVERSAL_MAX: {
    readonly maxElements: 100000;
    readonly maxDepth: 512;
};
//# sourceMappingURL=ax-limits.d.ts.map