/** Publishes public configuration for the account notification client plugin. */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.ts';
export { Config } from './config.ts';
/** @param ctx - Host page bootstrap collector. @param config - validated notification configuration. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map