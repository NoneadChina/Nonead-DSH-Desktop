/** Close-control copy owned by account notifications; notification content is server-localized. */
export declare const en: {
    close: string;
};
/** Chinese notification controls. */
export declare const zh: {
    close: string;
};
/** Japanese notification controls. */
export declare const ja: {
    close: string;
};
/** Spanish notification controls. */
export declare const es: {
    close: string;
};
/** French notification controls. */
export declare const fr: {
    close: string;
};
/** German notification controls. */
export declare const de: {
    close: string;
};
/** Russian notification controls. */
export declare const ru: {
    close: string;
};
/** Portuguese notification controls. */
export declare const pt: {
    close: string;
};
/** Localized notification control keys. */
export type NotificationKey = keyof typeof en;
//# sourceMappingURL=locales.d.ts.map