/** Read-only model tools for terminals the user controls in the Session's sidebar. */
import type { Context } from '@deepseek-ai/cordis';
import type { TerminalController, TerminalScreenPage } from '@deepseek-ai/dsh-api-terminal-controller';
/** Refusal for subagents, whose Sessions hold none of the terminals the user sees beside the conversation. */
export declare const SUBAGENT_USER_TERMINALS = "Subagents cannot read the user's terminals, which belong to the main conversation; report what you need to the main agent instead.";
/** The terminal controller operations the tools use. */
export type UserTerminals = Pick<TerminalController, 'list' | 'readScreen' | 'inspectActivity'>;
/** One user terminal as the model sees it. */
interface UserTerminal {
    id: string;
    title: string;
    cwd: string;
    running: 'yes' | 'no' | 'unknown';
}
/**
 * Render a terminal list, one terminal per line.
 * @param terminals - terminals the user controls.
 * @returns model-facing text.
 */
export declare function renderUserTerminals(terminals: readonly UserTerminal[]): string;
/**
 * Render a screen page with its position, keeping the complete result within the byte bound.
 * @param page - rendered screen page.
 * @param maxBytes - bound on the complete result.
 * @returns model-facing text.
 */
export declare function renderUserScreen(page: TerminalScreenPage, maxBytes: number): string;
/**
 * Register `user_terminal_list` and `user_terminal_read` in the context's tool layer.
 * @param ctx - context carrying the tool registry.
 * @param terminals - the Session terminal controller.
 * @param maxReadBytes - bound on one complete read result.
 */
export declare function registerUserTerminalTools(ctx: Context, terminals: UserTerminals, maxReadBytes: number): void;
export {};
//# sourceMappingURL=tools.d.ts.map