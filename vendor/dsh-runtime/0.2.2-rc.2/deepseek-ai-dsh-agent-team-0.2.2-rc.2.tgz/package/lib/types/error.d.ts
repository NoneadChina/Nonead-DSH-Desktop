/** Typed Agent Teams failures. */
import { HarnessError } from '@deepseek-ai/dsh-llm';
/** Stable failure raised by the Team domain. */
export declare class TeamError extends HarnessError {
    constructor(message: string, code: string, options?: ErrorOptions);
}
//# sourceMappingURL=error.d.ts.map