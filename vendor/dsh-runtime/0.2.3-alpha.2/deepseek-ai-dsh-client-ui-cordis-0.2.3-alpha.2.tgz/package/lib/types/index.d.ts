/**
 * Cordis dynamic-plugin card, node half. Pure UI plugin: the empty apply
 * exists so the plugin appears in the host cordis.yml / Loader; the browser
 * half ships via exports["./client"], discovered through the package.json
 * dshClient declaration.
 */
/** Host plugin body — no host-side behavior for this surface plugin. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map