/** The WeCom authorization section the Plugins page shows for each Host view. */
import type { CliAccountText } from '@deepseek-ai/dsh-cli-account/types';
import type { ConnectorAccountCopy, ConnectorAccountDisplay, ConnectorAccountOperation } from '@deepseek-ai/dsh-client-ui-connector-account/types';
import type { WecomTextKey } from './locales.ts';
import type { WecomOperationKind, WecomState } from './types.ts';
type Text = CliAccountText<WecomTextKey>;
/** The npm package whose bundle page carries the authorization section. */
export declare const WECOM_PACKAGE = "@deepseek-ai/dsh-wecom";
/**
 * List the operations the section's buttons start; binding a bot reports a notice in the browser that started it.
 * @param text - writes a key of the WeCom text in every shipped language.
 * @returns the operations with their notices.
 */
export declare function operations(text: Text): readonly ConnectorAccountOperation<WecomOperationKind>[];
/**
 * Write the section's title and hint, and the prompt after the bundle is switched on while unauthorized.
 * @param text - writes a key of the WeCom text in every shipped language.
 * @returns the section's fixed text.
 */
export declare function copy(text: Text): ConnectorAccountCopy;
/**
 * The authorization section for one Host view.
 * @param view - the authorization, the operation in progress, and the last result.
 * @param text - writes a key of the WeCom text in every shipped language.
 * @returns the phase, status, tag, buttons, detail, bound-bot and guide download rows, and failure guidance.
 */
export declare function presentAccount(view: WecomState, text: Text): ConnectorAccountDisplay;
export {};
//# sourceMappingURL=presentation.d.ts.map