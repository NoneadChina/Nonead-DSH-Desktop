/**
 * WeCom plugin: registers the managed wecom-cli and its authorization with `ctx.cliAccounts`, which tells the model the
 * CLI's absolute path and shows the authorization on the Plugins page, and registers the `wecom` entry skill with
 * `ctx.upstreamSkills`, which downloads the upstream guides it indexes. The CLI's authorization is shared with the
 * user's own terminal.
 * @module @deepseek-ai/dsh-wecom
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin name. */
export declare const name = "wecom";
/** Services the CLI's authorization and the entry skill register with. */
export declare const inject: string[];
/** Where wecom-cli and the upstream guides are. */
export interface Config {
    /** Absolute directory holding the `wecom-cli` executable; defaults to the installed platform package of `@wecom/cli`. */
    binDir?: string;
    /** Absolute directory holding the upstream guides at their repository paths; when set, nothing is downloaded. */
    skillsDir?: string;
}
/** Validates {@link Config}. */
export declare const Config: z<Config>;
/**
 * Register the entry skill, and the CLI with its authorization, whose view follows the guides' download.
 * @param ctx - Context carrying the CLI account Service and the upstream skills Service.
 * @param config - CLI location and the guides' directory.
 * @throws when `wecom-cli` is not executable or `skillsDir` is not a directory.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map