/** The WeCom text the Plugins page shows; the browser resolves it in its active language. */
/** Chinese dictionary and key source. */
export declare const zh: {
    'section.title': string;
    'status.checking': string;
    'status.disconnected': string;
    'status.unavailable': string;
    'status.connected': string;
    'step.authorizing': string;
    'step.connecting': string;
    'detail.disconnected': string;
    'detail.unavailable': string;
    'detail.connected': string;
    'detail.authorizing': string;
    'skills.downloading': string;
    'skills.failed': string;
    hint: string;
    failed: string;
    'action.connect': string;
    'action.rebind': string;
    'rebind.title': string;
    'rebind.body': string;
    'bot.bound': string;
    'action.open': string;
    'action.cancel': string;
    'action.retry': string;
    'badge.connected': string;
    'badge.disconnected': string;
    'badge.connecting': string;
    'badge.unavailable': string;
    'activation.title': string;
    'activation.body': string;
    'notice.connected': string;
};
/** Every key of the WeCom text. */
export type WecomTextKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<WecomTextKey, string>;
/** Japanese dictionary. */
export declare const ja: Record<WecomTextKey, string>;
/** Spanish dictionary. */
export declare const es: Record<WecomTextKey, string>;
/** French dictionary. */
export declare const fr: Record<WecomTextKey, string>;
/** German dictionary. */
export declare const de: Record<WecomTextKey, string>;
/** Russian dictionary. */
export declare const ru: Record<WecomTextKey, string>;
/** Portuguese dictionary. */
export declare const pt: Record<WecomTextKey, string>;
/** The dictionary of every shipped language. */
export declare const dictionaries: {
    zh: {
        'section.title': string;
        'status.checking': string;
        'status.disconnected': string;
        'status.unavailable': string;
        'status.connected': string;
        'step.authorizing': string;
        'step.connecting': string;
        'detail.disconnected': string;
        'detail.unavailable': string;
        'detail.connected': string;
        'detail.authorizing': string;
        'skills.downloading': string;
        'skills.failed': string;
        hint: string;
        failed: string;
        'action.connect': string;
        'action.rebind': string;
        'rebind.title': string;
        'rebind.body': string;
        'bot.bound': string;
        'action.open': string;
        'action.cancel': string;
        'action.retry': string;
        'badge.connected': string;
        'badge.disconnected': string;
        'badge.connecting': string;
        'badge.unavailable': string;
        'activation.title': string;
        'activation.body': string;
        'notice.connected': string;
    };
    en: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
    ja: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
    es: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
    fr: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
    de: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
    ru: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
    pt: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.rebind" | "rebind.title" | "rebind.body" | "bot.bound" | "action.open" | "action.cancel" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "activation.title" | "activation.body" | "notice.connected", string>;
};
//# sourceMappingURL=locales.d.ts.map