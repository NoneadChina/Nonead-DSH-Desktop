/** Registry of code-host providers with provider-neutral change requests and shared status polling. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { BranchUpdateRequest, ChangeRequestBriefListener, ChangeRequestDescription, ChangeRequestKnownState, ChangeRequestListener, ChangeRequestRef, ChangeRequestSnapshot, ChangeRequestUpdate, ChangeRequestWatchOptions, Config, ForgeCommitList, ForgeActionFailure, ForgeDescription, ForgeFailure, ForgeProvider, ForgeReadiness, ForgeRepository, ForgeRerunRequest, ForgeReviewData, ForgeReviewChange, ForgeReviewerCandidate, ForgeReviewersRequest, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest, ForgeViewerFilter, ForgeViewerList, ForgeViewerQuery, ForgeViewerSource, MergeRequest } from './types.ts';
export { changeRequestKey } from './keys.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        forge: ForgeService;
    }
    interface Events {
        /**
         * Announces a provider registration or withdrawal after the registry changes.
         * Listener failures are logged without preventing other listeners from running.
         * @param forge - family whose provider changed.
         * @mode parallel
         */
        'forge/providers-changed'(forge: string): void | Promise<void>;
        /**
         * Announces a review change the host accepted through this service: a thread or pending-review write, a submitted
         * review, or a viewed mark. Changes whose outcome is unknown, refused, stale, or unsupported are not announced.
         * Listener failures are logged without preventing other listeners from running.
         * @param ref - change request the change went to.
         * @param change - what changed and the head commit it was made against.
         * @mode parallel
         */
        'forge/review-changed'(ref: ChangeRequestRef, change: ForgeReviewChange): void | Promise<void>;
    }
}
/**
 * Registry of forge providers. Watchers of one change request share a single
 * polling loop, which reads its snapshot while a snapshot watcher remains and
 * its brief otherwise. Each forge has at most one snapshot fetch and one brief
 * fetch in flight; each batches every due change request of that forge at its
 * level, and those past the midpoint of the wait after a status, so change
 * requests that became due at different times come to share one fetch. A fetch
 * calls a provider that names a batch size once per that many change requests
 * of a host, and settles the results of each call when it returns.
 */
export declare class ForgeService extends Service {
    static Config: z<Config>;
    private readonly config;
    private readonly providers;
    private readonly watches;
    /** Lanes with a fetch in flight, as {@link laneOf} names them. */
    private readonly fetching;
    private readonly pending;
    private readonly lifetime;
    private timer;
    /**
     * Poll what is due. A field rather than a method, so the timer runs it on
     * the instance itself: a polling round started through a caller's `ctx.forge`
     * would otherwise run on that caller's shadow receiver, and every later round
     * would nest one more shadow until a property write overflows the stack.
     */
    private readonly tick;
    constructor(ctx: Context, config: Config);
    /**
     * Register the provider of one forge family as an effect on the calling
     * fiber. Watches of that forge receive an `unavailable` failure when the
     * registration ends. Unregistering cancels and awaits its in-flight calls;
     * results from the withdrawn registration are discarded.
     * @param provider - provider to serve `provider.forge` on `provider.hosts`.
     * @returns the disposer that unregisters the provider and waits for its calls to finish.
     * @throws when another provider already serves the same forge or one of the same hosts, compared without case, and
     * when the provider names a batch size that is not a positive safe integer.
     */
    register(provider: ForgeProvider): () => Promise<void>;
    /**
     * Name a forge family and its change requests for readers.
     * @param forge - forge family name, such as `github`.
     * @returns the registered provider's description, or undefined when no provider serves the family.
     */
    describe(forge: string): ForgeDescription | undefined;
    /**
     * Map a Git remote URL to a repository through the provider that serves its host.
     * @param url - fetch or push URL as Git reports it.
     * @returns the repository, or undefined when no provider serves the URL.
     */
    repositoryFromRemote(url: string): ForgeRepository | undefined;
    /**
     * Map a change request web URL through the provider that serves its host.
     * @param url - web URL of a pull or merge request.
     * @returns the change request, or undefined when no provider serves the URL.
     */
    changeRequestFromUrl(url: string): ChangeRequestRef | undefined;
    /**
     * Build the canonical web URL of a change request.
     * @param ref - change request served by a registered provider.
     * @returns the provider's canonical URL.
     * @throws when no provider serves the change request's forge.
     */
    changeRequestUrl(ref: ChangeRequestRef): string;
    /**
     * Find open change requests whose head is `branch`, excluding the default branch and forks.
     * @param repository - repository served by a registered provider.
     * @param branch - head branch name on the host.
     * @param signal - cancellation for the lookup.
     * @returns matching change requests, newest first as the provider reports them.
     * @throws when no provider serves the repository's forge or the lookup fails.
     */
    findByHead(repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<readonly ChangeRequestRef[]>;
    /**
     * Report whether the provider can reach the repository's host with current credentials.
     * @param repository - repository served by a registered provider.
     * @param signal - cancellation for the probe.
     * @returns the provider's readiness for the host.
     * @throws when no provider serves the repository's forge.
     */
    readiness(repository: ForgeRepository, signal: AbortSignal): Promise<ForgeReadiness>;
    /**
     * Mark a draft change request ready for review, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the change, or why it did not.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    markReady(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Merge a change request while its head is still `request.headSha`, then
     * poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - merge method and the head commit the user confirmed.
     * @param signal - cancellation of the request.
     * @returns undefined once the host merged it, or why it did not.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    merge(ref: ChangeRequestRef, request: MergeRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Rerun the failed checks of a change request's head commit while the head is still `request.headSha`, then poll it
     * at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - the head commit whose checks the user saw.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the rerun, or why it did not; a provider that reruns no checks fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    rerunChecks(ref: ChangeRequestRef, request: ForgeRerunRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Request reviews of a change request from more reviewers, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - the reviewers to ask.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the request, or why it did not; a provider that requests no reviews fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    requestReviews(ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * List accounts a review of a change request can be requested from.
     * @param ref - change request served by a registered provider.
     * @param query - text the login or name contains; empty for the host's suggestions and first accounts.
     * @param signal - cancellation of the read.
     * @returns the accounts, the host's suggestions first, or why the host did not list them; a provider that requests no
     * reviews returns `unsupported`.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    reviewerCandidates(ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
    /**
     * Bring the base branch's new commits into a change request's head branch while its head is still
     * `request.headSha`, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - update method and the head commit the user confirmed.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the update, or why it did not; a provider that updates no branches fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    updateBranch(ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Read complete check details independently of periodic polling.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the detail view.
     * @returns a complete snapshot or the provider's failure; unsupported providers return unavailable.
     * @throws on cancellation, provider disposal, or expiry of this read's own `fetchTimeoutMs` deadline.
     */
    fetchChecks(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestSnapshot | ForgeFailure>;
    /**
     * Read the changes of a change request at one head commit as its host
     * computes them. The first `stale` failure at a head commit polls a watched
     * change request again at once, so its next status names the current head;
     * later stale reads at the same commit wait for the regular poll, which
     * bounds the reads while the host's answers disagree. When the latest status of a watched change request names
     * `headSha`, its `baseSha` goes to the provider, which may then read the patch while it confirms the head.
     * @param ref - change request served by a registered provider.
     * @param headSha - head commit the patch must describe, usually the head of the latest status.
     * @param signal - cancellation of the read.
     * @returns one unified patch with `a/` and `b/` path prefixes, or why the host did not provide it at `headSha`.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    diff(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Read the review threads of a change request at one head commit. A
     * `stale` failure polls a watched change request again as {@link ForgeService.diff} does.
     * @param ref - change request served by a registered provider.
     * @param headSha - head commit the threads must be read at, usually the head of the displayed diff.
     * @param signal - cancellation of the read.
     * @returns the threads read at `headSha`, or why the host did not provide them; `unsupported` when the provider cannot read reviews.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    readReview(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
    /**
     * Write to the review threads or the pending review of a change request while its head is still `write.headSha`, then
     * poll the change request at once when it is watched, unless the provider cannot write reviews. A `stale` result polls
     * it as a stale read does; a write the host took is announced with `forge/review-changed`.
     * @param ref - change request served by a registered provider.
     * @param write - the write and the head commit the user saw.
     * @param signal - cancellation of the write.
     * @returns whether the host took the write; `unsupported` when the provider cannot write reviews, and `unknown` when the
     * outcome must be checked on the host before the write is tried again.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    writeReview(ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * Read the signed-in user's viewed marks on the files of a change request at one head commit. A `stale` failure
     * polls a watched change request again as {@link ForgeService.diff} does.
     * @param ref - change request served by a registered provider.
     * @param headSha - head commit the marks must be read at, usually the head of the displayed diff.
     * @param signal - cancellation of the read.
     * @returns the marks read at `headSha`, why the host did not provide them, or undefined when the provider keeps no
     * viewed marks.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    viewedFiles(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeViewedFiles | ForgeFailure | undefined>;
    /**
     * Set or clear the signed-in user's viewed mark on one file of a change request while its head is still
     * `request.headSha`. A `stale` failure polls a watched change request again as {@link ForgeService.diff} does; a saved
     * mark is announced with `forge/review-changed`.
     * @param ref - change request served by a registered provider.
     * @param request - the file, its mark, and the head commit the user saw.
     * @param signal - cancellation of the request.
     * @returns undefined once the host saved the mark, or why it did not; a provider that keeps no viewed marks fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    setViewed(ref: ChangeRequestRef, request: ForgeViewedRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * List the commits of a change request at its current head.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the read.
     * @returns the commits, why the host did not provide them, or undefined when the provider does not read commits.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    commits(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure | undefined>;
    /**
     * Read the changes between two commits of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param base - full object name of the commit compared from.
     * @param head - full object name of a commit that descends from `base`.
     * @param signal - cancellation of the read.
     * @returns one unified patch with `a/` and `b/` path prefixes, or why the host did not provide it; a provider that
     * does not read commits returns `unavailable`.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    compare(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Find the merge base of two commits of a change request's repository: the commit whose files the old side of the
     * change request's diff shows when `base` is the snapshot's `baseSha` and `head` its `headSha`.
     * @param ref - change request served by a registered provider.
     * @param base - full object name of the base commit.
     * @param head - full object name of the head commit.
     * @param signal - cancellation of the read.
     * @returns the merge base's full object name, or why the host did not provide it; `unsupported` when the provider
     * cannot name merge bases.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    mergeBase(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * List the viewer lists every registered provider offers; `forge/providers-changed` announces a change.
     * @returns one source per provider that declares viewer lists and reads them, in registration order.
     */
    viewerSources(): ForgeViewerSource[];
    /**
     * Read one list of open change requests that involve the signed-in user.
     * @param forge - forge family of a registered provider.
     * @param query - host, list, repository, and limit of the read.
     * @param signal - cancellation of the read.
     * @returns the list, or why the host did not provide it; `unsupported` when the provider does not offer the host or list.
     * @throws when no provider serves `forge`, or with `signal.reason` when it aborts.
     */
    listForViewer(forge: string, query: ForgeViewerQuery, signal: AbortSignal): Promise<ForgeViewerList | ForgeFailure>;
    /**
     * Count the change requests in each viewer list a provider offers on one host.
     * @param forge - forge family of a registered provider.
     * @param host - lowercase host name the provider lists on.
     * @param signal - cancellation of the read.
     * @returns the count of each list, or why the host did not provide them; `unsupported` when the provider does not list on `host`.
     * @throws when no provider serves `forge`, or with `signal.reason` when it aborts.
     */
    countForViewer(forge: string, host: string, signal: AbortSignal): Promise<ReadonlyMap<ForgeViewerFilter, number> | ForgeFailure>;
    /**
     * Read the description and labels of a change request.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the read.
     * @returns the description, or why the host did not provide it; `unsupported` when the provider reads no descriptions.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    readDescription(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestDescription | ForgeFailure>;
    /**
     * Publish one comment or a completed review, then refresh the watched status; a publication the host took is announced
     * with `forge/review-changed`.
     * @param ref - change request served by a registered provider.
     * @param request - explicitly selected commit, comments, and review decision.
     * @param signal - request cancellation.
     * @returns a publication URL or a failure, including an unknown write outcome.
     */
    submitReview(ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Read the text of one file at a commit of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @param signal - cancellation of the read.
     * @returns the text, or why the host did not provide it.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    fileText(ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Build the web page of one file at a commit of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @returns the provider's URL.
     * @throws when no provider serves the change request's forge.
     */
    fileUrl(ref: ChangeRequestRef, commit: string, path: string): string;
    /**
     * Watch the snapshot of one change request as an effect on the calling fiber. Its first snapshot watcher polls it at
     * once, and a later one does when `options.maxAgeMs` is given and the latest result is older. Listeners receive every
     * later snapshot poll result, and `latest` returns the current one. While a snapshot watcher remains, polls read the
     * snapshot; polling stops when the last watcher of the snapshot and the brief leaves. Listeners must not throw; a
     * thrown error is logged and skipped.
     * @param ref - change request to poll.
     * @param listener - receives each snapshot poll result.
     * @param options - when the watcher needs a status newer than the latest one.
     * @returns the disposer that stops this watch.
     */
    watch(ref: ChangeRequestRef, listener: ChangeRequestListener, options?: ChangeRequestWatchOptions): () => void;
    /**
     * Watch the brief of one change request as an effect on the calling fiber. Listeners receive the brief of every
     * later poll result: of a brief read while only brief watchers remain, and of a snapshot read otherwise. The first
     * watcher of a change request polls it at once, or as `known` times it. Polling stops when the last watcher of the
     * snapshot and the brief leaves. Listeners must not throw; a thrown error is logged and skipped.
     * @param ref - change request to poll.
     * @param listener - receives the brief of each poll result.
     * @param known - the state the caller last saw, which times the first poll of a change request without a watcher.
     * @returns the disposer that stops this watch.
     */
    watchBrief(ref: ChangeRequestRef, listener: ChangeRequestBriefListener, known?: ChangeRequestKnownState): () => void;
    /**
     * Poll a watched change request at once, including after a terminal state.
     * A fetch already in flight is followed immediately by another fetch; an
     * unwatched change request is unchanged. With `options.maxAgeMs`, the caller
     * needs a status no older than that many milliseconds: a change request
     * whose latest poll at either level, in flight or settled, started within
     * them is left alone, and so is a merged one, whose status is final.
     * @param ref - change request to poll.
     * @param options - when the caller needs a status newer than the latest one.
     */
    refresh(ref: ChangeRequestRef, options?: ChangeRequestWatchOptions): void;
    /**
     * Announce that a watched change request is about to change, as after a push to its head branch. It is polled at
     * once and then every `activeIntervalMs`, until a status reports running checks or a closed or merged change
     * request, and for at most `idleIntervalMs`; after that the regular cadence applies. A fetch already in flight is
     * followed immediately by another fetch; an unwatched change request is unchanged.
     * @param ref - change request the caller expects to change.
     */
    expectChange(ref: ChangeRequestRef): void;
    /**
     * Read the latest snapshot poll result of a watched change request.
     * @param ref - change request to read.
     * @returns the latest result, or undefined before the first snapshot poll settled or without a watch.
     */
    latest(ref: ChangeRequestRef): ChangeRequestUpdate | undefined;
    /** The watch of a change request, created with `timing` when it has none. */
    private open;
    /** Stop polling a change request once its last watcher left. */
    private close;
    /** Poll a watched change request at once after the first `stale` read or write at `headSha`; later ones wait for the regular poll. */
    private staleRead;
    /**
     * Run one optional provider action, then poll the change request at once when it is watched and the provider has the
     * action.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the action.
     * @param pick - the provider's action, or undefined when it lacks the capability.
     * @param missing - what a provider without the action does not do, for its failure.
     * @param run - calls the action.
     * @returns the action's failure, or undefined once the host accepted it.
     */
    private act;
    private provider;
    private providersChanged;
    private reviewChanged;
    /**
     * Start one parallel dispatch unless the service stopped, keeping it among the work disposal waits for and logging
     * listener failures.
     */
    private announce;
    private registration;
    private invoke;
    private missing;
    private schedule;
    private poll;
    /**
     * Fetch one forge's batch at one level, as briefs when the level is `brief` and the provider reads them. The batch
     * is read in the parts {@link partsOf} names, one provider call after another; each call has its own
     * `fetchTimeoutMs` deadline, and its watches are settled before the next call starts, so a call that fails or
     * outlives its deadline fails only its own change requests. Never rejects.
     */
    private fetch;
    /**
     * Take the watches of one part that its provider call reads: those still watched that no fetch of the other level
     * has read since the fetch started. A watch whose watchers changed its level while it waited is made due for the
     * fetch of that level instead.
     */
    private claim;
    /** Read one part of a batch within its own `fetchTimeoutMs` deadline; a call that rejects or outlives it is the part's failure. */
    private read;
    /**
     * Record one poll result of a watch, time its next poll, and deliver the result: a snapshot or a snapshot-level
     * failure to both kinds of watchers, a brief or a brief-level failure to brief watchers only.
     */
    private settle;
    private deliver;
}
export default ForgeService;
//# sourceMappingURL=index.d.ts.map