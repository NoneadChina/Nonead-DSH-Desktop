/**
 * Multilingual fuzzy search over an in-memory list.
 *
 * A {@link TextSearchIndex} prepares every key of a list once, then answers
 * any number of queries over that list. `fuzzy` keys (names, titles, labels,
 * readable ids) match as substrings or as fuzzysort subsequences that start at
 * a word start, so `cpt` finds `compact` while `fab` does not match inside
 * `Refactor build`. `substring` keys (descriptions, prompts, paths, opaque
 * ids) match only as a contiguous substring of each query term: a subsequence
 * scattered across a long sentence is noise. Every key may carry several
 * values, such as every language of a localized title. Both key kinds ignore
 * case, width (NFKC), U+0300–U+036F diacritics, and the stroke of letters such
 * as `ł` and `ø`. Matching requires every whitespace-separated query term to
 * match some key of the item.
 *
 * Each term scores by its best tier: a fuzzy-key prefix, then a fuzzy-key
 * substring, then a fuzzy subsequence ordered by fuzzysort score, then a
 * substring-key hit. Equal scores keep the build order, so a term that
 * prefixes every name leaves the list in product order.
 *
 * @module @deepseek-ai/dsh-util-text-search
 */
import type { LocalizedText } from '@deepseek-ai/dsh-package-manifest';
/** The text one item offers to a search; absent and empty values never match. */
export interface SearchKeys {
    /** Short identifying text matched as substrings or word-start fuzzy subsequences, ranked first: names, titles, labels, readable ids. */
    readonly fuzzy?: readonly (string | undefined)[];
    /** Longer text and opaque ids matched only as contiguous substrings: descriptions, prompts, paths, UUIDs. */
    readonly substring?: readonly (string | undefined)[];
}
/**
 * Every language of a localized value.
 * @param text - plain or localized text.
 * @returns the plain string, or every locale's value; none when absent.
 */
export declare function localizedValues(text: LocalizedText | undefined): readonly string[];
/**
 * Search index over one list. The constructor prepares every key of every
 * item; {@link TextSearchIndex.search} then answers queries without
 * re-reading the items or their keys. An index holds its list by reference and
 * never changes: callers must not mutate the list or its items, and call
 * {@link TextSearchIndex.update} with a new list when the list or any item's
 * keys change.
 */
export declare class TextSearchIndex<T> {
    #private;
    /**
     * Prepare every key of every item.
     * @param items - candidates in their display order, which ties keep.
     * @param keys - the search text of one item, called once per item here.
     */
    constructor(items: readonly T[], keys: (item: T) => SearchKeys);
    /**
     * Build the index of a changed list. Items added, removed, reordered, or
     * changed are all expressed by the complete new list; a key string that this
     * index already prepared is reused instead of prepared again, and strings no
     * item uses any more are not carried over. This index stays valid.
     * @param items - the complete new list in display order.
     * @param keys - the search text of one item, called once per item here.
     * @returns a new index over `items`.
     */
    update(items: readonly T[], keys: (item: T) => SearchKeys): TextSearchIndex<T>;
    /**
     * Filter and rank the indexed items by a query.
     * @param query - the user's search text.
     * @returns the build list itself when the query is blank or holds only
     * combining marks; otherwise the items matching every query term, best total
     * score first and build order on ties.
     */
    search(query: string): readonly T[];
}
//# sourceMappingURL=index.d.ts.map