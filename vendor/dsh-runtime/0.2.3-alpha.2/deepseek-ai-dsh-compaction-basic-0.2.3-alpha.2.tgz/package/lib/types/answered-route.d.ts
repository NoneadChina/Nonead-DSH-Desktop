/**
 * Host-only Session projection of the route that produced the latest assistant message.
 *
 * @module @deepseek-ai/dsh-compaction-basic/answered-route
 */
import { z } from 'zod';
/** Provider/model pair recorded on the latest assistant message; `null` before the first one. */
export type AnsweredRoute = {
    provider: string;
    model: string;
} | null;
/**
 * Fold of every `assistant/message` source. A request that ends without an
 * assistant message, such as one the provider rejects, leaves the state unchanged.
 */
export declare const answeredRouteProjectionDefinition: {
    key: "compactionAnsweredRoute";
    stateVersion: number;
    stateSchema: z.ZodNullable<z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
    }, z.core.$strict>>;
    init: () => AnsweredRoute;
    apply: (state: NoInfer<AnsweredRoute>, event: import("@deepseek-ai/dsh-session").SessionEvent) => AnsweredRoute;
};
//# sourceMappingURL=answered-route.d.ts.map