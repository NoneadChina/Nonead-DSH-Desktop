import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Compiler invocation and lock shared by preparations using the same scratch files. */
interface NativeCompilerBuild {
    packageRoot: string;
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    signal: AbortSignal;
    timeoutMs: number;
    graceMs: number;
    argv: string[];
    /** Compiler lock target; shared across outputs that write the same intermediate build files. */
    lockPath: string;
}
/**
 * Recognize a declared package directory inside a DSH source checkout.
 * @param packageRoot - Real directory containing the platform package.
 * @param directory - Repository-relative source directory owned by that provider.
 * @returns Whether source compilation is permitted at this location.
 */
export declare function sourceNativePackage(packageRoot: string, directory: string): Promise<boolean>;
/**
 * Run the compiler under its build lock, then resolve the platform-owned executable.
 * @param spec - Compiler and resource limits, with a callback locating the built executable.
 * @returns Platform executable path after managed process cleanup.
 */
export declare function buildNativeExecutable(spec: NativeCompilerBuild & {
    resolveExecutable: () => Promise<string>;
}): Promise<string>;
export {};
//# sourceMappingURL=native-build.d.ts.map