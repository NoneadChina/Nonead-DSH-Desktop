import { HarnessError } from '@deepseek-ai/dsh-error';
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { ToolExecution } from '@deepseek-ai/dsh-tools';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { Readable, Writable } from 'node:stream';
/**
 * Native refusal, transport failure, or host-side CUA refusal with a stable machine-readable code.
 * The helper supplies its own codes, such as `APP_ACCESS_DENIED` or `STALE_SNAPSHOT`, so consumers
 * tolerate unknown codes; the host adds `NATIVE_*` transport codes, application-access codes,
 * and `MODEL_DOES_NOT_SUPPORT_IMAGES` for a screenshot requested by a model without image input.
 */
export declare class NativeError extends HarnessError {
    /**
     * @param code - Native error code or a host-owned code.
     * @param message - Actionable diagnostic, without its code prefix.
     * @param options - Original failure when available.
     */
    constructor(code: string, message: string, options?: ErrorOptions);
}
/** Resolved helper executable and bounded process/response configuration. */
export interface NativeClientConfig {
    helperPath: string;
    cwd: string;
    timeoutMs: number;
    connectTimeoutMs: number;
    screenshotTimeoutMs: number;
    axTimeoutMs: number;
    maxRequestBytes: number;
    maxResponseBytes: number;
    graceMs: number;
    textEventIntervalMs: number;
    maxClickHoldMs: number;
}
/** One Agent's ordered connection to native operations and cleanup acknowledgement. */
export interface NativeChannel {
    readonly stdin: Writable;
    readonly stdout: Readable;
    readonly done: Promise<void>;
    /** Stop writes and release this connection's native state. */
    close(): void;
    /** @returns Completion after the connection and its owned startup processes close. */
    waitForClose(): Promise<void>;
}
/**
 * Open the platform connection with the configured resource bounds.
 * @param owner - Managed subprocess provider for startup and cleanup.
 * @param config - Executable, operation limits, and deadlines.
 * @returns Agent-owned native byte stream and its cleanup acknowledgement.
 */
export type NativeChannelFactory = (owner: {
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
}, config: NativeClientConfig) => NativeChannel;
/** One Agent owns this connection and its native handles; other Agents use independent connections. */
export declare class NativeClient {
    private readonly reportDiagnostic?;
    private readonly handle;
    private readonly config;
    private readonly chunks;
    private bufferedBytes;
    private failure;
    private disposal;
    private transportClosed;
    private readonly cleanups;
    private diagnostics;
    private diagnosticBytes;
    private discardedDiagnostics;
    private active;
    /**
     * @param owner - Managed subprocess provider.
     * @param config - Executable, transport bounds and deadlines.
     * @param createChannel - Platform-owned connection and process lifecycle.
     * @param reportDiagnostic - Optional Host diagnostic sink; never receives captured content.
     */
    constructor(owner: {
        subprocess: Pick<SubprocessRuntime, 'spawn'>;
    }, config: NativeClientConfig, createChannel: NativeChannelFactory, reportDiagnostic?: ((message: string) => void) | undefined);
    /**
     * Send one operation after any active native cleanup acknowledges completion.
     * Native refusals preserve this connection; transport failures invalidate its handles.
     * @param method - Helper operation name.
     * @param params - JSON operation parameters.
     * @param signal - Cancellation stops this request; the connection survives when native cleanup acknowledges it.
     * @param callId - Logged tool invocation ID, when this request belongs to a tool execution.
     * @returns The validated helper result, after failure cleanup when needed.
     */
    request(method: string, params: Record<string, JsonValue>, signal: AbortSignal, callId?: ToolExecution['callId']): Promise<JsonValue>;
    private send;
    /**
     * Dispatch cleanup after any active request acknowledges completion or cancellation.
     * Available during graceful disposal. A refusal or timeout invalidates the connection; cleanup
     * awaits its closure before rejecting. Distinct operation and close failures are aggregated.
     * @param method - Host-only helper cleanup operation.
     * @param params - Resources owned by the enclosing execution.
     * @returns The native cleanup acknowledgement, bounded by the connection's request deadline.
     */
    requestCleanup(method: string, params: Record<string, JsonValue>): Promise<JsonValue>;
    /** Await owned cleanup while retaining the operation's original failure. */
    private rejectAfterCleanup;
    /**
     * Register resource cleanup before graceful connection closure.
     * @param cleanup Stops resource admission and releases native state through requestCleanup.
     * canRequest is false after forced closure; then perform local cleanup only. A true value
     * does not guarantee that the transport survives the callback. Never call request or dispose here.
     * @returns Removal after the resource's normal cleanup settles; an admitted callback remains awaited.
     * @throws NativeError when the connection has failed or disposal has begun.
     */
    registerCleanup(cleanup: (canRequest: boolean) => Promise<void>): () => void;
    private screenshotDiagnostics;
    private retainDiagnostic;
    private diagnostic;
    /** Whether this connection rejects new operations because it failed or is closing. */
    get disposed(): boolean;
    /** Invalidate this Agent's handles and close its connection; await dispose for native cleanup. */
    invalidate(): void;
    /** Stop new operations, settle registered resources, and await connection closure even when cleanup fails. */
    dispose(): Promise<void>;
    /** Join transport closure without invoking resource callbacks or waiting on their disposal. */
    private waitForTransportClose;
    /** Reject execution after an asynchronous transport callback invalidates the connection. */
    private throwIfFailed;
    private fail;
    private receive;
    private receiveFrame;
}
//# sourceMappingURL=native-client.d.ts.map