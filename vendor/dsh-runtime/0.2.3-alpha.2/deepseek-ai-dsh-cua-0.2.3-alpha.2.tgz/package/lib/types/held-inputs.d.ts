/** Native-owned held input, program-end reminders, and failure/cancellation cleanup. */
import type { Context } from '@deepseek-ai/cordis';
import { type Agent } from '@deepseek-ai/dsh-agent';
import { z } from 'zod';
import { type NativeClient } from './native-client.ts';
declare const heldInputs: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"key">;
    key: z.ZodString;
    windowId: z.ZodOptional<z.ZodString>;
    appHandle: z.ZodString;
    mode: z.ZodEnum<{
        window: "window";
        application: "application";
        system: "system";
    }>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"mouse">;
    button: z.ZodEnum<{
        left: "left";
        right: "right";
        middle: "middle";
    }>;
    windowId: z.ZodString;
    appHandle: z.ZodString;
    mode: z.ZodEnum<{
        window: "window";
        application: "application";
        system: "system";
    }>;
}, z.core.$strip>], "kind">>;
declare class InputOwner {
    private readonly failed;
    private readonly released;
    readonly controller: AbortController;
    private client;
    private removeCleanup;
    private notifySessionOnRelease;
    closing: Promise<z.infer<typeof heldInputs>> | undefined;
    constructor(failed: (error: unknown) => void, released: (inputs: z.infer<typeof heldInputs>) => void);
    track(client: NativeClient, inTurn: boolean): void;
    reminder(inTurn: boolean): Promise<string | undefined>;
    close(canRequest?: boolean): Promise<z.infer<typeof heldInputs>>;
    settled(): Promise<void>;
}
/** One provider's held input owners; the helper remains the authority for which inputs are pressed. */
export declare class CuaHeldInputs {
    private readonly ctx;
    private readonly owners;
    private readonly programOwners;
    private readonly failures;
    private readonly turnSignals;
    /** @param ctx - Provider scope owning input observers and program middleware. */
    constructor(ctx: Context);
    /**
     * Wait for cleanup and obtain an owner for a new operation.
     * @param agent - Agent issuing a CUA operation.
     * @returns Ownership and cancellation shared by its held inputs.
     */
    ready(agent: Agent): Promise<InputOwner>;
    /**
     * Stop owned dispatch and release held input with an independent bounded native request.
     * @param agent - Agent whose input must be released.
     * @returns Completion after native acknowledgement, or rejection if cleanup is unconfirmed.
     */
    release(agent: Agent): Promise<void>;
    private stop;
    /**
     * Observe program outcomes and cancellation while retaining native cleanup dependencies.
     * @returns Exact disposers retained until programs and native connections have drained.
     */
    install(): Generator<() => void>;
}
export {};
//# sourceMappingURL=held-inputs.d.ts.map