import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import { type ImageAttachmentRef, type ImageRequestTarget } from '@deepseek-ai/dsh-attachment';
import type { CuaConfig } from './index.ts';
import type { CuaScreenshotTargetConfig } from './config.ts';
/** Host control over the dedicated `cua_run_code` environments; registered as `ctx.cuaPrograms`. */
export interface CuaPrograms {
    /**
     * Release one Agent's retained program environment with the dedicated runtime's owner release. The program
     * process exits, a program of that Agent that is still running fails as aborted, and the next `cua_run_code`
     * call starts a fresh process that re-creates the `cua` global. The Agent, its application grants and native
     * connection, and the desktop applications themselves are unaffected. Held input is released. The runtime rejects that Agent's
     * programs until the release settles, so the caller holds them back; after a failed release it rejects them
     * until a later release succeeds. Resolves when no environment exists.
     * @param agent - Agent whose `cua_run_code` state owner is released.
     * @returns Completion after the process has exited, its output has drained, and held-input cleanup has settled.
     * @throws When environment or input cleanup fails, reporting both causes if both fail.
     */
    release(agent: Agent): Promise<void>;
    /**
     * Release the Agent's tracked input while retaining its program variables and application grants.
     * Providers without held-input state support retain their existing cancellation behavior.
     * @param agent - Owner of the input to release.
     * @returns Completion after native acknowledgement, or rejection when cleanup is unconfirmed.
     */
    releaseInputs(agent: Agent): Promise<void>;
    /**
     * Request-image target the provider delivered for a stored screenshot when `screenshotTarget` is configured.
     * A host that forwards screenshots outside a model request reads the same request version with it, so the
     * image a caller sees matches the coordinate space the provider mapped.
     * @param image - Durable screenshot attachment from a `cua` result.
     * @returns The fixed target, or undefined when the Agent's model route selects the delivered version.
     */
    screenshotRequestTarget(image: ImageAttachmentRef): ImageRequestTarget | undefined;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Present while the CUA provider owns a dedicated program runtime. */
        cuaPrograms: CuaPrograms;
    }
}
/**
 * Project a configured screenshot target onto one stored image.
 * @param configured - Validated `screenshotTarget`.
 * @param image - Durable normalized screenshot.
 * @returns Maximum screenshot dimensions, with the configured byte value as both the hard limit and the soft target.
 */
export declare function fixedScreenshotTarget(configured: CuaScreenshotTargetConfig, image: ImageAttachmentRef): ImageRequestTarget;
/**
 * Register raw CUA for Agents on the configured preset and a persistent program tool for every other Agent,
 * including Agents without a preset and compositions without a preset registry.
 * @param ctx Provider context owning native calls and registrations.
 * @param config Validated preset selection and dedicated runtime bounds.
 * @param tool Internal native tool; Agents off the configured preset can reach it only through the program.
 * @param guidance Raw-tool operation instructions for the configured preset.
 * @param programGuidance Operation instructions available inside cua_run_code.
 * @param releaseInputs Release tracked input on cancellation or environment reset.
 * @returns Exact registration disposer, draining programs before native resources can close.
 */
export declare function installCuaTools(ctx: Context, config: CuaConfig, tool: ToolDefinition, guidance: string, programGuidance: string, releaseInputs: (agent: Agent) => Promise<void>): () => void | Promise<void>;
//# sourceMappingURL=tool-registration.d.ts.map