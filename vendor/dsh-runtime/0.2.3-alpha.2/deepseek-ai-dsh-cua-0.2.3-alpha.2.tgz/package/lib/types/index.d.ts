import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import { NativeClient, type NativeChannelFactory } from './native-client.ts';
import { installCuaAccess } from './access.ts';
import type { CuaApplicationGrant, CuaSystemPermission } from './access-types.ts';
import type { CuaAppHandle, CuaStartupCapabilities } from './types.ts';
import { type CuaScreenshotTargetConfig, type CuaStandaloneRunCodeConfig } from './config.ts';
export { CuaAccess } from './access.ts';
export type { CuaStartupCapabilities } from './types.ts';
export type { CuaPrograms } from './tool-registration.ts';
/** Native executable and per-operation resource bounds. */
export interface CuaConfig {
    /** Ask once per live Session before explicitly requested system keyboard or mouse input. */
    requireSystemInputApproval: boolean;
    /**
     * Preset receiving raw cua; every other Agent, with or without a preset, receives cua_run_code while its
     * program services are available. False registers raw cua globally.
     */
    agentPreset: string | false;
    /** Dedicated persistent program limits, independent of the profile's PTC runtime. */
    standaloneRunCode: CuaStandaloneRunCodeConfig;
    /**
     * Fixed request-image target for screenshots. Omission resolves the target from the Agent's model
     * route and refuses capture when that route declares no image input.
     */
    screenshotTarget?: CuaScreenshotTargetConfig | undefined;
    /** Legacy grants imported once into profile-scoped storage; later edits are ignored. */
    allowedApps: Array<Omit<CuaApplicationGrant, 'id'> & {
        /** Unbranded digest at the profile configuration boundary; admitted by the Config schema. */
        id: string;
    }>;
    /** Absolute executable inside the signed macOS helper .app; omission prepares the package-owned application. */
    helperPath?: string;
    /** Maximum time in milliseconds for native component preparation. */
    buildTimeoutMs: number;
    /** Deadline for one native operation, including capture and AX traversal. */
    timeoutMs: number;
    /** Maximum time to connect to or start the shared native helper. */
    connectTimeoutMs: number;
    /** Screenshot deadline including time queued behind other native operations. */
    screenshotTimeoutMs: number;
    /** Deadline for each individual Accessibility system call. */
    axTimeoutMs: number;
    /** Maximum bytes retained for one helper response frame. */
    maxResponseBytes: number;
    /** Maximum installed application matches returned for one discovery query. */
    maxAppMatches: number;
    /** Provider-specific clipboard byte limit for paste. */
    maxClipboardBytes: number;
    /** Provider-specific paste wait budget in milliseconds. */
    pasteReadTimeoutMs: number;
    /** Maximum UTF-8 bytes admitted for one helper request frame. */
    maxRequestBytes: number;
    /** Duration in milliseconds of one same-window drag. */
    dragDurationMs: number;
    /** Maximum explicitly requested mouse-button hold in milliseconds; zero allows immediate release only. */
    maxClickHoldMs: number;
    /** Number of movement segments dispatched during a drag. */
    dragSteps: number;
    /** Delay in milliseconds after each Unicode key-down or key-up event. */
    textEventIntervalMs: number;
    /** Native connection cleanup, socket-write and launcher termination budget in milliseconds. */
    graceMs: number;
    /** Default node limit when an accessibility read omits maxElements. */
    maxElements: number;
    /** Default depth limit when an accessibility read omits maxDepth. */
    maxDepth: number;
}
/** Validate shared configuration for native providers. */
export declare const CuaConfig: Schema<Schemastery.ObjectS<NoInfer<{
    requireSystemInputApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    standaloneRunCode: Schema<Partial<CuaStandaloneRunCodeConfig>, CuaStandaloneRunCodeConfig, "defined">;
    screenshotTarget: Schema<CuaScreenshotTargetConfig | undefined, CuaScreenshotTargetConfig | undefined, "plain">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    requireSystemInputApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    standaloneRunCode: Schema<Partial<CuaStandaloneRunCodeConfig>, CuaStandaloneRunCodeConfig, "defined">;
    screenshotTarget: Schema<CuaScreenshotTargetConfig | undefined, CuaScreenshotTargetConfig | undefined, "plain">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
}>>, "plain">;
/** Window read on a session's authorized native connection. */
export interface CuaWindowRead {
    agent: Agent;
    client: NativeClient;
    access: Pick<ReturnType<typeof installCuaAccess>, 'readCached'>;
    appHandle: CuaAppHandle;
    windowId: string;
}
/** Prepared platform executable, transport, platform-specific instructions and startup capabilities. */
export interface CuaBackend {
    helperPath: string;
    createChannel: NativeChannelFactory;
    /**
     * Stop the provider's shared transport after every Agent and permission connection has closed.
     * @returns Transport shutdown completion.
     */
    disposeNative?(): Promise<void>;
    /**
     * Select platform operation instructions for the exposed tool form.
     * @param kind Raw cua calls or standalone cua_run_code programs.
     * @returns Instructions before shared capability guidance and configured limits are added.
     */
    getGuidance(kind: 'raw' | 'standalone'): string;
    capabilities: CuaStartupCapabilities;
    /** Preserve discovery PIDs when getApp accepts a decimal PID as an exact process selector. */
    acceptsPidSelector?: boolean;
    /** Opt in to connection-scoped getHeldInputs and releaseHeldInputs; omission preserves the provider's existing protocol. */
    heldInputState?: boolean;
    /** Registers a window read. The returned receipt handler sees the native reply only after Host decoding succeeds. */
    windowRead?: (read: CuaWindowRead) => (reply: JsonValue) => void;
    /**
     * Build native permission parameters for the selected action and Client language.
     * @param method Native permission action.
     * @param permission System privilege selected by the user.
     * @param locale Current Client language.
     * @returns Parameters accepted by the provider's native implementation.
     */
    permissionParameters: (method: 'requestPermission' | 'openPermissionSettings', permission: CuaSystemPermission, locale: string) => Record<string, JsonValue>;
}
/**
 * Install authorized CUA calls and Agent-owned native connections.
 * @param ctx - Provider context with computer-use, subprocess, tools, prompt, and Agent services.
 * @param config - Validated resource limits and live application grants.
 * @param backend - Platform-owned executable, connection factory, and instructions.
 */
export declare function installCua(ctx: Context, config: CuaConfig, backend: CuaBackend): void;
/** Host marker for the optional Client contribution; platform providers install native execution separately. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map