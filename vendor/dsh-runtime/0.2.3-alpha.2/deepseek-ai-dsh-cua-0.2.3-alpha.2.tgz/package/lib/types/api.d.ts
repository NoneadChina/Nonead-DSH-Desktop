import type { CuaApi, CuaDispatch } from './types.ts';
export type * from './types.ts';
/**
 * Create app/window objects using the caller's authorized program dispatcher.
 * @param dispatch - Current tool authority; screenshots resolve to program Images and rejections propagate without retries.
 * @returns Objects independent of variable storage and evaluator lifecycle.
 */
export declare function createCuaApi(dispatch: CuaDispatch): CuaApi;
//# sourceMappingURL=api.d.ts.map