/** JSON validation shared by model tool admission and the native object facade. */
import { Buffer } from 'node:buffer'
import { z } from 'zod'
import type { ObjectJsonSchema } from '@deepseek-ai/dsh-tools'
import type { CuaAppHandle, CuaSnapshotId } from './types.ts'

const windowId = z.string().min(1)
const pixelDimension = z.number().int().positive().max(2 ** 32 - 1)
const point = z.number().nonnegative()
const relativePoint = z.number().int().min(0).max(999)
const traversalLimit = z.number().min(1).multipleOf(1)
const nativeTraversalLimits = z.object({
  maxElements: z.number().int().min(1).max(10000),
  maxDepth: z.number().int().min(1).max(100),
}).strict()
const app = { appHandle: z.string().min(1) }
const pointer = { mouseButton: z.enum(['left', 'right', 'middle']).optional(),
  modifiers: z.array(z.enum(['command', 'control', 'ctrl', 'option', 'alt', 'shift', 'win', 'fn'])).optional() }
const click = { ...pointer, clickCount: z.union([z.literal(1), z.literal(2)]).optional(),
  holdMs: z.number().int().nonnegative().optional()
    .describe('Milliseconds between each mouse press and release; omitted for an ordinary click.') }
const window = { ...app, windowId }
const jsonValue = z.json()
/** Provider-issued element reference from an accessibility observation. */
export const elementId = z.string().min(1)
  .describe('Opaque string defined by the platform provider, valid for at least the lifetime of one snapshot.')
const snapshot = { ...app, windowId: windowId.optional(), snapshotId: z.string().min(1), elementId }
const coordinate = { ...window, snapshotId: z.string().min(1).optional(), x: point, y: point }
const absoluteCoordinate = { ...coordinate, relative: z.literal(false).optional().describe('Omitted or false uses pixels in the latest screenshot returned by this tool.') }
const relativeCoordinate = { ...coordinate, relative: z.literal(true).describe('Use integer thousandths of the window width and height, from 0 to 999.'), x: relativePoint, y: relativePoint }
const bounds = z.object({
  x: z.number(), y: z.number(), width: z.number().nonnegative(), height: z.number().nonnegative(),
})
const operation = <M extends string, S extends z.ZodRawShape>(method: M, params: S) => z.object({
  method: z.literal(method), params: z.object(params).strict(),
}).strict()
// Native responses are byte-bounded before parsing. Exact re-encoding also rejects
// whitespace, missing padding and nonzero pad bits without a recursive regex.
const imageBase64 = z.string().min(1).refine(value => Buffer.from(value, 'base64').toString('base64') === value, {
  message: 'Expected canonical base64 image data',
})

/** Shared hover target variants. Providers may add options without replacing a target or its coordinate mode. */
export const MouseMoveTargets = [
  z.object(snapshot).strict(), z.object(absoluteCoordinate).strict(), z.object(relativeCoordinate).strict(),
] as const

const dragTargets = [
  z.object({ ...window, ...pointer, snapshotId: z.string().min(1).optional(), relative: z.literal(false).optional(),
    fromX: point, fromY: point, toX: point, toY: point }).strict(),
  z.object({ ...window, ...pointer, snapshotId: z.string().min(1).optional(), relative: relativeCoordinate.relative,
    fromX: relativePoint, fromY: relativePoint, toX: relativePoint, toY: relativePoint }).strict(),
] as const

const systemInputOption = {
  useSystemInput: z.boolean().optional().describe('True sends system keyboard or mouse input and presses any requested keyboard modifiers. Omitted or false uses the provider default.'),
}

const toggle = z.object({ ...window, mouseButton: pointer.mouseButton.unwrap(), direction: z.enum(['down', 'up']) }).strict()

function requestSchema<I extends z.ZodRawShape>(input: I) {
  return z.discriminatedUnion('method', [
    operation('getCapabilities', {}), operation('listApps', {}),
    operation('findApps', { query: z.string().min(1, 'Expected a non-empty search string').regex(/\S/, 'Expected a non-empty search string') }),
    operation('getApp', { selector: z.string().min(1) }),
    operation('activate', app),
    operation('show', { ...app, windowId: windowId.optional() }),
    operation('listWindows', app),
    operation('getState', { ...app, windowId: windowId.optional(),
      includeMenus: z.boolean().optional().describe('Expand menu contents; omitted or false shows menu-bar entries only.'),
      details: z.boolean().optional().describe('Include identifiers, global native bounds and complete action names.'),
      maxElements: traversalLimit.optional().describe('Maximum nodes to visit on this read. Omission uses the provider setting.'),
      maxDepth: traversalLimit.optional().describe('Maximum depth to traverse on this read. Omission uses the provider setting.'),
    }),
    operation('listActions', snapshot),
    operation('getActionSchema', { action: z.string().min(1) }),
    operation('performAction', { ...snapshot, action: z.string().min(1), argument: jsonValue.optional() }),
    operation('invoke', snapshot),
    z.object({ method: z.literal('toggleMouse'), params: toggle.extend(input) }).strict(),
    z.object({ method: z.literal('mouseMove'), params: z.union(MouseMoveTargets.map(target => target.extend(input))) }).strict(),
    z.object({ method: z.literal('click'), params: z.union([
      z.object({ ...snapshot, ...click, ...input }).strict(),
      z.object({ ...absoluteCoordinate, ...click, ...input }).strict(),
      z.object({ ...relativeCoordinate, ...click, ...input }).strict(),
    ]) }).strict(),
    operation('setValue', { ...snapshot, value: jsonValue }),
    operation('selectText', { ...snapshot, text: z.string().min(1), prefix: z.string().optional(), suffix: z.string().optional(),
      selectionType: z.enum(['text', 'cursor_before', 'cursor_after']).optional() }),
    operation('typeText', { ...app, windowId: windowId.optional(), text: z.string() }),
    operation('paste', { ...app, windowId: windowId.optional(), text: z.string(), format: z.enum(['text', 'html']).optional() }),
    operation('pressKey', { ...app, ...input, windowId: windowId.optional(), key: z.string().min(1), modifiers: z.array(z.string()).optional() }),
    operation('sendKeyEvent', { ...app, ...input, windowId: windowId.optional(), key: z.string().min(1), direction: z.enum(['down', 'up']) }),
    z.object({ method: z.literal('scroll'), params: z.union([
      z.object({ ...absoluteCoordinate,
        deltaLinesX: z.number().int().min(-10).max(10), deltaLinesY: z.number().int().min(-10).max(10) }).strict(),
      z.object({ ...relativeCoordinate,
        deltaLinesX: z.number().int().min(-10).max(10), deltaLinesY: z.number().int().min(-10).max(10) }).strict(),
    ]) }).strict(),
    z.object({ method: z.literal('drag'), params: z.union(dragTargets.map(target => target.extend(input))) }).strict(),
    operation('screenshot', window),
  ])
}

/** Portable operations for providers without explicit system-input selection. */
export const Request = requestSchema({})

/** Operations for providers supporting explicit system mouse input and keyboard modifiers. */
export const SystemInputRequest = requestSchema(systemInputOption)

/** Native resource fields supplied or completed by the Host before dispatch. */
export const NativeResourceParameters = {
  getState: nativeTraversalLimits,
  drag: z.object({ durationMs: z.number().int().min(1).max(5000), steps: z.number().int().min(1).max(240) }).strict(),
  paste: z.object({ maxClipboardBytes: z.number().int().min(1024), pasteReadTimeoutMs: z.number().int().min(1).max(2 ** 31 - 1),
    ...nativeTraversalLimits.shape,
  }).strict(),
  findApps: z.object({ maxAppMatches: z.number().int().min(1).max(1000) }).strict(),
}
/** Host-only launch, permission, and held-input operations; absent from model arguments. */
export const NativeOnlyOperations = [
  operation('launchApp', app), operation('permissionStatus', {}),
  operation('applicationIcons', { paths: z.array(z.string().min(1)) }),
  operation('requestPermission', { permission: z.enum(['accessibility', 'screenRecording']) }),
  operation('openPermissionSettings', { permission: z.enum(['accessibility', 'screenRecording']) }),
  operation('getHeldInputs', {}), operation('releaseHeldInputs', {}),
] as const

/** Application selection returned only after a successful app selection. */
export const AppResult = z.object({
  appHandle: z.string().min(1).transform(value => value as CuaAppHandle),
  name: z.string(), bundleId: z.string().optional(), running: z.boolean(),
})
const processId = z.number().int().positive().max(2 ** 31 - 1)
const appProcess = z.discriminatedUnion('isRunning', [
  z.object({ isRunning: z.literal(true), pid: processId.optional() }),
  z.object({ isRunning: z.literal(false) }),
])
/** Application records exposed for selection. Running macOS records carry a process ID. */
export const AppsResult = z.array(z.intersection(z.union([
  appProcess,
  z.object({ isRunning: z.literal(true).default(true), pid: processId }),
]), z.object({
  id: z.string().min(1).optional(), name: z.string(), bundleId: z.string().optional(),
})))
/** Installed matches preserve their installation selector and the PID of a running macOS instance. */
export const FoundAppsResult = z.array(z.intersection(appProcess, z.object({
  id: z.string().min(1), displayName: z.string(), path: z.string().min(1),
})))
/** Current windows and their global native bounds. */
export const WindowsResult = z.array(z.object({
  windowId, appName: z.string(), title: z.string(), bounds,
  isOnScreen: z.boolean(), onCurrentSpace: z.boolean().nullable(),
}))
/** Observed state for the selected application or window. */
export const StateResult = z.object({
  appHandle: z.string().min(1).transform(value => value as CuaAppHandle),
  windowId: windowId.nullable(),
  focusedWindowId: windowId.nullable().optional(),
  snapshotId: z.string().min(1).transform(value => value as CuaSnapshotId),
  tree: z.string(), windows: WindowsResult, truncated: z.boolean(), hasUnreadableElements: z.boolean().optional(),
})
/** Provider-defined action names for one element, including attribute-setting operations; an element may advertise none. */
export const ActionNamesResult = z.array(z.string())
/** Validates CUA response fields and JSON values; native providers own the nested schema definitions. */
export const ActionSchemaResult = z.object({
  type: z.literal('object'),
  properties: z.object({ argument: z.record(z.string(), jsonValue) }).strict(),
  required: z.union([z.tuple([]), z.tuple([z.literal('argument')])]),
  additionalProperties: z.literal(false),
}).strict().transform(schema => schema as ObjectJsonSchema)
/** Original native PNG and platform window geometry before Host image preparation. */
export const NativeScreenshotResult = z.object({
  mimeType: z.literal('image/png'), data: imageBase64, pixelWidth: pixelDimension, pixelHeight: pixelDimension, windowId,
  bounds: bounds.extend({ width: z.number().positive(), height: z.number().positive() }),
  coordinateSpace: z.enum(['window-points', 'window-pixels']),
})
/** Encoded model-request image; default input coordinates use these pixel dimensions. */
export const ScreenshotResult = NativeScreenshotResult.extend({
  mimeType: z.enum(['image/png', 'image/jpeg', 'image/webp', 'image/gif']), coordinateSpace: z.literal('screenshot-pixels'),
})
/** Permissions are reported without opening system permission dialogs. */
export const CapabilitiesResult = z.object({
  platform: z.string(), permissions: z.object({ accessibility: z.boolean(), screenRecording: z.boolean() }),
  /** Whether the provider supports application-level accessibility observations. */
  appLevelAccessibility: z.boolean(),
  /** Whether mouseMove, toggleMouse, click, drag, pressKey, and sendKeyEvent accept explicit system input. */
  systemInput: z.boolean().default(false),
  /** Scopes that support keyboard input. */
  keyboard: z.array(z.enum(['app', 'window'])),
  sessionLocked: z.boolean().nullable(),
  methods: z.array(z.string()), coordinateSpace: z.literal('screenshot-pixels'), browser: z.literal(false),
})
/** Reports whether the provider successfully executed the requested operation. */
export const ActionResult = z.object({
  /** True when the provider successfully executed the operation; false when no applicable operation was found. */
  dispatched: z.boolean(),
  /** Sampled foreground change; omitted when the provider does not sample this action, null when a requested sample was unavailable. */
  foregroundChanged: z.boolean().nullable().optional(),
})
/** Hover reports whether the selected route moved the user's system pointer. */
export const HoverResult = ActionResult.extend({ hoverRoute: z.enum(['accessibility', 'system-pointer']), systemPointerMoved: z.boolean() })
/** Background restoration dispatch and sampled foreground changes; null means the observation was unavailable. */
export const ShowResult = ActionResult.extend({ windowId: windowId.nullable(), foregroundChanged: z.boolean().nullable() })

/** Bounded native PNG thumbnail for human presentation, excluded from model results and saved grants. */
export const ApplicationIcon = z.string().max(65536).regex(/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/)
