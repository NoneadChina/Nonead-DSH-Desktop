/**
 * JSON-RPC methods and notifications for out-of-process harness SDKs.
 * The surrounding context owns plugins, persistence, and configured adapters.
 *
 * @module @deepseek-ai/dsh-sdk-jsonrpc-server/server
 */
import { type Context } from '@deepseek-ai/cordis';
import type { InitializeParams, InitializeResult, JsonRpcTransportPeer, SessionQueryParams, SessionQueryResult, SessionPromptParams, SessionPromptResult, SessionResumeParams, SessionWaitParams, SessionWorkingDirectoryParams, SessionWorkingDirectorySetParams, SessionWorkingDirectoryResult } from '@deepseek-ai/dsh-sdk-protocol';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /** SDK prompt with its canonical user time zone, when one was reported or sampled. */
        'sdk-user': {
            kind: 'user';
            clientTimeZone?: string;
        };
    }
}
/** A process event observed by the hosting plugin entry. */
export interface RuntimeProcessEvent {
    /** Event name and, for a failure, the first line of its message. */
    readonly description: string;
    readonly at: Date;
}
/** What the hosting plugin entry observes about the runtime that surrounds the server. */
export interface RuntimeObservation {
    /** Whether disposal of the whole runtime is in progress, which ends every plugin in the process. */
    unloading(): boolean;
    /** The last process event recorded before that disposal began; an observation, not an established cause. */
    lastProcessEvent(): RuntimeProcessEvent | undefined;
}
/** Deployment-specific status mapping for SDK turn and subagent outcomes. */
export interface HarnessSdkJsonRpcServerOptions {
    /** Report max-token termination as an accepted result instead of an infrastructure error. */
    maxTokensAsSuccess?: boolean;
    /** Runtime state that a liveness failure reports; without it the failure makes no statement about the runtime. */
    runtime?: RuntimeObservation;
}
/**
 * SDK server over one booted harness context and transport peer. Construction
 * subscribes to session, agent, and subagent lifecycle events until shutdown;
 * reinitialization is unsupported.
 */
export declare class HarnessSdkJsonRpcServer {
    private readonly ctx;
    private readonly transport;
    private readonly options;
    private cwd;
    private provider;
    private model;
    private reasoningEffort;
    private maxTokens;
    private llmFiber;
    private authFiber;
    private readonly sessions;
    private readonly sessionCreations;
    private readonly commandTasks;
    private readonly queryInvocation;
    private readonly queryActivities;
    private readonly goalLifetime;
    private readonly disposers;
    private shutdownTask;
    private shuttingDown;
    private readonly unloading;
    /** Name of the plugin whose unload began while no other was in progress; overlapping unloads can make it an unrelated plugin. */
    private unloadOrigin;
    private initialized;
    private approvalRequests;
    private readonly lifetime;
    private readonly userQuestions;
    private readonly initialization;
    /** Restored by a reminder and available for the client's first resume. */
    private readonly scheduledSessions;
    constructor(ctx: Context, transport: JsonRpcTransportPeer, options?: HarnessSdkJsonRpcServerOptions);
    /**
     * Validate and configure the SDK route, mounting the DeepSeek fallback only when unowned.
     * @param params - SDK handshake parameters.
     * @returns server identity for the handshake.
     */
    initialize(params: InitializeParams): Promise<InitializeResult>;
    /**
     * Queue one identified prompt without assigning later activity to it.
     * The message records the explicit or sampled canonical zone; an unusable sampled zone records none.
     * @param params - target session, user content, and optional user time zone.
     * @returns the durable message identity.
     * @throws TypeError before Session creation when an explicit time zone is not UTC or IANA Area/Location.
     */
    prompt(params: SessionPromptParams): Promise<SessionPromptResult>;
    /**
     * Dispatch text as a Desktop-style input; native commands own Session state changes.
     * Only the prompt branch records the time zone; native commands do not, matching Desktop command input.
     * @param params - ordered content blocks, receiving Session, and optional prompt time zone.
     * @returns a prompt receipt or native command acknowledgment; command activity completes by notification.
     * @throws TypeError before routing when an explicit time zone is not UTC or IANA Area/Location.
     * @throws on runtime failure; a recognized command failure never falls back to a prompt.
     */
    query(params: SessionQueryParams): Promise<SessionQueryResult>;
    /**
     * Restore a persisted session and repair its interrupted final turn without sending input.
     * Uses the initialized model route while preserving the stored session identity and directory.
     * An explicit permission preset is persisted during setup before execution; omission preserves saved permissions.
     * Already scheduled restorations reject permission overrides because execution may have started.
     * Rejects subagent, missing, unreadable, or already owned sessions; never creates a replacement.
     * @param params - persisted session identity in the configured persistence store.
     * @returns an empty result after the Agent is ready for prompts.
     */
    resume(params: SessionResumeParams): Promise<Record<string, never>>;
    /**
     * Wait for an existing owned Agent and its managed descendants to finish.
     * The response follows all Session notifications emitted during the wait.
     * Rejects a live Agent failure that has no subsequent durable terminal.
     * @param params - the SDK-owned session to observe without creating one.
     * @returns an empty result after the root stays idle across the descendant check.
     */
    wait(params: SessionWaitParams): Promise<Record<string, never>>;
    /**
     * Resolves live SDK ownership; root lookup failures other than SubagentError/UNAUTHORIZED propagate.
     * @param agent - Agent whose requests need routing.
     * @returns Whether this server owns the Agent or its live subagent tree root.
     */
    private ownsAgent;
    /** Reject a retained record whose Agent left the registry, naming what the server observed. */
    private assertLiveAgent;
    private disposalContext;
    /**
     * Read a Session's effective directory, recovering a missing directory to its origin.
     * @param params - target Session; an unknown id creates it.
     * @returns the absolute effective directory.
     */
    getWorkingDirectory(params: SessionWorkingDirectoryParams): Promise<SessionWorkingDirectoryResult>;
    /**
     * Change a Session's directory and queue its model-visible transition.
     * @param params - target Session and absolute or current-directory-relative path.
     * @returns the validated absolute directory; the origin is unchanged and the workspace-write boundary follows the directory.
     */
    setWorkingDirectory(params: SessionWorkingDirectorySetParams): Promise<SessionWorkingDirectoryResult>;
    private workingDirectoryAgent;
    /**
     * Dispose server-owned agents, adapter, and subscriptions to quiescence.
     * Managed descendants drain before the root Agent handles and adapter are released.
     * The surrounding context remains running.
     * @returns empty JSON-RPC result.
     */
    shutdown(): Promise<Record<string, never>>;
    private performShutdown;
    /**
     * Dispatch one incoming JSON-RPC request to its typed handler. Throws (→ a
     * JSON-RPC error response) on an unknown method.
     * @param method - the JSON-RPC method name.
     * @param params - the raw params object from the wire.
     * @returns the handler's result, to be serialized as the response.
     */
    handleRequest(method: string, params: Record<string, unknown> | undefined): Promise<unknown>;
    private getOrCreateSession;
    private openSession;
    private createSession;
    private hasAdapterFor;
}
//# sourceMappingURL=server.d.ts.map