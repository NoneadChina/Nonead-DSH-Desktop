/** Projection of the section list's registrations into the titles the panel draws, in the reader's order. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import { type StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionPanelSectionEntry } from './slots.ts';
/** Id of the built-in Environment section, which always shows first and cannot be moved. */
export declare const ENVIRONMENT_SECTION_ID = "environment";
/** localStorage key of the section order the reader chose: section ids, first to last. */
export declare const SECTION_ORDER_STORAGE_KEY = "dsh.sessionPanel.sectionOrder";
/**
 * Project live section registrations in display order. A registration
 * without a label cannot be titled; it is reported and left out.
 * @param entries - shadowing winners of the section list in ledger order.
 * @param report - receives one message per unlabeled registration.
 * @returns sections ordered by ascending `order`, then registration order.
 */
export declare function projectSections(entries: readonly StoredEntry[], report: (message: string) => void): readonly SessionPanelSectionEntry[];
/**
 * Put sections in the order the reader chose, after the Environment section,
 * which always comes first. The other sections the choice names come in its
 * order; one it does not name, such as one registered since, follows the
 * section it follows among them in the registered order, or leads them when
 * nothing precedes it there. Ids the choice names that no section has are
 * ignored, as is the place the choice gives Environment.
 * @param sections - sections in registered order.
 * @param preferred - section ids in the reader's order.
 * @returns the sections in display order; the same array when that is the registered order's.
 */
export declare function orderSections(sections: readonly SessionPanelSectionEntry[], preferred: readonly string[]): readonly SessionPanelSectionEntry[];
/** The section roster the panel draws, and the reader's reordering of it. */
export interface SectionSource extends ObservableSnapshot<readonly SessionPanelSectionEntry[]> {
    /**
     * Move a section beside another and persist the resulting order of every
     * live section. No effect when either id is not a live section, both are
     * the same one, or the section to move is Environment.
     * @param id - section to move.
     * @param target - section it lands beside.
     * @param placement - the side of the target it lands on; a section always lands after Environment.
     */
    readonly move: (id: string, target: string, placement: 'before' | 'after') => void;
}
/**
 * Observable section roster in the reader's order: recomputed when the
 * section list's ledger, the active locale, or the stored order changes, and
 * identity-stable between changes. A stored value that is not a list of
 * strings counts as no choice.
 * @param ctx - client context whose slot registry and locale the roster follows.
 * @returns the section source.
 */
export declare function sectionSource(ctx: ClientContext): SectionSource;
//# sourceMappingURL=sections.d.ts.map