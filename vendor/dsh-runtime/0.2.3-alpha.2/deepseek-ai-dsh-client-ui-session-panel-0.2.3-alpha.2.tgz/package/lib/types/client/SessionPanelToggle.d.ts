/** Session header entry that shows or hides the Session panel. */
import { type ReactNode } from 'react';
import type { SessionPanelToggleProps } from './slots.ts';
/**
 * Render the toggle. Its accessible name is the panel name followed by the
 * text of any indicator; the expanded state says whether the panel shows.
 * While no Chat View shows the Session, as in the trajectory View, the panel
 * has no place to show: the toggle is unavailable and its tooltip says so.
 * @param props - Session values, the room to dock, shared visibility, the toggle action, and copy.
 * @returns the header entry.
 */
export declare function SessionPanelToggle({ sessionId, useDockable, useVisibility, toggle, renderSlot, t, }: SessionPanelToggleProps): ReactNode;
//# sourceMappingURL=SessionPanelToggle.d.ts.map