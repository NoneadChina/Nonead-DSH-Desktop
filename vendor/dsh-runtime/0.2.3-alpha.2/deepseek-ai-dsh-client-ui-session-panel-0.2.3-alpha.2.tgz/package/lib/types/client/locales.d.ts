/** `sessionPanel` namespace dictionaries. */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "sessionPanel";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'panel.name': "会话面板";
    readonly 'toggle.show': "显示会话面板";
    readonly 'toggle.hide': "隐藏会话面板";
    readonly 'toggle.unavailable': "切换到「对话」视图后可显示会话面板";
    readonly 'section.environment': "环境";
    readonly 'project.label': "工作目录";
    readonly 'project.actions': "工作目录操作";
};
/** Every key of the `sessionPanel` namespace. */
export type SessionPanelKey = keyof typeof zh;
/** English dictionary, key-identical to the Chinese source of truth. */
export declare const en: Record<SessionPanelKey, string>;
/** Japanese dictionary. */
export declare const ja: {
    'panel.name': string;
    'toggle.show': string;
    'toggle.hide': string;
    'toggle.unavailable': string;
    'section.environment': string;
    'project.label': string;
    'project.actions': string;
};
/** Spanish dictionary. */
export declare const es: {
    'panel.name': string;
    'toggle.show': string;
    'toggle.hide': string;
    'toggle.unavailable': string;
    'section.environment': string;
    'project.label': string;
    'project.actions': string;
};
/** French dictionary. */
export declare const fr: {
    'panel.name': string;
    'toggle.show': string;
    'toggle.hide': string;
    'toggle.unavailable': string;
    'section.environment': string;
    'project.label': string;
    'project.actions': string;
};
/** German dictionary. */
export declare const de: {
    'panel.name': string;
    'toggle.show': string;
    'toggle.hide': string;
    'toggle.unavailable': string;
    'section.environment': string;
    'project.label': string;
    'project.actions': string;
};
/** Russian dictionary. */
export declare const ru: {
    'panel.name': string;
    'toggle.show': string;
    'toggle.hide': string;
    'toggle.unavailable': string;
    'section.environment': string;
    'project.label': string;
    'project.actions': string;
};
/** Brazilian Portuguese dictionary. */
export declare const pt: {
    'panel.name': string;
    'toggle.show': string;
    'toggle.hide': string;
    'toggle.unavailable': string;
    'section.environment': string;
    'project.label': string;
    'project.actions': string;
};
//# sourceMappingURL=locales.d.ts.map