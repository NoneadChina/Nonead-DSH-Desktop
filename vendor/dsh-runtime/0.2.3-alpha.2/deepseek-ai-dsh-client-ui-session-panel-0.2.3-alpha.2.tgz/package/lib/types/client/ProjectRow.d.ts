/** Environment row naming the Session's working folder. */
import type { ReactNode } from 'react';
import type { ProjectRowProps } from './slots.ts';
/**
 * Render the Session's working folder as its name followed by its parent
 * folder, with the label and the full path in the tooltip. The folder is the
 * Session's current working directory; before that projection arrives, or
 * when it records none, it is the directory the Session was created in, else
 * the Workspace that lists the Session. Paths under the Host account home
 * start with `~`. The row and its More button open the directory context menu.
 * @param props - Session values, the working directory projection, Workspace and Session list hooks, Host facts, menu bindings, and copy.
 * @returns the row, or null before the Session's directory is known.
 */
export declare function ProjectRow({ sessionId, useProjection, useWorkspaces, useSessions, useHost, useContextMenu, renderFactorySlot, t, }: ProjectRowProps): ReactNode;
//# sourceMappingURL=ProjectRow.d.ts.map