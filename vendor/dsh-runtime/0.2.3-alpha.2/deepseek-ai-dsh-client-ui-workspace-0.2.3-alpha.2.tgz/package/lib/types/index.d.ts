/**
 * Workspace picker plugin, node half. The browser half ships via
 * exports["./client"], discovered through the package.json dsh.client
 * declaration. The Host behavior is this plugin's configuration: its volatile
 * fields are the live values the browser receives through its synced Config.
 */
import z from '@deepseek-ai/schemastery';
import type { WorkspaceNavigationConfig } from './types.ts';
/** Live Workspace navigation preferences; the browser receives them through its synced Config. */
export type Config = WorkspaceNavigationConfig;
/** Live Workspace navigation preferences projected to the browser. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    recentViewLimit: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    recentViewLimit: z<number, number, "volatile-defined">;
}>>, "plain">;
/** Register the browser plugin without Host behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map