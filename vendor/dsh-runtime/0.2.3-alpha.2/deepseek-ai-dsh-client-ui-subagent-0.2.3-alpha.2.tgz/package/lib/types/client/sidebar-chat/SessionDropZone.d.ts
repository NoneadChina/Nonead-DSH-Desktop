import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionDragType } from '@deepseek-ai/dsh-client-ui-workspace/client';
import type { PaneId } from '@deepseek-ai/dsh-client-ui-sidebar-right/client';
import type { NS } from '../locales.ts';
/** Drag data type the Session list sets to a dragged row's Session id. */
export declare const SESSION_DRAG_TYPE: SessionDragType;
/** Viewport rectangle, in px, where a dragged Session can land. */
export interface SessionDropTarget {
    /** Docked Sidebar pane the Session opens in; absent for the area a collapsed Sidebar would open in. */
    readonly paneId?: PaneId;
    readonly left: number;
    readonly top: number;
    readonly width: number;
    readonly height: number;
}
/** A Session row in flight and where it can land. */
export interface SessionDrag {
    readonly sessionId: SessionId;
    readonly targets: readonly SessionDropTarget[];
}
/** Session drag tracking and the open operation supplied by the plugin. */
export interface SessionDropZoneInjected {
    readonly hooks: {
        /** Session dragged from the list that the on-screen Session's Sidebar can open; undefined otherwise. */
        readonly sessionDrag: HostObservable<SessionDrag | undefined>;
    };
    /** Open the Session's Conversation in the on-screen Session's right Sidebar, in the named docked pane if any. */
    readonly openAside: (sessionId: SessionId, paneId?: PaneId) => void;
}
/** Props of the `shell.overlay` drop target. */
export type SessionDropZoneProps = PropsRuntime<'shell.overlay'> & PropsLocale<typeof NS> & InjectFace<SessionDropZoneInjected>;
/**
 * Show a drop target over each place in the right Sidebar a dragged Session row can open in.
 * @param props - tracked drag, open operation, and copy.
 * @returns the drop target, or nothing outside a Session drag.
 */
export declare function SessionDropZone({ useSessionDrag, openAside, t }: SessionDropZoneProps): import("react").ReactPortal | null;
//# sourceMappingURL=SessionDropZone.d.ts.map