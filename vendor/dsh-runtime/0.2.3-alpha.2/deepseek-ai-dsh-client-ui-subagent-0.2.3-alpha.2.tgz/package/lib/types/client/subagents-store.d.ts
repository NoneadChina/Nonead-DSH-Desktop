/**
 * Whether the user unfolded the subagents list of the Session panel. The
 * registration declares it as an exclusive store, so each Session keeps its
 * own while its scope is retained, across hiding and showing the panel.
 */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-store';
/** The fold of one Session's subagents list. */
export interface SubagentsSectionState {
    /** Whether the list shows every row instead of holding back the rows past its limit. */
    unfolded: boolean;
}
/** The subagents section store's write set. */
type SubagentsSectionActions = {
    unfoldedSet: (draft: SubagentsSectionState, unfolded: boolean) => void;
};
/**
 * Declare the subagents section's store.
 * @returns the store handle to declare on the registration.
 */
export declare function createSubagentsSectionStore(): EngineStoreHandle<SubagentsSectionState, SubagentsSectionActions>;
export {};
//# sourceMappingURL=subagents-store.d.ts.map