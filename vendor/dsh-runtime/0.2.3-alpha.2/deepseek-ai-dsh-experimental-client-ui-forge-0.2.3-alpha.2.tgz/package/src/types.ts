/** Browser-safe panel state, the worktree request record, Remote error codes, and Host configuration of the forge panel. */

import type {} from '@deepseek-ai/dsh-typert-protocol'
import type { Branded } from '@deepseek-ai/dsh-brand'
import type {
  ChangeRequestRef, ChangeRequestSnapshot, ChangeRequestSummary, ChangeRequestUpdate, ForgeCommit, ForgeDescription, ForgeFailure,
  ForgeReadiness, ForgeRepository, ForgeViewerFilter,
} from '@deepseek-ai/dsh-experimental-forge/types'
import type { SessionChangeRequest } from '@deepseek-ai/dsh-experimental-forge-session/types'

/** Git facts for the checkout that contains the Session's current directory. */
export interface ForgeCheckout {
  /** Top-level directory of the checkout. */
  readonly root: string
  /** Checked-out branch, or null when HEAD is detached. */
  readonly branch: string | null
  /** Whether the checkout is a linked worktree of another checkout's repository. */
  readonly linked: boolean
  /** Abbreviated commit HEAD names, or null while the checked-out branch has no commit. */
  readonly commit: string | null
}

/** Inspection result for the Session's current directory. */
export type ForgeCheckoutState =
  /** The first inspection has not finished. */
  | { readonly state: 'pending' }
  /** The current directory is not inside a Git checkout. */
  | { readonly state: 'none' }
  /** Git could not run or reported an error. */
  | { readonly state: 'failed'; readonly message: string }
  /** The checkout facts. */
  | { readonly state: 'ready'; readonly checkout: ForgeCheckout }

/** The worktree the panel created and entered for a Session before its first step. */
export interface ForgeSessionWorktree {
  /** Canonical checkout directory. */
  readonly path: string
  /** Branch created for the checkout. */
  readonly branch: string
  /**
   * Requested base: the full name of a local or remote-tracking branch, a short branch name that earlier panels
   * recorded, or null when the checkout started from HEAD of the source checkout.
   */
  readonly from: string | null
  /** Commit object name the branch started from. */
  readonly baseCommit: string
  /** Canonical root of the source checkout. */
  readonly repositoryRoot: string
}

/** Payload of the `plugin:client-ui-forge/worktree` record. */
export type WorktreeRecord =
  /**
   * Create a worktree before the Session's first step, starting from `from`, or from HEAD when it is null, on the
   * branch `name`, or on a generated branch name when `name` is absent.
   */
  | { readonly action: 'request'; readonly from: string | null; readonly name?: string }
  /** Withdraw the open request. */
  | { readonly action: 'cancel' }
  /** The requested worktree was created and became the Session's working directory. */
  | { readonly action: 'created'; readonly worktree: ForgeSessionWorktree }
  /** Restoration started; the checkout stays unavailable until restoration completes. */
  | { readonly action: 'restoring' }
  /** The recorded worktree was completely restored. */
  | { readonly action: 'restored' }

/** One open worktree request. */
export interface ForgeWorktreeRequest {
  /**
   * Base: the full name of a local or remote-tracking branch, a short branch name that earlier panels recorded, or
   * null for HEAD of the source checkout. A remote-tracking branch is fetched before each attempt that does not skip it.
   */
  readonly from: string | null
  /** New branch name the user chose, which every attempt uses, or null for a generated name per attempt. */
  readonly name: string | null
}

/** Host-only state of the `forgeWorktree` projection. */
export interface ForgeWorktreeState {
  /** Open request, or null without one. */
  readonly request: ForgeWorktreeRequest | null
  /** Created worktree, or null before creation. */
  readonly created: ForgeSessionWorktree | null
  /** Whether a turn has started; requests and withdrawals recorded afterwards are ignored. */
  readonly locked: boolean
  /** Whether a step has started; no worktree is created afterwards. */
  readonly stepped: boolean
  /** The Session's working directory as its log last recorded it, or null when none is recorded. */
  readonly cwd: string | null
  /** Whether a restoration started without a successful completion, including across reloads. */
  readonly restoring: boolean
}

/** Why the Session's checkout cannot host a new worktree. */
export type ForgeWorktreeBlocker =
  /** The current directory is not inside a Git checkout. */
  | 'not-git'
  /** The Session's sandbox cannot write the checkout or its Git directory, as for a linked worktree outside the writable root. */
  | 'outside-writable-root'
  /** The Session runs read-only. */
  | 'read-only'

/** One running worktree creation. */
export interface ForgeWorktreeCreation {
  /**
   * Running step: `fetch` fetches a remote base branch, `prepare` validates and creates the branch, then
   * `checkout` writes the files.
   */
  readonly phase: 'fetch' | 'prepare' | 'checkout'
  /** Branch the attempt creates. */
  readonly branch: string
  /** Base as the request names it, or null for HEAD. */
  readonly from: string | null
  /** Whether the attempt fetches its remote base branch first. */
  readonly fetch: boolean
  /**
   * Whether a message waits for the creation before its turn starts. Only
   * such a creation can be stopped, after which the message keeps waiting; a
   * creation at the first step serves a message the Session already holds.
   */
  readonly held: boolean
}

/** One running restoration of the removed worktree a Session works in. */
export interface ForgeWorktreeRestoration {
  /** Running step: `prepare` registers the checkout again, creating a missing branch, then `checkout` writes the files. */
  readonly phase: 'prepare' | 'checkout'
}

/** The last attempt to create the requested worktree for a message, which failed. */
export interface ForgeWorktreeFailure {
  /** Branch the attempt created, or null when it failed before naming one. */
  readonly branch: string | null
  /** Base of the attempt as the request names it, or null for HEAD. */
  readonly from: string | null
  /** Whether the attempt fetched, or tried to fetch, its remote base branch first. */
  readonly fetch: boolean
  /** Step that failed. */
  readonly phase: 'fetch' | 'prepare' | 'checkout'
  /** Failure text. */
  readonly message: string
  /** Whether the branch or the checkout directory of that name already existed, which another name avoids. */
  readonly exists: boolean
}

/**
 * What a message waits for before its turn starts: the creation of the
 * requested worktree, or the restoration or leaving of the removed worktree
 * the Session works in.
 */
export type ForgeWorktreeWaiting = 'creation' | 'restoration'

/** The recorded worktree whose directory is missing, invalid, or incompletely restored. */
export interface ForgeMissingWorktree {
  /** Whether its branch exists, or null when an incomplete restoration cannot inspect it. */
  readonly branchExists: boolean | null
}

/** Worktree facts of one Session in the panel state. */
export interface ForgePanelWorktree {
  /**
   * Whether the Session can still request or withdraw a worktree: a worktree
   * service is mounted, no turn has started, and none was created.
   */
  readonly editable: boolean
  /** Why the checkout cannot host a worktree, or null when it can, before the first inspection, and after a failed one. */
  readonly blocker: ForgeWorktreeBlocker | null
  /** Prefix of generated branch names, the Config `worktreePrefix`, which a name the user types starts from. */
  readonly namePrefix: string
  /** Open request, or null without one. */
  readonly request: ForgeWorktreeRequest | null
  /** Created worktree, or null before creation. */
  readonly created: ForgeSessionWorktree | null
  /** Running creation, or null. */
  readonly creation: ForgeWorktreeCreation | null
  /**
   * The last failed attempt of the creation a message waits for, or null. It
   * clears when another attempt starts, when the request changes or is
   * withdrawn, and when the wait ends.
   */
  readonly failure: ForgeWorktreeFailure | null
  /** The created worktree the Session works in when its directory is gone, or null. */
  readonly missing: ForgeMissingWorktree | null
  /** Running restoration of the removed worktree, or null. */
  readonly restoration: ForgeWorktreeRestoration | null
  /** What a message of the Session waits for before its turn starts, or null while none waits. */
  readonly waiting: ForgeWorktreeWaiting | null
}

/**
 * The last polled state of one change request that a listed Session binds, as
 * the Session list shows it.
 */
export type ForgeChangeRequestListState = Pick<
  ChangeRequestSnapshot, 'url' | 'title' | 'state' | 'draft' | 'checksRollup' | 'reviewDecision' | 'mergeability'
> & {
  /** Change request number on its code host. */
  readonly number: number
}

/**
 * One frame of `forgePanel.changeRequestStates`: the known state of every
 * change request the reader may see first, then the states that changed or
 * became visible since the previous frame.
 */
export type ForgeChangeRequestStatesFrame =
  | { readonly type: 'baseline'; readonly states: readonly ForgeChangeRequestListState[] }
  | { readonly type: 'changed'; readonly states: readonly ForgeChangeRequestListState[] }

/** One list of the review page: the latest successful read of one viewer list on one host, and the latest failure. */
export interface ForgeReviewList {
  /** Change requests most recently updated first, from the latest successful read, or null before the first. */
  readonly items: readonly ChangeRequestSummary[] | null
  /** Size of the whole list the host reported with `items`; 0 before the first successful read. */
  readonly total: number
  /** Epoch milliseconds of the read `items` come from, or null before the first successful read. */
  readonly fetchedAt: number | null
  /** Why the latest read failed, or null when it succeeded or none settled yet. */
  readonly failure: ForgeFailure | null
}

/** The review page's lists on one host of one provider. */
export interface ForgeReviewHost {
  /** Forge family of the provider. */
  readonly forge: string
  /** Lowercase host name. */
  readonly host: string
  /** Login of the signed-in user the latest successful read named, or null before one. */
  readonly viewer: string | null
  /** Each list the provider offers on the host; a list it does not offer is absent. */
  readonly lists: Partial<Readonly<Record<ForgeViewerFilter, ForgeReviewList>>>
}

/** Everything the review page lists, as one frame. */
export interface ForgeReviewFrame {
  /** Each host a provider lists change requests on, in registration and configuration order. */
  readonly hosts: readonly ForgeReviewHost[]
  /** Whether a read is in flight. */
  readonly reading: boolean
}

/** The number the review page's navigation entry shows. */
export interface ForgeReviewCountFrame {
  /** Open change requests that ask the signed-in user for a review, summed over the hosts read, or null before any count. */
  readonly reviewRequested: number | null
}

/** One change request the review page shows in full, with its latest polling result. */
export interface ForgeReviewChangeRequest {
  /** Web URL the page asked for. */
  readonly url: string
  /** Parsed reference. */
  readonly ref: ChangeRequestRef
  /** How readers name the change request's code host and its change requests, or null once its provider left. */
  readonly forge: ForgeDescription | null
  /** Latest polling result, or null before the first poll. */
  readonly update: ChangeRequestUpdate | null
  /** Latest snapshot a poll returned, kept while later polls fail, or null before the first successful poll. */
  readonly snapshot: ChangeRequestSnapshot | null
  /** Number of review changes `forge/review-changed` announced for the change request since the panel host started. */
  readonly reviewRevision: number
}

/** One bound change request in the panel state. */
export interface ForgePanelChangeRequest extends SessionChangeRequest {
  /** How readers name the change request's code host and its change requests, or null when no provider serves its URL. */
  readonly forge: ForgeDescription | null
  /** Latest snapshot a poll returned, kept while later polls fail, or null before the first successful poll. */
  readonly snapshot: ChangeRequestSnapshot | null
  /**
   * Number of review changes `forge/review-changed` announced for the change request since the panel host started; it
   * grows when any plugin's write is accepted, so a reader shows threads and viewed marks read after it.
   */
  readonly reviewRevision: number
}

/** Everything the panel shows for one Session. */
export interface ForgePanelState {
  /** Current working directory of the Session. */
  readonly directory: string
  /** Inspection result for `directory`. */
  readonly checkout: ForgeCheckoutState
  /** Code host repository of the checkout's upstream remote or `origin`, or null when no provider serves them. */
  readonly repository: ForgeRepository | null
  /** Sign-in state for the repository's host, or null before the first probe and without a repository. */
  readonly readiness: ForgeReadiness | null
  /** Visible change request bindings with their latest polling results, in first-recorded order. */
  readonly changeRequests: readonly ForgePanelChangeRequest[]
  /** Worktree request and creation state. */
  readonly worktree: ForgePanelWorktree
  /**
   * Files the `branch` scope changes, or null before the first inspection,
   * outside a checkout, and without a fork point.
   */
  readonly local: ForgeLocalChanges | null
}

/** Branches offered as the base of a new worktree whose names contain a query. */
export interface ForgeWorktreeBases {
  /** Checked-out branch, or null when HEAD is detached or its name does not contain the query. */
  readonly current: ForgeBaseBranch | null
  /** Default branch of each remote that names one with `refs/remotes/<remote>/HEAD`, in remote order. */
  readonly defaults: readonly ForgeRemoteDefault[]
  /** Other local branches, most recently committed first, at most `maxBranches`. */
  readonly local: readonly ForgeBaseBranch[]
  /**
   * Remote-tracking branches of each configured remote in remote order: the remote the checked-out branch tracks,
   * then `origin`, then the others as Git lists them. Remotes without a matching branch are left out.
   */
  readonly remotes: readonly ForgeRemoteBranches[]
}

/** A remote's default branch, which `refs/remotes/<remote>/HEAD` names. */
export interface ForgeRemoteDefault extends ForgeBaseBranch {
  /** Remote the branch belongs to; it may contain `/`. */
  readonly remote: string
}

/** Remote-tracking branches of one remote, without its default branch. */
export interface ForgeRemoteBranches {
  /** Remote name such as `origin`; it may contain `/`. */
  readonly name: string
  /** `owner/name` of the repository a provider recognizes from the remote's URLs, else its fetch URL, or null without one. */
  readonly repository: string | null
  /** Branches named `<remote>/<branch>`, most recently committed first, at most `maxBranches`. */
  readonly branches: readonly ForgeBaseBranch[]
}

/** A branch the `branch` scope can compare with. */
export interface ForgeBaseBranch {
  /** Full ref name: `refs/heads/<branch>` or `refs/remotes/<remote>/<branch>`. */
  readonly ref: string
  /** The ref without `refs/heads/` or `refs/remotes/`, such as `master` or `origin/master`. */
  readonly name: string
}

/** What the `branch` scope compares with while no base branch is chosen. */
export interface ForgeAutomaticBase {
  /** The created worktree's base branch or abbreviated base commit, or the default branch of the code host remote. */
  readonly name: string
  /** Whether the fork point is the base commit of the worktree the Session created rather than a merge base. */
  readonly worktree: boolean
}

/** Branches the `branch` scope can compare with, whose names contain a query. */
export interface ForgeBaseBranches {
  /** The fork point used while no base branch is chosen, whatever the query; null without one. */
  readonly automatic: ForgeAutomaticBase | null
  /** Remote-tracking branches without symbolic refs such as `origin/HEAD`, most recently committed first, at most `maxBranches`. */
  readonly remote: readonly ForgeBaseBranch[]
  /** Local branches other than the checked-out one, most recently committed first, at most `maxBranches`. */
  readonly local: readonly ForgeBaseBranch[]
}

/**
 * Consecutive commits a changes view shows instead of its whole comparison, named by full object names in the order
 * the commit list shows them, oldest first; the view shows the changes from the first commit's first parent to the last.
 */
export interface ForgeCommitRange {
  /** First, oldest commit shown. */
  readonly from: string
  /** Last, newest commit shown; equal to `from` for one commit. */
  readonly to: string
}

/** Which local changes a diff covers; each reads the Session's checkout through Git. */
export type ForgeLocalScope =
  /**
   * The working tree and untracked files against a fork point: the merge base of HEAD with the
   * `base` ref, or while `base` is null, the base commit of the worktree the Session created,
   * else the merge base of HEAD with the default branch of the code host remote. With `commits`, only the changes
   * of those commits between the fork point and HEAD, without uncommitted or untracked files.
   */
  | { readonly kind: 'branch'; readonly base: string | null; readonly commits: ForgeCommitRange | null }
  /** The working tree and untracked files against HEAD. */
  | { readonly kind: 'uncommitted' }
  /** The working tree and untracked files against the index. */
  | { readonly kind: 'unstaged' }
  /** The index against HEAD. */
  | { readonly kind: 'staged' }

/** One hunk of a file diff. */
export interface ForgeDiffHunk {
  /** First old line the hunk covers, or the old line it comes before when it covers none. */
  readonly oldStart: number
  /** Old lines the hunk covers. */
  readonly oldLines: number
  /** First new line the hunk covers, or the new line it comes before when it covers none. */
  readonly newStart: number
  /** New lines the hunk covers. */
  readonly newLines: number
  /** Lines in patch form: a leading space for context, `+` for added, `-` for deleted, and `\` for a missing final newline. */
  readonly lines: readonly string[]
}

/** How one file changed. */
export type ForgeDiffStatus = 'added' | 'deleted' | 'modified' | 'renamed'

/**
 * Review layer of a changed file: the layer the repository's root `.gitattributes` names with `dsh-review-layer`, else
 * `test` for a file it marks `linguist-generated`, else the first of `testPaths`, `interfacePaths`, and the built-in
 * test and interface rules that the path matches, else `implementation`.
 */
export type ForgeFileLayer = 'interface' | 'implementation' | 'test'

/** One changed file of a diff. */
export interface ForgeDiffFile {
  /** Path relative to the repository root after the change, or before it for a deleted file. */
  readonly path: string
  /** Path before a rename, else null. */
  readonly previousPath: string | null
  /** How the file changed. */
  readonly status: ForgeDiffStatus
  /** Whether the content is binary, which carries no hunks. */
  readonly binary: boolean
  /** Whether an untracked file exceeds `maxDiffBytes`, so it carries no hunks. */
  readonly oversized: boolean
  /** Whether Git does not track the file yet; only local diffs list such files. */
  readonly untracked: boolean
  /** Lines added. */
  readonly additions: number
  /** Lines deleted. */
  readonly deletions: number
  /** Hunks in file order; none for a binary file or a change of mode or name only. */
  readonly hunks: readonly ForgeDiffHunk[]
  /** Review layer the path falls in. */
  readonly layer: ForgeFileLayer
  /**
   * Digest of the file's change: its paths, status, and hunks, plus the blob names of a binary change, or the content
   * of an untracked binary file. Equal digests describe the same change; reading the same comparison again keeps it.
   */
  readonly digest: string
}

/** Local changes of the Session's checkout in one scope. */
export interface ForgeLocalDiff {
  /** Ref or abbreviated commit the `branch` scope compares with, such as `origin/master`; null for other scopes. */
  readonly base: string | null
  /** Changed files in Git's path order, untracked files last. */
  readonly files: readonly ForgeDiffFile[]
  /** Untracked files left out beyond `maxUntrackedFiles`. */
  readonly omitted: number
}

/** Changes of a change request, or of consecutive commits of it, as its code host computes them. */
export interface ForgeChangeRequestDiff {
  /** Commit whose new side the diff describes: the head, or the last chosen commit. */
  readonly headSha: string
  /** Changed files in the host's order. */
  readonly files: readonly ForgeDiffFile[]
  /**
   * Commits the checkout's branch has beyond the head when that branch is the change request's head
   * branch and the head commit is present locally; null otherwise and for chosen commits.
   */
  readonly localAhead: number | null
  /** Web page of each changed file at `headSha`, by path. */
  readonly fileUrls: Readonly<Record<string, string>>
}

/** Opaque identity of a filter lens, chosen by the plugin that registers it, such as `example/public-interface`. */
export type ForgeLensId = Branded<'ForgeLensId'>

/** One changed file a lens classifies: the diff's description of it, without the lines. */
export type ForgeLensFile = Pick<ForgeDiffFile, 'path' | 'previousPath' | 'status' | 'binary' | 'layer' | 'hunks' | 'digest'>

/** Lines `start` through `end` of one side of a file, both inclusive and 1-based. */
export interface ForgeLineRange {
  readonly start: number
  readonly end: number
}

/** What a lens keeps of one file. */
export interface ForgeLensKeep {
  /**
   * Lines the lens is about on each side; hunks that touch none of them fold into one row the reader can expand.
   * Omitted: every hunk of the file shows.
   */
  readonly ranges?: { readonly old: readonly ForgeLineRange[]; readonly new: readonly ForgeLineRange[] }
}

/** The files a lens keeps, by path; a file the result does not name is filtered out. */
export interface ForgeLensResult {
  readonly files: Readonly<Record<string, ForgeLensKeep>>
}

/** What a changes view shows, as a lens sees it. */
export type ForgeLensSource =
  /** Local changes of a Session's checkout in one scope. */
  | { readonly kind: 'local'; readonly scope: ForgeLocalScope }
  /** A change request at one head commit, whole or as consecutive commits. */
  | { readonly kind: 'change'; readonly ref: ChangeRequestRef; readonly headSha: string; readonly commits: ForgeCommitRange | null }

/** What one `classify` call receives. */
export interface ForgeLensInput {
  /** What the view shows. */
  readonly source: ForgeLensSource
  /** Every file of the diff in display order, with the layer the panel gave it. */
  readonly files: readonly ForgeLensFile[]
  /**
   * Read one side of a file of `files`, by its `path`: the old side reads `previousPath` for a renamed file. Resolves to
   * null when the side does not exist, as the old side of an added file, or holds binary content. Rejects for a path not
   * in `files`, once the reads of one call exceed the panel's `maxLensReadBytes`, for an old side the provider cannot
   * locate, and when the read fails.
   */
  text(side: 'old' | 'new', path: string, signal: AbortSignal): Promise<string | null>
  /** Report how many of `total` units the lens finished; the changes view shows it while the lens runs. */
  progress(done: number, total: number): void
}

/** A filter over the files of a changes view, which a plugin registers with `ctx.forgePanel.registerLens()`. */
export interface ForgeLens {
  /** Identity the plugin chooses; one registration holds an id at a time. */
  readonly id: ForgeLensId
  /** Changes whenever `classify` may answer differently for the same input, which drops results kept under another version. */
  readonly version: string
  /**
   * Decide which files the lens keeps and which lines it is about. The signal aborts when the reader stops waiting, the
   * registration ends, or `lensTimeoutMs` passes; a rejection fails the request without a partial result.
   */
  classify(input: ForgeLensInput, signal: AbortSignal): Promise<ForgeLensResult>
}

/** What a changes view asks a lens to classify: its source, the version of the files it shows, and the lens. */
export interface ForgeLensRequest {
  /** The view's source: local changes in a scope, or a binding URL with its chosen commits. */
  readonly source:
    | { readonly kind: 'local'; readonly scope: ForgeLocalScope }
    | { readonly kind: 'change'; readonly url: string; readonly commits: ForgeCommitRange | null }
  /** `lensVersion` of the files the view shows; files read since with another version refuse the request. */
  readonly version: string
  /** Identity of the registered lens. */
  readonly lens: string
}

/** One frame of a lens request: how far the lens is, then what it keeps. */
export type ForgeLensFrame =
  | { readonly kind: 'progress'; readonly done: number; readonly total: number }
  | { readonly kind: 'result'; readonly files: Readonly<Record<string, ForgeLensKeep>> }

/** A registered lens as changes views see it. */
export interface ForgeRegisteredLens {
  /** Identity of the lens. */
  readonly id: string
  /** The lens's `version`; a view does not reuse results of another version. */
  readonly version: string
}

/** Facts about the panel's extensions that every changes view reads. */
export interface ForgeExtensionState {
  /** The registered lenses, in registration order. */
  readonly lenses: readonly ForgeRegisteredLens[]
  /** Most line annotations a changes view shows in one file, across every annotation source. */
  readonly maxAnnotationsPerFile: number
}

/** Commits of the `branch` scope at one HEAD commit, which the changes view can show one or several of. */
export interface ForgeLocalCommits {
  /** HEAD commit the list was read at. */
  readonly headSha: string
  /** Commits oldest first, ending with HEAD's commit. */
  readonly commits: readonly ForgeCommit[]
  /** Whether the branch has more commits than `maxCommits`; the listed ones are the newest. */
  readonly truncated: boolean
}

/** One file the `branch` scope changes, without its hunks. */
export interface ForgeChangedFile {
  /** Path relative to the repository root after the change. */
  readonly path: string
  /** Lines added, or 0 for a binary file. */
  readonly additions: number
  /** Lines deleted, or 0 for a binary file. */
  readonly deletions: number
  /** Whether the content is binary. */
  readonly binary: boolean
}

/** Size of the `branch` scope, which the Session panel's local changes row shows. */
export interface ForgeLocalChanges {
  /** Ref or abbreviated commit the scope compares with. */
  readonly base: string
  /** Changed files in Git's path order, untracked files last, at most `maxUntrackedFiles` of those. */
  readonly files: readonly ForgeChangedFile[]
}

/** Host settings of the forge panel Remote. */
export interface Config {
  /** Git executable name or absolute path in the Session's execution world. */
  gitCommand?: string
  /** Deadline in milliseconds for one Git command, including confinement. */
  gitTimeoutMs?: number
  /** Termination grace period in milliseconds for each Git process. */
  graceMs?: number
  /** Maximum captured bytes per Git output stream. */
  maxOutputBytes?: number
  /** Deadline in milliseconds for one provider sign-in probe. */
  readinessTimeoutMs?: number
  /** Most local branches listed as worktree bases, and most branches in each group of base branches listed for the `branch` scope. */
  maxBranches?: number
  /**
   * Prefix of the branch and checkout directory created for a Session worktree; the first eight
   * hexadecimal digits of the Session id's UUID, a hyphen, and four random hexadecimal digits follow it.
   */
  worktreePrefix?: string
  /** Largest diff, file read to show unchanged lines, or list of base branch refs, in bytes. */
  maxDiffBytes?: number
  /** Most untracked files a local diff or the local changes row includes. */
  maxUntrackedFiles?: number
  /** Most UTF-8 bytes of change request diffs kept in memory for later reads at the same head commit and base branch. */
  maxCachedDiffBytes?: number
  /** Most commits of the `branch` scope listed; a longer branch lists its newest ones. */
  maxCommits?: number
  /**
   * Globs of files in the `test` layer, which the changes view can hide, beside the built-in rules and checked before
   * them; matched against repository-relative paths with dot files included. A repository's `.gitattributes` overrides both.
   */
  testPaths?: string[]
  /**
   * Globs of files in the `interface` layer beside the built-in rules, matched like `testPaths`; checked after
   * `testPaths` and before the built-in rules.
   */
  interfacePaths?: string[]
  /**
   * Most UTF-8 bytes, as JSON, of change request review threads kept in memory for later reads at the same head commit
   * and update time, and, counted apart, of viewed marks kept for later reads at the same head commit.
   */
  maxCachedReviewBytes?: number
  /**
   * Age in milliseconds at which review threads and viewed marks kept in memory are read from the code host again; a
   * GitHub pull request's update time does not change when a thread is resolved, and nothing announces a mark changed
   * on the code host itself.
   */
  reviewRefreshMs?: number
  /**
   * Age in milliseconds past which the status of a change request is read at once when a Session's panel or the
   * review page starts to show it.
   */
  statusMaxAgeMs?: number
  /** Deadline in milliseconds for one lens `classify` call. */
  lensTimeoutMs?: number
  /** Most UTF-8 bytes of file text one lens `classify` call may read. */
  maxLensReadBytes?: number
  /** Most UTF-8 bytes, as JSON, of lens results kept in memory for later requests with the same files, lens, and lens version. */
  maxCachedLensBytes?: number
  /** Most line annotations a changes view shows in one file, across every annotation source. */
  maxAnnotationsPerFile?: number
  /** Milliseconds between two reads of the review page's lists while the page is open. */
  reviewListIntervalMs?: number
  /** Milliseconds between two reads of the review page's navigation count while it is shown. */
  reviewCountIntervalMs?: number
  /** Largest delay in milliseconds between two reads of the review page's lists or count after consecutive failures. */
  reviewMaxBackoffMs?: number
  /** Most change requests one review page list shows, capped by each provider's own limit. */
  reviewPageSize?: number
}

declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** No registered provider serves the change request URL. */
    'forgePanel/unrecognized-url': Record<string, never>
    /** A turn of the Session has started, or its worktree was created, so its worktree request can no longer change. */
    'forgePanel/session-started': Record<string, never>
    /** No worktree service is mounted. */
    'forgePanel/worktrees-unavailable': Record<string, never>
    /** The requested base branch name is empty. */
    'forgePanel/invalid-branch': Record<string, never>
    /** The requested new branch name breaks one of Git's branch-name rules, or the worktree service's refusal of a leading `-`. */
    'forgePanel/invalid-name': Record<string, never>
    /** A local branch with the requested new branch name exists in the Session's checkout. */
    'forgePanel/branch-exists': Record<string, never>
    /** The Session has no created worktree to restore or leave. */
    'forgePanel/no-worktree': Record<string, never>
    /** The Session's Agent is not loaded or has other work, so its checkout cannot change now. */
    'forgePanel/session-busy': Record<string, never>
    /** No message of the Session waits after a failed or stopped attempt to create its worktree. */
    'forgePanel/not-waiting': Record<string, never>
    /** The removed worktree could not be checked out again; the message gives the reason. */
    'forgePanel/restore-failed': Record<string, never>
    /** The URL is not a visible binding of the Session that a provider serves, so the panel does not act on it. */
    'forgePanel/not-bound': Record<string, never>
    /**
     * The change request's head is no longer the commit the request named: the head the user confirmed for a merge,
     * the head displayed for complete checks, the head of the latest status for a diff, or the head of the displayed
     * diff for review threads and viewed marks. A diff, review, or viewed mark read the host refuses polls the change
     * request again at once, so a later status names the current head.
     */
    'forgePanel/stale-head': Record<string, never>
    /** The code host refused the change or could not be reached; the message gives the host's reason. */
    'forgePanel/action-failed': Record<string, never>
    /** The code host did not confirm whether it applied the change, which must be checked there before trying again. */
    'forgePanel/action-unknown': Record<string, never>
    /** The Session's directory is not inside a Git checkout, so it has no local changes. */
    'forgePanel/not-a-checkout': Record<string, never>
    /**
     * HEAD shares no history with the base branch chosen for the `branch` scope, or with none chosen, no remote names a
     * default branch that HEAD shares history with and the checkout is not a worktree the Session created.
     */
    'forgePanel/no-fork-point': Record<string, never>
    /** The base branch chosen for the `branch` scope does not exist, as after the branch was deleted. */
    'forgePanel/base-missing': Record<string, never>
    /** Filter configuration could not be read completely; no comparison ran. Correct Git settings or the output limit before retrying. */
    'forgePanel/filter-config-failed': Record<string, never>
    /**
     * The patch, the untracked file list, or the file exceeds `maxDiffBytes`, or the code host
     * or its provider refuses a change request's diff or file over a size limit.
     */
    'forgePanel/diff-too-large': Record<string, never>
    /** Complete checks could not be loaded; the polling preview remains available. */
    'forgePanel/checks-failed': Record<string, never>
    /** The code host did not provide the change request's diff or file, or its status has not been read yet; the message says why. */
    'forgePanel/diff-failed': Record<string, never>
    /** A chosen commit is no longer among the listed commits of the branch or change request, or the commits are out of order. */
    'forgePanel/commits-missing': Record<string, never>
    /** A chosen commit after the first lacks the commit listed before it as its first parent, so two ends cannot name the run. */
    'forgePanel/commits-not-linear': Record<string, never>
    /** The code host did not provide the signed-in user's viewed marks on the change request's files; the message says why. */
    'forgePanel/viewed-failed': Record<string, never>
    /** The code host did not list the accounts a review can be requested from; the message says why. */
    'forgePanel/reviewers-failed': Record<string, never>
    /** The code host did not provide a change request's description; the message says why. */
    'forgePanel/description-failed': Record<string, never>
    /** The code host's provider cannot read review threads, so the changes view shows none. */
    'forgePanel/review-unsupported': Record<string, never>
    /** The code host did not provide the change request's review threads, or its status has not been read yet; the message says why. */
    'forgePanel/review-failed': Record<string, never>
    /** No lens with the requested identity is registered, as after its plugin unloaded. */
    'forgePanel/lens-missing': Record<string, never>
    /** The files the view shows are no longer the files the panel reads, so the view reads them again before asking. */
    'forgePanel/lens-stale': Record<string, never>
    /**
     * The lens failed, ran past `lensTimeoutMs`, read more than `maxLensReadBytes`, or answered over `maxCachedLensBytes`;
     * the message says which.
     */
    'forgePanel/lens-failed': Record<string, never>
  }
}

declare module '@deepseek-ai/dsh-session/types' {
  interface PluginRecordMap {
    /** A request, withdrawal, or creation of the worktree a Session starts in. */
    'plugin:client-ui-forge/worktree': WorktreeRecord
  }
}

declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionMap {
    /** The worktree the panel created for the Session while the Session works in it, else null. */
    forgeWorktree: ForgeSessionWorktree | null
  }
}
