/** Live panel state of one followed Session, shared by all of its followers. */

import { isDeepStrictEqual } from 'node:util'
import type { Context } from '@deepseek-ai/cordis'
import type { ChangeRequestRef, ChangeRequestSnapshot, ForgeReadiness, ForgeRepository } from '@deepseek-ai/dsh-experimental-forge'
import type { SessionChangeRequest } from '@deepseek-ai/dsh-experimental-forge-session'
import type {} from '@deepseek-ai/dsh-experimental-worktree'
import type {} from '@deepseek-ai/dsh-sandbox-policy'
import { pluginRecordOf } from '@deepseek-ai/dsh-session'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import type { ProjectionHandle } from '@deepseek-ai/dsh-session-projection'
import { deadline } from '@deepseek-ai/dsh-timeout'
import { gitIn, hasBranch, inspectCheckout } from './git.ts'
import type { GitConfig, Inspection } from './git.ts'
import { localChanges } from './local-diff.ts'
import type { DiffConfig } from './local-diff.ts'
import { remoteOrder, upstreamBranch } from './parse.ts'
import type {
  ForgeCheckoutState, ForgeLocalChanges, ForgeMissingWorktree, ForgePanelChangeRequest, ForgePanelState, ForgePanelWorktree,
  ForgeWorktreeBlocker, ForgeWorktreeState,
} from './types.ts'
import type {} from '@deepseek-ai/dsh-working-directory'
import { within, WORKTREE_RECORD } from './worktree.ts'
import type { WorktreeCreations } from './worktree.ts'

/** Git and diff limits plus the sign-in probe deadline. */
export interface PanelConfig extends DiffConfig {
  /** Deadline in milliseconds for one provider sign-in probe. */
  readonly readinessTimeoutMs: number
  /** Age in milliseconds past which the status of the Session's change requests is read at once when the panel starts. */
  readonly statusMaxAgeMs: number
  /** Prefix of generated worktree branch names, which a name the user types starts from. */
  readonly worktreePrefix: string
}

/** The checkout's upstream branch and the remote URL its change requests are looked up at. */
interface Upstream {
  /** URL of the upstream's remote that a provider recognizes. */
  readonly remote: string
  /** Branch name on that remote. */
  readonly branch: string
}

/** What the panel of a Session leaves when its last follower left, for the next panel of that Session to start from. */
export interface KeptPanel {
  /** The last published state. */
  readonly state: ForgePanelState
  /** The latest snapshot of each change request, by URL. */
  readonly snapshots: ReadonlyMap<string, ChangeRequestSnapshot>
  /** Why the last inspection found that no worktree can be created. */
  readonly blocker: ForgeWorktreeBlocker | null
  /** The unavailable worktree the last inspection found. */
  readonly missing: ForgeMissingWorktree | null
  /** Remote URL and branch of the upstream that a branch lookup covered. */
  readonly discovered: string | null
}

/**
 * Panel state of one Session. Construction starts the first checkout
 * inspection and watches the Session's change requests. A panel given what the
 * previous panel of the Session kept publishes that state first, with the
 * current bindings and worktree facts, unless the Session has moved to another
 * directory. Inspections run one at
 * a time; a request that arrives during one runs once more after it, and a
 * result for a directory the Session has since left is dropped. A sign-in
 * probe runs when an inspection recognizes a new code host, after the first
 * inspection of a panel whose kept probe did not find the host ready, on
 * `refresh`, on `revisit` while the host is not ready, and once when status
 * reads on a host shown as ready start to be refused as unauthenticated;
 * a probe result for a host the panel no longer shows is dropped. Each change
 * request keeps the latest snapshot a poll returned while later polls fail.
 * When an inspection finds an upstream branch on a remote a provider
 * recognizes, the open change requests of that branch are bound as discovered,
 * once per remote and branch until a refresh, or until a panel starts or is
 * revisited while the Session shows no change request. The
 * worktree facts follow the `forgeWorktree` projection, the live creation, and the last failed one;
 * each inspection also decides whether the Session's sandbox can write the
 * checkout and its shared Git directory, which a new worktree needs, whether
 * the worktree the Session created and works in is gone, and how many lines
 * the `branch` scope changes; a measurement that fails leaves that null.
 */
export class SessionPanel {
  private current: ForgePanelState
  private readonly followers = new Set<() => void>()
  private readonly lifetime = new AbortController()
  private readonly tasks = new Set<Promise<void>>()
  private readonly stopWatching: () => void
  private readonly snapshots = new Map<string, ChangeRequestSnapshot>()
  private blocker: ForgeWorktreeBlocker | null = null
  private missing: ForgeMissingWorktree | null = null
  private inspection: Promise<void> | null = null
  private rerun: Promise<void> | null = null
  /** Remote URL and branch of the upstream that the last branch lookup covered, until the next lookup is due. */
  private discovered: string | null = null
  /** Whether the readiness the panel started with must be probed again after its first inspection. */
  private unconfirmed = false
  /** Whether a refused status read already started a sign-in probe, until no status read on the host is refused. */
  private questioned = false

  /**
   * @param ctx - service context that provides the forge, Session, directory, and process services.
   * @param config - Git limits, the sign-in probe deadline, and the worktree branch name prefix.
   * @param session - Session the panel describes.
   * @param worktreeStates - reads the `forgeWorktree` projection of the Session.
   * @param creations - reads the running creation and restoration, the last failed creation, and what a message of the
   * Session waits for.
   * @param reviewRevision - reads how many review changes were announced for a change request.
   * @param kept - what the previous panel of the Session kept, when there was one.
   * @param onIdle - called when the last follower leaves.
   */
  constructor(
    private readonly ctx: Context,
    private readonly config: PanelConfig,
    readonly session: Session,
    private readonly worktreeStates: ProjectionHandle<ForgeWorktreeState>,
    private readonly creations: Pick<WorktreeCreations, 'of' | 'restorationOf' | 'failureOf' | 'waitingOf'>,
    private readonly reviewRevision: (ref: ChangeRequestRef) => number,
    kept: KeptPanel | undefined,
    private readonly onIdle: () => void,
  ) {
    const directory = ctx.workingDirectory.get(session)
    const start = kept?.state.directory === directory ? kept : undefined
    if (start !== undefined) {
      for (const [url, snapshot] of start.snapshots) this.snapshots.set(url, snapshot)
      this.blocker = start.blocker
      this.missing = start.missing
      this.unconfirmed = start.state.readiness?.state !== 'ready'
    }
    const changeRequests = this.entries(ctx.forgeSession.changeRequests(session))
    if (start !== undefined && changeRequests.length > 0) this.discovered = start.discovered
    this.current = start === undefined
      ? { directory, checkout: { state: 'pending' }, repository: null, readiness: null, changeRequests, worktree: this.worktree(), local: null }
      : { ...start.state, changeRequests, worktree: this.worktree() }
    this.stopWatching = ctx.forgeSession.watch(session, (latest) => {
      this.publish({ ...this.current, changeRequests: this.entries(latest) })
      this.confirmSignIn(latest)
    }, { maxAgeMs: config.statusMaxAgeMs })
    void this.inspect()
  }

  /**
   * Name what the next panel of the Session starts from.
   * @returns the last published state and what the inspections and status polls found.
   */
  keep(): KeptPanel {
    return { state: this.current, snapshots: this.snapshots, blocker: this.blocker, missing: this.missing, discovered: this.discovered }
  }

  /**
   * Yield the current state, then each later state, until `signal` aborts or the panel stops.
   * @param signal - ends this follower.
   * @returns the states in publication order; intermediate states may be skipped.
   */
  async *follow(signal: AbortSignal): AsyncGenerator<ForgePanelState> {
    let wake: (() => void) | undefined
    const notify = (): void => { wake?.() }
    this.followers.add(notify)
    signal.addEventListener('abort', notify)
    this.lifetime.signal.addEventListener('abort', notify)
    try {
      let delivered: ForgePanelState | undefined
      while (!signal.aborted && !this.lifetime.signal.aborted) {
        if (this.current !== delivered) {
          delivered = this.current
          yield delivered
          continue
        }
        await new Promise<void>((resolve) => { wake = resolve })
        wake = undefined
      }
    } finally {
      this.followers.delete(notify)
      signal.removeEventListener('abort', notify)
      this.lifetime.signal.removeEventListener('abort', notify)
      if (this.followers.size === 0) this.onIdle()
    }
  }

  /**
   * React to one committed event of the Session: a directory change moves the
   * panel and reinspects; a tool result reinspects, because the tool may have
   * changed the checkout; a sandbox mode change reinspects, because it decides
   * whether a worktree can be created; the first turn, the first step, and
   * worktree records update the worktree facts.
   * @param event - committed Session event.
   */
  observe(event: SessionEvent): void {
    if (event.type === 'workspace-root/change') {
      this.publish({ ...this.current, directory: event.data.cwd, checkout: { state: 'pending' }, local: null })
      void this.inspect()
    } else if (event.type === 'tool/result' || event.type === 'sandbox/mode') {
      void this.inspect()
    } else if (event.type === 'turn/start' || event.type === 'step/start' || pluginRecordOf(event)?.type === WORKTREE_RECORD) {
      this.updateWorktree()
    }
  }

  /** Republish the worktree facts when they changed, such as after a creation moved or a worktree service appeared or left. */
  updateWorktree(): void {
    const worktree = this.worktree()
    if (!sameWorktree(worktree, this.current.worktree)) this.publish({ ...this.current, worktree })
  }

  /** Forget the missing worktree once it was checked out again; the next publication carries it, and a reinspection confirms it. */
  restored(): void {
    this.missing = null
  }

  /** Reinspect the checkout, such as after its directory was created again. */
  reinspect(): void {
    void this.inspect()
  }

  /**
   * Check again whether the worktree the Session works in is gone, publishing a change.
   * @param signal - cancellation of the check.
   * @returns the unavailable worktree, or null for a valid checkout or a Session working elsewhere.
   * @throws when the filesystem or Git cannot answer.
   */
  async checkMissing(signal: AbortSignal): Promise<ForgeMissingWorktree | null> {
    const directory = this.current.directory
    const state = this.worktreeStates.stateOf(this.session)
    const missing = await missingWorktree(
      this.ctx, this.config, this.session, state, directory, AbortSignal.any([signal, this.lifetime.signal]),
    )
    if (this.current.directory === directory) {
      this.missing = missing
      this.updateWorktree()
    }
    return missing
  }

  /**
   * Reinspect the checkout, probe sign-in again, and poll every bound change request at once.
   * @returns settles once the inspection and the sign-in probe have ended; each poll publishes its result when it finishes.
   */
  async refresh(): Promise<void> {
    this.discovered = null
    const inspection = this.inspect()
    const probe = this.current.repository === null ? undefined : this.probe(this.current.repository)
    for (const entry of this.current.changeRequests) {
      if (entry.ref !== null) this.ctx.forge.refresh(entry.ref)
    }
    await Promise.all([inspection, probe])
  }

  /**
   * Bring the panel up to date after its surface showed again: reinspect the checkout, poll each bound change request
   * whose latest poll is older than `statusMaxAgeMs`, probe sign-in again unless the last probe found the host ready,
   * and let the inspection look the upstream branch up again while the Session shows no change request.
   * @returns settles once the inspection and the sign-in probe have ended; each poll publishes its result when it finishes.
   */
  async revisit(): Promise<void> {
    if (this.current.changeRequests.length === 0) this.discovered = null
    const inspection = this.inspect()
    const { repository, readiness } = this.current
    // A null readiness has its probe in flight, or due after the inspection.
    const probe = repository !== null && readiness !== null && readiness.state !== 'ready' ? this.probe(repository) : undefined
    for (const entry of this.current.changeRequests) {
      if (entry.ref !== null) this.ctx.forge.refresh(entry.ref, { maxAgeMs: this.config.statusMaxAgeMs })
    }
    await Promise.all([inspection, probe])
  }

  /** Publish the review revisions of the bound change requests after a review change was announced. */
  reviewChanged(): void {
    this.publish({ ...this.current, changeRequests: this.entries(this.ctx.forgeSession.changeRequests(this.session)) })
  }

  /**
   * Stop inspections, probes, and the change request watch, end every follower, and wait for pending work.
   * @returns settles once pending inspections and probes have ended.
   */
  async dispose(): Promise<void> {
    this.lifetime.abort()
    this.stopWatching()
    await Promise.allSettled(this.tasks)
  }

  private entries(changeRequests: readonly SessionChangeRequest[]): ForgePanelChangeRequest[] {
    return changeRequests.map((entry) => {
      if (entry.update !== null && 'snapshot' in entry.update) this.snapshots.set(entry.url, entry.update.snapshot)
      const reviewRevision = entry.ref === null ? 0 : this.reviewRevision(entry.ref)
      const forge = entry.ref === null ? null : this.ctx.forge.describe(entry.ref.repository.forge) ?? null
      return { ...entry, forge, snapshot: this.snapshots.get(entry.url) ?? null, reviewRevision }
    })
  }

  private worktree(): ForgePanelWorktree {
    const state = this.worktreeStates.stateOf(this.session)
    return {
      editable: this.ctx.get('worktrees') !== undefined && !state.locked && state.created === null,
      blocker: this.blocker,
      namePrefix: this.config.worktreePrefix,
      request: state.request,
      created: state.created,
      creation: this.creations.of(this.session),
      failure: this.creations.failureOf(this.session),
      missing: this.missing,
      restoration: this.creations.restorationOf(this.session),
      waiting: this.creations.waitingOf(this.session),
    }
  }

  private publish(next: ForgePanelState): void {
    // A reinspection after a tool result usually finds the same checkout; equal states reach no follower.
    if (isDeepStrictEqual(next, this.current)) return
    this.current = next
    for (const notify of [...this.followers]) notify()
  }

  /** Track `task` for disposal; the returned promise resolves once it settles, whatever the outcome. */
  private run(task: Promise<void>): Promise<void> {
    this.tasks.add(task)
    const settle = (): void => { this.tasks.delete(task) }
    return task.then(settle, settle)
  }

  /**
   * Inspect the checkout, one inspection at a time; calls during an
   * inspection share one trailing rerun.
   * @returns resolves once an inspection that started after the call has ended.
   */
  private inspect(): Promise<void> {
    if (this.lifetime.signal.aborted) return Promise.resolve()
    if (this.inspection === null) {
      this.inspection = this.run(this.inspectOnce()).then(() => { this.inspection = null })
      return this.inspection
    }
    this.rerun ??= this.inspection.then(() => {
      this.rerun = null
      return this.inspect()
    })
    return this.rerun
  }

  private async inspectOnce(): Promise<void> {
    const directory = this.current.directory
    let checkout: ForgeCheckoutState
    let repository: ForgeRepository | null = null
    let blocker: ForgeWorktreeBlocker | null = null
    let local: ForgeLocalChanges | null = null
    let upstream: Upstream | null = null
    try {
      const inspection = await inspectCheckout(this.ctx, this.config, this.session, directory, this.lifetime.signal)
      if (inspection === undefined) {
        checkout = { state: 'none' }
        blocker = 'not-git'
      } else {
        checkout = { state: 'ready', checkout: inspection.checkout }
        repository = this.recognize(inspection)
        upstream = this.upstreamOf(inspection)
        blocker = await this.blockerOf(inspection)
        local = await this.localOf(inspection)
      }
    } catch (error) {
      checkout = { state: 'failed', message: error instanceof Error ? error.message : String(error) }
    }
    let missing: ForgeMissingWorktree | null = null
    try {
      missing = await missingWorktree(
        this.ctx, this.config, this.session, this.worktreeStates.stateOf(this.session), directory, this.lifetime.signal)
    } catch (_worktreeUnreadable) {
      // Without an answer from the filesystem or Git the panel offers no restoration.
    }
    if (this.lifetime.signal.aborted || this.current.directory !== directory) return
    this.blocker = blocker
    this.missing = missing
    const sameHost = repository !== null && this.current.repository !== null && hostOf(repository) === hostOf(this.current.repository)
    const readiness = sameHost ? this.current.readiness : null
    this.publish({ ...this.current, checkout, repository, readiness, worktree: this.worktree(), local })
    if (repository !== null && (!sameHost || this.unconfirmed)) void this.probe(repository)
    this.unconfirmed = false
    if (upstream !== null) this.discover(upstream)
  }

  /** The upstream branch with the first URL of its remote that a provider recognizes. */
  private upstreamOf(inspection: Inspection): Upstream | null {
    const tracked = upstreamBranch(inspection.upstream, inspection.remotes)
    const remote = tracked?.remote.urls.find(url => this.ctx.forge.repositoryFromRemote(url) !== undefined)
    return tracked === undefined || remote === undefined ? null : { remote, branch: tracked.branch }
  }

  /** Bind the open change requests of the upstream branch, once per remote and branch until a refresh. */
  private discover(upstream: Upstream): void {
    const key = `${upstream.remote}\n${upstream.branch}`
    if (this.discovered === key) return
    this.discovered = key
    void this.run(this.ctx.forgeSession.discoverBranch(this.session, upstream.remote, upstream.branch))
  }

  /** Decide whether the Session's sandbox lets the worktree service write the checkout and its shared Git directory. */
  private async blockerOf(inspection: Inspection): Promise<ForgeWorktreeBlocker | null> {
    const policy = this.ctx.sandboxPolicy.resolve({ session: this.session })
    if (policy.mode === 'danger-full-access') return null
    if (policy.mode === 'read-only') return 'read-only'
    const root = this.ctx.fs.processPath(await this.ctx.fs.resolve(policy.workspaceRoot, { signal: this.lifetime.signal }))
    // The Git directory of a linked checkout lies outside its root; a grant the policy carries for it counts.
    const writable = [root, ...policy.additionalWritableRoots ?? []]
    const granted = writable.some(directory => within(directory, inspection.commonDir))
    return within(root, inspection.checkout.root) && granted ? null : 'outside-writable-root'
  }

  /** Measure the `branch` scope; a failed measurement only hides the local changes row. */
  private async localOf(inspection: Inspection): Promise<ForgeLocalChanges | null> {
    try {
      return await localChanges(this.ctx, this.config, this.session, inspection, this.worktree().created, this.lifetime.signal)
    } catch (_error) {
      // The changes view reads and reports the same changes itself.
      return null
    }
  }

  private recognize(inspection: Inspection): ForgeRepository | null {
    for (const remote of remoteOrder(inspection.upstream, inspection.remotes)) {
      for (const url of remote.urls) {
        const repository = this.ctx.forge.repositoryFromRemote(url)
        if (repository !== undefined) return repository
      }
    }
    return null
  }

  /**
   * Probe sign-in again when a status read on the host the panel shows as ready was refused as unauthenticated, once
   * until a status read on that host is no longer refused.
   */
  private confirmSignIn(changeRequests: readonly SessionChangeRequest[]): void {
    const { repository, readiness } = this.current
    if (repository === null) return
    const refused = changeRequests.some(entry => entry.ref !== null && hostOf(entry.ref.repository) === hostOf(repository)
      && entry.update !== null && 'failure' in entry.update && entry.update.failure.code === 'unauthenticated')
    if (!refused) {
      this.questioned = false
      return
    }
    if (this.questioned || readiness?.state !== 'ready') return
    this.questioned = true
    this.publish({ ...this.current, readiness: null })
    void this.probe(repository)
  }

  /** Probe sign-in on the repository's host; resolves once the probe has ended. */
  private probe(repository: ForgeRepository): Promise<void> {
    const host = hostOf(repository)
    return this.run((async () => {
      let readiness: ForgeReadiness
      try {
        using timeout = deadline(this.lifetime.signal, this.config.readinessTimeoutMs, 'FORGE_PANEL_READINESS_TIMEOUT')
        readiness = await this.ctx.forge.readiness(repository, timeout.signal)
      } catch (error) {
        readiness = { state: 'unavailable', message: error instanceof Error ? error.message : String(error), signIn: null }
      }
      if (this.lifetime.signal.aborted || this.current.repository === null || hostOf(this.current.repository) !== host) return
      this.publish({ ...this.current, readiness })
    })())
  }
}

function sameWorktree(left: ForgePanelWorktree, right: ForgePanelWorktree): boolean {
  return left.editable === right.editable && left.blocker === right.blocker && left.request === right.request
    && left.created === right.created && left.creation === right.creation && left.failure === right.failure
    && left.missing?.branchExists === right.missing?.branchExists && left.restoration === right.restoration
    && left.waiting === right.waiting
}

/**
 * Decide whether a Session works inside the worktree it created while that
 * worktree's directory is gone, and whether its branch still exists.
 * @param ctx - context that provides `fs` and the process services.
 * @param config - Git limits.
 * @param session - Session to check.
 * @param state - recorded worktree and restoration completion.
 * @param directory - the Session's current directory.
 * @param signal - cancellation of the check.
 * @returns the unavailable worktree, or null for a valid checkout or a Session working elsewhere.
 * @throws when the filesystem or Git cannot answer.
 */
export async function missingWorktree(
  ctx: Context,
  config: GitConfig,
  session: Session,
  state: ForgeWorktreeState,
  directory: string,
  signal: AbortSignal,
): Promise<ForgeMissingWorktree | null> {
  const created = state.created
  if (created === null || !within(created.path, directory)) return null
  if (!state.restoring && await ctx.fs.lstat(created.path, undefined, signal) !== undefined) {
    const git = gitIn(ctx, config, session, created.path, signal)
    const top = await git('rev-parse', ['rev-parse', '--show-toplevel'], [0, 128])
    if (top.exitCode === 0) {
      const target = await ctx.fs.resolve(created.path, { signal })
      const root = await ctx.fs.resolve(top.stdout.replace(/\r?\n$/, ''), { cwd: created.path, signal })
      if (root.targetKey === target.targetKey) {
        const common = await git('common-dir', ['rev-parse', '--path-format=absolute', '--git-common-dir'])
        const source = await gitIn(ctx, config, session, created.repositoryRoot, signal, created.repositoryRoot)(
          'common-dir', ['rev-parse', '--path-format=absolute', '--git-common-dir'],
        )
        const actual = await ctx.fs.resolve(common.stdout.replace(/\r?\n$/, ''), { cwd: created.path, signal })
        const expected = await ctx.fs.resolve(source.stdout.replace(/\r?\n$/, ''), { cwd: created.repositoryRoot, signal })
        if (actual.targetKey === expected.targetKey) return null
      }
    }
  }
  try {
    return { branchExists: await hasBranch(ctx, config, session, created.repositoryRoot, created.branch, signal) }
  } catch (error) {
    signal.throwIfAborted()
    if (!state.restoring) throw error
    return { branchExists: null }
  }
}

function hostOf(repository: ForgeRepository): string {
  return `${repository.forge}:${repository.host}`
}
