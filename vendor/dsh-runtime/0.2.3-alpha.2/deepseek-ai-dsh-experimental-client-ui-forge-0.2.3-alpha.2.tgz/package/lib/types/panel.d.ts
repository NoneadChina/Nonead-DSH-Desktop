/** Live panel state of one followed Session, shared by all of its followers. */
import type { Context } from '@deepseek-ai/cordis';
import type { ChangeRequestRef, ChangeRequestSnapshot } from '@deepseek-ai/dsh-experimental-forge';
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
import type { ProjectionHandle } from '@deepseek-ai/dsh-session-projection';
import type { GitConfig } from './git.ts';
import type { DiffConfig } from './local-diff.ts';
import type { ForgeMissingWorktree, ForgePanelState, ForgeWorktreeBlocker, ForgeWorktreeState } from './types.ts';
import type { WorktreeCreations } from './worktree.ts';
/** Git and diff limits plus the sign-in probe deadline. */
export interface PanelConfig extends DiffConfig {
    /** Deadline in milliseconds for one provider sign-in probe. */
    readonly readinessTimeoutMs: number;
    /** Age in milliseconds past which the status of the Session's change requests is read at once when the panel starts. */
    readonly statusMaxAgeMs: number;
    /** Prefix of generated worktree branch names, which a name the user types starts from. */
    readonly worktreePrefix: string;
}
/** What the panel of a Session leaves when its last follower left, for the next panel of that Session to start from. */
export interface KeptPanel {
    /** The last published state. */
    readonly state: ForgePanelState;
    /** The latest snapshot of each change request, by URL. */
    readonly snapshots: ReadonlyMap<string, ChangeRequestSnapshot>;
    /** Why the last inspection found that no worktree can be created. */
    readonly blocker: ForgeWorktreeBlocker | null;
    /** The unavailable worktree the last inspection found. */
    readonly missing: ForgeMissingWorktree | null;
    /** Remote URL and branch of the upstream that a branch lookup covered. */
    readonly discovered: string | null;
}
/**
 * Panel state of one Session. Construction starts the first checkout
 * inspection and watches the Session's change requests. A panel given what the
 * previous panel of the Session kept publishes that state first, with the
 * current bindings and worktree facts, unless the Session has moved to another
 * directory. Inspections run one at
 * a time; a request that arrives during one runs once more after it, and a
 * result for a directory the Session has since left is dropped. A sign-in
 * probe runs when an inspection recognizes a new code host, after the first
 * inspection of a panel whose kept probe did not find the host ready, on
 * `refresh`, on `revisit` while the host is not ready, and once when status
 * reads on a host shown as ready start to be refused as unauthenticated;
 * a probe result for a host the panel no longer shows is dropped. Each change
 * request keeps the latest snapshot a poll returned while later polls fail.
 * When an inspection finds an upstream branch on a remote a provider
 * recognizes, the open change requests of that branch are bound as discovered,
 * once per remote and branch until a refresh, or until a panel starts or is
 * revisited while the Session shows no change request. The
 * worktree facts follow the `forgeWorktree` projection, the live creation, and the last failed one;
 * each inspection also decides whether the Session's sandbox can write the
 * checkout and its shared Git directory, which a new worktree needs, whether
 * the worktree the Session created and works in is gone, and how many lines
 * the `branch` scope changes; a measurement that fails leaves that null.
 */
export declare class SessionPanel {
    private readonly ctx;
    private readonly config;
    readonly session: Session;
    private readonly worktreeStates;
    private readonly creations;
    private readonly reviewRevision;
    private readonly onIdle;
    private current;
    private readonly followers;
    private readonly lifetime;
    private readonly tasks;
    private readonly stopWatching;
    private readonly snapshots;
    private blocker;
    private missing;
    private inspection;
    private rerun;
    /** Remote URL and branch of the upstream that the last branch lookup covered, until the next lookup is due. */
    private discovered;
    /** Whether the readiness the panel started with must be probed again after its first inspection. */
    private unconfirmed;
    /** Whether a refused status read already started a sign-in probe, until no status read on the host is refused. */
    private questioned;
    /**
     * @param ctx - service context that provides the forge, Session, directory, and process services.
     * @param config - Git limits, the sign-in probe deadline, and the worktree branch name prefix.
     * @param session - Session the panel describes.
     * @param worktreeStates - reads the `forgeWorktree` projection of the Session.
     * @param creations - reads the running creation and restoration, the last failed creation, and what a message of the
     * Session waits for.
     * @param reviewRevision - reads how many review changes were announced for a change request.
     * @param kept - what the previous panel of the Session kept, when there was one.
     * @param onIdle - called when the last follower leaves.
     */
    constructor(ctx: Context, config: PanelConfig, session: Session, worktreeStates: ProjectionHandle<ForgeWorktreeState>, creations: Pick<WorktreeCreations, 'of' | 'restorationOf' | 'failureOf' | 'waitingOf'>, reviewRevision: (ref: ChangeRequestRef) => number, kept: KeptPanel | undefined, onIdle: () => void);
    /**
     * Name what the next panel of the Session starts from.
     * @returns the last published state and what the inspections and status polls found.
     */
    keep(): KeptPanel;
    /**
     * Yield the current state, then each later state, until `signal` aborts or the panel stops.
     * @param signal - ends this follower.
     * @returns the states in publication order; intermediate states may be skipped.
     */
    follow(signal: AbortSignal): AsyncGenerator<ForgePanelState>;
    /**
     * React to one committed event of the Session: a directory change moves the
     * panel and reinspects; a tool result reinspects, because the tool may have
     * changed the checkout; a sandbox mode change reinspects, because it decides
     * whether a worktree can be created; the first turn, the first step, and
     * worktree records update the worktree facts.
     * @param event - committed Session event.
     */
    observe(event: SessionEvent): void;
    /** Republish the worktree facts when they changed, such as after a creation moved or a worktree service appeared or left. */
    updateWorktree(): void;
    /** Forget the missing worktree once it was checked out again; the next publication carries it, and a reinspection confirms it. */
    restored(): void;
    /** Reinspect the checkout, such as after its directory was created again. */
    reinspect(): void;
    /**
     * Check again whether the worktree the Session works in is gone, publishing a change.
     * @param signal - cancellation of the check.
     * @returns the unavailable worktree, or null for a valid checkout or a Session working elsewhere.
     * @throws when the filesystem or Git cannot answer.
     */
    checkMissing(signal: AbortSignal): Promise<ForgeMissingWorktree | null>;
    /**
     * Reinspect the checkout, probe sign-in again, and poll every bound change request at once.
     * @returns settles once the inspection and the sign-in probe have ended; each poll publishes its result when it finishes.
     */
    refresh(): Promise<void>;
    /**
     * Bring the panel up to date after its surface showed again: reinspect the checkout, poll each bound change request
     * whose latest poll is older than `statusMaxAgeMs`, probe sign-in again unless the last probe found the host ready,
     * and let the inspection look the upstream branch up again while the Session shows no change request.
     * @returns settles once the inspection and the sign-in probe have ended; each poll publishes its result when it finishes.
     */
    revisit(): Promise<void>;
    /** Publish the review revisions of the bound change requests after a review change was announced. */
    reviewChanged(): void;
    /**
     * Stop inspections, probes, and the change request watch, end every follower, and wait for pending work.
     * @returns settles once pending inspections and probes have ended.
     */
    dispose(): Promise<void>;
    private entries;
    private worktree;
    private publish;
    /** Track `task` for disposal; the returned promise resolves once it settles, whatever the outcome. */
    private run;
    /**
     * Inspect the checkout, one inspection at a time; calls during an
     * inspection share one trailing rerun.
     * @returns resolves once an inspection that started after the call has ended.
     */
    private inspect;
    private inspectOnce;
    /** The upstream branch with the first URL of its remote that a provider recognizes. */
    private upstreamOf;
    /** Bind the open change requests of the upstream branch, once per remote and branch until a refresh. */
    private discover;
    /** Decide whether the Session's sandbox lets the worktree service write the checkout and its shared Git directory. */
    private blockerOf;
    /** Measure the `branch` scope; a failed measurement only hides the local changes row. */
    private localOf;
    private recognize;
    /**
     * Probe sign-in again when a status read on the host the panel shows as ready was refused as unauthenticated, once
     * until a status read on that host is no longer refused.
     */
    private confirmSignIn;
    /** Probe sign-in on the repository's host; resolves once the probe has ended. */
    private probe;
}
/**
 * Decide whether a Session works inside the worktree it created while that
 * worktree's directory is gone, and whether its branch still exists.
 * @param ctx - context that provides `fs` and the process services.
 * @param config - Git limits.
 * @param session - Session to check.
 * @param state - recorded worktree and restoration completion.
 * @param directory - the Session's current directory.
 * @param signal - cancellation of the check.
 * @returns the unavailable worktree, or null for a valid checkout or a Session working elsewhere.
 * @throws when the filesystem or Git cannot answer.
 */
export declare function missingWorktree(ctx: Context, config: GitConfig, session: Session, state: ForgeWorktreeState, directory: string, signal: AbortSignal): Promise<ForgeMissingWorktree | null>;
//# sourceMappingURL=panel.d.ts.map