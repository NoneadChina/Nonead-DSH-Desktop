/**
 * The version of a diff's files that a lens request names. The panel host and the changes view compute it alike, so a
 * request refers to exactly the files its view shows.
 */
/**
 * Name the files of one diff: equal versions describe the same paths with the same changes in the same order.
 * @param files - the diff's files in display order.
 * @returns 14 hexadecimal digits of a 53-bit hash over each path and change digest.
 */
export declare function lensVersion(files: readonly {
    readonly path: string;
    readonly digest: string;
}[]): string;
//# sourceMappingURL=lens-version.d.ts.map