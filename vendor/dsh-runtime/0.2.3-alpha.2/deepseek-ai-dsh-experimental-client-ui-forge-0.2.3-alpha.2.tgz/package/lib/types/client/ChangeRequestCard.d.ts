/**
 * One change request as a compact card of the Session panel: one line with
 * the state glyph, the title, the number, and the checks outcome, which opens
 * the changes view, and, while expanded, one row per fact (checks, review,
 * merge state, the changed lines, which open its changes too, and the linked
 * issues) above the merge action. Opening on the host, copying, viewing
 * changes, marking a draft ready, and removing live in the card's actions
 * menu, which shows on hover or focus as on the panel's other rows.
 */
import { type ReactNode } from 'react';
import type { PanelDetailsProps } from '@deepseek-ai/dsh-client-ui-session-panel/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangeRequestSnapshot, MergeRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgePanelChangeRequest } from '../types.ts';
import { type OverviewActions } from './ChangeRequestOverview.tsx';
import type { NS } from './locales.ts';
import type { ForgeChangeRequestCardActionsProps } from './slots.ts';
import { type ChangeRequestEntry } from './status.ts';
type Translate = PropsLocale<typeof NS>['t'];
/**
 * What a card can do; a surface without a Session binding omits `remove`, `markReady`, `merge`, `viewChanges`, and the
 * overview actions.
 */
export interface ChangeRequestActions extends OverviewActions {
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy a URL to the clipboard. */
    readonly copyLink: (url: string) => void;
    /** Read the status again after a failed read. */
    readonly retry: () => void;
    /** Remove the change request from its Session. */
    readonly remove?: ((entry: ChangeRequestEntry) => void) | undefined;
    /** Mark a draft ready for review; settles once the outcome is reported. */
    readonly markReady?: ((entry: ChangeRequestEntry) => Promise<void>) | undefined;
    /** Merge the change request as `request` describes; settles once the outcome is reported. */
    readonly merge?: ((entry: ChangeRequestEntry, request: MergeRequest) => Promise<void>) | undefined;
    /** Load complete check details independently of polling; cancellation follows the open list. */
    readonly readChecks?: ((url: string, headSha: string, signal: AbortSignal) => Promise<ChangeRequestSnapshot>) | undefined;
    /** Open the changes view of the change request. */
    readonly viewChanges?: ((entry: ChangeRequestEntry) => void) | undefined;
    /** Draw the icon buttons plugins add to the card's head through `forge.change-request.card.actions`. */
    readonly renderActions?: ((owner: ForgeChangeRequestCardActionsProps) => ReactNode) | undefined;
    /**
     * Draw the content of the card's hover card, as the Session panel's rows do. A surface without it shows none.
     */
    readonly renderDetails?: ((details: PanelDetailsProps) => ReactNode) | undefined;
}
/** Props of one change request card. */
export interface ChangeRequestCardProps {
    /** Change request with its latest snapshot and polling result. */
    readonly entry: ForgePanelChangeRequest;
    /** Whether the details show. */
    readonly expanded: boolean;
    /** Show or hide the details. */
    readonly onToggle: () => void;
    /** Current epoch milliseconds for relative times. */
    readonly now: number;
    /** Card actions. */
    readonly actions: ChangeRequestActions;
    /** Active UI language for numeric formatting. */
    readonly locale: string;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render the changed lines with the unresolved review thread count, as a row that opens the changes view when the
 * provider serves the change request.
 * @param props - the change request, its snapshot, how the row names it, the actions, the number locale, and copy.
 * @returns the row.
 */
export declare function ChangesRow({ entry, snapshot, name, actions, locale, t }: {
    readonly entry: ChangeRequestEntry;
    readonly snapshot: ChangeRequestSnapshot;
    readonly name: string;
    readonly actions: ChangeRequestActions;
    readonly locale: string;
    readonly t: Translate;
}): ReactNode;
/**
 * Render the merge action of an open change request the host would merge now.
 * @param props.entry - the change request.
 * @param props.snapshot - its latest snapshot.
 * @param props.name - how menus name it.
 * @param props.actions - the actions the surface offers.
 * @param props.className - class of the wrapper, the card footer's by default.
 * @param props.t - forge panel copy.
 * @returns the action, or null when the host would not merge now or the surface does not offer it.
 */
export declare function ChangeRequestPrimary({ entry, snapshot, name, actions, className, t }: {
    readonly entry: ChangeRequestEntry;
    readonly snapshot: ChangeRequestSnapshot;
    readonly name: string;
    readonly actions: ChangeRequestActions;
    readonly className?: string | undefined;
    readonly t: Translate;
}): ReactNode;
/**
 * Render the merged or closed fact of a finished change request with its time.
 * @param props - the snapshot, current epoch milliseconds for the relative time, and copy.
 * @returns the row.
 */
export declare function FinishedRow({ snapshot, now, t }: {
    readonly snapshot: ChangeRequestSnapshot;
    readonly now: number;
    readonly t: Translate;
}): ReactNode;
/**
 * The aggregate review outcome of an open change request in words, with its tone.
 * @param snapshot - the snapshot.
 * @param t - forge panel copy.
 * @returns the outcome and its tone.
 */
export declare function reviewOutcome(snapshot: ChangeRequestSnapshot, t: Translate): {
    readonly value: string;
    readonly tone: string | undefined;
};
/**
 * Render the merge state of an open change request: whether it conflicts with its base, and the branch update.
 * @param props - the change request, its snapshot, the update action, and copy.
 * @returns the row.
 */
export declare function MergeStateRow({ entry, snapshot, updateBranch, t }: {
    readonly entry: ChangeRequestEntry;
    readonly snapshot: ChangeRequestSnapshot;
    readonly updateBranch: ChangeRequestActions['updateBranch'];
    readonly t: Translate;
}): ReactNode;
/**
 * Render one change request. A press on the card's line opens the changes view of a change request a provider serves
 * and has read; with the platform's modifier key or the middle button, and for any other change request, it opens
 * the host's page. The line shows its status as glyphs and, while collapsed, reads it in words to assistive
 * technology, which the expanded rows do otherwise; the hover card names the full title, the branches, and that status.
 * @param props - change request, expansion, current time, actions, and copy.
 * @returns the card.
 */
export declare function ChangeRequestCard({ entry, expanded, onToggle, now, actions, locale, t }: ChangeRequestCardProps): ReactNode;
export {};
//# sourceMappingURL=ChangeRequestCard.d.ts.map