/**
 * The expansion the user chose for the change request cards of one Session, and whether its list shows every card. The
 * registration declares it as an exclusive store, so each Session keeps its
 * choices while its scope is retained, across hiding and showing the panel.
 */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-store';
/** Card choices of one Session. */
export interface ChangeRequestsSectionState {
    /** Whether the user expanded (true) or collapsed (false) a card, by change request URL; unchosen cards are absent. */
    expanded: Record<string, boolean>;
    /** Whether the list shows the cards past its first three. */
    unfolded: boolean;
}
/** The change requests section store's write set. */
type ChangeRequestsSectionActions = {
    toggled: (draft: ChangeRequestsSectionState, url: string, expanded: boolean) => void;
    unfoldedSet: (draft: ChangeRequestsSectionState, unfolded: boolean) => void;
};
/**
 * Declare the change requests section's store.
 * @returns the store handle to declare on the registration.
 */
export declare function createChangeRequestsSectionStore(): EngineStoreHandle<ChangeRequestsSectionState, ChangeRequestsSectionActions>;
export {};
//# sourceMappingURL=change-requests-store.d.ts.map