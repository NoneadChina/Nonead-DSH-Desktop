/**
 * The review page: the signed-in user's change requests beside the one the reader shows in full. The page reads its
 * lists and the shown change request through Host streams that run only while it is mounted, keeps the reader's choices
 * in its store, and shows one column at a time where the page is narrow.
 */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRenderSlots, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangeRequestDescription, ForgeReviewThread } from '@deepseek-ai/dsh-experimental-forge/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeReviewChangeRequest, ForgeReviewFrame } from '../../types.ts';
import type { ChangeRequestActions } from '../ChangeRequestCard.tsx';
import { type ChangesTabInjected } from '../ChangesTab.tsx';
import type { NS } from '../locales.ts';
import { type ReviewChatFace } from './ReviewChat.tsx';
import type { ReviewSelection } from '../review.ts';
import type { createReviewStore } from './review-store.ts';
import type { HostStream } from '../source.ts';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/**
 * What the changes view of the review page reads and does, each naming the change request by URL; the page quotes
 * comments and threads into its own conversation.
 */
export type ReviewChangesFace = Omit<ChangesTabInjected, 'keyedHooks' | 'hooks' | 'reconnect' | 'addReviewToInput' | 'addThreadToInput'>;
/** Business face of the review page. */
export interface ReviewPageInjected {
    /** The UI language; the renderer binds it as `useLocale`. */
    readonly hooks: {
        readonly locale: HostObservable<string>;
    };
    /** Open the list stream of one repository, named `owner/name`, or of every repository for the empty string. */
    readonly openLists: (scope: string, signal: AbortSignal) => HostStream<ForgeReviewFrame>;
    /** Open the stream of one change request by URL. */
    readonly openChangeRequest: (url: string, signal: AbortSignal) => HostStream<ForgeReviewChangeRequest>;
    /** Subscribe to transport resets, after which open streams no longer deliver. */
    readonly subscribeReset: (listener: () => void) => () => void;
    /** Read every list again; settles once the Host accepted the request, after reporting a failure. */
    readonly refresh: () => Promise<void>;
    /** Read the description and labels of a change request. */
    readonly readDescription: (url: string, signal: AbortSignal) => Promise<RemoteResult<ChangeRequestDescription>>;
    /** The card actions acting on one change request; `showChanges` opens the changes tab. */
    readonly actionsFor: (url: string, showChanges: () => void) => ChangeRequestActions;
    /** Reads and writes of the changes view. */
    readonly changes: ReviewChangesFace;
    /** Copy text and report the outcome. */
    readonly copyText: (text: string) => void;
    /** What the chat tab asks of the forge panel. */
    readonly chat: ReviewChatFace;
    /** Quote a comment in a retained Session's draft; returns whether the draft took it. */
    readonly quoteReview: (sessionId: SessionId, selection: ReviewSelection) => boolean;
    /** Quote a whole thread in a retained Session's draft; returns whether the draft took it. */
    readonly quoteThread: (sessionId: SessionId, thread: ForgeReviewThread, url: string, range: string | null) => boolean;
}
/** Full props of the review page. */
export type ReviewPageProps = InjectFace<ReviewPageInjected> & PropsStore<ReturnType<typeof createReviewStore>> & Pick<PropsRenderSlots<'forge.review.conversation'>, 'renderSlot' | 'SessionProvider'> & PropsLocale<typeof NS>;
/**
 * Render the review page.
 * @param props - the Host streams and reads, the card actions, the page store, and copy.
 * @returns the page.
 */
export declare function ReviewPage(props: ReviewPageProps): ReactNode;
//# sourceMappingURL=ReviewPage.d.ts.map