/** The review page's navigation row: its glyph, and the number of change requests that ask the user for a review. */
import type { ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from '../locales.ts';
import type { StreamSnapshot } from '../source.ts';
/**
 * Draw the change request glyph at the size the sidebar asks for; the sidebar names the row.
 * @param props - the sidebar's icon share.
 * @returns the decorative glyph.
 */
export declare function ReviewNavIcon({ size }: PropsRuntime<'sidebar.panellist'>): ReactNode;
/** Business face of the navigation count. */
export interface ReviewNavCountInjected {
    /** The count stream's latest value; the renderer binds it as `useCount`. */
    readonly hooks: {
        readonly count: HostObservable<StreamSnapshot<number | null>>;
    };
}
/** Full props of the navigation count. */
export type ReviewNavCountProps = PropsRuntime<'sidebar.panellist.trailing'> & InjectFace<ReviewNavCountInjected> & PropsLocale<typeof NS>;
/**
 * Render the number of change requests that ask the user for a review, nothing before the first count or at zero.
 * The visible number is decorative; the sentence beside it describes the row's button.
 * @param props - the count hook, the row's width state, and copy.
 * @returns the count, or null.
 */
export declare function ReviewNavCount({ useCount, wide, t }: ReviewNavCountProps): ReactNode;
//# sourceMappingURL=ReviewNav.d.ts.map