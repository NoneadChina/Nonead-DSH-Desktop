/**
 * Registrations of the review page: its navigation row and count, its page, and the actions and reads its views call
 * through the forge panel Remote's review methods, which name a change request by URL and need no Session.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgePanelKey } from '../locales.ts';
import { type ReviewPageInjected } from './ReviewPage.tsx';
import { type NoticeSource } from '../source.ts';
import type { ChangeRequestEntry } from '../status.ts';
declare module '@deepseek-ai/dsh-api-session-controller/client' {
    interface SessionReferenceSourceMap {
        /** The review page's conversation about a change request. */
        forgeReview: unknown;
        /** A Session panel stream, held from its opening until it ends. */
        forgePanel: unknown;
    }
}
/** Main panel and navigation row id of the review page. */
export declare const REVIEW_PANEL: MainPanelId;
/** What the review page shares with the forge panel's other surfaces. */
export interface ReviewPageDeps {
    /** Action notices. */
    readonly notices: NoticeSource;
    /** Report a failed Remote call with `failure`, or the key `codes` names for its code; returns whether it succeeded. */
    readonly settled: (result: RemoteResult<unknown>, failure: ForgePanelKey, codes?: Partial<Record<string, ForgePanelKey>>) => boolean;
    /** How toasts name a change request. */
    readonly nameOf: (entry: ChangeRequestEntry) => string;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy text and report the outcome. */
    readonly copyText: (text: string) => void;
    /** Copy a path and report the outcome. */
    readonly copyPath: (path: string) => void;
    /** Quote a comment in a retained Session's draft, numbered after the comments already there. */
    readonly quoteReview: ReviewPageInjected['quoteReview'];
    /** Quote a whole thread in a retained Session's draft, numbered after the threads already there. */
    readonly quoteThread: ReviewPageInjected['quoteThread'];
    /** The UI language. */
    readonly locale: HostObservable<string>;
}
/**
 * Register the review page while the current Peer may read the review lists.
 * @param ctx - client plugin lifetime with the forge panel Remote.
 * @param deps - what the page shares with the other surfaces.
 */
export declare function registerReviewPage(ctx: Context, deps: ReviewPageDeps): void;
//# sourceMappingURL=review-mount.d.ts.map