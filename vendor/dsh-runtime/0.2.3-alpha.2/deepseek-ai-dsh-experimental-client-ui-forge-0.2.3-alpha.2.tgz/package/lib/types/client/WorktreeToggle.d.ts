/** New Session option: start the Session in a new worktree, on a chosen or generated branch, from a local or remote branch. */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeWorktreeBases } from '../types.ts';
import type { NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
import { type WorktreeRequestResult } from './WorktreeNameDialog.tsx';
/** Business face of the New Session option. */
export interface WorktreeToggleInjected {
    /** Panel snapshot of the Session; the renderer binds it as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
    /**
     * Request a worktree from a base on a branch name, replacing an open request.
     * @param from - full name of a local or remote-tracking base branch, or null for HEAD.
     * @param name - new branch name, or null for a generated one.
     * @returns the outcome; a failure other than a refused name is already reported.
     */
    readonly request: (from: string | null, name: string | null) => Promise<WorktreeRequestResult>;
    /**
     * Withdraw the open request.
     * @returns whether the Host accepted it.
     */
    readonly cancel: () => Promise<boolean>;
    /**
     * List the branches a worktree of the Session's checkout can start from whose names contain `query`.
     * @param query - search text; empty for every branch.
     * @param signal - aborts the read.
     * @returns the branches, or the failure the menu shows.
     */
    readonly bases: (query: string, signal: AbortSignal) => Promise<RemoteResult<ForgeWorktreeBases>>;
}
/** Full props of the New Session option. */
export type WorktreeToggleProps = InjectFace<WorktreeToggleInjected> & PropsLocale<typeof NS>;
/**
 * Render the worktree option while the Session can still start in a worktree:
 * the current branch, or the base and branch name menu once requested, then the
 * checkbox. The menu searches local branches and each remote's branches and
 * opens the naming dialog. A blocked request keeps its selected base visible
 * without a menu; the checkbox only withdraws it. Branch details support
 * pointer, touch, and keyboard access. The request stays fixed while the
 * worktree is being created.
 * @param props - panel snapshot hook, request actions, the base listing, and copy.
 * @returns the option, or nothing outside a known Git checkout, once a turn started,
 * the request settled, or no worktree service is mounted.
 */
export declare function WorktreeToggle({ usePanel, request, cancel, bases, t }: WorktreeToggleProps): ReactNode;
//# sourceMappingURL=WorktreeToggle.d.ts.map