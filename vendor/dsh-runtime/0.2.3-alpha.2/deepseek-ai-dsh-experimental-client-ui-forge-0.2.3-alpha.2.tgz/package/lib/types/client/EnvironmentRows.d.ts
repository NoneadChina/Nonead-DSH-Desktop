/** Environment section rows: the Session's checkout, its branch changes, and a lost panel stream. */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRenderFactories, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteHostFacts } from '@deepseek-ai/dsh-api-remotes/client';
import type { NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
/** Business face of the checkout row. */
export interface CheckoutRowInjected {
    /** Panel snapshot of the Session and the Host facts; bound as `usePanel` and `useHost`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
        readonly host: HostObservable<RemoteHostFacts>;
    };
    /**
     * Reinspect the checkout, probe sign-in, and poll the change requests,
     * unless an automatic refresh of this Session ran in the last 10 seconds.
     */
    readonly refreshIfStale: () => void;
    /** Check the removed worktree of the Session out again, reporting the outcome. */
    readonly restore: () => void;
}
/** Full props of the checkout row. */
export type CheckoutRowProps = PropsRuntime<'conversation.session.panel.environment.row'> & PropsRenderFactories & InjectFace<CheckoutRowInjected> & PropsLocale<typeof NS>;
/** Business face of the local changes row. */
export interface LocalChangesRowInjected {
    /** Panel snapshot of the Session; bound as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
    /** Open the local changes view in the right sidebar. */
    readonly viewLocalChanges: () => void;
    /** Ask the Session's Agent to create a change request for its changes, reporting the outcome. */
    readonly createChangeRequest: () => void;
}
/** Full props of the local changes row. */
export type LocalChangesRowProps = PropsRuntime<'conversation.session.panel.environment.row'> & InjectFace<LocalChangesRowInjected> & PropsLocale<typeof NS>;
/**
 * Render the branch the Session works on and the kind of its directory. The
 * row and its More button open the shared directory menu on the checkout
 * root; a removed worktree offers Restore instead, and a failed inspection
 * shows a warning whose tooltip carries the failure. Tooltips show after
 * 500ms of hover, and a branch name the row clips crawls into view while the
 * pointer rests on the row. The row is mounted
 * whenever the panel shows, so it refreshes the Session's forge state when
 * the panel opens and when the window regains focus, which picks up changes
 * made outside the Session.
 * @param props - panel snapshot and Host facts hooks, refresh, restore, menu bindings, and copy.
 * @returns the row, or null before the first inspection and outside a Git checkout.
 */
export declare function CheckoutRow({ sessionId, usePanel, useHost, useContextMenu, renderFactorySlot, refreshIfStale, restore, t, }: CheckoutRowProps): ReactNode;
/** Business face of the connection row. */
export interface ConnectionRowInjected {
    /** Panel snapshot of the Session; bound as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
    /** Open the stream again after it ended. */
    readonly reconnect: () => void;
}
/** Full props of the connection row. */
export type ConnectionRowProps = PropsRuntime<'conversation.session.panel.environment.row'> & InjectFace<ConnectionRowInjected> & PropsLocale<typeof NS>;
/**
 * Say that the Session's panel stream ended, so the Git and change request
 * details may be out of date, whether or not it delivered a state first; Retry
 * opens the stream again. Assistive technology announces the row when it shows.
 * @param props - panel snapshot hook, reconnect action, and copy.
 * @returns the row, or null while the stream is open.
 */
export declare function ConnectionRow({ usePanel, reconnect, t }: ConnectionRowProps): ReactNode;
/**
 * Render the size of the branch's changes; the row opens the local changes
 * view, and its menu offers the view and, without an open change request for
 * the branch, asking the Agent to create one. Opening the view closes the
 * panel's overlay.
 * @param props - panel snapshot hook, view and create actions, panel owner values, and copy.
 * @returns the row, or null while the branch changes no files.
 */
export declare function LocalChangesRow({ usePanel, dismissOverlay, viewLocalChanges, createChangeRequest, t, }: LocalChangesRowProps): ReactNode;
//# sourceMappingURL=EnvironmentRows.d.ts.map