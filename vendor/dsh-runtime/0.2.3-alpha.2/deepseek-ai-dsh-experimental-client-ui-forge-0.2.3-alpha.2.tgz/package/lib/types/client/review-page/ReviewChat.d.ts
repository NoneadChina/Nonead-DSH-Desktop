/**
 * The review page's chat tab: a conversation about one change request in a blank Session of a Workspace, shown with
 * the New Session hero until its first message and as a transcript afterwards. The page binds the change request to
 * the Session once its first message enters the inbox, and only a Session the page started for the change request
 * shows here, never an existing conversation.
 */
import { type ReactNode } from 'react';
import type { ConversationViewsProps, WorkspaceSelectedHandler, WorkspaceSessionAdopter } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { PropsLocale, PropsRenderFactories, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionReference } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ForgeReviewChangeRequest } from '../../types.ts';
import type { NS } from '../locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/**
 * A request to fill the draft: the change request reference while the draft is empty, or a suggested prompt that
 * replaces the draft and quotes the reference after it.
 */
export type ReviewDraft = {
    readonly kind: 'reference';
    readonly frame: ForgeReviewChangeRequest;
} | {
    readonly kind: 'prompt';
    readonly frame: ForgeReviewChangeRequest;
    readonly text: string;
};
/** What the chat tab asks of the forge panel. */
export interface ReviewChatFace {
    /**
     * Resolve the blank Session a new conversation about the change request starts in: in the Workspace whose folder
     * name is the repository's name, else in the most recently updated Workspace.
     * @returns the Session, or undefined without any Workspace.
     */
    readonly connect: (frame: ForgeReviewChangeRequest) => Promise<SessionId | undefined>;
    /** Resolve the blank Session of a Workspace the reader picked in the conversation; rejects when it cannot connect. */
    readonly connectWorkspace: (workspaceId: Parameters<WorkspaceSelectedHandler>[0]) => Promise<SessionId>;
    /** Tell the reader that a picked Workspace could not be opened. */
    readonly workspaceFailed: (error: unknown) => void;
    /** Retain a Session; the caller releases the returned reference. */
    readonly retain: (sessionId: SessionId) => SessionReference;
    /** Bind the change request to the Session at its next message, or forget the choice for null. */
    readonly stage: (sessionId: SessionId, url: string | null) => void;
    /** Fill the draft of a retained Session once it opens; settles once the draft is filled or the Session failed to open. */
    readonly fill: (reference: SessionReference, draft: ReviewDraft) => Promise<void>;
    /** Show the Session in the main conversation view. */
    readonly openInMain: (sessionId: SessionId) => void;
    /** Ask for a worktree for the Session before its first step. */
    readonly requestWorktree: (sessionId: SessionId) => void;
}
/** The Chat view only, which the embedded conversation shows. */
export declare function ReviewChatView(props: ConversationViewsProps): ReactNode;
/** Full props of the embedded conversation. */
export type ReviewConversationProps = PropsRuntime<'forge.review.conversation'> & PropsRenderFactories;
/**
 * Render the shared conversation content for the Session the chat tab shows.
 * @param props - the Session, its conversation state, and the owner's headline and Workspace handler.
 * @returns the embedded conversation.
 */
export declare function ReviewConversation({ sessionId, useSession, useConversation, useSessions, renderFactorySlot, headline, onWorkspaceSelected, }: ReviewConversationProps): ReactNode;
/** The conversation the review page keeps for the change request it shows, held while the page shows it. */
export interface ReviewConversation {
    /** Whether no conversation could start, because no Workspace exists or connecting failed. */
    readonly failed: boolean;
    /** The retained conversation, or null before one. */
    readonly reference: SessionReference | null;
    /**
     * Keep another Session as the conversation: retain it, move the draft of the one held before to it while both are
     * retained, then release the one held before.
     */
    readonly moveTo: (sessionId: SessionId, adopt: WorkspaceSessionAdopter) => void;
    /** Record that a conversation's draft already names the change request. */
    readonly markFilled: (sessionId: SessionId) => void;
    /**
     * Start the conversation when there is none, retain it, bind the change request at its next message, and quote the
     * change request in its draft.
     * @returns the opened conversation once its draft names the change request, or undefined when none could start.
     */
    readonly start: () => Promise<SessionReference | undefined>;
}
/**
 * Keep the conversation of the shown change request: retain it while the page shows the change request, so its draft
 * takes quotes from any tab, and quote the change request in its draft once.
 * @param frame - the shown change request, or undefined before its first frame.
 * @param sessionId - the conversation recorded for the change request, or undefined before one.
 * @param onConversation - records the conversation of the change request, or forgets it for null.
 * @param chat - what the chat asks of the forge panel.
 * @returns the conversation state and its actions.
 */
export declare function useReviewConversation(frame: ForgeReviewChangeRequest | undefined, sessionId: SessionId | undefined, onConversation: (sessionId: SessionId | null) => void, chat: ReviewChatFace): ReviewConversation;
/** Props of the chat tab. */
export interface ReviewChatProps extends Pick<PropsRenderSlots<'forge.review.conversation'>, 'renderSlot' | 'SessionProvider'> {
    /** The change request. */
    readonly frame: ForgeReviewChangeRequest;
    /** The conversation the page started for the change request, or undefined before one. */
    readonly sessionId: SessionId | undefined;
    /** The conversation the page keeps for the change request. */
    readonly conversation: ReviewConversation;
    /** Record the conversation of the change request, or forget it for null. */
    readonly onConversation: (sessionId: SessionId | null) => void;
    /** What the tab asks of the forge panel. */
    readonly chat: ReviewChatFace;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render the chat tab: start the conversation on first show, then embed it with the suggested prompts above it.
 * @param props - the change request, its conversation, and the forge panel's chat actions.
 * @returns the tab body.
 */
export declare function ReviewChat({ frame, sessionId, conversation, onConversation, chat, renderSlot, SessionProvider, t, }: ReviewChatProps): ReactNode;
export {};
//# sourceMappingURL=ReviewChat.d.ts.map