/** Inline comment records and the editing of comment drafts kept in the browser at their captured code location. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ReviewActions } from './ReviewComposer.tsx';
import { type FileReviewState, type ReviewThread as Thread } from './review-queue.ts';
import type { NS } from './locales.ts';
/**
 * Subscribe only to comments that belong to the displayed file and source.
 * @param actions - review actions and their browser store.
 * @param path - displayed file path.
 * @returns stable file-scoped comments and write availability.
 */
export declare function useFileReview(actions: ReviewActions | undefined, path: string): FileReviewState;
/**
 * Render a saved comment at its line: its lines and state, the menu of its less frequent actions, its text, and Add to
 * input. A reference or a publication receipt can be removed from the view, which leaves the main input and the code
 * host as they are. A comment draft kept in the browser can be edited, deleted after a confirmation, or moved into the
 * pending review on the code host.
 * @param props - record, edit availability, source actions, and localized copy.
 * @returns one compact inline comment card.
 */
export declare function ReviewThread({ thread, actions, locked, outdated, t }: PropsLocale<typeof NS> & {
    readonly thread: Thread;
    readonly actions: ReviewActions;
    readonly locked: boolean;
    readonly outdated: boolean;
}): ReactNode;
//# sourceMappingURL=ReviewThread.d.ts.map