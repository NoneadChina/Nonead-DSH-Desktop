/**
 * Highlighting of drawn rows with the lines before them. A run of rows drawn after collapsed unchanged lines is
 * highlighted again with up to {@link HIGHLIGHT_CONTEXT_LINES} lines of the file before it, so a code block, comment,
 * or string that opens in the collapsed lines colors the run as it does in the whole file. Constructs that open further
 * back keep the colors of the run alone.
 */
import { type RefObject } from 'react';
import type { CodeHighlighter, HighlightSpan } from '@deepseek-ai/dsh-client-ui-primitives';
import type { ForgeDiffHunk } from '../types.ts';
import type { DiffRow } from './diff-rows.ts';
/** Lines before a run that its highlighting reads; one call stays within an idle period for the slower grammars. */
export declare const HIGHLIGHT_CONTEXT_LINES = 120;
/** Tokens of one side's lines by line number. */
export type LineSpans = ReadonlyMap<number, readonly HighlightSpan[]>;
/** One side of one run of rows: its first and last line numbers and their texts. */
export interface SideRun {
    readonly side: 'old' | 'new';
    readonly first: number;
    readonly last: number;
    readonly texts: readonly string[];
}
/**
 * Rebuild the old side of a file from its new side and the hunks of its diff.
 * @param lines - the new side, which the hunks describe.
 * @param hunks - the hunks, in file order.
 * @returns the old side's lines.
 */
export declare function oldSideLines(lines: readonly string[], hunks: readonly ForgeDiffHunk[]): string[];
/**
 * One side of a run of rows, which numbers its lines consecutively.
 * @param rows - the run.
 * @param side - the side.
 * @returns the side's lines, or undefined when the run has none on that side.
 */
export declare function sideRun(rows: readonly DiffRow[], side: 'old' | 'new'): SideRun | undefined;
/**
 * Highlight one side of a run after the lines of the file before it.
 * @param run - the side of the run.
 * @param file - the whole side the run belongs to.
 * @param highlighter - the file's highlighter.
 * @returns the run's tokens by line number, null when nothing precedes the run, or undefined while the grammar is
 * unavailable.
 */
export declare function contextSpans(run: SideRun, file: readonly string[], highlighter: CodeHighlighter): LineSpans | null | undefined;
/** Whole sides of a file: the new side as read, and the old side rebuilt from it. */
export interface FileSides {
    readonly old: readonly string[];
    readonly new: readonly string[];
}
/**
 * Key of one side of a run in one change of a file, which its tokens are kept under. Tokens carry the text of their
 * lines, so the key names the change: the same lines of another change of the file never take these tokens.
 * @param change - the digest of the file's change.
 * @param run - the side of the run.
 * @returns the key.
 */
export declare function runKey(change: string, run: SideRun): string;
/**
 * Highlight each side of each run again with the lines before it, one side of one run per idle period, once the whole
 * file is known. The tokens apply in one update when every run is done and only while the reader selects nothing
 * inside `root`, since redrawn tokens would drop the selection; a selection or drag defers them until it ends. Tokens
 * are kept under the change they were computed for, so another change of the file finds none of them, even before its
 * text is read; a new reading of the text starts the work over.
 * @param runs - the sides of the drawn runs.
 * @param sides - the whole file, or undefined while it is unknown.
 * @param change - the digest of the file's change, which every key names.
 * @param highlighter - the file's highlighter; a grammar that loads later resumes the work.
 * @param root - the element whose selection defers the update.
 * @param selecting - whether the reader is dragging a selection.
 * @returns the corrected tokens by {@link runKey}.
 */
export declare function useContextHighlight(runs: readonly SideRun[], sides: FileSides | undefined, change: string, highlighter: CodeHighlighter, root: RefObject<HTMLElement | null>, selecting: boolean): ReadonlyMap<string, LineSpans>;
//# sourceMappingURL=highlight-context.d.ts.map