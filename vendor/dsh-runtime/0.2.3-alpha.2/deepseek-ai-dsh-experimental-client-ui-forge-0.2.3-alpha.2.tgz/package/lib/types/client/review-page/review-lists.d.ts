/**
 * What the review page's list column shows from the Host's list frames: one section per list with its items and the
 * text they are searched by, the hint each item carries, the repositories the lists name, and the failure each section reports.
 */
import type { ChangeRequestSummary, ForgeFailure, ForgeViewerFilter } from '@deepseek-ai/dsh-experimental-forge/types';
import type { SearchKeys } from '@deepseek-ai/dsh-util-text-search';
import type { ForgeReviewFrame } from '../../types.ts';
import type { ForgePanelKey } from '../locales.ts';
import { type ChangeRequestTone } from '../status.ts';
/** The lists in the order the page shows them. */
export declare const REVIEW_FILTERS: readonly ForgeViewerFilter[];
/** One listed change request with the host it was listed on. */
export interface ReviewItem {
    /** The change request. */
    readonly summary: ChangeRequestSummary;
    /** Forge family of the provider that listed it. */
    readonly forge: string;
    /** Host it was listed on. */
    readonly host: string;
}
/** One list section. */
export interface ReviewSection {
    /** The list. */
    readonly filter: ForgeViewerFilter;
    /** Items most recently updated first; null before any host read the list. */
    readonly items: readonly ReviewItem[] | null;
    /** Size of the whole list summed over the hosts read. */
    readonly total: number;
    /** Whether some host listed fewer change requests than its total. */
    readonly truncated: boolean;
    /** The first failure of the latest read on any host, or null. */
    readonly failure: {
        readonly host: string;
        readonly forge: string;
        readonly failure: ForgeFailure;
    } | null;
}
/** A repository the lists name. */
export interface ReviewRepository {
    /** Owner or namespace. */
    readonly owner: string;
    /** Repository name. */
    readonly name: string;
}
/**
 * Build the list sections from one frame.
 * @param frame - the latest frame, or undefined before the first.
 * @param directOnly - whether the review-requested list leaves out requests made only of one of the user's teams.
 * @returns one section per list some host offers, in page order, each with every item most recently updated first.
 */
export declare function reviewSections(frame: ForgeReviewFrame | undefined, directOnly: boolean): readonly ReviewSection[];
/**
 * The text a listed change request is searched by under the client search rule: its title, number, repository, and
 * author each match as a substring or a word-start fuzzy subsequence.
 * @param item - the listed change request.
 * @returns the search keys.
 */
export declare function reviewSearchKeys(item: ReviewItem): SearchKeys;
/**
 * List the repositories the lists name, by owner then name.
 * @param frame - the latest frame, or undefined before the first.
 * @returns distinct repositories.
 */
export declare function reviewRepositories(frame: ForgeReviewFrame | undefined): readonly ReviewRepository[];
/**
 * Whether a frame holds every list of every host from a settled read, so the repositories it names are all the lists
 * name.
 * @param frame - the latest frame, or undefined before the first.
 * @returns true once no read is in flight and no list is unread or failed.
 */
export declare function reviewListsComplete(frame: ForgeReviewFrame | undefined): boolean;
/**
 * Merge repositories into one list without duplicates, by owner then name.
 * @param groups - lists of repositories.
 * @returns the distinct repositories, sorted as {@link reviewRepositories} sorts.
 */
export declare function mergeRepositories(...groups: readonly (readonly ReviewRepository[])[]): readonly ReviewRepository[];
/** The hint an item carries: a dictionary key and its values. */
export interface ReviewHint {
    /** Dictionary key of the hint text. */
    readonly key: ForgePanelKey;
    /** Values interpolated into the text. */
    readonly params: Readonly<Record<string, string>>;
    /** `error` for a hint that asks for the user's action, `success` for an approval, otherwise none. */
    readonly tone: 'error' | 'success' | undefined;
}
/**
 * Pick the one hint an item shows, most urgent first: the user requested changes and a review is asked again, a review
 * asked of one of the user's teams, the user approved the latest commit, a draft, and on the user's own change
 * requests the review decision.
 * @param summary - the item.
 * @param filter - the list the item shows in.
 * @returns the hint, or undefined without one.
 */
export declare function reviewHint(summary: ChangeRequestSummary, filter: ForgeViewerFilter): ReviewHint | undefined;
/**
 * The tone of a listed change request, which is open, as its glyph draws it.
 * @param summary - the item.
 * @returns the tone.
 */
export declare function summaryTone(summary: ChangeRequestSummary): ChangeRequestTone;
/**
 * Read the search text as a change request URL to open directly.
 * @param query - search text.
 * @returns the URL, or undefined when the text is not one absolute HTTP(S) URL.
 */
export declare function pastedUrl(query: string): string | undefined;
/**
 * Prepare a change request description for Markdown rendering: an HTML image becomes a Markdown image, which the
 * renderer shows while it drops other HTML, and each attachment address the host signed is replaced by its signed URL.
 * @param body - the description as written.
 * @param images - signed URL of each attachment address.
 * @returns the Markdown to render.
 */
export declare function descriptionMarkdown(body: string, images: Readonly<Record<string, string>>): string;
//# sourceMappingURL=review-lists.d.ts.map