/** Parsers for the porcelain output of the read-only Git commands the panel runs. */
import type { ForgeBaseBranch, ForgeWorktreeBases } from './types.ts';
/** One remote with the URLs `git remote -v` prints for it. */
export interface GitRemote {
    /** Remote name such as `origin`. */
    readonly name: string;
    /** Distinct URLs, fetch URL first. */
    readonly urls: readonly string[];
}
/**
 * Read the first line that `git rev-parse` prints for a directory query such as `--show-toplevel`.
 * @param output - stdout of the command.
 * @returns the directory.
 * @throws when the output is empty.
 */
export declare function parseTopLevel(output: string): string;
/**
 * Read the first line of a one-name output such as `git symbolic-ref --quiet HEAD`.
 * @param output - stdout of the command.
 * @returns the name, or null when the command printed none.
 */
export declare function parseName(output: string): string | null;
/** Ref prefixes of the branches the `branch` scope can compare with: local branches, then remote-tracking branches. */
export declare const BASE_REF_PREFIXES: readonly ["refs/heads/", "refs/remotes/"];
/**
 * Select the branches the `branch` scope can compare with from `git for-each-ref`
 * output, keeping its order and leaving out symbolic refs and the checked-out branch.
 * @param output - stdout of `git for-each-ref --format=%(refname)%00%(symref)` over {@link BASE_REF_PREFIXES}.
 * @param current - checked-out branch, or null when HEAD is detached.
 * @param query - text the names must contain, ignoring case; empty or blank for every branch.
 * @param limit - most branches in each group.
 * @returns remote-tracking and local branches, at most `limit` of each.
 */
export declare function parseBaseBranches(output: string, current: string | null, query: string, limit: number): {
    readonly remote: ForgeBaseBranch[];
    readonly local: ForgeBaseBranch[];
};
/**
 * Select the branches a new worktree can start from out of `git for-each-ref` output, keeping its order within
 * each group: the checked-out branch, each remote's default branch, the other local branches, and the other
 * remote-tracking branches of each remote. A remote's default branch is the branch its `refs/remotes/<remote>/HEAD`
 * names; remote-tracking branches of unconfigured remotes and other symbolic refs are left out.
 * @param output - stdout of `git for-each-ref --format=%(refname)%00%(symref)` over {@link BASE_REF_PREFIXES}.
 * @param current - checked-out branch, or null when HEAD is detached.
 * @param remotes - configured remotes in the order their groups take.
 * @param query - text the names must contain, ignoring case; empty or blank for every branch.
 * @param limit - most branches in the local group and in each remote's group.
 * @param repositoryOf - the repository a remote's group names.
 * @returns the branches, with remotes that have no listed branch left out.
 */
export declare function parseWorktreeBases(output: string, current: string | null, remotes: readonly GitRemote[], query: string, limit: number, repositoryOf: (remote: GitRemote) => string | null): ForgeWorktreeBases;
/**
 * Group the lines of `git remote -v` by remote.
 * @param output - stdout of the command.
 * @returns remotes in first-listed order.
 */
export declare function parseRemotes(output: string): GitRemote[];
/**
 * Split an upstream branch such as `origin/feature/x` into its remote and the
 * branch on that remote. The remote is the longest remote name followed by `/`
 * at the start of the upstream branch.
 * @param upstream - upstream branch such as `origin/main`, or null.
 * @param remotes - remotes in listed order.
 * @returns the remote and branch, or undefined without an upstream or a remote it starts with.
 */
export declare function upstreamBranch(upstream: string | null, remotes: readonly GitRemote[]): {
    readonly remote: GitRemote;
    readonly branch: string;
} | undefined;
/**
 * Name the repository a remote's group shows: `owner/name` of the first URL a provider recognizes, else the first URL
 * without the user name and password a URL can carry as a token, since the name reaches the browser.
 * @param remote - remote with its URLs, fetch URL first.
 * @param recognize - the repository a provider recognizes from a URL, or undefined.
 * @returns the name, or null for a remote without a URL.
 */
export declare function remoteRepository(remote: GitRemote, recognize: (url: string) => {
    readonly owner: string;
    readonly name: string;
} | undefined): string | null;
/**
 * Order remotes for code host recognition: the upstream's remote first, then
 * `origin`, then the rest in listed order.
 * @param upstream - upstream branch such as `origin/main`, or null.
 * @param remotes - remotes in listed order.
 * @returns the same remotes in recognition order.
 */
export declare function remoteOrder(upstream: string | null, remotes: readonly GitRemote[]): GitRemote[];
//# sourceMappingURL=parse.d.ts.map