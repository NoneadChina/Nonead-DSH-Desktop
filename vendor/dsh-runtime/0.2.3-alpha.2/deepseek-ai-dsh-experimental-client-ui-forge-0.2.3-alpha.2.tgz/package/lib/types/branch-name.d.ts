/** Branch-name rules and branch labels shared by the Host and the Client; free of Node imports. */
/** Prefix of the full names of local branches. */
export declare const LOCAL_REF_PREFIX = "refs/heads/";
/** Prefix of the full names of remote-tracking branches. */
export declare const REMOTE_REF_PREFIX = "refs/remotes/";
/**
 * Why a name cannot be a new branch name: Git's rules for `refs/heads/<name>`, plus the worktree service's
 * refusal of a leading `-`.
 */
export type BranchNameProblem = 'empty' | 'space' | 'character' | 'leading-dash' | 'leading-slash' | 'trailing-slash' | 'double-slash' | 'double-dot' | 'trailing-dot' | 'at' | 'at-brace' | 'dot-segment' | 'lock-segment';
/**
 * Find the first rule a new branch name breaks. `git check-ref-format` stays the final check on the Host.
 * @param name - candidate branch name.
 * @returns the broken rule, or null when the name passes every rule.
 */
export declare function branchNameProblem(name: string): BranchNameProblem | null;
/**
 * The name a branch shows: a full local or remote-tracking branch name without its `refs/heads/` or
 * `refs/remotes/` prefix; any other revision, such as a short name an earlier panel recorded, as it is.
 * @param ref - branch or revision.
 * @returns the shown name.
 */
export declare function branchLabel(ref: string): string;
/**
 * Whether a revision is the full name of a remote-tracking branch, which a worktree creation fetches first.
 * @param ref - branch or revision, or null for HEAD.
 * @returns whether `ref` lies under `refs/remotes/`.
 */
export declare function isRemoteRef(ref: string | null): boolean;
//# sourceMappingURL=branch-name.d.ts.map