/**
 * The review page's lists of the signed-in user's change requests and its navigation count. Lists are read only while
 * some reader streams them and the count only while some reader streams it; neither joins the forge's status polling.
 * Readers of one repository scope share one poller, which reads every list of every host each round, hosts in parallel
 * and each host's lists one after another, so one host has at most one read in flight. A round with a failure delays
 * the next round as status polling does after consecutive failures.
 */
import type { ForgeFailure, ForgeViewerFilter, ForgeViewerList, ForgeViewerQuery, ForgeViewerSource } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgeReviewCountFrame, ForgeReviewFrame } from './types.ts';
/** What the hub reads through the forge registry. */
export interface ViewerListSources {
    /** The viewer lists every registered provider offers. */
    readonly sources: () => readonly ForgeViewerSource[];
    /** Read one list. */
    readonly list: (forge: string, query: ForgeViewerQuery, signal: AbortSignal) => Promise<ForgeViewerList | ForgeFailure>;
    /** Read the size of every list on one host. */
    readonly count: (forge: string, host: string, signal: AbortSignal) => Promise<ReadonlyMap<ForgeViewerFilter, number> | ForgeFailure>;
    /** Report a read that rejected instead of resolving to a failure. */
    readonly report: (error: unknown) => void;
}
/** Cadence and size of the reads. */
export interface ViewerListTiming {
    /** Milliseconds between two rounds of a list poller. */
    readonly listIntervalMs: number;
    /** Milliseconds between two rounds of the count poller. */
    readonly countIntervalMs: number;
    /** Largest delay in milliseconds after consecutive failed rounds. */
    readonly maxBackoffMs: number;
    /** Most change requests one list read asks for, before each provider's own limit. */
    readonly pageSize: number;
}
/** One repository to list in, or null for every repository. */
export type ViewerScope = {
    readonly owner: string;
    readonly name: string;
} | null;
/** A stream's latest undelivered frame; a newer frame replaces one the reader has not taken. */
export declare class Reader<T> {
    private readonly signal;
    private pending;
    private wake;
    private ended;
    private readonly abort;
    constructor(signal: AbortSignal);
    /**
     * Offer a frame, replacing one the reader has not taken; ignored after the stream ended.
     * @param frame - the frame.
     */
    push(frame: T): void;
    /** End the stream once the reader took the frame it waits for. */
    end(): void;
    /** End the stream and stop following its abort signal. */
    dispose(): void;
    /**
     * Yield each latest frame as the reader takes it, until the stream ends.
     * @returns the frames.
     */
    frames(): AsyncIterable<T>;
}
/** Streams the review page's lists and navigation count, reading them only while streamed. */
export declare class ViewerLists {
    private readonly sources;
    private readonly timing;
    private readonly scopes;
    private readonly countReaders;
    private readonly counts;
    private countPoller;
    private disposed;
    /**
     * @param sources - the registry reads and the report of a rejected read.
     * @param timing - cadence and size of the reads.
     */
    constructor(sources: ViewerListSources, timing: ViewerListTiming);
    /**
     * Stream the lists of one repository scope: the lists read so far first, then a frame after each read settles.
     * The stream ends when `signal` aborts or the hub is disposed; the last stream of a scope stops its reads.
     * @param scope - one repository, or null for every repository.
     * @param signal - ends the stream.
     * @returns frames, each complete.
     */
    lists(scope: ViewerScope, signal: AbortSignal): AsyncIterable<ForgeReviewFrame>;
    /**
     * Stream the navigation count: the latest count first, then each change. The stream ends when `signal` aborts or the
     * hub is disposed; the last stream stops the count reads.
     * @param signal - ends the stream.
     * @returns frames, each complete.
     */
    count(signal: AbortSignal): AsyncIterable<ForgeReviewCountFrame>;
    /** Stop the count reads; a disposed hub already stopped them. */
    private stopCounting;
    /** Read every streamed list and the count again at once. */
    refresh(): void;
    /** Forget hosts that no longer have a provider, publish that, and read the hosts that gained one. */
    sourcesChanged(): void;
    /**
     * End every stream and stop every read.
     * @returns settles once every poller stopped.
     */
    dispose(): Promise<void>;
    /** Read every list of every host once; resolves to whether every read succeeded. */
    private readScope;
    /** Read the count of every host once; resolves to whether every read succeeded. */
    private readCounts;
    /** Run one read, turning a rejection into an `unavailable` failure and reporting it unless `signal` aborted. */
    private read;
    /** Record one list read; resolves to whether it succeeded. */
    private settle;
    private publish;
    private publishCount;
    private countFrame;
    private delay;
}
//# sourceMappingURL=viewer-lists.d.ts.map