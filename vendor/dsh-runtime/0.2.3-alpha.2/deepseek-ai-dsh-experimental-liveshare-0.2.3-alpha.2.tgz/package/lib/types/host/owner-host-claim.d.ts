/**
 * One running host's claim on a LiveShare owner state directory.
 *
 * Two hosts that start on the same DSH home restore the same persisted shares. A Relay registration
 * belongs to one host at a time, so the later host re-registering them makes the earlier host's
 * authority reads answer for a registration the Relay has moved: the earlier host then fences the
 * share and, with it, cancels the owner's running turn. This claim names the host that owns the
 * state: the holder restores, registers, and mutates the shares, and every other host reads them
 * without publishing anything.
 *
 * The rules follow the session write lease
 * ([Agent Note](../../../../../.agents/notes/implemented/feature/2026-08-31-cross-process-session-write-lease.md)):
 * ownership has no expiry, the arbiter outlives a holder's failure, and contention is a typed answer
 * rather than a crash. Two properties differ because this directory is not session data: the claim is
 * advisory and gates Relay registrations rather than file writes, and a record naming this process is
 * reclaimed, because every host in one process shares the same owner state. The
 * [owner state note](../../../../../.agents/notes/implemented/feature/2026-11-11-liveshare-owner-state-host-claim.md)
 * records why a recorded claim beats kernel arbitration.
 *
 * The claim is created exclusively (`wx`), so at most one creator wins on a local filesystem. A
 * holder is live while its recorded pid is; a record left by a process that is gone is reclaimed by
 * the next host, and so is one that names this process. The liveness check protects no share data and
 * no Session log, and pid reuse can at worst leave a live host without its shares until its next
 * start. There is deliberately no deadline that could expropriate a stalled holder.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/host/owner-host-claim
 */
/** Base name of the claim file inside the owner state directory. */
export declare const OWNER_HOST_CLAIM_FILENAME = "owner-host.json";
/** Another running host already owns this owner state directory. */
export declare class OwnerHostClaimHeldError extends Error {
    readonly holderPid: number;
    /**
     * @param holderPid - Process that holds the claim, or this process when its own claim blocks it.
     */
    constructor(holderPid: number);
}
/** One held claim, released exactly once by the host that took it. */
export interface OwnerHostClaim {
    /** Release the claim when this process still holds it. */
    release(): void;
    /**
     * Whether the claim file still names this host.
     *
     * A successor can replace the record while this host runs, so a caller about to change or
     * re-register the state re-reads it instead of trusting the claim taken at startup.
     * @returns True while the file still names the host that took the claim.
     */
    holds(): boolean;
    /** Record this claim carries, which names the holder that took it. */
    readonly hostId: string;
}
/** Liveness probe a test can replace. */
export interface OwnerHostClaimOptions {
    /** Whether the recorded holder is still running; defaults to a kernel signal-0 probe. */
    readonly alive?: (pid: number) => boolean;
}
/**
 * Path of the claim file for one owner state directory.
 * @param dir - Directory that holds the owner state file.
 * @returns The claim file path.
 */
export declare function ownerHostClaimPath(dir: string): string;
/**
 * Claim one owner state directory for this process.
 * @param dir - Directory that holds the owner state file.
 * @param options - Liveness probe override.
 * @returns The held claim.
 * @throws {OwnerHostClaimHeldError} while another live host holds the claim.
 */
export declare function claimOwnerHost(dir: string, options?: OwnerHostClaimOptions): OwnerHostClaim;
//# sourceMappingURL=owner-host-claim.d.ts.map