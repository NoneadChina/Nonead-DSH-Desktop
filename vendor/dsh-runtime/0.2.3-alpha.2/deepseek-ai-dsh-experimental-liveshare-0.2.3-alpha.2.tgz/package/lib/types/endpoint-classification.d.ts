/**
 * Why each Remote endpoint may be called on a share viewer's behalf.
 *
 * LiveShare refuses by default: the `share-viewer` policy binds only the actions its roles list. This
 * table states, for every endpoint a Client build can name, which access condition puts that endpoint
 * on the list, so adding an endpoint cannot silently extend the reader’s reach. The Host derives
 * `POLICY_DECIDED_ACTIONS` from the `reader-*` entries, the Client compilation face proves the table
 * covers `RemoteEndpoint`, and the Host asserts at load that the derived set is exactly the actions its
 * roles list.
 *
 * Classes: `reader-*` entries are decided by the share-viewer policy and can never be exposed through
 * a plugin declaration; `always-allowed` bypasses every policy; `plugin-offered` is reachable only
 * through a plugin's live declaration and the owner's selection; `owner-only` is never exposed.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/endpoint-classification
 */
/** Why one Remote endpoint may be called on a share viewer's behalf. */
export type ViewerEndpointClass = 'reader-global-read' | 'reader-session-read' | 'reader-workspace-read' | 'reader-session-input' | 'reader-fork' | 'reader-child-rename' | 'always-allowed' | 'plugin-offered' | 'owner-only';
/** The classes the share-viewer policy decides; the Host derives its decided-action set from them. */
export type ReaderEndpointClass = Extract<ViewerEndpointClass, `reader-${string}`>;
/**
 * Every Remote endpoint this Client build can name, with the access condition that reaches it.
 *
 * The Client face checks this record against `Extract<keyof TypertRemoteMap, string>`; a new generated
 * endpoint without a class fails that compilation. The Host derives `POLICY_DECIDED_ACTIONS` from the
 * `reader-*` entries, so the policy whitelist has no second handwritten copy.
 */
export declare const VIEWER_ENDPOINT_CLASSES: {
    readonly 'llm/listConfigurableProviders': "reader-global-read";
    readonly 'llm/listProviders': "reader-global-read";
    readonly 'session/canOpenWorkspacePath': "reader-global-read";
    readonly 'session/modelCatalog': "reader-global-read";
    readonly 'pluginEvents/follow': "reader-global-read";
    readonly 'productAnalytics/enabled': "reader-global-read";
    readonly 'productAnalytics/report': "reader-global-read";
    readonly 'productAnalytics/watchPolicy': "reader-global-read";
    readonly 'speech/cancelPreparation': "reader-global-read";
    readonly 'speech/catalog': "reader-global-read";
    readonly 'speech/follow': "reader-global-read";
    readonly 'speech/prepare': "reader-global-read";
    readonly 'speech/transcribe': "reader-global-read";
    readonly 'commands/list': "reader-session-read";
    readonly 'fileReferences/list': "reader-session-read";
    readonly 'fileUploads/upload': "reader-session-read";
    readonly 'session/control': "reader-session-read";
    readonly 'session/list': "reader-session-read";
    readonly 'goals/get': "reader-session-read";
    readonly 'goals/edit': "reader-session-read";
    readonly 'goals/clear': "reader-session-read";
    readonly 'goals/complete': "reader-session-read";
    readonly 'goals/create': "reader-session-read";
    readonly 'goals/pause': "reader-session-read";
    readonly 'goals/resume': "reader-session-read";
    readonly 'job/list': "reader-session-read";
    readonly 'job/follow': "reader-session-read";
    readonly 'sessionReferenceResolver/candidates': "reader-session-read";
    readonly 'userQuestions/answer': "reader-session-read";
    readonly 'userQuestions/attachWait': "reader-session-read";
    readonly 'session/attachment': "reader-session-read";
    readonly 'session/follow': "reader-session-read";
    readonly 'session/page': "reader-session-read";
    readonly 'session/projections': "reader-session-read";
    readonly 'skills/list': "reader-session-read";
    readonly 'session/events': "reader-session-read";
    readonly 'session/observeEvent': "reader-session-read";
    readonly 'session/observeProjections': "reader-session-read";
    readonly 'session/observeState': "reader-session-read";
    readonly 'session/state': "reader-session-read";
    readonly 'session/wait': "reader-session-read";
    readonly 'toolResults/watch': "reader-session-read";
    readonly 'workspace/follow': "reader-workspace-read";
    readonly 'session/prompt': "reader-session-input";
    readonly 'session/cancel': "reader-session-input";
    readonly 'session/fork': "reader-fork";
    readonly 'session/rename': "reader-child-rename";
    readonly 'remoteAccess/follow': "always-allowed";
    readonly 'account/cancelSignIn': "owner-only";
    readonly 'account/getBalance': "owner-only";
    readonly 'account/getProfile': "owner-only";
    readonly 'account/getState': "owner-only";
    readonly 'account/getNotificationContent': "owner-only";
    readonly 'account/getNotifications': "owner-only";
    readonly 'account/reportNotificationEvent': "owner-only";
    readonly 'account/hasRunningAccountTasks': "owner-only";
    readonly 'account/signOut': "owner-only";
    readonly 'account/startSignIn': "owner-only";
    readonly 'account/watch': "owner-only";
    readonly 'account/watchExpiry': "owner-only";
    readonly 'commands/execute': "owner-only";
    readonly 'job/kill': "owner-only";
    readonly 'session/create': "owner-only";
    readonly 'session/initializeDefaultModel': "owner-only";
    readonly 'session/openWorkspacePath': "owner-only";
    readonly 'session/search': "owner-only";
    readonly 'session/selectModel': "owner-only";
    readonly 'session/updateQueue': "owner-only";
    readonly 'session/workspacePathApplications': "owner-only";
    readonly 'sessionStatus/follow': "owner-only";
    readonly 'sessionStatus/mark': "owner-only";
    readonly 'credentials/describe': "owner-only";
    readonly 'credentials/set': "owner-only";
    readonly 'credentials/unset': "owner-only";
    readonly 'settings/describe': "owner-only";
    readonly 'settings/mutate': "owner-only";
    readonly 'settings/openSettingsDocument': "owner-only";
    readonly 'settings/replace': "owner-only";
    readonly 'settings/update': "owner-only";
    readonly 'terminal/attach': "owner-only";
    readonly 'terminal/close': "owner-only";
    readonly 'terminal/create': "owner-only";
    readonly 'terminal/environment': "owner-only";
    readonly 'terminal/list': "owner-only";
    readonly 'terminal/rename': "owner-only";
    readonly 'terminal/retain': "owner-only";
    readonly 'terminal/shells': "owner-only";
    readonly 'terminal/watch': "owner-only";
    readonly 'directoryPicker/createDirectory': "owner-only";
    readonly 'directoryPicker/list': "owner-only";
    readonly 'directoryPicker/pick': "owner-only";
    readonly 'workspace/archiveSession': "owner-only";
    readonly 'workspace/create': "owner-only";
    readonly 'workspace/delete': "owner-only";
    readonly 'workspace/initializeDefault': "owner-only";
    readonly 'workspace/insertBefore': "owner-only";
    readonly 'workspace/insertSessionBefore': "owner-only";
    readonly 'workspace/pinSession': "owner-only";
    readonly 'workspace/rename': "owner-only";
    readonly 'workspace/unarchiveSession': "owner-only";
    readonly 'workspace/unpinSession': "owner-only";
    readonly 'workspaceFiles/changes': "owner-only";
    readonly 'workspaceFiles/list': "owner-only";
    readonly 'workspaceFiles/read': "owner-only";
    readonly 'workspaceFiles/readBytes': "owner-only";
    readonly 'workspaceFiles/search': "owner-only";
    readonly 'workspaceFiles/stat': "owner-only";
    readonly 'pluginManager/cancelInstall': "owner-only";
    readonly 'pluginManager/inspect': "owner-only";
    readonly 'pluginManager/installBundle': "owner-only";
    readonly 'pluginManager/listBundles': "owner-only";
    readonly 'pluginManager/listPlugins': "owner-only";
    readonly 'pluginManager/listVersionExemptions': "owner-only";
    readonly 'pluginManager/listVersions': "owner-only";
    readonly 'pluginManager/readBundleDetail': "owner-only";
    readonly 'pluginManager/registries': "owner-only";
    readonly 'pluginManager/removeBundle': "owner-only";
    readonly 'pluginManager/setBundleEnabled': "owner-only";
    readonly 'pluginManager/setPluginEnabled': "owner-only";
    readonly 'pluginManager/setVersionExemption': "owner-only";
    readonly 'pluginManager/updateBundle': "owner-only";
    readonly 'pluginManager/waitForInstall': "owner-only";
    readonly 'pluginMarket/listIndexes': "owner-only";
    readonly 'pluginMarket/readEntryDetail': "owner-only";
    readonly 'pluginMarket/search': "owner-only";
    readonly 'pluginMarket/setIndexes': "owner-only";
    readonly 'pluginRegistryProbe/fastest': "owner-only";
    readonly 'actionCards/act': "owner-only";
    readonly 'pluginRecommendations/describe': "owner-only";
    readonly 'connectorAccounts/cancel': "owner-only";
    readonly 'connectorAccounts/start': "owner-only";
    readonly 'connectorAccounts/watch': "owner-only";
    readonly 'officeKit/generation': "owner-only";
    readonly 'officeKit/render': "owner-only";
    readonly 'speech/configure': "owner-only";
    readonly 'claudeCodeMods/pressBand': "owner-only";
    readonly 'claudeCodeMods/watchBand': "owner-only";
    readonly 'cotTranslation/limits': "owner-only";
    readonly 'cotTranslation/translate': "owner-only";
    readonly 'cuaAccess/applicationIcons': "owner-only";
    readonly 'cuaAccess/applications': "owner-only";
    readonly 'cuaAccess/enablePersistentPtc': "owner-only";
    readonly 'cuaAccess/openSettings': "owner-only";
    readonly 'cuaAccess/ptcConfiguration': "owner-only";
    readonly 'cuaAccess/requestPermission': "owner-only";
    readonly 'cuaAccess/retryApproval': "owner-only";
    readonly 'cuaAccess/revoke': "owner-only";
    readonly 'cuaAccess/systemStatus': "owner-only";
    readonly 'dynamicCordisRunner/getClientCode': "owner-only";
    readonly 'dynamicCordisRunner/inventory': "owner-only";
    readonly 'dynamicCordisRunner/invoke': "owner-only";
    readonly 'dynamicCordisRunner/reportClientGuardFailure': "owner-only";
    readonly 'dynamicCordisRunner/reportRenderFailure': "owner-only";
    readonly 'dynamicCordisRunner/resolveInspectQuery': "owner-only";
    readonly 'dynamicCordisRunner/resolveRequestRun': "owner-only";
    readonly 'dynamicCordisRunner/runHostHalf': "owner-only";
    readonly 'dynamicCordisRunner/settleUserRun': "owner-only";
    readonly 'dynamicCordisRunner/stopFromPanel': "owner-only";
    readonly 'dynamicCordisRunner/syncInspectManifest': "owner-only";
    readonly 'dynamicCordisRunner/undefineFromPanel': "owner-only";
    readonly 'sessionFeedback/record': "owner-only";
    readonly 'messageFeedback/delete': "owner-only";
    readonly 'messageFeedback/list': "owner-only";
    readonly 'messageFeedback/put': "owner-only";
    readonly 'pluginInventory/list': "owner-only";
    readonly 'mcpManager/probe': "owner-only";
    readonly 'mcpManager/restart': "owner-only";
    readonly 'mcpManager/watch': "owner-only";
    readonly 'permissionPresets/catalog': "owner-only";
    readonly 'permissionPresets/set': "owner-only";
    readonly 'llm/discoverModels': "owner-only";
    readonly 'web/listProviders': "owner-only";
    readonly 'agentPresets/list': "owner-only";
    readonly 'agentPresets/read': "owner-only";
    readonly 'agentPresets/select': "owner-only";
    readonly 'agentTeams/setEnabled': "owner-only";
    readonly 'schedule/catalog': "owner-only";
    readonly 'schedule/create': "owner-only";
    readonly 'schedule/deliveryLimits': "owner-only";
    readonly 'schedule/deleteInactive': "owner-only";
    readonly 'schedule/edit': "owner-only";
    readonly 'schedule/history': "owner-only";
    readonly 'schedule/list': "owner-only";
    readonly 'schedule/run': "owner-only";
    readonly 'schedule/view': "owner-only";
    readonly 'subagents/interruptByUser': "owner-only";
    readonly 'subagents/prompt': "owner-only";
    readonly 'liveshareShares/audit': "owner-only";
    readonly 'liveshareShares/capabilities': "owner-only";
    readonly 'liveshareShares/create': "owner-only";
    readonly 'liveshareShares/addSessions': "owner-only";
    readonly 'liveshareShares/identity': "owner-only";
    readonly 'liveshareShares/list': "owner-only";
    readonly 'liveshareShares/relay': "owner-only";
    readonly 'liveshareShares/setCapabilities': "owner-only";
    readonly 'liveshareShares/setRelay': "owner-only";
    readonly 'liveshareShares/stop': "owner-only";
    readonly 'liveshareShares/testPublish': "owner-only";
    readonly 'liveshareShares/testRelay': "owner-only";
    readonly 'liveshareShares/updatePermissions': "owner-only";
};
/**
 * Session notifications the share policy forwards to a served reader.
 *
 * Events are not Remote endpoints, so they are not keys of `VIEWER_ENDPOINT_CLASSES`; the policy roles
 * list them directly and the Host adds this set to `POLICY_DECIDED_ACTIONS` so a plugin declaration
 * cannot name one either.
 */
export declare const VIEWER_FORWARDED_EVENTS: readonly ["event:api-session/activity", "event:api-session/added", "event:api-session/error", "event:api-session/removed", "event:api-session/status"];
/**
 * Endpoints the share-viewer policy decides, in table order.
 * @param classes - Classification table to read.
 * @returns The keys whose class starts with `reader-`.
 */
export declare function readerPolicyEndpoints<K extends string>(classes: Readonly<Record<K, ViewerEndpointClass>>): K[];
/**
 * Assert two action sets name exactly the same keys, reporting both directions.
 *
 * The Host runs this when it derives `POLICY_DECIDED_ACTIONS`, so a classification table that drifts
 * from the policy roles fails at load instead of silently granting less or more.
 * @param actual - Keys the caller has.
 * @param expected - Keys the caller must have.
 * @param label - Set name for the failure message.
 * @throws {TypeError} When the sets differ; the message lists missing and unexpected keys.
 */
export declare function assertSameViewerActions(actual: Iterable<string>, expected: Iterable<string>, label: string): void;
//# sourceMappingURL=endpoint-classification.d.ts.map