/**
 * Check, sign-in, and sign-out of the default tmeet account that the user's terminal shares, as the operations
 * `ctx.cliAccounts` runs.
 */
import type { CliOperationControl } from '@deepseek-ai/dsh-cli-account/types';
import type { UpstreamSkillsHandle } from '@deepseek-ai/dsh-upstream-skills/types';
import type { TencentMeetingAccountState, TencentMeetingCommand, TencentMeetingOperationKind, TencentMeetingPhase } from './types.ts';
type Control = CliOperationControl<TencentMeetingAccountState, TencentMeetingPhase, TencentMeetingCommand>;
/** The upstream guide whose state the account carries and whose failed download each check restarts. */
type Guides = Pick<UpstreamSkillsHandle, 'state' | 'retry'>;
/**
 * Bind the Tencent Meeting account operations to the upstream guide.
 * @param guides - the registered upstream guide.
 * @returns the function that carries out one operation with tmeet and publishes the account each check observes; it
 *   throws when a command fails, prints an unknown status, or leaves no verified sign-in after a sign-in.
 */
export declare function performWith(guides: Guides): (kind: TencentMeetingOperationKind, control: Control, signal: AbortSignal) => Promise<void>;
export {};
//# sourceMappingURL=account.d.ts.map