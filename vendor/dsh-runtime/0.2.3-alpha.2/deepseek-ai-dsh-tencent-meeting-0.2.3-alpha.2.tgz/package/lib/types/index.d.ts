/**
 * Tencent Meeting plugin: registers the managed tmeet and its account with `ctx.cliAccounts`, which tells the model the
 * CLI's absolute path and shows the account on the Plugins page, and registers the `tencent-meeting` entry skill with
 * `ctx.upstreamSkills`, which downloads the upstream guide it indexes. The CLI's default sign-in is shared with the
 * user's own terminal.
 * @module @deepseek-ai/dsh-tencent-meeting
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin name. */
export declare const name = "tencent-meeting";
/** Services the CLI's account and the entry skill register with. */
export declare const inject: string[];
/** Where tmeet and the upstream guide are. */
export interface Config {
    /** Absolute directory holding the `tmeet` executable; defaults to the installed `@tencentcloud/tmeet` executable for this platform. */
    binDir?: string;
    /** Absolute directory holding the upstream guide at its repository paths; when set, nothing is downloaded. */
    skillsDir?: string;
}
/** Validates {@link Config}. */
export declare const Config: z<Config>;
/**
 * Register the entry skill, and the CLI with its account, whose view follows the guide's download.
 * @param ctx - Context carrying the CLI account Service and the upstream skills Service.
 * @param config - CLI location and the guide's directory.
 * @throws when this platform has no packaged `tmeet`, `tmeet` is not executable, or `skillsDir` is not a directory.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map