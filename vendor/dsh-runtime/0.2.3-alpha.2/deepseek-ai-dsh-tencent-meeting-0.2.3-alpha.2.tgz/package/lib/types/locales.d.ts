/** The Tencent Meeting text the Plugins page shows; the browser resolves it in its active language. */
/** Chinese dictionary and key source. */
export declare const zh: {
    'section.title': string;
    'status.checking': string;
    'status.disconnected': string;
    'status.unavailable': string;
    'status.connected': string;
    'step.authorizing': string;
    'step.connecting': string;
    'step.signing-out': string;
    'detail.disconnected': string;
    'detail.unavailable': string;
    'detail.connected': string;
    'detail.authorizing': string;
    'skills.downloading': string;
    'skills.failed': string;
    hint: string;
    failed: string;
    'action.connect': string;
    'action.open': string;
    'action.cancel': string;
    'action.signOut': string;
    'action.retry': string;
    'badge.connected': string;
    'badge.disconnected': string;
    'badge.connecting': string;
    'badge.unavailable': string;
    'signOut.title': string;
    'signOut.body': string;
    'activation.title': string;
    'activation.body': string;
    'notice.connected': string;
    'notice.signed-out': string;
};
/** Every key of the Tencent Meeting text. */
export type TencentMeetingTextKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<TencentMeetingTextKey, string>;
/** Japanese dictionary. */
export declare const ja: Record<TencentMeetingTextKey, string>;
/** Spanish dictionary. */
export declare const es: Record<TencentMeetingTextKey, string>;
/** French dictionary. */
export declare const fr: Record<TencentMeetingTextKey, string>;
/** German dictionary. */
export declare const de: Record<TencentMeetingTextKey, string>;
/** Russian dictionary. */
export declare const ru: Record<TencentMeetingTextKey, string>;
/** Portuguese dictionary. */
export declare const pt: Record<TencentMeetingTextKey, string>;
/** The dictionary of every shipped language. */
export declare const dictionaries: {
    zh: {
        'section.title': string;
        'status.checking': string;
        'status.disconnected': string;
        'status.unavailable': string;
        'status.connected': string;
        'step.authorizing': string;
        'step.connecting': string;
        'step.signing-out': string;
        'detail.disconnected': string;
        'detail.unavailable': string;
        'detail.connected': string;
        'detail.authorizing': string;
        'skills.downloading': string;
        'skills.failed': string;
        hint: string;
        failed: string;
        'action.connect': string;
        'action.open': string;
        'action.cancel': string;
        'action.signOut': string;
        'action.retry': string;
        'badge.connected': string;
        'badge.disconnected': string;
        'badge.connecting': string;
        'badge.unavailable': string;
        'signOut.title': string;
        'signOut.body': string;
        'activation.title': string;
        'activation.body': string;
        'notice.connected': string;
        'notice.signed-out': string;
    };
    en: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    ja: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    es: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    fr: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    de: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    ru: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    pt: Record<"failed" | "section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.connected" | "detail.authorizing" | "skills.downloading" | "skills.failed" | "hint" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
};
//# sourceMappingURL=locales.d.ts.map