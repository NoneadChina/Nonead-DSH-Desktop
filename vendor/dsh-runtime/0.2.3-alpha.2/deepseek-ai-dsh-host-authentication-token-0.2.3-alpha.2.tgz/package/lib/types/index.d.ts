/** Default token authentication, HTTP exchanges, and entry URL contribution. */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Stable plugin name. */
export declare const name = "host-authentication-token";
/** Services owning request admission and the persistent signing key. */
export declare const inject: string[];
/** Default browser and API cookie lifetime. */
export interface Config {
    /** Absolute cookie lifetime in days; default 30. */
    cookieMaxAgeDays: number;
}
/** Validate cookie lifetime before preparing the token implementation. */
export declare const Config: z<Config>;
/**
 * Register the token provider and its optional Web transport integration.
 * @param ctx - plugin scope owning the shared Peer and registrations.
 * @param config - validated browser and API cookie lifetime.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map