/**
 * Forward file and folder mention candidates in original text, without Facts or discovery.
 * The node components decide whether a candidate names an existing path.
 */
import type { UserTextRule } from '@deepseek-ai/dsh-client-ui-conversation/client';
interface PathReferenceData {
    readonly path: string;
    readonly label: string;
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface UserTextDataMap {
        file: PathReferenceData;
        folder: PathReferenceData;
    }
}
/**
 * Decode the path a complete `@path` or `@"quoted path"` mention names.
 * @param mention - mention spelling starting with `@`, without trailing sentence punctuation.
 * @returns the path that file and folder nodes carry.
 */
export declare function mentionPath(mention: string): string;
/** Return the nearest complete file reference using original whitespace boundaries. */
export declare const fileReferenceRule: UserTextRule<'file'>;
/** Return the nearest trailing-slash directory using the file-reference grammar. */
export declare const folderReferenceRule: UserTextRule<'folder'>;
export {};
//# sourceMappingURL=user-text-rules.d.ts.map