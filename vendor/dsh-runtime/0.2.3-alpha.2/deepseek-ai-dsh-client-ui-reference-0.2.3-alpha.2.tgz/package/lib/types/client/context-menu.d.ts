/** File references contributed to the shared file menu. */
import type { Context } from '@deepseek-ai/cordis';
import type { ReferenceKey } from './locales.ts';
/**
 * Add the captured file to its Session draft without submitting or replacing selected text.
 * @param ctx - reference plugin's menu and conversation dependencies.
 * @param t - localized labels and failure feedback.
 */
export declare function registerReferenceMenu(ctx: Context, t: (key: ReferenceKey) => string): void;
//# sourceMappingURL=context-menu.d.ts.map