/** Find the fenced blocks of answer text that offer action cards. */
import type { ActionCardFence } from './types.ts';
/** Language of a block that offers a card, matched after lowercasing, as the Chat client dispatches fences. */
export declare const ACTION_CARD_FENCE: ActionCardFence;
/**
 * Contents of the fenced code blocks whose language is {@link ACTION_CARD_FENCE}, in text order.
 * A fence opens with at least three backticks or tildes after at most three spaces, optionally followed by the marker of
 * the list item it starts. It closes at a line of the same character at least as long, indented at most three spaces
 * past the list item's content column or, outside a list item, the line start; an unclosed fence runs to the end of the
 * text. Content lines lose up to the opening's indentation, marker included. Fences in block quotes or indented four or
 * more spaces are not read.
 * @param text - one text block of an assistant message.
 * @returns the blocks' contents.
 */
export declare function actionCardFences(text: string): string[];
//# sourceMappingURL=fence.d.ts.map