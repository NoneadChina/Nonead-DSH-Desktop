/** Runs the GitLab CLI on the host with a scrubbed, non-interactive environment that cannot redirect it to another host. */
/** Complete output of one `glab` invocation that ran to an exit code. */
export interface GlabOutput {
    /** Process exit code. */
    readonly exitCode: number;
    /** Standard output without its final newline. */
    readonly stdout: string;
    /** Standard error without its final newline. */
    readonly stderr: string;
}
/** Runs `glab` with literal arguments; rejects when the process cannot run to an exit code. */
export type GlabRunner = (args: readonly string[], signal: AbortSignal, input?: string) => Promise<GlabOutput>;
/** Resolved executable and limits for `glab`. */
export interface GlabConfig {
    /** Executable name or absolute host path. */
    readonly glabCommand: string;
    /** Deadline in milliseconds for one invocation. */
    readonly timeoutMs: number;
    /** Maximum captured bytes per output stream. */
    readonly maxOutputBytes: number;
}
/** Thrown when the `glab` executable cannot start, for example because it is not installed. */
export declare class GlabUnavailableError extends Error {
    name: string;
}
/** Thrown when one invocation outlives `timeoutMs`; the process is killed. */
export declare class GlabTimeoutError extends Error {
    name: string;
}
/** Thrown when an output stream exceeds `maxOutputBytes`; the process is killed. */
export declare class GlabOutputLimitError extends Error {
    name: string;
}
/**
 * Build a runner for `glab` on the host. The child inherits the scrubbed parent environment without the variables that
 * redirect `glab` to another host or repository, so `glab` authenticates from its own credential store; it runs in the
 * temporary directory, so no checkout's remotes choose a host. Prompts, update checks, telemetry, pagers, and colors
 * are disabled.
 * @param config - executable and limits.
 * @returns the runner.
 */
export declare function glabRunner(config: GlabConfig): GlabRunner;
//# sourceMappingURL=glab.d.ts.map