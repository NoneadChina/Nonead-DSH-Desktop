/** GitLab REST and GraphQL reads and writes through `glab api`, with failures mapped to forge codes. */
import type { ForgeActionFailure, ForgeFailure } from '@deepseek-ai/dsh-experimental-forge';
import type { GlabOutput, GlabRunner } from './glab.ts';
/** A parsed JSON answer, or why GitLab did not give one. */
export type ApiResult = {
    readonly ok: true;
    readonly body: unknown;
} | {
    readonly ok: false;
    readonly failure: ForgeFailure;
};
/**
 * The answer to a write: its parsed body once GitLab accepted it, else the HTTP status GitLab answered with, if any,
 * the body it answered with, and the failure.
 */
export type WriteResult = {
    readonly ok: true;
    readonly body: unknown;
} | {
    readonly ok: false;
    readonly status: number | null;
    readonly body: unknown;
    readonly failure: ForgeActionFailure;
};
/** A GraphQL mutation's payload once GitLab applied it. */
export type MutationResult = {
    readonly ok: true;
    readonly payload: Readonly<Record<string, unknown>>;
} | ForgeActionFailure;
/** GraphQL refusals of a query over GitLab's complexity or size limits, which a smaller query avoids. */
export declare const QUERY_LIMIT: RegExp;
/**
 * Reads and writes one GitLab host through a `glab` runner. Every request names its host, so `glab` never infers one
 * from a checkout or the environment.
 */
export declare class GitLabApi {
    private readonly glab;
    /**
     * @param glab - runner that executes `glab` on the host.
     */
    constructor(glab: GlabRunner);
    /**
     * Read a REST resource as JSON.
     * @param host - GitLab host.
     * @param path - API path below `/api/v4/`, with its query.
     * @param signal - cancellation of the read.
     * @returns the parsed answer, or the mapped failure.
     */
    rest(host: string, path: string, signal: AbortSignal): Promise<ApiResult>;
    /**
     * Read one page of a REST list with GitLab's `X-Total` count of all its entries.
     * @param host - GitLab host.
     * @param path - API path below `/api/v4/`, with its query.
     * @param signal - cancellation of the read.
     * @returns the parsed page and the total, which is null when GitLab omits it, or the mapped failure.
     */
    restPage(host: string, path: string, signal: AbortSignal): Promise<ApiResult & {
        readonly total?: number | null;
    }>;
    /**
     * Read a REST resource as text, such as a raw file.
     * @param host - GitLab host.
     * @param path - API path below `/api/v4/`, with its query.
     * @param signal - cancellation of the read.
     * @returns the text, or the mapped failure.
     */
    restText(host: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Run a GraphQL query whose document and variables travel as JSON on stdin.
     * @param host - GitLab host.
     * @param query - GraphQL document.
     * @param variables - query variables.
     * @param signal - cancellation of the read.
     * @returns the `data` object when GitLab reported no error, else the mapped failure; a query over GitLab's
     * complexity or size limits fails as `too-large`.
     */
    graphql(host: string, query: string, variables: Readonly<Record<string, unknown>>, signal: AbortSignal): Promise<ApiResult>;
    /**
     * Send one REST or GraphQL write once, without retrying.
     * @param host - GitLab host.
     * @param args - `glab api` arguments after `--hostname <host>`, such as `-X PUT <path>`.
     * @param signal - cancellation of the write.
     * @param input - request body for `--input -`, when the write takes one.
     * @returns the parsed answer of an accepted write, or why GitLab did not accept it: HTTP 401 or a diagnostic about
     * credentials is `unauthenticated`, any other 4xx status is a refusal that changed nothing, `failed`, as is a `glab`
     * that cannot start; a 5xx status, an answer without a status, and a run past `timeoutMs` or the output limit are
     * `unknown`, since GitLab may have applied the write.
     */
    write(host: string, args: readonly string[], signal: AbortSignal, input?: string): Promise<WriteResult>;
    /**
     * Run one GraphQL mutation once, with its document and variables as JSON on stdin.
     * @param host - GitLab host.
     * @param query - GraphQL document with one mutation field.
     * @param variables - mutation variables.
     * @param field - the mutation field, whose payload holds the mutation's `errors`.
     * @param signal - cancellation of the write.
     * @returns the payload once GitLab applied the mutation; `failed` when the payload lists errors or GitLab answered with
     * GraphQL errors and no payload, which GitLab does for a refusal; otherwise the failure of the write, or `unknown`.
     */
    mutate(host: string, query: string, variables: Readonly<Record<string, unknown>>, field: string, signal: AbortSignal): Promise<MutationResult>;
    /** Run `glab`, mapping a runner that cannot finish to a failure. */
    private attempt;
}
/**
 * Map a failed `glab api` run to a forge failure: HTTP 404 is `not-found`, a diagnostic about credentials or HTTP 401
 * is `unauthenticated`, HTTP 406 and 413 are `too-large`, and anything else is `unavailable` with GitLab's message.
 * @param output - the failed run.
 * @returns the failure.
 */
export declare function failureOf(output: GlabOutput): ForgeFailure;
//# sourceMappingURL=api.d.ts.map