/** GitLab writes and reads of the merge request overview: pipeline retries, review requests, reviewer candidates, and rebases. */
import type { BranchUpdateRequest, ChangeRequestRef, ChangeRequestSnapshot, ForgeActionFailure, ForgeFailure, ForgeRerunRequest, ForgeReviewerCandidate, ForgeReviewersRequest } from '@deepseek-ai/dsh-experimental-forge';
import type { GitLabApi } from './api.ts';
/** The merge request's reviewers and whether it takes more than one; variables `path` and `iid` are strings. */
export declare const REVIEWERS_QUERY = "query($path: ID!, $iid: String!) {\n  project(fullPath: $path) { mergeRequest(iid: $iid) { allowsMultipleReviewers reviewers(first: 100) { nodes { id username } } } }\n}";
/** Add reviewers by username; variables `path`, `iid`, and `usernames` name them. */
export declare const SET_REVIEWERS_MUTATION = "mutation($path: ID!, $iid: String!, $usernames: [String!]!) {\n  mergeRequestSetReviewers(input: { projectPath: $path, iid: $iid, reviewerUsernames: $usernames, operationMode: APPEND }) { errors }\n}";
/** Ask a reviewer for another review; variables `path`, `iid`, and `user`, the reviewer's global id. */
export declare const REREVIEW_MUTATION = "mutation($path: ID!, $iid: String!, $user: UserID!) {\n  mergeRequestReviewerRereview(input: { projectPath: $path, iid: $iid, userId: $user }) { errors }\n}";
/** Accounts that match a search and the merge request's author; variables `path`, `iid`, and `search` are strings. */
export declare const CANDIDATES_QUERY = "query($path: ID!, $iid: String!, $search: String!) {\n  project(fullPath: $path) { autocompleteUsers(search: $search) { username name avatarUrl } mergeRequest(iid: $iid) { author { username } } }\n}";
/**
 * Retry the head pipeline when it has failed jobs and none pending. GitLab retries a pipeline's failed and cancelled jobs
 * together, so every job names its pipeline as its rerun; the head is read first through `read`, and a head other than
 * `request.headSha` is refused with `stale`.
 * @param api - GitLab writes.
 * @param read - reads the merge request's status with all its checks.
 * @param ref - merge request, with a project path already checked for inlining.
 * @param request - the head commit whose checks the user saw.
 * @param signal - cancellation of the read and the retries.
 * @returns undefined once GitLab accepted every retry, or why it did not.
 */
export declare function rerunGitLabChecks(api: GitLabApi, read: () => Promise<ChangeRequestSnapshot | ForgeFailure>, ref: ChangeRequestRef, request: ForgeRerunRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
/**
 * Request reviews, adding to GitLab's reviewers. Accounts that are not reviewers yet are added by username; a reviewer
 * named again is asked for another review. GitLab has no team reviewers, and a merge request that takes one reviewer,
 * as on GitLab's free tier, refuses a second before anything is sent.
 * @param api - GitLab reads and writes.
 * @param ref - merge request, with a project path already checked for inlining.
 * @param request - the reviewers to ask.
 * @param signal - cancellation of every request.
 * @returns undefined once GitLab accepted every request, or why it refused; a refused second review request follows
 * accepted earlier ones.
 */
export declare function requestGitLabReviews(api: GitLabApi, ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
/**
 * List accounts a review can be requested from: GitLab's matches for `query` among the users who can see the project,
 * without the author. GitLab suggests no reviewers on its free tier, so no account is marked suggested.
 * @param api - GitLab reads.
 * @param ref - merge request, with a project path already checked for inlining.
 * @param query - text the login or name contains.
 * @param signal - cancellation of the read.
 * @returns at most 20 accounts, each with an absolute avatar URL, or why GitLab did not list them.
 */
export declare function gitLabReviewerCandidates(api: GitLabApi, ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
/**
 * Rebase the head branch onto the target branch. GitLab names no head commit in a rebase request, so the merge request is
 * read first and the rebase is refused with `stale` once its head is another commit; a push between the read and the
 * request is rebased too. GitLab rebases in the background and answers once it accepted the rebase.
 * @param api - GitLab reads and writes.
 * @param ref - merge request, with a project path already checked for inlining.
 * @param request - update method and the head commit the user confirmed.
 * @param signal - cancellation of the read and the request.
 * @returns undefined once GitLab accepted the rebase, `stale` when the head moved, or why GitLab refused.
 */
export declare function updateGitLabBranch(api: GitLabApi, ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
//# sourceMappingURL=overview.d.ts.map