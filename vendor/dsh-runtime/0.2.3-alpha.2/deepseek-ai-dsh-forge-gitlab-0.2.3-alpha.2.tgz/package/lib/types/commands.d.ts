/** The GitLab CLI commands that bind merge requests to a Session through forge-session. */
import type { ForgeCommandRule } from '@deepseek-ai/dsh-experimental-forge-session';
/**
 * `glab mr create` prints the merge request it opens; `glab mr view`, `glab mr update`, and `glab mr checkout` act on
 * the merge request a URL or a number with `--repo`/`-R` selects. A number whose repository is a full `http` or `https`
 * project URL binds directly; any other repository form resolves through `glab mr view` in the call's shell, which
 * applies the GitLab CLI's own host resolution. `glab api` binds the merge request its REST path names, such as
 * `projects/group%2Fapp/merge_requests/7/changes`: directly with `--hostname` or a full URL, else through `glab mr view`,
 * which for the `:fullpath` and `:id` placeholders reads the repository of the current directory.
 */
export declare const GLAB_COMMANDS: ForgeCommandRule;
//# sourceMappingURL=commands.d.ts.map