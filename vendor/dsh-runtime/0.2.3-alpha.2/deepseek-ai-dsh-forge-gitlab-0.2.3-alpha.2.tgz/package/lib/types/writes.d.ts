/** GitLab writes to merge request discussions, draft notes, and reviews, each after a check of the head. */
import type { ChangeRequestRef, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult } from '@deepseek-ai/dsh-experimental-forge';
import type { GitLabApi } from './api.ts';
import type { VersionFile } from './position.ts';
/** Reads the changed files of one diff version by their path on either side, or undefined when GitLab does not list them. */
export type VersionFiles = (version: number) => Promise<ReadonlyMap<string, VersionFile> | undefined>;
/**
 * Write to the discussions or the draft notes of a merge request. The newest diff version is read first and the write
 * is refused with `stale` once its head is another commit. Replies and resolutions name a discussion and edits and
 * deletions a note or draft note through the merge request's own paths, so GitLab refuses ids of another merge request;
 * an id this provider never issued, such as the thread of a draft note, is refused without a write. A pending reply or
 * comment is a draft note, which only its author sees; a comment's position addresses the lines of the newest version.
 * Submitting publishes every draft note with the summary, after approving at the head when the decision is `approve`;
 * requesting changes or commenting records that review state for a reviewer. Discarding deletes the draft notes one by
 * one. No write is retried: a refusal GitLab reports returns `failed`, and an answer that does not show whether GitLab
 * applied a write returns `unknown`.
 * @param api - GitLab reads and writes.
 * @param files - reads the changed files of a diff version.
 * @param ref - merge request, with a project path already checked for inlining.
 * @param write - the write and the head commit the user saw.
 * @param signal - cancellation of the reads and writes.
 * @returns whether GitLab took the write.
 */
export declare function writeGitLabReview(api: GitLabApi, files: VersionFiles, ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
/**
 * Publish one comment or one complete review on a merge request. The newest diff version is read first and the
 * submission is refused with `stale` once its head is another commit; comment positions address its lines, and every
 * position is found before anything is written. A comment starts a discussion at once. A review is refused while the
 * signed-in user has draft notes, which publishing would include; otherwise each comment becomes a draft note, an
 * `approve` decision approves at the head, and the drafts are published with the summary and the decision's review state.
 * A refused draft or approval deletes the drafts written before it, so a refused review changes nothing; a refused
 * publication deletes them too, keeping only an approval, which a retry does not repeat. Nothing is retried.
 * @param api - GitLab reads and writes.
 * @param files - reads the changed files of a diff version.
 * @param ref - merge request, with a project path already checked for inlining.
 * @param request - the comment or review and the head commit the user reviewed.
 * @param signal - cancellation of the reads and writes.
 * @returns the page of the published comment or of the merge request, or why GitLab did not take it.
 */
export declare function submitGitLabReview(api: GitLabApi, files: VersionFiles, ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
//# sourceMappingURL=writes.d.ts.map