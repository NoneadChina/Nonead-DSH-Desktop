import type { PropsLocale, PropsRenderFactories, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
import type { createTeamBoardStore } from './team-board-store.ts';
/** Full props of the shared tasks section body. */
export type TeamBoardProps = PropsRuntime<'conversation.session.panel.section'> & PropsRenderFactories & PropsStore<ReturnType<typeof createTeamBoardStore>> & PropsLocale<typeof NS>;
/** Full props of the progress beside the section title. */
export type TeamProgressProps = PropsRuntime<'conversation.session.panel.section.actions'> & PropsLocale<typeof NS>;
/**
 * Render read-only tasks: the ones in progress first, then the pending ones,
 * then the completed ones. The list shows five tasks and then a fold control
 * that shows the rest, once that holds back two tasks or more; the choice is
 * kept per Session. The Session panel owns the title and scrolling, and hides
 * the section while this renders nothing.
 * @param props - Session values, the `agentTeam` projection, the fold store, and copy.
 * @returns the task list with any board failure, or null with neither.
 */
export declare function TeamBoard({ sessionId, useProjection, useStore, actions, renderFactorySlot, t }: TeamBoardProps): import("react").JSX.Element | null;
/**
 * Render the tasks' progress beside the section title, one line that clips.
 * @param props - the `agentTeam` projection and copy.
 * @returns the progress phrase, or null without visible tasks.
 */
export declare function TeamProgress({ useProjection, t }: TeamProgressProps): import("react").JSX.Element | null;
//# sourceMappingURL=TeamBoard.d.ts.map