/**
 * Classification of fetch transport failures: maps the system or undici error code found in a
 * rejection's cause chain to a stable `WebError` code and a short model-visible summary, and keeps
 * a bounded technical detail.
 * @module @deepseek-ai/dsh-web-fetch-http/transport-failure
 */
/** A classified transport failure. */
export interface TransportFailure {
    /** Stable `WebError` code of the failure class. */
    code: string;
    /** Model-visible text: the class summary, the system code when known, and the bounded detail. */
    message: string;
}
/**
 * Classify a transport rejection. Undici rejects with a generic `TypeError: fetch failed` whose
 * `cause` holds the system error, such as `getaddrinfo ENOTFOUND host`; a connection attempt across
 * several resolved addresses nests those errors in an `AggregateError`. A failure is classified only
 * when its code, or every attempt's code, belongs to one class; an unreachable attempt beside attempts
 * of one other class, as an IPv6 attempt on an IPv4-only network, takes that other class.
 * @param error - the rejection of the request or body read.
 * @returns the failure's code and model-visible message.
 */
export declare function classifyTransportFailure(error: unknown): TransportFailure;
//# sourceMappingURL=transport-failure.d.ts.map