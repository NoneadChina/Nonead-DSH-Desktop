/** Theme CSS is compiled into module resources; DPR presentation follows the plugin lifetime. */
import type { Context } from '@deepseek-ai/cordis';
import '../styles/base.css';
import '../styles/corner-shape.css';
import '../styles/design-platform.css';
import '../styles/focus.css';
import '../styles/onboarding.css';
import '../styles/scrollbar.css';
import '../styles/gradient-shadow-text.css';
import '../styles/shiki.css';
/**
 * Publish the current document's DPR-aware stroke width for the theme plugin lifetime.
 * @param ctx - Owning plugin context.
 */
export declare function installThemeStyles(ctx: Context): void;
//# sourceMappingURL=styles.d.ts.map