/** Browser plugin for durable workflow-run Conversation Nodes. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type WorkflowRunKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Durable workflow-run node copy. */
        workflowRun: WorkflowRunKey;
    }
}
/**
 * Required services for Definition, keyed renderer, navigation, and copy. `uiSession.sessionStatus` provides the
 * `useSessionStatus` hook the run panel renders with, so the plugin unloads and reloads with it.
 */
export declare const inject: string[];
/** Register the workflow Definition, dictionary, and keyed Chat renderer. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map