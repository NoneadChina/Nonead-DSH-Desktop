/** Account notifications driven by the existing account UI stream. */
import type { Context } from '@deepseek-ai/cordis';
import type { SyncedConfig } from '@deepseek-ai/dsh-client-config/types';
import type { AccountNotificationsConfig } from '../types.ts';
export type { AccountNotificationsInjected, AccountNotificationsProps } from './AccountNotifications.tsx';
/** Services used for notification lifecycle and presentation. */
export declare const inject: string[];
/**
 * @param ctx - client plugin context sharing the account owner's existing state stream.
 * @param config - Host-synced initial polling delay, read whenever a poll without a server-provided delay is scheduled.
 */
export declare function apply(ctx: Context, config: SyncedConfig<AccountNotificationsConfig>): void;
//# sourceMappingURL=index.d.ts.map