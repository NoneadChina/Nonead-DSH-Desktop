/** Host Loader entry declaring the account notification polling interval; polling belongs to the Client. */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { AccountNotificationsConfig } from './types.ts';
/** Initial polling interval; the browser receives it through its synced Config. */
export type Config = AccountNotificationsConfig;
/** Initial polling interval synced to the browser; the upper bound is the browser timer limit. */
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    notificationPollIntervalMs: Schema<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    notificationPollIntervalMs: Schema<number, number, "volatile-defined">;
}>>, "plain">;
/**
 * Register the browser plugin without Host behavior; the Loader validates the entry's Config, and the browser face
 * receives its volatile fields.
 * @param _ctx - Host context; unused.
 * @param _config - validated Config; unused on the Host.
 */
export declare function apply(_ctx: Context, _config: Config): void;
//# sourceMappingURL=index.d.ts.map