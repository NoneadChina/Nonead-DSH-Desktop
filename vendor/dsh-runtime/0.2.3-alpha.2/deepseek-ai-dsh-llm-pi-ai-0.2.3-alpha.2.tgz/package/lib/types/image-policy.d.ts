/** Resolve pi-ai image resize metadata and route-owned overrides. */
import type { Api, Model } from '@earendil-works/pi-ai';
import type { ResolvedPiAiProviderProfile } from './config.ts';
import type { PiImageRequestBudget } from './context.ts';
/**
 * Resolve one model's image dimensions and hard raw encoded-byte limit.
 * @param model - selected pi-ai catalog model.
 * @param profile - validated route with optional overrides.
 * @returns resize limits shared by request serialization and screenshot coordinates.
 */
export declare function resolveImageRequestBudget(model: Pick<Model<Api>, 'inputLimits'>, profile: Pick<ResolvedPiAiProviderProfile, 'requestImagePixelBudget' | 'requestImageMaxDimension' | 'maxImageBytes' | 'maxRequestImageBytes' | 'requestImageBudgetCount'>): PiImageRequestBudget;
//# sourceMappingURL=image-policy.d.ts.map