/**
 * Model tools for entering a Git worktree, which is created when no worktree has the requested name, and for
 * returning to the source checkout, through the shared runtime.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis plugin name. */
export declare const name = "tool-worktree";
/** Services required to register and execute the worktree tools. */
export declare const inject: string[];
/**
 * Register enter_worktree and exit_worktree for model and PTC callers.
 * @param ctx - tool registry and worktree runtime.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map