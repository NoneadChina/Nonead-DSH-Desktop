/**
 * The one-shot app's command-line provider: it parses the task positional,
 * Session identity, permission options, output mode, and help, then publishes
 * {@link HEADLESS_STARTUP_SERVICE}. The runner is an ordinary consumer whose
 * lazy config waits for that service.
 * @module @deepseek-ai/dsh-headless/startup
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ApprovalPolicy } from '@deepseek-ai/dsh-user-approval';
/** Stable Cordis plugin name. */
export declare const name = "headless-startup";
/** Services required before the task can be resolved. */
export declare const inject: string[];
/** Service provided by this plugin and injected by the one-shot runner. */
export declare const HEADLESS_STARTUP_SERVICE = "headlessStartup";
/** What the runner row reads from {@link HEADLESS_STARTUP_SERVICE}. */
export interface HeadlessStartupValues {
    /** The task text this invocation asked for; absent when the runner reads stdin. */
    task: string | undefined;
    /** Exact Session identity to adopt; absent for a fresh random identity. */
    sessionId: string | undefined;
    /** Whether stdout carries the machine-readable event stream instead of final text. */
    json: boolean;
    /** Permission preset to apply before the task; absent preserves session policy. */
    permissionMode?: string;
    /** Approval behavior applied after the permission preset; absent keeps the current policy. */
    approvalPolicy?: ApprovalPolicy;
    /** Explicit absolute write grants for this invocation; absent adds no directories. */
    additionalWritableRoots?: string[];
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Parsed arguments of this headless invocation. */
        headlessStartup: HeadlessStartupValues;
    }
}
/**
 * Parse and provide the one-shot task as an ordinary Cordis service. The
 * command's action publishes the task; a missing task on an interactive stdin
 * is a usage error, so on rejection (and on `--help`) nothing is provided.
 * @param ctx - plugin context carrying the command line.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=startup.d.ts.map