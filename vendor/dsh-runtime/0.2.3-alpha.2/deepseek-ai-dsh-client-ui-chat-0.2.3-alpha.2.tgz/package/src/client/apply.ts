import type {} from '@deepseek-ai/dsh-client-ui-context-menu/client'
/** Register the Chat Conversation target, renderers, stats, and details surface. */
import type {} from '@deepseek-ai/dsh-client-ui-file-drag/client'
import type {} from '@deepseek-ai/dsh-client-product-analytics/client'
import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type { SessionBinding } from '@deepseek-ai/dsh-api-session-controller/client'
import { sessionDirectory } from '@deepseek-ai/dsh-api-session-controller/client/directories'
import type { GroupKey } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { createSnapshotStore, type ObservableSnapshot } from '@deepseek-ai/dsh-client-store'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-browser/client'
import type {} from '@deepseek-ai/dsh-client-ui-input-trigger/client'
// The `file` entry of `SidebarRightResourceParamsMap`, which types `{ params: { line } }` below.
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/client'
import { fileAddressFor } from '@deepseek-ai/dsh-util-workspace-path'
// Type-only service and declaration merges used by the apply world.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-workspace/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {
  ChatFlowDataInjected, ChatFlowInjected, ChatNodeInjected, ChatScrollPosition, ChatViewInjected,
  QuotaNoticeInjected, QuotaNoticeState,
} from './contract/slots.ts'
import type { ChatSnapshot } from './contract/snapshot.ts'
import { EMPTY_CHAT_SNAPSHOT } from './contract/snapshot.ts'
import { ApprovalCommand } from './chat/ApprovalCommand.tsx'
import { sessionFilePath } from './file-path.ts'
import { ChatView } from './chat/ChatView.tsx'
import { ChatFlow } from './chat/ChatFlow.tsx'
import { registerChatNodeRenderers } from './chat/register-node-renderers.ts'
import { UserContent } from './chat/UserContent.tsx'
import { ActivityPill, UsagePill } from './chat/StatsPills.tsx'
import { registerConversationNodes } from './conversation-nodes/register.ts'
import { registerFenceLayers } from './fence/register.ts'
import { QuotaNoticeHost } from './chat/QuotaNoticeHost.tsx'
import { en, ja, es, fr, de, ru, pt, NS, zh } from './locale.ts'
import { TranscriptViewRow, type TranscriptViewRowInjected } from './settings/TranscriptViewRow.tsx'
import { createChatStore } from './stores.ts'
import { TranscriptViewPolicy } from './transcript-view.ts'
import { derivePresentationPolicy } from './presentation-policy.ts'
import { CHAT_SETTINGS_NAMESPACE, DEFAULT_LINK_OPENING, DEFAULT_TRANSCRIPT_VIEW_MODE, type ChatSettings } from '../chat-settings.ts'
import { LinkOpeningRow, type LinkOpeningRowInjected } from './settings/LinkOpeningRow.tsx'
import { PerformanceUsageRow, type PerformanceUsageRowInjected } from './settings/PerformanceUsageRow.tsx'
import { PerformanceUsagePolicy } from './performance-usage.ts'
import { useTurnDataValue } from './chat/use-turn-data.ts'
import { bindDisclosure } from './chat/use-disclosure.ts'
import { useFlowHidden, useMotionHidden } from './chat/flow-motion.ts'

/** Bind group and header visibility to the viewport of one flow render. */
export const CHAT_FLOW_INJECT: ChatFlowInjected = {
  hooks: {
    groupAction: (_standard, { motion }) => function useGroupAction(hidden, reveal) {
      return useFlowHidden(hidden, reveal, motion)
    },
    groupHeaderAction: (_standard, { motion }) => function useGroupHeaderAction(ref, hidden) {
      useMotionHidden(ref, hidden, motion)
    },
  },
}

/** Bind node-local sources and forward the flow's existing visibility hook. */
export const CHAT_NODE_INJECT: ChatNodeInjected = {
  hooks: {
    turnData: (_standard, { turnData }) => function useTurnData(key) {
      return useTurnDataValue(turnData, key)
    },
    disclosure: (_standard, { disclosureReset }) => bindDisclosure(disclosureReset),
    groupAction: (_standard, { useGroupAction }) => useGroupAction,
  },
}

/** Services required by the Chat target and its presentation registrations. */
export const inject = [
  'slots', 'sessions', 'uiWorkspace', 'uiSession', 'uiConversation', 'locale',
  'configForms', 'connection', 'remote', 'remote.session', 'sidebarRight', 'fileDrag',
]

/**
 * Mount all Chat-owned contributions.
 * @param ctx - Client root context.
 */
export function apply(ctx: Context): void {
  const quotaNotice = createSnapshotStore<QuotaNoticeState | null>(null)
  let quotaNoticeSeq = 0
  // Each hold is its own token, so a release can only drop the hold it was
  // issued for: one arriving after a dismissal or a later acquisition leaves
  // that newer hold alone.
  const quotaNoticeHolds = new Set<symbol>()
  const chatSources = new WeakMap<SessionBinding, ObservableSnapshot<ChatSnapshot>>()
  const quotaSubscriptions = new Set<() => Promise<void>>()
  ctx.effect(() => async () => {
    await Promise.all([...quotaSubscriptions].map(dispose => dispose()))
  }, 'ui-chat: live quota notices')
  const chatSource = (binding: SessionBinding): ObservableSnapshot<ChatSnapshot> => {
    let source = chatSources.get(binding)
    if (source === undefined) {
      // One live quota failure publishes one frame-wide notice; history
      // replacement or paging never does, because an old failure scrolling
      // back into view is not news.
      const dispose = binding.ctx.effect(() => {
        // Live quota failures are reported only while a rendering reference retains the Session's Conversation.
        const retainInfo = ctx.sessions.retainInfo(binding.sessionId)
        const retained = (): boolean => ctx.sessions.binding(binding.sessionId) === binding
          && (retainInfo.getSnapshot().retainedFacets?.conversation ?? 0) > 0
        let stopEvents: (() => void) | undefined
        const follow = (): void => {
          if (!retained()) {
            stopEvents?.()
            stopEvents = undefined
            return
          }
          stopEvents ??= binding.eventSource.subscribe(() => {
            // A dispatch in progress keeps calling copied listeners after unsubscription.
            if (!retained()) return
            const { change } = binding.eventSource.getSnapshot()
            if (change.kind !== 'append') return
            for (const { event } of change.entries) {
              if (event.type !== 'turn/end' || event.data.reason.kind !== 'error') continue
              const { code } = event.data.reason.error
              if (quotaNoticeHolds.size > 0 || (code !== 'QUOTA' && code !== 'ACCOUNT_QUOTA')) continue
              quotaNotice.set({ code, seq: ++quotaNoticeSeq })
            }
          })
        }
        const stopRetained = retainInfo.subscribe(follow)
        follow()
        return () => {
          stopRetained()
          stopEvents?.()
          chatSources.delete(binding)
          quotaSubscriptions.delete(dispose)
        }
      }, 'ui-chat: Provider binding quota notices')
      quotaSubscriptions.add(dispose)
      const target = ctx.uiConversation.binding(binding).target('chat')
      source = {
        getSnapshot: () => target.getSnapshot() ?? EMPTY_CHAT_SNAPSHOT,
        subscribe: listener => target.subscribe(listener),
      }
      chatSources.set(binding, source)
    }
    return source
  }
  registerConversationNodes(ctx)
  ctx.uiSession.provide({
    hooks: ['chat'],
    resolve: binding => ({ hooks: { chat: chatSource(binding) } }),
  })

  ctx.effect(() => ctx.locale.register(NS, { zh, en, ja, es, fr, de, ru, pt }), 'ui-chat: dictionaries')
  const t = ctx.locale.bind(NS)
  const chatStore = createChatStore()
  const chatScrollPositions = new Map<SessionId, ChatScrollPosition>()
  const chatSettings = ctx.configForms.get<ChatSettings>(CHAT_SETTINGS_NAMESPACE)
  const linkOpening = createSnapshotStore(chatSettings.getSnapshot().value?.linkOpening ?? DEFAULT_LINK_OPENING)
  ctx.effect(() => chatSettings.subscribe(() => {
    const accepted = chatSettings.getSnapshot().value?.linkOpening
    if (accepted !== undefined) linkOpening.set(accepted)
  }))
  ctx.inject(['sidebarRightTabs'], (scope) => {
    const tabs = scope.sidebarRightTabs
    const browserAvailable: ObservableSnapshot<boolean> = {
      getSnapshot: () => tabs.get('browser') !== undefined,
      subscribe: listener => tabs.subscribe(listener),
    }
    scope.slots.inject('settings.general.item', () => scope.slots.register({
      name: 'settings.general.item',
      id: 'link-opening',
      order: 17,
      locale: NS,
      inject: (): LinkOpeningRowInjected => ({
        hooks: { linkOpening, browserAvailable },
        setLinkOpening: (destination) => {
          linkOpening.set(destination)
          void chatSettings.set('linkOpening', destination).catch((_error: unknown) => {
            // The local choice remains usable when persistence is unavailable.
          })
        },
      }),
    }, LinkOpeningRow))
  })
  const transcriptView = new TranscriptViewPolicy(chatSettings, 'dshDesktop' in globalThis ? 'standard' : DEFAULT_TRANSCRIPT_VIEW_MODE)
  const presentation = derivePresentationPolicy(transcriptView.mode, transcriptView.collapseTiming, transcriptView.foldedReplies)
  const performancePolicy = new PerformanceUsagePolicy(chatSettings)
  ctx.effect(() => () => { transcriptView.dispose(); performancePolicy.dispose() })
  const performanceUsage = performancePolicy.mode
  registerChatNodeRenderers(ctx, performanceUsage, presentation)
  ctx.slots.registerFactory({
    name: 'conversation.chat.user.content', scope: 'session', locale: NS,
    children: { 'conversation.chat.user.images': { kind: 'single', scope: 'session' } },
  }, UserContent)

  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item',
    id: 'performance-usage',
    order: 30,
    locale: NS,
    inject: (): PerformanceUsageRowInjected => ({
      hooks: { performanceUsage },
      setPerformanceUsage: (mode) => { performancePolicy.setMode(mode) },
    }),
  }, PerformanceUsageRow))

  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item',
    id: 'transcript-view',
    order: 12,
    locale: NS,
    inject: (): TranscriptViewRowInjected => ({
      hooks: {
        transcriptView: transcriptView.mode,
        collapseTiming: transcriptView.collapseTiming,
        foldedReplies: transcriptView.foldedReplies,
      },
      setTranscriptView: (mode) => { transcriptView.setMode(mode) },
      setCollapseTiming: (timing) => { transcriptView.setCollapseTiming(timing) },
      setFoldedReplies: (replies) => { transcriptView.setFoldedReplies(replies) },
    }),
  }, TranscriptViewRow))

  const connectionState = (ctx.get('connection') as ConnectionHandle).state
  const nodeSources = (binding: SessionBinding): Pick<ChatViewInjected, 'keyedHooks'> => {
    const chat = chatSource(binding)
    const conversation = ctx.uiConversation.binding(binding)
    return {
      keyedHooks: {
        chatNode: key => chat.getSnapshot().nodes.source(key),
        chatNodeBottom: key => chat.getSnapshot().nodes.bottomSource(key),
        chatNodeProcess: key => chat.getSnapshot().nodes.processSource(key),
        chatGroup: key => conversation.snapshot.getSnapshot().views.grouped('chat')?.groupSource(key as GroupKey),
      },
    }
  }

  ctx.slots.inject('conversation.chat.flow', () => ctx.slots.register({
    name: 'conversation.chat.flow', locale: NS, store: chatStore,
    children: {
      'conversation.chat.node': { kind: 'keyed', scope: 'session', inject: CHAT_NODE_INJECT },
    },
    inject: (sessionId: SessionId): ChatFlowDataInjected => {
      const binding = ctx.sessions.binding(sessionId)
      if (binding === undefined) throw new Error(`ui-chat: unknown session "${sessionId}"`)
      return { ...nodeSources(binding), hooks: { presentation, connectionState } }
    },
  }, ChatFlow))

  ctx.slots.inject('conversation.view', () => {
    const disposeView = ctx.slots.register({
      name: 'conversation.view',
      id: 'chat',
      order: 0,
      label: () => t('view.chat'),
      locale: NS,
      children: {
        'conversation.chat.flow': { kind: 'single', scope: 'session', inject: CHAT_FLOW_INJECT },
        'conversation.chat.text-interaction': { kind: 'keyed', scope: 'session' },
        'conversation.chat.markdown.fence': { kind: 'hoc', scope: 'session' },
        'conversation.chat.aside': { kind: 'single', scope: 'session' },
      },
      store: chatStore,
      inject: (sessionId: SessionId): ChatViewInjected => {
        const binding = ctx.sessions.binding(sessionId)
        if (binding === undefined) throw new Error(`ui-chat: unknown session "${sessionId}"`)
        const session = binding.session
        const chat = chatSource(binding)
        return {
          ...nodeSources(binding),
          fileDrag: ctx.fileDrag.actions,
          hooks: { presentation, interactionIds: ctx.uiConversation.interactions },
          dispatchInteraction: gesture => ctx.uiConversation.interactions.dispatch(sessionId, gesture),
          // Files open in the right Sidebar, not in a desktop application: the
          // content stays in the product, beside the conversation that produced
          // it. An absolute path names its file wherever the Session works. A
          // relative path resolves from the Session's directory at click time,
          // so one written before a directory move follows the move. The
          // address, `dsh-resource://file/session/<id>/<absolute path>`,
          // carries the resolved path: the opened tab keeps its file across
          // later moves. Which tab type claims the address is the Sidebar's
          // decision, not this call site's.
          // A line travels as a navigation parameter, not as part of the
          // address: the file is one piece of content whether it is opened at
          // its top or at line 400, so the same tab is revealed and told where
          // to land.
          openFile: async (path, options) => {
            const directory = sessionDirectory(ctx.sessions, sessionId)
            const url = fileAddressFor(sessionId, directory, path)
            if (options?.line === undefined) ctx.sidebarRight.openResource(url)
            else ctx.sidebarRight.openResource(url, { params: { line: options.line } })
            await Promise.resolve()
          },
          resolveFilePath: sessionFilePath(ctx, sessionId),
          openExternalLink: (url) => {
            if (linkOpening.getSnapshot() === 'sidebar' && ctx.get('sidebarRightTabs')?.get('browser') !== undefined) {
              ctx.sidebarRight.openTab('browser', { params: { url } })
            } else {
              window.open(url, '_blank', 'noopener,noreferrer')
            }
          },
          loadOlder: () => { void session.loadOlder({ deferConsumption: true }) },
          consumeOlder: () => session.consumeOlder(),
          loadThrough: seq => session.loadThrough(seq),
          loadImage: Object.assign(
            (attachment: ImageAttachmentRef) => ctx.uiConversation.imageUrl(sessionId, attachment),
            { peek: (attachment: ImageAttachmentRef) => ctx.uiConversation.peekImageUrl(sessionId, attachment) },
          ),
          chatScroll: {
            save: (position) => {
              if (position === null) chatScrollPositions.delete(sessionId)
              else chatScrollPositions.set(sessionId, position)
            },
            read: () => chatScrollPositions.get(sessionId) ?? null,
          },
          forkAt: (seq) => {
            const turn = [...chat.getSnapshot().timeline.turns.values()].find(turn => turn.end?.seq === seq)
            const messageId = turn?.data.get('turn-tail')?.closing?.finalNode.messageId
            ctx.sessions.fork({ sessionId, atSeq: seq, increaseTitle: true, onCreated: (childId) => {
              ctx.get('productAnalytics')?.track('branch_session_click', { session_id: childId, parent_session_id: sessionId, ...messageId === undefined ? {} : { parent_message_id: messageId }, click_position: 'footer' })
            } })
              .then((childId) => { ctx.uiWorkspace.openSession(childId) })
              .catch(() => {
                // Fork or child-title failure leaves the source view unchanged.
              })
          },
        }
      },
    }, ChatView)
    return disposeView
  })
  registerFenceLayers(ctx)

  // The quota notice host lives in the frame-wide layer so a notice outlives
  // the Chat panel that reported it. Its chain child lets a package with a
  // billing surface claim the one live notice without importing Chat.
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay', id: 'chat.quota-notice', locale: NS,
    children: { 'shell.quota-notice': { kind: 'chain', scope: 'root' } },
    inject: (): QuotaNoticeInjected => ({
      hooks: { notice: quotaNotice },
      dismissNotice: () => { quotaNoticeHolds.clear(); quotaNotice.set(null) },
      keepNoticeOpen: () => {
        // Nothing live to retain: later failures must still publish.
        if (quotaNotice.getSnapshot() === null) return () => {}
        const token = Symbol('ui-chat quota notice hold')
        quotaNoticeHolds.add(token)
        return () => { quotaNoticeHolds.delete(token) }
      },
    }),
  }, QuotaNoticeHost))

  // One dock entry per pill, so a plugin replaces or adds a single pill by id.
  const statPillInject = () => ({ hooks: { performanceUsage } })
  ctx.slots.inject('conversation.composer.dock', function* () {
    yield ctx.slots.register({
      name: 'conversation.composer.dock', id: 'activity', order: 0, locale: NS, inject: statPillInject,
    }, ActivityPill)
    yield ctx.slots.register({
      name: 'conversation.composer.dock', id: 'usage', order: 1, locale: NS, inject: statPillInject,
    }, UsagePill)
  })

  ctx.slots.inject('conversation.approval.detail', () =>
    ctx.slots.register({ name: 'conversation.approval.detail' }, ApprovalCommand))

}
