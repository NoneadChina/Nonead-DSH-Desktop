import type { ChatViewSlotProps } from '../contract/slots.ts';
type CommandRowState = 'running' | 'ok' | 'error';
interface CommandStatusRowProps {
    title: string;
    state: CommandRowState;
    summary: string;
    body: string | null;
    t: ChatViewSlotProps['t'];
}
/** Render a running or settled status with optional multiline details.
 * @param props - localized labels, status, and expandable content.
 * @returns the status row.
 */
export declare const CommandStatusRow: import("react").MemoExoticComponent<({ title, state, summary, body, t }: CommandStatusRowProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=CommandStatusRow.d.ts.map