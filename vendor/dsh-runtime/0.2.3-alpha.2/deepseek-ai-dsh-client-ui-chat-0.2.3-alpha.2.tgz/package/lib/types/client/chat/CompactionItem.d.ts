import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { ChatViewSlotProps } from '../contract/slots.ts';
import type { CompactionSummaryNode } from '../contract/snapshot.ts';
/** Session-bound checkpoint navigation for manual and automatic compaction rows. */
export interface CompactionRowInjected {
    hooks: {
        compactionPreview: ObservableSnapshot<boolean>;
    };
    openCompaction: (seq: number, signal: AbortSignal) => Promise<string | null>;
}
interface CompactionItemProps {
    openCompaction: CompactionRowInjected['openCompaction'] | undefined;
    node: CompactionSummaryNode;
    /** Optional command title for a manual compaction folded into this marker. */
    title?: string;
    /** Command settlement text used when structured compaction counts are unavailable. */
    fallbackSummary?: string | null;
    /** The owning view's locale seat. */
    t: ChatViewSlotProps['t'];
}
/**
 * Renders the model-history compaction marker.
 * @param props - the marker node off the snapshot cache and the Sidebar opener.
 * @returns the marker row; disabled while no Sidebar tab type opens checkpoints.
 */
export declare const CompactionItem: import("react").MemoExoticComponent<({ node, openCompaction, title, fallbackSummary, t, }: CompactionItemProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=CompactionItem.d.ts.map