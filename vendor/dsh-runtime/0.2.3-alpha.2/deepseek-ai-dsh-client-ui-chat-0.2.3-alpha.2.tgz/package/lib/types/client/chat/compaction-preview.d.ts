/** Session-bound Markdown previews for manual and automatic compaction rows. */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { CompactionRowInjected } from './CompactionItem.tsx';
/** Bind summary reads to the requesting row and the document viewer lifetime.
 * @param ctx - Chat plugin context.
 * @returns the preview action and availability hook for a Session.
 */
export declare function compactionRows(ctx: Context): (sessionId: SessionId) => CompactionRowInjected;
//# sourceMappingURL=compaction-preview.d.ts.map