import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** @param props - current tab navigation and Markdown labels.
 * @returns the summary or its expired state after a page reload.
 */
export declare function SummaryPreview({ useTabInfo, t }: PropsRuntime<'sidebar.right.pane.tab'> & PropsLocale<'documentMarkdown'>): import("react").JSX.Element;
/** @param props - current locale.
 * @returns the Markdown tab icon and localized summary title.
 */
export declare function SummaryTitle({ t }: PropsLocale<'documentMarkdown'>): import("react").JSX.Element;
//# sourceMappingURL=SummaryPreview.d.ts.map