/** Physical frame encoding selected by the plugin's `compression` config. */
export type FrameCompression = 'zstd' | 'none';
/** Stored `frames.codec` for UTF-8 JSON lines; a format constant, never reinterpreted. */
export declare const FRAME_CODEC_UTF8 = 0;
/** Stored `frames.codec` for one Zstandard frame of UTF-8 JSON lines; a format constant, never reinterpreted. */
export declare const FRAME_CODEC_ZSTD = 1;
/** One encoded frame: the stored bytes, their codec, and the number of events they hold. */
export interface EncodedFrame {
    readonly codec: typeof FRAME_CODEC_UTF8 | typeof FRAME_CODEC_ZSTD;
    readonly bytes: Buffer;
    readonly count: number;
}
/**
 * Encode one batch of event JSON texts as a frame. Synchronous: a batch costs
 * milliseconds at most, and callers yield between batches of a long import.
 * @param lines - the batch's events, each serialized as one JSON text without newlines.
 * @param compression - `zstd` compresses when that is smaller; `none` stores the text.
 * @returns the frame to store.
 */
export declare function encodeFrame(lines: readonly string[], compression: FrameCompression): EncodedFrame;
/**
 * Decode one stored frame back to its event JSON texts. A compressed frame
 * decompresses on the libuv thread pool, so callers may decode several frames
 * concurrently; a text frame decodes inline.
 * @param codec - the frame's stored codec.
 * @param bytes - the frame's stored bytes.
 * @returns the JSON text of each event, in sequence order.
 * @throws {RangeError} for an unknown codec; a corrupt frame rejects with the Zstandard error.
 */
export declare function decodeFrame(codec: number, bytes: Uint8Array): Promise<string[]>;
//# sourceMappingURL=frame.d.ts.map