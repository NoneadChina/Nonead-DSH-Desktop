/** Exclusive legacy Session import with same-provider open sequencing. @module */
import type { SessionId } from '@deepseek-ai/dsh-session';
import type { JsonlSessionPersistence } from '@deepseek-ai/dsh-session-persistence-jsonl';
import type { SessionAccess, SessionHandle, SessionPersistenceOpenOptions } from '@deepseek-ai/dsh-session-persistence';
import type { SqliteStore } from './sqlite.ts';
/** Historical reads used by the persistence service; no JSONL writes or live handles. */
export type JsonlBackend = Pick<JsonlSessionPersistence, 'stat' | 'hasStoredJsonl' | 'prepare' | 'list'>;
/** Owns pending legacy opens until import, ownership handoff, and cleanup finish. */
export declare class LegacySessionMigration {
    private readonly jsonl;
    private readonly sqlite;
    private readonly selected;
    private readonly publish;
    private readonly pending;
    private closing;
    private readonly stopped;
    constructor(jsonl: JsonlBackend, sqlite: SqliteStore, selected: (id: SessionId) => Promise<boolean>, publish: (id: SessionId) => Promise<void>);
    /**
     * Serialize legacy opens within this provider. Readers wait for another provider's import; writers reject contention.
     * @param id - legacy Session identity.
     * @param access - requested access after import.
     * @param options - optional cancellation checked when the queued open starts.
     * @returns SQLite handle; a write handle retains the import lease without a release/reacquire gap.
     */
    open(id: SessionId, access: SessionAccess, options?: SessionPersistenceOpenOptions): Promise<SessionHandle>;
    private migrate;
    /** Stop admission and settle accepted imports before SQLite closes. @returns settled cleanup. */
    close(): Promise<void>;
}
//# sourceMappingURL=migration.d.ts.map