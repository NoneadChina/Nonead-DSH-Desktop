/** SQLite Session persistence and event storage. @module */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Config as JsonlConfigOptions } from '@deepseek-ai/dsh-session-persistence-jsonl';
/** Loader label for the SQLite Session persistence provider. */
export declare const name = "session-persistence-sqlite";
/** Storage root, JSONL settings used when importing legacy Sessions, and the frame size for new writes. */
export interface Config extends JsonlConfigOptions {
    /**
     * Maximum events stored per frame. One frame is the unit of compression and
     * of decoding, so this bounds both the compression ratio and the cost of
     * reading a slice; stored frames keep the size they were written with.
     */
    frameEvents?: number;
}
/** Validate the storage root, legacy JSONL reader settings, and frame size. */
export declare const Config: z<Config>;
/**
 * Provide SQLite persistence and retain storage resources through consumer unload.
 * @param ctx - plugin context owning the provider and its resources.
 * @param config - storage root and legacy JSONL reader settings.
 * @returns resolves after the persistence service is registered.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map