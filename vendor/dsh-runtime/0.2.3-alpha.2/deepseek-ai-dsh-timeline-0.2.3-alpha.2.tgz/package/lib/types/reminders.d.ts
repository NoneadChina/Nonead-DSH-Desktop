import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
import type { OwnsAgent } from './delegation.ts';
import type { TimelineStorage } from './storage.ts';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'timeline-priority': {
            kind: 'timeline-priority';
            form: 'notice';
            summary: string;
        };
    }
}
/**
 * Count main-agent iterations, not tool calls or independent reporting requests.
 * @param ctx - owning plugin context.
 * @param config - current Timeline settings.
 * @param storage - Timeline's session data service.
 * @param owns - whether this installation owns the agent's planning tools.
 */
export declare function installReminders(ctx: Context, config: Config, storage: TimelineStorage, owns: OwnsAgent): void;
//# sourceMappingURL=reminders.d.ts.map