import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.ts';
import type { PluginConfig } from './config.ts';
export { Config };
export declare const name = "timeline";
export declare const inject: string[];
/**
 * Install Timeline for the profile's agents and client.
 * @param ctx Plugin context.
 * @param input Loader-owned Timeline settings.
 */
export declare function apply(ctx: Context, input: PluginConfig): Promise<void>;
//# sourceMappingURL=index.d.ts.map