import { z } from 'zod';
import type { Annotation, Task, Tree } from './records.ts';
/** Maximum encoded size of an imported task tree. */
export declare const CHECKPOINT_BYTES: number;
declare const schema: z.ZodObject<{
    format: z.ZodLiteral<"dsh-timeline-tree">;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    elapsedMs: z.ZodOptional<z.ZodNumber>;
    tasks: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        parent: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>>;
        title: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<{
            pending: "pending";
            active: "active";
            paused: "paused";
            blocked: "blocked";
            done: "done";
            retired: "retired";
        }>>;
        done: z.ZodOptional<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
        weight: z.ZodOptional<z.ZodNumber>;
        note: z.ZodOptional<z.ZodString>;
        details: z.ZodOptional<z.ZodString>;
        priority: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            P0: "P0";
            P1: "P1";
            P2: "P2";
            P3: "P3";
        }>>>;
        history: z.ZodOptional<z.ZodArray<z.ZodObject<{
            done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
            title: z.ZodString;
            description: z.ZodString;
            note: z.ZodString;
            details: z.ZodString;
            priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                P0: "P0";
                P1: "P1";
                P2: "P2";
                P3: "P3";
            }>>>;
            at: z.ZodNumber;
            progress: z.ZodNumber;
            previousProgress: z.ZodNullable<z.ZodNumber>;
            weight: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    discussions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        task: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
        text: z.ZodString;
        createdAt: z.ZodOptional<z.ZodNumber>;
        reply: z.ZodOptional<z.ZodObject<{
            text: z.ZodString;
            createdAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodJSONSchema>>;
}, z.core.$strict>;
type CheckpointData = z.infer<typeof schema>;
/** Portable version-one plan data, independent of Session storage and plugin versions. */
export declare class Checkpoint {
    private readonly data;
    readonly tasks: readonly Task[];
    private constructor();
    /**
     * Validate a UTF-8-sized JSON file and its complete task graph before any write.
     * @param text - the text to parse.
     * @returns the validated portable plan.
     */
    static fromString(text: string): Checkpoint;
    /**
     * Normalize file values through the same graph and progress checks as task edits.
     * @param input - input to validate.
     * @returns the validated portable plan.
     */
    static fromJson(input: unknown): Checkpoint;
    /**
     * Export one acknowledged tree and its ordinary user discussions without live requests.
     * @param tree - the task tree before the change.
     * @param annotations - saved notes and work requests.
     * @param now - current wall clock time in milliseconds.
     * @param sessionId - identifier of the owning session.
     * @param pluginVersion - release version to include in the export metadata, when known.
     * @returns the portable snapshot of the tree.
     */
    static fromTree(tree: Tree, annotations: readonly Annotation[], now: number, sessionId: string, pluginVersion?: string): Checkpoint;
    /**
     * Return canonical readable fields; empty text, default values and inert metadata are omitted.
     * @returns portable data without descriptive metadata.
     */
    toJson(): CheckpointData;
    /**
     * Encode a checkpoint that the same bounded reader can import.
     * @returns the complete JSON export.
     */
    toString(): string;
    /**
     * Create detached local identities; imported active leaves wait for an explicit continuation.
     * @param id - new identifier for the imported tree.
     * @param now - current wall clock time in milliseconds.
     * @returns the restored tree, notes, and unfinished work.
     */
    restore(id: string, now: number): {
        tree: Tree;
        annotations: Annotation[];
        resume: string[];
    };
}
export {};
//# sourceMappingURL=checkpoint.d.ts.map