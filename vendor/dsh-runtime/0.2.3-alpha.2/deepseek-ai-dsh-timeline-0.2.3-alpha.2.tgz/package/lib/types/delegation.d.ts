import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { TimelineStorage } from './storage.ts';
/**
 * Session ancestry alone also describes user forks; only origin identifies delegated work.
 * @param agent - the agent whose session or role is being checked.
 * @returns whether the agent is a delegated worker.
 */
export declare function isWorker(agent: Agent | undefined): boolean;
/** The Timeline installation that owns an agent's planning tools. */
export type OwnsAgent = (agent: Agent) => boolean;
/**
 * Compare tool identity so an enclosing installation cannot also manage a scoped agent.
 * @param ctx - context that registered the planning tool.
 * @returns a predicate that checks whether this installation owns an agent.
 */
export declare function planningOwner(ctx: Context): OwnsAgent;
/**
 * Read loaded ancestry only. IDs are assignment references, never cross-session capabilities.
 * @param ctx - owning plugin context.
 * @param agent - the agent whose session or role is being checked.
 * @param storage - Timeline's session data service.
 * @returns guidance for the delegated worker, or empty text.
 */
export declare function delegationContext(ctx: Context, agent: Agent, storage: TimelineStorage): string;
/**
 * Workers report to their parent; only managers can use Timeline's session-local tools.
 * @param ctx - owning plugin context.
 * @param owns - whether this installation owns the agent's planning tools.
 */
export declare function installDelegation(ctx: Context, owns: OwnsAgent): void;
//# sourceMappingURL=delegation.d.ts.map