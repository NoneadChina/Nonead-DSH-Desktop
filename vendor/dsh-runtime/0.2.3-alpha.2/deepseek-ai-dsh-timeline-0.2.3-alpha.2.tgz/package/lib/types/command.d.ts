import type { Context } from '@deepseek-ai/cordis';
import type { TimelineStorage } from './storage.ts';
/**
 * Register a human command; importing needs no model or new agent tool.
 * @param ctx - owning plugin context.
 * @param storage - Timeline's session data service.
 */
export declare function installCommand(ctx: Context, storage: TimelineStorage): void;
//# sourceMappingURL=command.d.ts.map