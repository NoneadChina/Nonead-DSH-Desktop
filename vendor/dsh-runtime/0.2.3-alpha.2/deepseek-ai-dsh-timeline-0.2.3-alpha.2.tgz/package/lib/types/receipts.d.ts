import type { Task, TaskPatch, TaskReceipt, Tree } from './records.ts';
/**
 * Snapshot one semantic task batch without reading conversation history or model output.
 * @param tree - the task tree before the change.
 * @param tasks - task records for the addressed tree.
 * @param patches - the task edits sent in the batch.
 * @param at - wall clock time associated with the update.
 * @returns the changes for a progress card, or null for a no-op.
 */
export declare function taskReceipt(tree: Tree, tasks: readonly Task[], patches: readonly TaskPatch[], at: number): TaskReceipt | null;
//# sourceMappingURL=receipts.d.ts.map