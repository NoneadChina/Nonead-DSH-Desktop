import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
import type { IntervalReport, StoredRequest, Summary } from './records.ts';
declare module '@deepseek-ai/dsh-llm/types' {
    interface LlmRequestPurposeMap {
        'timeline-report': true;
    }
}
interface SummaryInput {
    draft: IntervalReport;
    request: StoredRequest;
    children: readonly IntervalReport[];
    previous: Summary | undefined;
    settings: Pick<Config, 'language' | 'uiLanguage' | 'levelPrompts' | 'summaryPrompt' | 'maxResponseBytes' | 'reportMaxTokens' | 'reportReasoningEffort'>;
    record: (request: StoredRequest) => Promise<void>;
}
/**
 * Query and validate one tool-free report, recording each request before dispatch.
 * @param llm - the model service used to generate the report.
 * @param input - input to validate.
 * @param signal - cancellation signal for this operation.
 * @returns the validated model report.
 */
export declare function summarizeReport(llm: Context['llm'], input: SummaryInput, signal: AbortSignal): Promise<Summary>;
export {};
//# sourceMappingURL=summary.d.ts.map