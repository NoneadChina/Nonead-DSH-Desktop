import { z } from 'zod';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** Authenticated RPC channel for Timeline edits. */
export declare const TIMELINE_CHANNEL = "/timeline";
/** Method for applying a user edit. */
export declare const TIMELINE_EDIT = "edit";
/** Method for reporting the owner browser's resolved UI language. */
export declare const TIMELINE_LOCALE = "locale";
/** Accept only language identifiers supported for Timeline output. */
export declare const browserLanguageSchema: z.ZodEnum<{
    en: "en";
    "zh-CN": "zh-CN";
    ja: "ja";
    es: "es";
    fr: "fr";
    de: "de";
    ru: "ru";
    pt: "pt";
}>;
/** Validate user actions before they reach session state. */
export declare const editRequestSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    action: z.ZodLiteral<"import">;
    sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    id: z.ZodString;
    content: z.ZodString;
    copy: z.ZodDefault<z.ZodBoolean>;
    continue: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"remove">;
    sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    draft: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"control">;
    sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"tree">;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"task">;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    }, z.core.$strict>], "kind">;
    id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
    intent: z.ZodEnum<{
        pause: "pause";
        resume: "resume";
    }>;
    text: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"delivery">;
    sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
    delivery: z.ZodEnum<{
        unknown: "unknown";
        accepted: "accepted";
    }>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"annotate">;
    sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"tree">;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"task">;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"report">;
        report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
    }, z.core.$strict>], "kind">;
    id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
    text: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"priority">;
    sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    priority: z.ZodNullable<z.ZodEnum<{
        P0: "P0";
        P1: "P1";
        P2: "P2";
        P3: "P3";
    }>>;
}, z.core.$strict>], "action">;
/** Validate the server result of a user action. */
export declare const editResponseSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    action: z.ZodLiteral<"import">;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    reused: z.ZodBoolean;
    notified: z.ZodBoolean;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"remove">;
    removed: z.ZodBoolean;
    notified: z.ZodBoolean;
    draft: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"control">;
    annotation: z.ZodObject<{
        id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"tree">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"task">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"report">;
            report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        }, z.core.$strict>], "kind">;
        text: z.ZodString;
        createdAt: z.ZodNumber;
        reply: z.ZodNullable<z.ZodObject<{
            text: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        control: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                pause: "pause";
                resume: "resume";
            }>;
            delivery: z.ZodEnum<{
                unknown: "unknown";
                sending: "sending";
                accepted: "accepted";
            }>;
            outcome: z.ZodNullable<z.ZodObject<{
                status: z.ZodEnum<{
                    applied: "applied";
                    completed: "completed";
                    unavailable: "unavailable";
                    answered: "answered";
                    superseded: "superseded";
                }>;
                at: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    dispatch: z.ZodBoolean;
    context: z.ZodJSONSchema;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"delivery">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"annotate">;
    annotation: z.ZodObject<{
        id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"tree">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"task">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"report">;
            report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        }, z.core.$strict>], "kind">;
        text: z.ZodString;
        createdAt: z.ZodNumber;
        reply: z.ZodNullable<z.ZodObject<{
            text: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        control: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                pause: "pause";
                resume: "resume";
            }>;
            delivery: z.ZodEnum<{
                unknown: "unknown";
                sending: "sending";
                accepted: "accepted";
            }>;
            outcome: z.ZodNullable<z.ZodObject<{
                status: z.ZodEnum<{
                    applied: "applied";
                    completed: "completed";
                    unavailable: "unavailable";
                    answered: "answered";
                    superseded: "superseded";
                }>;
                at: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    context: z.ZodJSONSchema;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"priority">;
}, z.core.$strip>], "action">;
/** Validated user action sent to the host. */
export type UserEdit = z.infer<typeof editRequestSchema>;
/** Saved action outcome returned by the host. */
export type UserEditResult = z.infer<typeof editResponseSchema>;
//# sourceMappingURL=protocol.d.ts.map