/** Profile entry id used by the Timeline settings form. */
export declare const TIMELINE_CONFIG_ID = "timeline-experimental";
/** Reports and the sidebar never operate below minute resolution. */
export declare const MINUTE_MS = 60000;
/** Maximum number of characters in one editable prompt. */
export declare const PROMPT_LIMIT = 32768;
/** The settings defaults are also used while the client loads its configuration. */
export declare const defaultReportCadence: {
    readonly intervalMs: number;
    readonly rollupFactors: readonly [4, 4];
};
/** Display window in milliseconds. Session logs retain their original records. */
export declare const HISTORY_MS: number;
/** Maximum active discussions in one Session. */
export declare const MAX_ANNOTATIONS = 512;
/** Languages that Timeline can request from the model. */
export declare const outputLanguages: readonly ["en", "zh-CN", "ja", "es", "fr", "de", "ru", "pt"];
/** Language options including the current app language and the agent's own choice. */
export declare const languages: readonly ["ui", "chat", "en", "zh-CN", "ja", "es", "fr", "de", "ru", "pt"];
/** A fixed output language, the app preference, or the language the agent chooses from the chat. */
export type Language = (typeof languages)[number];
/** One language supported for Timeline model output. */
export type OutputLanguage = (typeof outputLanguages)[number];
/** Native names also identify the required language in model instructions. */
export declare const languageText: Record<OutputLanguage, {
    label: string;
    noActivity: string;
    priority: string;
}>;
/** Supported counts of displayed decimal places. */
export declare const progressPrecisions: readonly [0, 1, 2, 3];
/** Number of displayed decimal places. */
export type ProgressPrecision = (typeof progressPrecisions)[number];
/**
 * Resolve Harness language tags; unsupported language packs use English output.
 * @param locale - the active app locale or its client service.
 * @returns a supported model language, falling back to English.
 */
export declare function appLanguage(locale: string): OutputLanguage;
/**
 * Resolve the language that Timeline requires of the model.
 * @param language - configured Timeline language.
 * @param uiLanguage - current app language when following the app.
 * @returns the required output language, or `undefined` when following the chat sets no requirement.
 */
export declare function outputLanguage(language: Language, uiLanguage: OutputLanguage): OutputLanguage | undefined;
/**
 * Select the text that Timeline writes without the model; following the chat uses the app language.
 * @param language - configured Timeline language.
 * @param uiLanguage - current app language.
 * @returns the fixed text in the selected language.
 */
export declare function fixedText(language: Language, uiLanguage: OutputLanguage): (typeof languageText)[OutputLanguage];
/**
 * Language applies only to saved task-tree content, not the agent's other work.
 * @param language - required output language.
 * @returns the language rule for task content only.
 */
export declare function taskLanguageInstruction(language: OutputLanguage): string;
/**
 * Fixed policy used only in independent report queries.
 * @param language - required output language.
 * @returns the language rule for report content.
 */
export declare function languageInstruction(language: OutputLanguage): string;
/**
 * Round a timestamp down to a whole minute.
 * @param time - wall clock timestamp in milliseconds.
 * @returns the start time of the enclosing minute.
 */
export declare function minuteAt(time: number): number;
//# sourceMappingURL=policy.d.ts.map