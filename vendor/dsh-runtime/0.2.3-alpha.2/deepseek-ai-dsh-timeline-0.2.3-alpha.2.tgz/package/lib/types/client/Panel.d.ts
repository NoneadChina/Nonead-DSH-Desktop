import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PropsStore, ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { Config } from '../config.ts';
import type { createViewStore } from './store.ts';
import type { AnnotationRequest, PriorityRequest, TaskRequest } from './actions.ts';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { TreeTransferActions } from './TreeTransfer.tsx';
export interface PanelInjected extends TreeTransferActions {
    hooks: {
        clock: ObservableSnapshot<number>;
        locale: ObservableSnapshot<{
            active: string;
        }>;
        settings: ObservableSnapshot<ConfigFormSnapshot<Config>>;
        selection: ObservableSnapshot<SessionId | null>;
    };
    requestTask: (request: TaskRequest) => Promise<void>;
    setPriority: (request: PriorityRequest) => Promise<void>;
    annotate: (request: AnnotationRequest) => Promise<{
        notified: boolean;
    }>;
    consumeSelection: () => void;
}
type PanelProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsLocale<'timeline'> & PropsStore<ReturnType<typeof createViewStore>> & InjectFace<PanelInjected>;
/** Read the shared committed view; this panel owns only viewing choices. */
export declare function Panel({ sessionId, useProjection, useStore, actions, useClock, useLocale, useSettings, t, useSession, requestTask, setPriority, annotate, useTabInfo, useSelection, consumeSelection, importTree, removeTree, }: PanelProps): ReactNode;
export {};
//# sourceMappingURL=Panel.d.ts.map