import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { TimelineView, IntervalReport } from '../records.ts';
import type { ViewState } from './store.ts';
import { reportPeriods } from '../periods.ts';
interface ScheduleProps extends PropsLocale<'timeline'> {
    locale?: string;
    cadence: Parameters<typeof reportPeriods>[0];
    view: TimelineView;
    state: ViewState;
    now: number;
    update: (patch: Partial<ViewState>) => void;
    openReport: (id: IntervalReport['id']) => void;
}
/** All hierarchy levels share one reverse time ruler; focus changes width and scale, never report identity. */
export declare function Schedule({ view, cadence, state, now, update, openReport, t, locale }: ScheduleProps): ReactNode;
export {};
//# sourceMappingURL=Schedule.d.ts.map