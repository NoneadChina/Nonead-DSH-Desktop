/** One linear wall-clock axis shared by every report column. */
export declare class TimeScale {
    private readonly anchor;
    private readonly start;
    /** Full pixel height of the visible history window. */
    readonly height: number;
    constructor(anchor: number, pixelsPerHour: number);
    private clampTime;
    /**
     * Map a wall clock timestamp to the shared vertical axis.
     * @param time - wall clock timestamp in milliseconds.
     * @returns vertical position in pixels.
     */
    position(time: number): number;
    /**
     * Map a vertical offset back to wall clock time.
     * @param position - vertical offset in pixels.
     * @returns wall clock timestamp in milliseconds.
     */
    time(position: number): number;
    /**
     * Keep the grid at minute resolution, including empty spans between reports.
     * @param top - first visible pixel on the axis.
     * @param height - visible height of the axis in pixels.
     * @param spacing - desired distance between tick labels in pixels.
     * @returns visible calendar ticks in time order.
     */
    ticks(top: number, height: number, spacing: number): Date[];
}
//# sourceMappingURL=TimeScale.d.ts.map