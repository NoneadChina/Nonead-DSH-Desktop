import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProgressPrecision } from '../policy.ts';
import type { Task } from '../records.ts';
/** Read-only revisions stay folded and unmounted until the user opens them. */
export declare function TaskHistory({ task, decimals, locale, t, }: {
    task: Task;
    locale?: string;
    decimals: ProgressPrecision;
} & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=TaskHistory.d.ts.map