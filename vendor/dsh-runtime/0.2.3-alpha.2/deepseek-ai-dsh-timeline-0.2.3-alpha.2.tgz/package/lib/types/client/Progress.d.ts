import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { Task } from '../records.ts';
import type { ProgressPrecision } from '../policy.ts';
import type { ProgressParts } from '../tasks.ts';
/** Keep incomplete work below 100 at the chosen display precision. */
export declare function formatProgress(value: number, decimals?: ProgressPrecision): string;
/**
 * Show a task weight independently of the progress precision setting.
 * @param weight - the stored sibling weight.
 * @returns the weight rounded to at most two decimal places, without trailing zeros.
 */
export declare function formatWeight(weight: number): string;
/** Stable, determinate progress with quiet motion only while work is active. */
export declare function Progress({ value, status, label, decimals, parts, t, }: {
    value: number;
    status: Task['status'];
    label: string;
    decimals?: ProgressPrecision;
    parts?: ProgressParts | undefined;
} & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=Progress.d.ts.map