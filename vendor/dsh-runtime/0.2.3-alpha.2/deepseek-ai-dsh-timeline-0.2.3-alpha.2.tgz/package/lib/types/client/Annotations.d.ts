import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { Annotation, AnnotationTarget, TimelineView } from '../records.ts';
import type { AnnotationRequest } from './actions.ts';
import type { AnnotationDraftControl } from './store.ts';
/** Use the session-owned draft when mounted in the Timeline panel. */
export declare function useAnnotationDraft(control?: AnnotationDraftControl): AnnotationDraftControl;
/** Append-only user feedback with one agent resolution. */
export declare function Annotations({ annotations, locale, targetTitle, t, }: {
    locale?: string;
    annotations: readonly Annotation[];
    targetTitle?: (target: AnnotationTarget) => ReactNode;
} & PropsLocale<'timeline'>): ReactNode;
/** One read-only Session history shared by the main pages, newest first; collapsed content stays unmounted. */
export declare function DiscussionHistory({ view, locale, open, onToggle, t, }: {
    view: TimelineView;
    locale?: string;
    open: boolean;
    onToggle: (open: boolean) => void;
} & PropsLocale<'timeline'>): ReactNode;
/** Edit a discussion draft and retain the same identity across failed saves. */
export declare function AnnotationEditor({ target, draft: { open, text, id, busy, messageKey }, update, save, t, }: {
    target: AnnotationTarget;
    save: (request: AnnotationRequest) => Promise<{
        notified: boolean;
    }>;
} & AnnotationDraftControl & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=Annotations.d.ts.map