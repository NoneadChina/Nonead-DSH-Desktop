import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** Render saved detail text with Harness's shared, compact Markdown component. */
export declare function Markdown({ text, t }: {
    text: string;
} & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=Markdown.d.ts.map