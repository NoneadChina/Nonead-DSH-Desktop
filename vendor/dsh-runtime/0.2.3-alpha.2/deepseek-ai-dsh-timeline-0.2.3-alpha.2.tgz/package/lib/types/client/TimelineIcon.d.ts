import type { ReactNode } from 'react';
/** Shared connected-timeline glyph; its owner supplies the accessible label. */
export declare function TimelineIcon({ size, className, }: {
    size?: number | undefined;
    className?: string | undefined;
}): ReactNode;
//# sourceMappingURL=TimelineIcon.d.ts.map