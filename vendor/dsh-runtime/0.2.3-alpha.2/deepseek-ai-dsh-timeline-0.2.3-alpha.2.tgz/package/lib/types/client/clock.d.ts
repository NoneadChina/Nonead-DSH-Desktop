/**
 * One aligned clock per plugin registration; late background timers resync to the next minute.
 * @param update - receiver of each new minute.
 * @returns cleanup that stops the clock.
 */
export declare function startMinuteClock(update: (time: number) => void): () => void;
//# sourceMappingURL=clock.d.ts.map