import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { Tree, TimelineView } from '../records.ts';
import type { ImportRequest } from './actions.ts';
import type { UserEditResult } from '../protocol.ts';
import type { ProgressPrecision } from '../policy.ts';
export interface TreeTransferActions {
    importTree: (request: ImportRequest) => Promise<Extract<UserEditResult, {
        action: 'import';
    }>>;
    removeTree: (tree: Tree['id']) => Promise<Extract<UserEditResult, {
        action: 'remove';
    }>>;
}
/** Download the acknowledged plan; no model request or host filesystem write is needed. */
export declare function exportTree(tree: Tree, annotations: TimelineView['annotations'], sessionId: string): void;
/** Review a local checkpoint or confirm deletion through the same user-owned storage path. */
export declare function TreeTransfer({ mode, sessionId, tree, view, running, decimals, close, imported, removed, importTree, removeTree, t, }: {
    mode: 'import' | 'remove' | null;
    sessionId: string;
    tree: Tree | undefined;
    view: TimelineView;
    running: boolean;
    decimals: ProgressPrecision;
    close: () => void;
    imported: (tree: Tree['id'], warning: boolean) => void;
    removed: (warning: boolean) => void;
} & TreeTransferActions & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=TreeTransfer.d.ts.map