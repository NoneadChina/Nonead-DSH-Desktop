import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { IntervalReport, TimelineView } from '../records.ts';
import type { AnnotationDraftControl } from './store.ts';
import type { AnnotationRequest } from './actions.ts';
interface ReportDetailsProps extends PropsLocale<'timeline'> {
    view: TimelineView;
    locale?: string;
    reportId: IntervalReport['id'] | null;
    openReport: (id: IntervalReport['id']) => void;
    back: () => void;
    annotate: (request: AnnotationRequest) => Promise<{
        notified: boolean;
    }>;
    annotationDraft?: AnnotationDraftControl | undefined;
}
/** Short report content, with actual duration and links to the included reports. */
export declare function ReportDetails({ view, locale, reportId, openReport, back, annotate, annotationDraft, t, }: ReportDetailsProps): ReactNode;
export {};
//# sourceMappingURL=ReportDetails.d.ts.map