import type { Activity, IntervalReport, TimeRange } from './records.ts';
/**
 * Union recorded intervals without inventing activity across gaps.
 * @param ranges - ranges to merge.
 * @returns ordered, nonoverlapping ranges.
 */
export declare function mergeRanges(ranges: readonly TimeRange[]): TimeRange[];
/**
 * Public turn brackets are the timing authority; an open turn is clipped at the requested boundary.
 * @param activity - recorded session activity.
 * @param start - lower time bound in milliseconds.
 * @param end - upper time bound in milliseconds.
 * @returns activity within the requested bounds.
 */
export declare function activeRanges(activity: Activity, start: number, end: number): TimeRange[];
/**
 * Captured report timing is immutable; old reports can use retained Session evidence.
 * @param report - the saved report to inspect.
 * @param activity - recorded session activity.
 * @returns the report's recorded ranges or reconstructed activity.
 */
export declare function reportRanges(report: IntervalReport, activity: Activity | undefined): TimeRange[] | undefined;
/**
 * A saved report keeps its original nominal period when live settings change.
 * @param report - the saved report to inspect.
 * @returns the report's configured period, when known.
 */
export declare function savedPeriod(report: IntervalReport): number | undefined;
/**
 * Minimum elapsed-time thresholds; actual work remains separate from report coverage.
 * @param policy - configured interval and rollup periods.
 * @returns each report level's period in milliseconds.
 */
export declare function reportPeriods(policy: {
    intervalMs: number;
    rollupFactors: readonly number[];
}): number[];
/**
 * Check that each report level is reachable before its child reports expire.
 * @param periods - ordered report periods in milliseconds, starting with the base.
 * @returns whether the cadence can be saved and scheduled.
 */
export declare function validReportPeriods(periods: readonly number[]): boolean;
/**
 * Format a configured report period for display.
 * @param ms - duration in milliseconds.
 * @returns a compact interval label.
 */
export declare function formatPeriod(ms: number): string;
/**
 * Stable human-readable elapsed time without rapidly changing decimal minutes.
 * @param ms - duration in milliseconds.
 * @returns a compact elapsed time label.
 */
export declare function formatDuration(ms: number): string;
//# sourceMappingURL=periods.d.ts.map