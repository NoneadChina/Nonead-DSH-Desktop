import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
import type { OwnsAgent } from './delegation.ts';
import type { TimelineStorage } from './storage.ts';
/**
 * Hide Todo through the public registry; both the agent and this plugin own each mask.
 * @param ctx - owning plugin context.
 * @param config - current Timeline settings.
 * @param storage - Timeline's session data service.
 * @param owns - whether this installation owns the agent's planning tools.
 */
export declare function installGuidance(ctx: Context, config: Config, storage: TimelineStorage, owns: OwnsAgent): void;
//# sourceMappingURL=guidance.d.ts.map