/** Default limits and writing guidance shared by the Host and client. */
declare const _default: {
    taskPrompt: string;
    summaryPrompt: string;
};
export default _default;
//# sourceMappingURL=defaults.d.ts.map