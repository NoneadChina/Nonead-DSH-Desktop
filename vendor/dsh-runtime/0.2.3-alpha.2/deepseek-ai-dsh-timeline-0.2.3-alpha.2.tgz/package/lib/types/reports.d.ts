import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
import type { OwnsAgent } from './delegation.ts';
import type { TimelineStorage } from './storage.ts';
/**
 * Check elapsed thresholds while active; idle Sessions catch up on their next turn.
 * @param ctx - owning plugin context.
 * @param config - current Timeline settings.
 * @param storage - Timeline's session data service.
 * @param owns - whether this installation owns the agent's planning tools.
 */
export declare function installReports(ctx: Context, config: Config, storage: TimelineStorage, owns: OwnsAgent): void;
//# sourceMappingURL=reports.d.ts.map