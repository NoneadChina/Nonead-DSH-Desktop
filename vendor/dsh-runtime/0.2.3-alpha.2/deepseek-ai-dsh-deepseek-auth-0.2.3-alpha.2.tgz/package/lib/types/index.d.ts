/**
 * DeepSeek request authentication (`ctx.deepseekAuth`). DeepSeek APIs accept two kinds of credential, the API key and
 * the account sign-in, and each API accepts one or both. A consumer names the kinds its API accepts and the billing
 * its settings choose; this service orders the kinds, binds each to the deployment its credential belongs to, and
 * releases the request headers of the first kind that has a credential. Model route plugins connect the deployment
 * their settings name; without a connection the API key is `DEEPSEEK_API_KEY` at the official API and the account
 * sign-in goes to the deployment `DEEPSEEK_BASE_URL` names.
 *
 * ```ts
 * const authorization = await ctx.deepseekAuth.authorize({
 *   consumer: name, accepts: ['account', 'api-key'], billing: 'auto', route, destination: { path: '/v1/tools/search' },
 * }, signal)
 * ```
 *
 * @module @deepseek-ai/dsh-deepseek-auth
 */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-error';
import type { DeepSeekAuthCandidate, DeepSeekAuthConnection, DeepSeekAuthKind, DeepSeekAuthRequest, DeepSeekAuthUnresolved, DeepSeekAuthorization } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        deepseekAuth: DeepSeekAuth;
    }
}
/** Failure codes of {@link DeepSeekAuthError}. */
export type DeepSeekAuthErrorCode = 
/** A second connection of one kind; one model route plugin owns each kind's deployment. */
'DUPLICATE_CONNECTION'
/** The configured API key is blank or cannot travel in an HTTP header. */
 | 'INVALID_CREDENTIAL'
/** The connection of the kind an operation reached does not resolve. */
 | 'UNRESOLVED_CONNECTION';
/** A DeepSeek authentication failure; `message` never contains a credential. */
export declare class DeepSeekAuthError extends HarnessError {
    readonly code: DeepSeekAuthErrorCode;
    /**
     * @param message - what failed and what to change.
     * @param code - the failure class.
     * @param options - the underlying failure.
     */
    constructor(message: string, code: DeepSeekAuthErrorCode, options?: ErrorOptions);
}
/** `ctx.deepseekAuth`: the two DeepSeek credential kinds behind one request-authorization operation. */
export declare class DeepSeekAuth extends Service {
    private readonly connections;
    /** @param ctx - Host context; the credentials service and the account service are read when mounted. */
    constructor(ctx: Context);
    /**
     * Connect the deployment a model route plugin's settings name for one kind. Call it from within `ctx.effect()`.
     * @param kind - the kind the plugin's route bills.
     * @param route - provider route the plugin registers; {@link routeKind} answers `kind` for it while connected.
     * @param connection - reads the plugin's current settings; a throw marks the kind unresolved for that operation.
     * @returns the disposer removing the connection.
     * @throws {DeepSeekAuthError} code `DUPLICATE_CONNECTION` when the kind is already connected.
     */
    connect(kind: DeepSeekAuthKind, route: string, connection: () => DeepSeekAuthConnection): () => void;
    /**
     * The kind that bills a conversation on one model route.
     * @param route - provider route of a model request; undefined names none.
     * @returns the kind connected under that route, or undefined for a route no plugin connected.
     */
    routeKind(route: string | undefined): DeepSeekAuthKind | undefined;
    /**
     * The kinds one request can authenticate with, in the order its billing tries them, each bound to its destination.
     * Nothing is read from a credential store.
     * @param request - the request.
     * @returns candidates and unresolved kinds, first preferred; empty when the destination accepts no kind the
     *   billing allows or no allowed kind serves an absolute destination.
     */
    candidates(request: DeepSeekAuthRequest): (DeepSeekAuthCandidate | DeepSeekAuthUnresolved)[];
    /**
     * Release the credential of the first candidate that has one. A later candidate is not read once an earlier one
     * has a credential, fails to read, or does not resolve.
     * @param request - the request.
     * @param signal - cancellation for the lookups.
     * @returns the authorization, or undefined when no candidate has a credential.
     * @throws {DeepSeekAuthError} code `UNRESOLVED_CONNECTION` at an unresolved kind, `INVALID_CREDENTIAL` for an
     *   unusable API key; store failures propagate.
     */
    authorize(request: DeepSeekAuthRequest, signal?: AbortSignal): Promise<DeepSeekAuthorization | undefined>;
    /** The kinds the billing tries, in order, before the destination's accepted kinds narrow them. */
    private order;
    /** Bind one kind to the request's destination; empty when the kind does not serve an absolute destination. */
    private candidate;
    /** The connection of a kind no model route plugin connected. */
    private unconnected;
    /** The API key read under the connection's reference, sent in the headers the request names. */
    private apiKey;
    /** The account sign-in the account service releases for the endpoint; absent without that service. */
    private account;
}
export default DeepSeekAuth;
//# sourceMappingURL=index.d.ts.map