/** Web dictionaries for the chrome around a mod's band; the mods' own content is theirs. */
/** Locale namespace owned by the mods band. */
export declare const NS = "claude-code-mods";
/** Simplified Chinese dictionary and key source. */
export declare const zh: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** Mods band locale key union. */
export type ModsBandKey = keyof typeof zh;
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** Japanese copy, checked against the English keys. */
export declare const ja: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** Spanish dictionary, checked against the English keys. */
export declare const es: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** French dictionary, checked against the English keys. */
export declare const fr: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** German dictionary, checked against the English keys. */
export declare const de: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** Russian dictionary, checked against the English keys. */
export declare const ru: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** Portuguese dictionary, checked against the English keys. */
export declare const pt: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
//# sourceMappingURL=locales.d.ts.map