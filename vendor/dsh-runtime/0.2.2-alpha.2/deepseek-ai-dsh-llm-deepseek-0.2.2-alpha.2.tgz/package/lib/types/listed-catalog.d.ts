import type { LlmModelBadge } from '@deepseek-ai/dsh-llm';
import type { ListingEntry } from './listing.ts';
import type { DeepSeekCatalogModel } from './types.ts';
/** Field overrides for one model; unset fields and empty lists inherit the underlying entry. */
export type ModelOverride = Omit<DeepSeekCatalogModel, 'id'>;
/** Why this build refuses one listed model before network I/O. */
export type CatalogRefusal = {
    readonly kind: 'upgrade-required';
    readonly requiredVersion: string;
} | {
    readonly kind: 'unsupported';
};
/** Inputs of one catalog resolution. */
export interface ListedCatalogInput {
    /** Entries of the last successful listing, or `undefined` before one succeeds. */
    readonly listing: readonly ListingEntry[] | undefined;
    /** Validated models this build supports, carrying its client-side knowledge. */
    readonly supported: readonly DeepSeekCatalogModel[];
    /** Overrides by model id, holding only the fields each one declares. */
    readonly overrides: Readonly<Record<string, ModelOverride>>;
    /** Route output cap that a listed output capability bounds. */
    readonly routeMaxTokens: number;
    /** This build's semantic version. */
    readonly clientVersion: string;
}
/** One resolved listed catalog. */
export interface ListedCatalog {
    /** Selectable models in listing order, or this build's models when no listing succeeded. */
    readonly offered: readonly DeepSeekCatalogModel[];
    /** Entries request resolution consults: offered models, then supported models the listing does not offer. */
    readonly resolution: readonly DeepSeekCatalogModel[];
    /** Listed models refused before network I/O, by id. */
    readonly refusals: ReadonlyMap<string, CatalogRefusal>;
    /** Listed badges of offered models, by id. */
    readonly badges: ReadonlyMap<string, LlmModelBadge>;
    /** Listing entries hidden because their declarations are unreadable or unusable, and offered models whose badge is dropped. */
    readonly problems: readonly string[];
    /** Configuration diagnostics for `modelOverrides`. */
    readonly overrideErrors: readonly string[];
}
/**
 * Resolve a route's catalog from its listing. A declared minimum client version decides a
 * listed model's availability; without one, only models this build supports
 * are offered and the other listed models stay hidden.
 * @param input - listing, supported models, overrides, route cap, and this build's version.
 * @returns offered models, request-resolution entries, refusals, and diagnostics.
 */
export declare function resolveListedCatalog(input: ListedCatalogInput): ListedCatalog;
/**
 * Refuse a listed model this build cannot serve, before any network I/O.
 * @param model - requested wire model id.
 * @param refusal - the catalog's refusal for `model`, or `undefined` when it is admitted.
 * @throws LlmError `CLIENT_UPGRADE_REQUIRED` naming the required and current versions, or `MODEL_UNSUPPORTED`.
 */
export declare function refuseListedModel(model: string, refusal: CatalogRefusal | undefined): void;
//# sourceMappingURL=listed-catalog.d.ts.map