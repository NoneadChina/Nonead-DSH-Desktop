/** Read-only Git inspection of a Session's current directory in the Session's execution world. */
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import type { GitRemote } from './parse.ts';
import type { ForgeBranches, ForgeCheckout } from './types.ts';
/** Resolved Git executable and process limits. */
export interface GitConfig {
    /** Git executable name or absolute path. */
    readonly gitCommand: string;
    /** Deadline in milliseconds for one command, including executable lookup and confinement. */
    readonly gitTimeoutMs: number;
    /** Termination grace period in milliseconds for each process. */
    readonly graceMs: number;
    /** Maximum captured bytes per output stream. */
    readonly maxOutputBytes: number;
}
/** Checkout facts with the upstream and remotes used to recognize the code host. */
export interface Inspection {
    /** Facts the panel shows. */
    readonly checkout: ForgeCheckout;
    /** Canonical Git directory shared by every checkout of the repository. */
    readonly commonDir: string;
    /** Upstream branch such as `origin/main`, or null when none is configured or HEAD is detached. */
    readonly upstream: string | null;
    /** Remotes in listed order. */
    readonly remotes: readonly GitRemote[];
}
/** Complete output of one Git command that exited with an allowed code. */
export interface GitOutput {
    readonly stdout: string;
    readonly stderr: string;
    readonly exitCode: number;
}
/** Runs one Git subcommand in a fixed directory; output with an exit code outside `allowedExitCodes` throws. */
export type Git = (name: string, args: readonly string[], allowedExitCodes?: readonly number[]) => Promise<GitOutput>;
/** Thrown when a Git command prints more than `maxOutputBytes` on standard output. */
export declare class GitOutputTooLarge extends Error {
    name: string;
}
/**
 * Inspect the checkout containing `directory`. Every command runs through the
 * mounted subprocess provider under a read-only confinement of the Session's
 * sandbox policy and reads refs and configuration only, never the working
 * tree. The top-level and shared Git directories Git prints are resolved
 * through `ctx.fs` into canonical process paths, the form the
 * working-directory service records.
 * @param ctx - context that provides `fs`, `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - executable and process limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param directory - absolute directory to inspect.
 * @param signal - cancellation of every command.
 * @returns the checkout facts, shared Git directory, upstream, and remotes, or undefined when `directory` is not inside a checkout.
 * @throws when Git cannot run, fails, times out, or prints more than `maxOutputBytes`.
 */
export declare function inspectCheckout(ctx: Context, config: GitConfig, session: Session, directory: string, signal: AbortSignal): Promise<Inspection | undefined>;
/**
 * List the local branches that can start a worktree of the checkout containing
 * `directory`, under the same confinement as {@link inspectCheckout}.
 * @param ctx - context that provides `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - executable and process limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param directory - absolute directory inside the checkout.
 * @param limit - most branch names to return.
 * @param signal - cancellation of every command.
 * @returns the checked-out branch and local branches, the checked-out one first and then most recently committed first.
 * @throws when `directory` is not inside a checkout, or Git cannot run, fails, times out, or prints more than `maxOutputBytes`.
 */
export declare function listBranches(ctx: Context, config: GitConfig, session: Session, directory: string, limit: number, signal: AbortSignal): Promise<ForgeBranches>;
/**
 * Report whether a local branch exists, under the same confinement as {@link inspectCheckout}.
 * @param ctx - context that provides `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - executable and process limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param repositoryRoot - absolute root of a checkout of the repository.
 * @param branch - local branch name.
 * @param signal - cancellation of the command.
 * @returns whether `refs/heads/<branch>` exists.
 * @throws when Git cannot run, fails, times out, or prints more than `maxOutputBytes`.
 */
export declare function hasBranch(ctx: Context, config: GitConfig, session: Session, repositoryRoot: string, branch: string, signal: AbortSignal): Promise<boolean>;
/**
 * Bind the confined Git runner to one Session and directory: every command
 * runs under a read-only confinement of the Session's sandbox policy with the
 * scrubbed environment, the fixed command prefix, and `config`'s limits.
 * @param ctx - context that provides `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - executable and process limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param directory - working directory of every command.
 * @param signal - cancellation of every command.
 * @returns the runner.
 */
export declare function gitIn(ctx: Context, config: GitConfig, session: Session, directory: string, signal: AbortSignal): Git;
//# sourceMappingURL=git.d.ts.map