/** Experimental custom plugin index composition; runtime rows live in cordis.patch.yml. */
export {};
//# sourceMappingURL=index.d.ts.map