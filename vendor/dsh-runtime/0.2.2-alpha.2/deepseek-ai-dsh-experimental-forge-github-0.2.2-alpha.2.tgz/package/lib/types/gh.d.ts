/** Runs the GitHub CLI on the host with a scrubbed, non-interactive environment. */
/** Complete output of one `gh` invocation that ran to an exit code. */
export interface GhOutput {
    /** Process exit code. */
    readonly exitCode: number;
    /** Standard output without its final newline. */
    readonly stdout: string;
    /** Standard error without its final newline. */
    readonly stderr: string;
}
/** Runs `gh` with literal arguments; rejects when the process cannot run to an exit code. */
export type GhRunner = (args: readonly string[], signal: AbortSignal) => Promise<GhOutput>;
/** Resolved executable and limits for `gh`. */
export interface GhConfig {
    /** Executable name or absolute host path. */
    readonly ghCommand: string;
    /** Deadline in milliseconds for one invocation. */
    readonly timeoutMs: number;
    /** Maximum captured bytes per output stream. */
    readonly maxOutputBytes: number;
}
/** Thrown when the `gh` executable cannot start, for example because it is not installed. */
export declare class GhUnavailableError extends Error {
    name: string;
}
/** Thrown when one invocation outlives `timeoutMs`; the process is killed. */
export declare class GhTimeoutError extends Error {
    name: string;
}
/** Thrown when an output stream exceeds `maxOutputBytes`; the process is killed. */
export declare class GhOutputLimitError extends Error {
    name: string;
}
/**
 * Build a runner for `gh` on the host. The child inherits the scrubbed parent
 * environment, so variables whose names contain KEY, PASSWORD, SECRET, or
 * TOKEN never reach it and `gh` authenticates from its own credential store.
 * Prompts, update notices, pagers, and colors are disabled.
 * @param config - executable and limits.
 * @returns the runner.
 */
export declare function ghRunner(config: GhConfig): GhRunner;
//# sourceMappingURL=gh.d.ts.map