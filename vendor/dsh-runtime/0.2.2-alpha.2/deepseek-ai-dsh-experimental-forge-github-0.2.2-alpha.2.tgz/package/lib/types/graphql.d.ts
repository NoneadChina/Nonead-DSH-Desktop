/** GitHub GraphQL documents and their mapping into provider-neutral results. */
import type { ChangeRequestKey, ChangeRequestRef, ChangeRequestSnapshot, ForgeFailure, ForgeRepository } from '@deepseek-ai/dsh-experimental-forge';
/** Head-branch lookup; variables `owner`, `name`, and `branch` are passed as strings. */
export declare const HEAD_QUERY = "query($owner: String!, $name: String!, $branch: String!) {\n  repository(owner: $owner, name: $name) {\n    defaultBranchRef { name }\n    pullRequests(headRefName: $branch, states: OPEN, first: 20, orderBy: { field: CREATED_AT, direction: DESC }) { nodes { number isCrossRepository } }\n  }\n}";
/**
 * Distinguish GraphQL response fields from HTTP error bodies.
 * @param body - parsed JSON returned by GitHub.
 * @returns whether the object carries GraphQL data or errors; field validation remains with the query mapper.
 */
export declare function hasGraphqlFields(body: unknown): boolean;
/** One batched snapshot query and the change request behind each alias. */
export interface SnapshotQuery {
    /** GraphQL document with one aliased field per change request. */
    readonly document: string;
    /** Change requests keyed by alias path `r<i>.p<j>`. */
    readonly targets: ReadonlyMap<string, ChangeRequestRef>;
}
/**
 * Build one query that reads every change request in `refs`, grouping them by
 * repository. Owners, names, and numbers are validated before they are inlined.
 * @param refs - change requests on one host.
 * @returns the document and its alias targets.
 * @throws when an owner, name, or number cannot be inlined safely.
 */
export declare function snapshotQuery(refs: readonly ChangeRequestRef[]): SnapshotQuery;
/**
 * Map a snapshot response, including GitHub's partial-error form, into one
 * result per alias target. Path-scoped errors apply to their repository or
 * pull request; errors without a path apply to every unresolved target. A
 * repository without readable merge settings offers no merge.
 * @param body - parsed JSON printed by `gh api graphql`.
 * @param query - the query that produced the response.
 * @returns a snapshot or failure for every target.
 */
export declare function mapSnapshotResponse(body: unknown, query: SnapshotQuery): Map<ChangeRequestKey, ChangeRequestSnapshot | ForgeFailure>;
/**
 * Map a head-branch lookup of {@link HEAD_QUERY}, which selects open pull requests, into change requests.
 * @param body - parsed JSON printed by `gh api graphql`.
 * @param repository - repository that was queried.
 * @param branch - head branch that was queried.
 * @returns open non-fork change requests for `branch`, or none when it is the default branch.
 * @throws when the response is malformed or the repository is not visible.
 */
export declare function mapHeadResponse(body: unknown, repository: ForgeRepository, branch: string): ChangeRequestRef[];
//# sourceMappingURL=graphql.d.ts.map