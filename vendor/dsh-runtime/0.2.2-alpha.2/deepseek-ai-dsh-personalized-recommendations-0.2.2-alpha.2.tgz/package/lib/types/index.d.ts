/** Personalized recommendations composition; runtime rows live in cordis.patch.yml. */
export {};
//# sourceMappingURL=index.d.ts.map