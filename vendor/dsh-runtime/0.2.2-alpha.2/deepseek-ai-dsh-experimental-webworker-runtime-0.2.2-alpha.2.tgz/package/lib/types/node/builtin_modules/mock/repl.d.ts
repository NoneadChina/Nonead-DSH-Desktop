/** REPL construction is unavailable in the browser worker. */
export declare const start: typeof import('node:repl').start;
/** CommonJS interop marker consumed by the Worker module loader. */
export declare const __esModule = true;
/** CommonJS export for the REPL member used by the Node PTC evaluator. */
declare const _default: {
    start: typeof import("repl").start;
};
export default _default;
//# sourceMappingURL=repl.d.ts.map