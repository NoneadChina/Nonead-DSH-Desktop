import type { SessionEventLike } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SessionEvent } from '@deepseek-ai/dsh-session/types';
import type { ConversationGroupData, ConversationGroupedView, ConversationGroupInput } from './groups.ts';
/** Definition-local identity; start permits initialization when no earlier start is present. */
export interface ConversationMatchResult {
    readonly id: string;
    readonly role: 'start' | 'update';
}
/** Merge-extensible business values published against one Turn. */
export interface ConversationTurnDataMap {
}
/** Merge-extensible business values published against one Step. */
export interface ConversationStepDataMap {
}
/** Observable value for one independently owned Location-data key. */
export interface ConversationLocationDataSource<Value> {
    /** @returns the current value. */
    readonly getSnapshot: () => Value;
    /** @param listener - callback for value changes. @returns the unsubscribe function. */
    readonly subscribe: (listener: () => void) => () => void;
}
/** Stable keyed reader for independently owned Location business values. */
export interface ConversationLocationDataStore<DataMap extends object> {
    /**
     * Read one business value without exposing another owner's mutable State.
     * @param key - declaration-merged business key.
     * @returns latest immutable value, when its owning Context has published one.
     */
    get<Key extends keyof DataMap & string>(key: Key): Readonly<DataMap[Key]> | undefined;
    /**
     * Observe one business value without subscribing to unrelated Location keys.
     * @param key - declaration-merged business key.
     * @returns identity-stable source for the current value.
     */
    source<Key extends keyof DataMap & string>(key: Key): ConversationLocationDataSource<Readonly<DataMap[Key]> | undefined>;
}
interface ConversationLocationDataValue {
    readonly kind: 'turn' | 'step';
    readonly turn: number;
    readonly step?: number;
    readonly key: string;
    readonly value: unknown;
}
type RegisteredTurnData<DataMap extends object> = {
    [Key in Extract<keyof DataMap, string>]: {
        readonly kind: 'turn';
        readonly turn: number;
        readonly key: Key;
        readonly value: DataMap[Key];
    };
}[Extract<keyof DataMap, string>];
type RegisteredStepData<DataMap extends object> = {
    [Key in Extract<keyof DataMap, string>]: {
        readonly kind: 'step';
        readonly turn: number;
        readonly step: number;
        readonly key: Key;
        readonly value: DataMap[Key];
    };
}[Extract<keyof DataMap, string>];
type ConversationLocationDataOf<TurnData extends object, StepData extends object> = [
    keyof TurnData | keyof StepData
] extends [never] ? ConversationLocationDataValue : RegisteredTurnData<TurnData> | RegisteredStepData<StepData>;
/** One Definition-owned value attached to an Engine-owned Turn or Step. */
export type ConversationLocationData = ConversationLocationDataOf<ConversationTurnDataMap, ConversationStepDataMap>;
/** Immutable resolved boundary for one Agent step. */
export interface StepLocation {
    readonly turn: number;
    readonly step: number;
    readonly start: SessionEvent<'step/start'> | undefined;
    readonly end: SessionEvent<'step/end'> | undefined;
    readonly status: 'open' | 'closed' | 'unknown';
    /** Stable reader for Step-scoped business values. */
    readonly data: ConversationLocationDataStore<ConversationStepDataMap>;
}
/** Immutable resolved boundary for one Agent turn. */
export interface TurnLocation {
    readonly turn: number;
    readonly start: SessionEvent<'turn/start'> | undefined;
    readonly end: SessionEvent<'turn/end'> | undefined;
    readonly status: 'open' | 'closed' | 'unknown';
    readonly steps: readonly StepLocation[];
    /** Stable reader for Turn-scoped business values. */
    readonly data: ConversationLocationDataStore<ConversationTurnDataMap>;
}
/** Engine-owned placement of one matched event in the Session hierarchy. */
export type ConversationLocation = {
    readonly kind: 'session';
} | {
    readonly kind: 'turn';
    readonly turn: TurnLocation;
} | {
    readonly kind: 'step';
    readonly turn: TurnLocation;
    readonly step: StepLocation;
} | {
    readonly kind: 'unresolved';
};
interface ConversationMatchOf<Event extends SessionEventLike, Role extends ConversationMatchResult['role']> {
    readonly event: Event;
    readonly role: Role;
    readonly location: ConversationLocation;
}
/** A durable or transient event that can initialize its Context. */
export type ConversationStartMatch = ConversationMatchOf<SessionEventLike, 'start'>;
/** One event accepted by a Definition, with its lifecycle role and resolved Location. */
export type ConversationMatch = ConversationStartMatch | ConversationMatchOf<SessionEventLike, 'update'>;
/** Target-neutral identity returned by a business Definition. */
export interface ConversationViewNode {
    readonly key: string;
    readonly kind: string;
    readonly id: string;
    readonly target: string;
    readonly data: unknown;
}
/** Merge-extensible immutable snapshots published by registered view targets. */
export interface ConversationViewSnapshotMap {
}
/** Stable reader over the latest snapshot of every registered view target. */
export interface ConversationViewSnapshotStore {
    /** @param target - registered view target. @returns its current snapshot. */
    get<Target extends Extract<keyof ConversationViewSnapshotMap, string>>(target: Target): ConversationViewSnapshotMap[Target] | undefined;
    /**
     * Read grouping for an activated target without activating another target.
     * @param target - registered View target.
     * @returns its grouped reader, when a Group Definition is active.
     */
    grouped<Target extends string>(target: Target): ConversationGroupedView<ConversationGroupData<Target>> | undefined;
}
/** Immutable public view of an assembled business Context. */
export interface ConversationNodeContext<State = unknown> {
    readonly key: string;
    readonly kind: string;
    readonly id: string;
    readonly matches: readonly ConversationMatch[];
    readonly start: ConversationStartMatch | undefined;
    readonly state: State | undefined;
    readonly current: ReadonlyMap<string, ConversationViewNode | null>;
}
/** Read-only predecessor returned to a Definition's start function. */
export interface ConversationPreviousContext<State = unknown> {
    readonly key: string;
    readonly kind: string;
    readonly id: string;
    readonly startSeq: number;
    readonly state: Readonly<State>;
    readonly matches: readonly ConversationMatch[];
}
/** Strictly-backward Context lookup available while a start is evaluated. */
export interface ConversationContextReader {
    /**
     * Find the active Context of `kind` with the greatest start seq below the
     * current start event.
     * @param kind - Definition kind to query.
     * @returns the nearest predecessor, or undefined when absent in the current window.
     */
    previous<State>(kind: string): ConversationPreviousContext<State> | undefined;
}
/** Requested cadence; `animation-frame` materializes after three browser animation frames. */
export type ConversationPublication = 'none' | 'animation-frame' | 'immediate';
/** Engine-owned Location data publication phase. */
export type ConversationLocationDataScope = 'step' | 'turn';
/** One independently registered business Event-to-Node state machine. */
export interface ConversationNodeDefinition<State = unknown> {
    readonly kind: string;
    /** Sole view target owned by this Definition; omitted for state-only Contexts. */
    readonly target?: string;
    /**
     * Extract this Definition's stable business identity from one event.
     * @param event - standard or compact Client history event; no Context or history access is available.
     * @returns identity and lifecycle role, or null when unrelated.
     */
    match(event: SessionEventLike): ConversationMatchResult | null;
    /**
     * Create State from the earliest currently loaded start Match.
     * @param context - complete evidence currently collected for the Context.
     * @param match - the start Match.
     * @param reader - strictly-backward read-only Context lookup.
     * @returns the State adopted by the engine.
     */
    start(context: ConversationNodeContext<State>, match: ConversationStartMatch, reader: ConversationContextReader): State;
    /**
     * Apply a later Match, including another event marked start.
     * @param context - Context with its current State.
     * @param match - subsequent Match in ascending event order.
     * @returns the State adopted by the engine.
     */
    update(context: ConversationNodeContext<State> & {
        readonly state: State;
    }, match: ConversationMatch): State;
    /**
     * Select publication cadence for one accepted Match.
     * @param match - accepted Match.
     * @returns requested cadence; omission defaults to immediate.
     */
    publication?(match: ConversationMatch): ConversationPublication;
    /**
     * Publish this Definition's read-only business value for one Location phase.
     * The Engine evaluates every Definition first for Step and then for Turn,
     * owns replacement/removal, and rejects another Context trying to publish
     * the same Location key.
     * @param context - latest complete Context.
     * @param scope - Location hierarchy level currently being materialized.
     * @param previous - value from the preceding materialization; return it when unchanged.
     * @returns current Location value, preserving value identity while unchanged,
     * or null while unavailable.
     */
    buildLocationData?(context: ConversationNodeContext<State>, scope: ConversationLocationDataScope, previous: ConversationLocationData | null): ConversationLocationData | null;
    /**
     * Materialize one final Node for this Definition's declared view target.
     * @param context - latest complete Context.
     * @returns final Node, or null when this Context is not currently visible.
     */
    buildViewNode?(context: ConversationNodeContext<State>): ConversationViewNode | null;
}
/** Reference-stable Turn/Step facts published beside view Nodes. */
export interface ConversationTimelineSnapshot {
    readonly turnOrder: readonly number[];
    readonly turns: ReadonlyMap<number, TurnLocation>;
}
/** Per-Session incremental builder for one view target. */
export interface ConversationViewBuilder<Node extends ConversationViewNode = ConversationViewNode, Snapshot = unknown> {
    readonly empty: Snapshot;
    /**
     * Replace the low-frequency complete materialized Node set.
     * @param input - complete Nodes and current timeline.
     * @returns next view snapshot.
     */
    replace(input: {
        readonly nodes: readonly Node[];
        readonly timeline: ConversationTimelineSnapshot;
        readonly changedTurns?: readonly number[];
    }): Snapshot;
    /**
     * Apply only Nodes whose materialized values changed in this transaction.
     * @param input - changed Nodes and current timeline.
     * @returns next view snapshot.
     */
    apply(input: {
        readonly upserts: readonly Node[];
        readonly timeline: ConversationTimelineSnapshot;
        readonly changedTurns?: readonly number[];
    }): Snapshot;
    /** @returns the latest target-processed Node inputs; required only for a grouped target. */
    groupInput?(): ConversationGroupInput<Node>;
    /** Publish local sources after all target snapshots and grouping results have been installed. */
    publish?(): void;
}
/** Registry contribution that creates an isolated builder when a Session first uses this target. */
export interface ConversationViewDefinition<Node extends ConversationViewNode = ConversationViewNode, Snapshot = unknown> {
    readonly target: string;
    /**
     * Address a tool call in this target's inspector; absent for non-inspection views.
     * @param callId - tool-call identity from the Session.
     * @returns the target's opaque focus identity.
     */
    toolCallFocus?(callId: string): string;
    /** @returns a new Session-owned incremental builder. */
    create(): ConversationViewBuilder<Node, Snapshot>;
    /**
     * Decide whether this target contributes visible Conversation activity.
     * @param snapshot - latest target-owned snapshot.
     * @returns whether the shell should treat this target as active.
     */
    isActive?(snapshot: Snapshot): boolean;
}
/**
 * Build a stable collision-free key for one Definition-local business identity.
 * @param kind - Definition kind.
 * @param id - Definition-local business identity.
 * @returns engine-owned Context key.
 */
export declare function conversationContextKey(kind: string, id: string): string;
export {};
//# sourceMappingURL=conversation.d.ts.map