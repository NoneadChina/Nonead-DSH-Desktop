/** Registers the sidebar shell and global panel navigation. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type SidebarKey } from './locales.ts';
export type { SidebarBrandMarkOwnerProps, SidebarBrandNameOwnerProps, SidebarFooterActionOwnerProps, SidebarPanelIconOwnerProps, SidebarPanelMetadata, SidebarRootComponentProps, SidebarRootInjected, SidebarSectionOwnerProps, SidebarSettingsOwnerProps, } from './contract/slots.ts';
export type { SidebarKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Sidebar controls and global panel copy. */
        sidebar: SidebarKey;
    }
}
/** Services required by the sidebar plugin. */
export declare const inject: string[];
/** Registers the sidebar shell and its service callbacks.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map