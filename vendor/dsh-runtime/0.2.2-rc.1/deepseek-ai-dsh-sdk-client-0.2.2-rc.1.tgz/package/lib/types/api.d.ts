/**
 * High-level run API over {@link HarnessClient}: route text to prompts or native
 * commands and collect prompt activity for text and image input.
 *
 * @module @deepseek-ai/dsh-sdk-client/api
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import { HarnessClient } from './client.ts';
import type { RuntimeProcessOptions } from './launch.ts';
import type { DeepSeekHarnessOptions, HarnessNotification, RunResult, SdkPromptContentBlock } from './types.ts';
/**
 * Reusable SDK for running DeepSeek Harness agent turns in a runtime
 * subprocess. The subprocess starts lazily on first use and stays owned by
 * this instance until {@link close}; always close (or `await using`) so the
 * child is reaped.
 */
export declare class DeepSeekHarness implements AsyncDisposable {
    private clientInstance;
    private readonly createClient;
    private readonly cwd;
    private readonly provider;
    private readonly model;
    private readonly reasoningEffort;
    private readonly maxTokens;
    private readonly approvalRequests;
    private initialized;
    private closed;
    /** @param options - dsh launch configuration plus the session route, effort, and output cap. */
    constructor(options?: DeepSeekHarnessOptions);
    /**
     * The underlying JSON-RPC client (exposed for low-level access). A failed
     * handshake swaps in a fresh instance only after cleanup proves the runtime
     * exited; cleanup failure retains this client, so do not cache it across a
     * failed {@link start}.
     * @returns the client currently owning the runtime subprocess.
     */
    get client(): HarnessClient;
    /**
     * Start the subprocess and perform the `initialize` handshake once. On
     * failure, successful SDK-owned cleanup reaps the runtime and installs a
     * fresh client (`HarnessClient.close` is permanent), so a later call retries
     * with a new subprocess unless {@link close} already ended this harness. If
     * cleanup also fails, rejects with an `AggregateError` whose ordered errors
     * preserve both causes and retains the failed client rather than spawning
     * alongside a process whose exit was not proved.
     * @returns settlement of the (memoized) handshake.
     */
    start(): Promise<void>;
    /**
     * Open a session handle (no wire traffic; the runtime creates the session
     * on its first prompt or working-directory operation).
     * @param sessionId - explicit id to reuse; omitted mints a fresh one.
     * @returns the session handle.
     */
    session(sessionId?: string): HarnessSession;
    /**
     * Start the runtime and restore a persisted session without sending input.
     * The configured Harness home must contain its history; missing or occupied sessions reject.
     * @param sessionId - exact persisted identity to continue.
     * @returns a handle ready to run new prompts on the restored history.
     */
    resumeSession(sessionId: string): Promise<HarnessSession>;
    /**
     * Run text or content blocks on a fresh or named Session through native input routing.
     * @param input - prompt or command text, optionally accompanied by image content blocks.
     * @param options - optional Session identity and notification observer.
     * @returns the completed input's RunResult, including its Session id.
     */
    run(input: string | SdkPromptContentBlock[], options?: RunOptions): Promise<RunResult>;
    /**
     * Shut down and reap the runtime subprocess. Idempotent and terminal —
     * a closed harness no longer retries a failed handshake.
     * @returns settlement of the complete teardown.
     */
    close(): Promise<void>;
    /**
     * `await using` support: {@link close}.
     * @returns settlement of the teardown.
     */
    [Symbol.asyncDispose](): Promise<void>;
}
/** Construct the high-level API against a generic process for package-local fake-runtime tests. */
export declare function createProcessDeepSeekHarness(runtime: RuntimeProcessOptions, options?: DeepSeekHarnessOptions): DeepSeekHarness;
/** Per-run Session identity and notification observer. */
export interface RunOptions {
    /** Session id to run on; omitted mints a fresh session per call. */
    sessionId?: string;
    /**
     * Observe the input's Session-tree activity in wire order until completion.
     * The interval can include overlapping work from other inputs.
     */
    onNotification?: (notification: HarnessNotification) => void;
}
/**
 * One SDK session: a stable id plus owned activity intervals.
 */
export declare class HarnessSession {
    readonly harness: DeepSeekHarness;
    readonly id: string;
    /**
     * @param harness - the owning harness (supplies the client and handshake).
     * @param id - the wire session id this handle runs on.
     */
    constructor(harness: DeepSeekHarness, id: string);
    /**
     * Read the effective directory and recover a missing directory to the Session origin.
     * @returns the absolute directory used by new independent operations.
     */
    getWorkingDirectory(): Promise<string>;
    /**
     * Change the effective directory without moving existing processes or changing permissions.
     * @param path - absolute or Session-current-directory-relative directory.
     * @returns the validated absolute directory.
     */
    setWorkingDirectory(path: string): Promise<string>;
    /**
     * Run text or content blocks through native prompt-or-command routing.
     * @param input - prompt or command text, optionally accompanied by image content blocks; image-only input is an ordinary prompt.
     * @param options - a per-notification observer.
     * @returns RunResult after prompt activity, a state-only command, or command-started model work ends.
     * Goal creation and resume include automatic rounds through goal termination and the closing reply.
     * Native handler refusals return finishReason="error".
     * @throws on routing, protocol, transport or observer failure; runtime work is not rolled back.
     */
    run(input: string | SdkPromptContentBlock[], options?: Pick<RunOptions, 'onNotification'>): Promise<RunResult>;
}
/**
 * Validate the event envelope and assistant/turn fields consumed by SDK readers.
 * @param value - the raw `session.event` event payload.
 * @returns the event, or throws a protocol error for malformed consumed fields.
 */
export declare function validatedSessionEvent(value: unknown): SessionEvent;
/**
 * Extract the concatenated text of the last assistant message.
 * @param events - the activity interval's `session.event` payloads in wire order.
 * @returns the final response text, or `''` when no assistant message exists.
 */
export declare function finalResponse(events: SessionEvent[]): string;
//# sourceMappingURL=api.d.ts.map