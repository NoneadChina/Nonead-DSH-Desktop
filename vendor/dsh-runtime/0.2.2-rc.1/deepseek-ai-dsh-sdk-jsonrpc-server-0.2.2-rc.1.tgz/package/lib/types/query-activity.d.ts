/** Observe command-admitted activity through quiescence and preserve a goal's first terminal outcome. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { CommandExecution, JsonRpcTransportPeer } from '@deepseek-ai/dsh-sdk-protocol';
/** One command's SDK completion observer; its listeners end at completion, rejection, or shutdown. */
export declare class QueryActivity {
    private readonly agent;
    private readonly transport;
    private readonly onClose;
    private readonly disposers;
    private commandId;
    private result;
    private closed;
    private input;
    private inputIdle;
    private goalId;
    private goalOutcome;
    private goalStopped;
    private response;
    private turnReason;
    /**
     * Subscribe before the native command starts so fast input and completion cannot be lost.
     * @param ctx - server-owned context; goal services remain optional for other commands.
     * @param agent - exact receiving Agent.
     * @param transport - SDK notification stream.
     * @param ownsInvocation - whether the current async operation is this native invocation.
     * @param signal - server lifetime; abort releases observation without cancelling unrelated work.
     * @param onClose - remove this closed observer from its owner's registry.
     */
    constructor(ctx: Context, agent: Agent, transport: JsonRpcTransportPeer, ownsInvocation: () => boolean, signal: AbortSignal, onClose: (activity: QueryActivity) => void);
    /**
     * Retain native settlement; admitted input waits through replacement work before completing.
     * @param execution - the already-logged native result.
     */
    accept(execution: CommandExecution): void;
    /** Report withdrawal of the optional provider needed by an active goal query. */
    goalUnavailable(): void;
    /** Release all listeners when the request fails or the server shuts down. */
    close(): void;
    private check;
    private finish;
}
//# sourceMappingURL=query-activity.d.ts.map