/** SDK content-block validation and extraction for native command routing. */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { SdkEncodedImageBlock, SdkPromptContentBlock } from '@deepseek-ai/dsh-sdk-protocol';
/**
 * Validate fields used by input routing before creating a Session.
 * @param value - untrusted contentBlocks from a JSON-RPC query.
 * @returns ordered input blocks; ordinary prompt admission owns non-routing content.
 * @throws on an empty input or malformed text or encoded image fields.
 */
export declare function queryContent(value: unknown): SdkPromptContentBlock[];
/**
 * Select command images without joining text blocks or dropping other content.
 * @param blocks - validated input containing a recognized command.
 * @param text - the exact first text block used to recognize the command.
 * @returns encoded images in their original order, before any attachment writes.
 * @throws if the command shares its input with another text block or unsupported attachment representation.
 */
export declare function queryCommandImages(blocks: SdkPromptContentBlock[], text: ContentBlock & {
    type: 'text';
}): SdkEncodedImageBlock[];
//# sourceMappingURL=query-content.d.ts.map