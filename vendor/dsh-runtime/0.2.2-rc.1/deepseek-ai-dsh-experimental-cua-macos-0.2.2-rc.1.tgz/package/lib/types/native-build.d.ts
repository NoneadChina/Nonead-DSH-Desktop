import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Architecture names used by the platform-specific native payload. */
export type NativeArchitecture = 'arm64' | 'x64';
/**
 * Validate the host before preparing a platform-specific application.
 * @param platform - Node host platform.
 * @param architecture - Node host architecture.
 * @returns Supported macOS architecture.
 * @throws When the current host has no native implementation.
 */
export declare function nativeHostArchitecture(platform: string, architecture: string): NativeArchitecture;
/** Explicit compiler ownership and resource limits for one preparation. */
export interface NativeBuildSpec {
    packageRoot: string;
    architecture: NativeArchitecture;
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    signal: AbortSignal;
    timeoutMs: number;
    graceMs: number;
}
/**
 * Resolve the immutable application selected by a packaged or source-build receipt.
 * @param directory - Architecture-specific directory containing current.json and application generations.
 * @returns Executable inside the selected application bundle.
 * @throws When the receipt is invalid or the application executable is missing.
 */
export declare function nativeExecutablePath(directory: string): Promise<string>;
/**
 * Recognize the repository-owned package location before allowing local compilation.
 * @param packageRoot - Real directory containing the CUA package manifest.
 * @returns True only for a CUA package in a DSH source checkout.
 */
export declare function isSourcePackage(packageRoot: string): Promise<boolean>;
/**
 * Build and sign an immutable helper application with the selected Apple developer tools.
 * @param spec - Checkout, target, managed process provider and cancellation/deadline limits.
 * @returns Executable inside the prepared application, after complete compiler cleanup.
 * @throws When preparation, cancellation, resource cleanup or receipt validation fails.
 */
export declare function buildNativeExecutable(spec: NativeBuildSpec): Promise<string>;
/**
 * Prepare source builds on activation; installed packages carry their signed application.
 * @param spec - Native preparation inputs for this host.
 * @returns Executable inside a ready application without compiling or re-signing an installed package.
 */
export declare function prepareNativeExecutable(spec: NativeBuildSpec): Promise<string>;
//# sourceMappingURL=native-build.d.ts.map