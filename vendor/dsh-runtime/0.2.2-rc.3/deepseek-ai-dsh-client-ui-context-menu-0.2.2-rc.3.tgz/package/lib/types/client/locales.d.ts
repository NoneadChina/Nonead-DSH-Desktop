/** Context-menu operation feedback, separate from plugin display metadata. */
export declare const dictionaries: {
    zh: {
        back: string;
        failed: string;
    };
    en: {
        back: string;
        failed: string;
    };
    ja: {
        back: string;
        failed: string;
    };
    es: {
        back: string;
        failed: string;
    };
    fr: {
        back: string;
        failed: string;
    };
    de: {
        back: string;
        failed: string;
    };
    ru: {
        back: string;
        failed: string;
    };
    pt: {
        back: string;
        failed: string;
    };
};
//# sourceMappingURL=locales.d.ts.map