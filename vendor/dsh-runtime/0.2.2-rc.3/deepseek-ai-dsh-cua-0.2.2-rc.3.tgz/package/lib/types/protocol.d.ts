import { z } from 'zod';
import type { CuaAppHandle, CuaSnapshotId } from './types.ts';
/** Provider-issued element reference from an accessibility observation. */
export declare const elementId: z.ZodString;
/** Shared hover target variants. Providers may add options without replacing a target or its coordinate mode. */
export declare const MouseMoveTargets: readonly [z.ZodObject<{
    windowId: z.ZodOptional<z.ZodNumber>;
    snapshotId: z.ZodString;
    elementId: z.ZodString;
    appHandle: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    relative: z.ZodOptional<z.ZodLiteral<false>>;
    snapshotId: z.ZodOptional<z.ZodString>;
    x: z.ZodNumber;
    y: z.ZodNumber;
    windowId: z.ZodNumber;
    appHandle: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    relative: z.ZodLiteral<true>;
    x: z.ZodNumber;
    y: z.ZodNumber;
    snapshotId: z.ZodOptional<z.ZodString>;
    windowId: z.ZodNumber;
    appHandle: z.ZodString;
}, z.core.$strict>];
/** Portable model operations, including standard hover without a system-pointer option. */
export declare const Request: z.ZodDiscriminatedUnion<[z.ZodObject<{
    method: z.ZodLiteral<"getCapabilities">;
    params: z.ZodObject<{}, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"listApps">;
    params: z.ZodObject<{}, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"findApps">;
    params: z.ZodObject<{
        query: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"getApp">;
    params: z.ZodObject<{
        selector: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"activate">;
    params: z.ZodObject<{
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"show">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"listWindows">;
    params: z.ZodObject<{
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"getState">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        includeMenus: z.ZodOptional<z.ZodBoolean>;
        details: z.ZodOptional<z.ZodBoolean>;
        maxElements: z.ZodOptional<z.ZodNumber>;
        maxDepth: z.ZodOptional<z.ZodNumber>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"listActions">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"performAction">;
    params: z.ZodObject<{
        action: z.ZodString;
        argument: z.ZodOptional<z.ZodJSONSchema>;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"invoke">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"mouseMove">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        snapshotId: z.ZodOptional<z.ZodString>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        relative: z.ZodLiteral<true>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        snapshotId: z.ZodOptional<z.ZodString>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"click">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        clickCount: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        holdMs: z.ZodOptional<z.ZodNumber>;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        clickCount: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        holdMs: z.ZodOptional<z.ZodNumber>;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        snapshotId: z.ZodOptional<z.ZodString>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        clickCount: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        holdMs: z.ZodOptional<z.ZodNumber>;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        relative: z.ZodLiteral<true>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        snapshotId: z.ZodOptional<z.ZodString>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"setValue">;
    params: z.ZodObject<{
        value: z.ZodJSONSchema;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"selectText">;
    params: z.ZodObject<{
        text: z.ZodString;
        prefix: z.ZodOptional<z.ZodString>;
        suffix: z.ZodOptional<z.ZodString>;
        selectionType: z.ZodOptional<z.ZodEnum<{
            text: "text";
            cursor_before: "cursor_before";
            cursor_after: "cursor_after";
        }>>;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"typeText">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        text: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"paste">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        text: z.ZodString;
        format: z.ZodOptional<z.ZodEnum<{
            text: "text";
            html: "html";
        }>>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"pressKey">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        key: z.ZodString;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodString>>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"sendKeyEvent">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        key: z.ZodString;
        direction: z.ZodEnum<{
            down: "down";
            up: "up";
        }>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"scroll">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        deltaLinesX: z.ZodNumber;
        deltaLinesY: z.ZodNumber;
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        snapshotId: z.ZodOptional<z.ZodString>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        deltaLinesX: z.ZodNumber;
        deltaLinesY: z.ZodNumber;
        relative: z.ZodLiteral<true>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        snapshotId: z.ZodOptional<z.ZodString>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"drag">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        snapshotId: z.ZodOptional<z.ZodString>;
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        fromX: z.ZodNumber;
        fromY: z.ZodNumber;
        toX: z.ZodNumber;
        toY: z.ZodNumber;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        snapshotId: z.ZodOptional<z.ZodString>;
        relative: z.ZodLiteral<true>;
        fromX: z.ZodNumber;
        fromY: z.ZodNumber;
        toX: z.ZodNumber;
        toY: z.ZodNumber;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"screenshot">;
    params: z.ZodObject<{
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>], "method">;
/** Model operations for providers that can move the user's system pointer. */
export declare const SystemPointerRequest: z.ZodDiscriminatedUnion<[z.ZodObject<{
    method: z.ZodLiteral<"getCapabilities">;
    params: z.ZodObject<{}, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"listApps">;
    params: z.ZodObject<{}, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"findApps">;
    params: z.ZodObject<{
        query: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"getApp">;
    params: z.ZodObject<{
        selector: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"activate">;
    params: z.ZodObject<{
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"show">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"listWindows">;
    params: z.ZodObject<{
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"getState">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        includeMenus: z.ZodOptional<z.ZodBoolean>;
        details: z.ZodOptional<z.ZodBoolean>;
        maxElements: z.ZodOptional<z.ZodNumber>;
        maxDepth: z.ZodOptional<z.ZodNumber>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"listActions">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"performAction">;
    params: z.ZodObject<{
        action: z.ZodString;
        argument: z.ZodOptional<z.ZodJSONSchema>;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"invoke">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"mouseMove">;
    params: z.ZodUnion<(z.ZodObject<{
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        snapshotId: z.ZodOptional<z.ZodString>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
        useSystemPointer: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict> | z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
        useSystemPointer: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict> | z.ZodObject<{
        relative: z.ZodLiteral<true>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        snapshotId: z.ZodOptional<z.ZodString>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
        useSystemPointer: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>)[]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"click">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        clickCount: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        holdMs: z.ZodOptional<z.ZodNumber>;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        clickCount: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        holdMs: z.ZodOptional<z.ZodNumber>;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        snapshotId: z.ZodOptional<z.ZodString>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        clickCount: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        holdMs: z.ZodOptional<z.ZodNumber>;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        relative: z.ZodLiteral<true>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        snapshotId: z.ZodOptional<z.ZodString>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"setValue">;
    params: z.ZodObject<{
        value: z.ZodJSONSchema;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"selectText">;
    params: z.ZodObject<{
        text: z.ZodString;
        prefix: z.ZodOptional<z.ZodString>;
        suffix: z.ZodOptional<z.ZodString>;
        selectionType: z.ZodOptional<z.ZodEnum<{
            text: "text";
            cursor_before: "cursor_before";
            cursor_after: "cursor_after";
        }>>;
        windowId: z.ZodOptional<z.ZodNumber>;
        snapshotId: z.ZodString;
        elementId: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"typeText">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        text: z.ZodString;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"paste">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        text: z.ZodString;
        format: z.ZodOptional<z.ZodEnum<{
            text: "text";
            html: "html";
        }>>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"pressKey">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        key: z.ZodString;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodString>>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"sendKeyEvent">;
    params: z.ZodObject<{
        windowId: z.ZodOptional<z.ZodNumber>;
        key: z.ZodString;
        direction: z.ZodEnum<{
            down: "down";
            up: "up";
        }>;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"scroll">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        deltaLinesX: z.ZodNumber;
        deltaLinesY: z.ZodNumber;
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        snapshotId: z.ZodOptional<z.ZodString>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        deltaLinesX: z.ZodNumber;
        deltaLinesY: z.ZodNumber;
        relative: z.ZodLiteral<true>;
        x: z.ZodNumber;
        y: z.ZodNumber;
        snapshotId: z.ZodOptional<z.ZodString>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"drag">;
    params: z.ZodUnion<readonly [z.ZodObject<{
        snapshotId: z.ZodOptional<z.ZodString>;
        relative: z.ZodOptional<z.ZodLiteral<false>>;
        fromX: z.ZodNumber;
        fromY: z.ZodNumber;
        toX: z.ZodNumber;
        toY: z.ZodNumber;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        snapshotId: z.ZodOptional<z.ZodString>;
        relative: z.ZodLiteral<true>;
        fromX: z.ZodNumber;
        fromY: z.ZodNumber;
        toX: z.ZodNumber;
        toY: z.ZodNumber;
        mouseButton: z.ZodOptional<z.ZodEnum<{
            left: "left";
            right: "right";
            middle: "middle";
        }>>;
        modifiers: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            fn: "fn";
            shift: "shift";
            command: "command";
            control: "control";
            option: "option";
        }>>>;
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>]>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"screenshot">;
    params: z.ZodObject<{
        windowId: z.ZodNumber;
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>], "method">;
/** Native resource fields supplied or completed by the Host before dispatch. */
export declare const NativeResourceParameters: {
    getState: z.ZodObject<{
        maxElements: z.ZodNumber;
        maxDepth: z.ZodNumber;
    }, z.core.$strict>;
    drag: z.ZodObject<{
        durationMs: z.ZodNumber;
        steps: z.ZodNumber;
    }, z.core.$strict>;
    paste: z.ZodObject<{
        maxElements: z.ZodNumber;
        maxDepth: z.ZodNumber;
        maxClipboardBytes: z.ZodNumber;
        pasteReadTimeoutMs: z.ZodNumber;
    }, z.core.$strict>;
    findApps: z.ZodObject<{
        maxAppMatches: z.ZodNumber;
    }, z.core.$strict>;
};
/** Host-only launch continuation and user-facing system permission controls; absent from model arguments. */
export declare const NativeOnlyOperations: readonly [z.ZodObject<{
    method: z.ZodLiteral<"launchApp">;
    params: z.ZodObject<{
        appHandle: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"permissionStatus">;
    params: z.ZodObject<{}, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"applicationIcons">;
    params: z.ZodObject<{
        paths: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"requestPermission">;
    params: z.ZodObject<{
        permission: z.ZodEnum<{
            accessibility: "accessibility";
            screenRecording: "screenRecording";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    method: z.ZodLiteral<"openPermissionSettings">;
    params: z.ZodObject<{
        permission: z.ZodEnum<{
            accessibility: "accessibility";
            screenRecording: "screenRecording";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>];
/** Application selection returned only after a successful app selection. */
export declare const AppResult: z.ZodObject<{
    appHandle: z.ZodPipe<z.ZodString, z.ZodTransform<CuaAppHandle, string>>;
    name: z.ZodString;
    bundleId: z.ZodOptional<z.ZodString>;
    running: z.ZodBoolean;
}, z.core.$strip>;
/** Running application records from the helper. */
export declare const AppsResult: z.ZodArray<z.ZodObject<{
    pid: z.ZodNumber;
    name: z.ZodString;
    bundleId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>>;
/** Installed application matches keep running and stopped records distinct. */
export declare const FoundAppsResult: z.ZodArray<z.ZodIntersection<z.ZodObject<{
    id: z.ZodString;
    displayName: z.ZodString;
    path: z.ZodString;
}, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    isRunning: z.ZodLiteral<true>;
    pid: z.ZodNumber;
}, z.core.$strip>, z.ZodObject<{
    isRunning: z.ZodLiteral<false>;
}, z.core.$strip>], "isRunning">>>;
/** Current windows and their global native bounds. */
export declare const WindowsResult: z.ZodArray<z.ZodObject<{
    windowId: z.ZodNumber;
    appName: z.ZodString;
    title: z.ZodString;
    bounds: z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    isOnScreen: z.ZodBoolean;
    onCurrentSpace: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>>;
/** Observed state for the selected application or window. */
export declare const StateResult: z.ZodObject<{
    appHandle: z.ZodPipe<z.ZodString, z.ZodTransform<CuaAppHandle, string>>;
    windowId: z.ZodNullable<z.ZodNumber>;
    focusedWindowId: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    snapshotId: z.ZodPipe<z.ZodString, z.ZodTransform<CuaSnapshotId, string>>;
    tree: z.ZodString;
    windows: z.ZodArray<z.ZodObject<{
        windowId: z.ZodNumber;
        appName: z.ZodString;
        title: z.ZodString;
        bounds: z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
            width: z.ZodNumber;
            height: z.ZodNumber;
        }, z.core.$strip>;
        isOnScreen: z.ZodBoolean;
        onCurrentSpace: z.ZodNullable<z.ZodBoolean>;
    }, z.core.$strip>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>;
/** Provider-defined action names for one element, including attribute-setting operations; an element may advertise none. */
export declare const ActionNamesResult: z.ZodArray<z.ZodString>;
/** Original native PNG and platform window geometry before Host image preparation. */
export declare const NativeScreenshotResult: z.ZodObject<{
    mimeType: z.ZodLiteral<"image/png">;
    data: z.ZodString;
    pixelWidth: z.ZodNumber;
    pixelHeight: z.ZodNumber;
    windowId: z.ZodNumber;
    bounds: z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    coordinateSpace: z.ZodEnum<{
        "window-points": "window-points";
        "window-pixels": "window-pixels";
    }>;
}, z.core.$strip>;
/** Encoded model-request image; default input coordinates use these pixel dimensions. */
export declare const ScreenshotResult: z.ZodObject<{
    data: z.ZodString;
    pixelWidth: z.ZodNumber;
    pixelHeight: z.ZodNumber;
    windowId: z.ZodNumber;
    bounds: z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    mimeType: z.ZodEnum<{
        "image/png": "image/png";
        "image/jpeg": "image/jpeg";
        "image/webp": "image/webp";
        "image/gif": "image/gif";
    }>;
    coordinateSpace: z.ZodLiteral<"screenshot-pixels">;
}, z.core.$strip>;
/** Permissions are reported without opening system permission dialogs. */
export declare const CapabilitiesResult: z.ZodObject<{
    platform: z.ZodString;
    permissions: z.ZodObject<{
        accessibility: z.ZodBoolean;
        screenRecording: z.ZodBoolean;
    }, z.core.$strip>;
    appLevelAccessibility: z.ZodBoolean;
    systemPointer: z.ZodDefault<z.ZodBoolean>;
    keyboard: z.ZodArray<z.ZodEnum<{
        app: "app";
        window: "window";
    }>>;
    sessionLocked: z.ZodNullable<z.ZodBoolean>;
    methods: z.ZodArray<z.ZodString>;
    coordinateSpace: z.ZodLiteral<"screenshot-pixels">;
    browser: z.ZodLiteral<false>;
}, z.core.$strip>;
/** Reports whether the provider successfully executed the requested operation. */
export declare const ActionResult: z.ZodObject<{
    dispatched: z.ZodBoolean;
    foregroundChanged: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>;
/** Hover reports whether the selected route moved the user's system pointer. */
export declare const HoverResult: z.ZodObject<{
    dispatched: z.ZodBoolean;
    foregroundChanged: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    hoverRoute: z.ZodEnum<{
        accessibility: "accessibility";
        "system-pointer": "system-pointer";
    }>;
    systemPointerMoved: z.ZodBoolean;
}, z.core.$strip>;
/** Background restoration dispatch and sampled foreground changes; null means the observation was unavailable. */
export declare const ShowResult: z.ZodObject<{
    dispatched: z.ZodBoolean;
    windowId: z.ZodNullable<z.ZodNumber>;
    foregroundChanged: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
/** Bounded native PNG thumbnail for human presentation, excluded from model results and saved grants. */
export declare const ApplicationIcon: z.ZodString;
//# sourceMappingURL=protocol.d.ts.map