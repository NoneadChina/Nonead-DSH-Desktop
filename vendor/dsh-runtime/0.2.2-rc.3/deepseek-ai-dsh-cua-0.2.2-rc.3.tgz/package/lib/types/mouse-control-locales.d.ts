/** Scope and interruption shown before the user grants mouse control. */
export declare const mouseControlPrompt: {
    question: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
    detail: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
};
//# sourceMappingURL=mouse-control-locales.d.ts.map