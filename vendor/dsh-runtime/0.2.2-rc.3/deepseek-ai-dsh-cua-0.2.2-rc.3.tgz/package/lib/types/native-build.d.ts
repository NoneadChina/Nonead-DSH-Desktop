import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Compiler invocation and lock shared by preparations using the same scratch files. */
interface NativeCompilerBuild {
    packageRoot: string;
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    signal: AbortSignal;
    timeoutMs: number;
    graceMs: number;
    argv: string[];
    /** Compiler lock target; shared across outputs that write the same intermediate build files. */
    lockPath: string;
}
/** Locations for publishing a standalone executable by content digest. */
export interface NativeExecutableBuild extends NativeCompilerBuild {
    outputPath: string;
    executablePath: string;
    retainedDirectory: string;
    binaryName: string;
}
/**
 * Recognize a declared package directory inside a DSH source checkout.
 * @param packageRoot - Real directory containing the platform package.
 * @param directory - Repository-relative source directory owned by that provider.
 * @returns Whether source compilation is permitted at this location.
 */
export declare function sourceNativePackage(packageRoot: string, directory: string): Promise<boolean>;
/**
 * Run the compiler under its build lock, then publish the binary or resolve the executable from the built application.
 * @param spec - Compiler and resource limits, with standalone binary paths or a callback reading the signed application receipt.
 * @returns Content-addressed runtime path after managed process cleanup.
 */
export declare function buildNativeExecutable(spec: NativeExecutableBuild | (NativeCompilerBuild & {
    resolveExecutable: () => Promise<string>;
})): Promise<string>;
export {};
//# sourceMappingURL=native-build.d.ts.map