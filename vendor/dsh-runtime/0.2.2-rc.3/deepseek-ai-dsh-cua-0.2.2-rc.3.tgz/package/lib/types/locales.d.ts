/** Locale-owned application-access approval messages. */
/** English application-access messages. */
export declare const en: {
    question: string;
    detail: string;
    approve: string;
};
/** Chinese application-access messages. */
export declare const zh: {
    question: string;
    detail: string;
    approve: string;
};
/** Japanese application-access messages. */
export declare const ja: {
    question: string;
    detail: string;
    approve: string;
};
/** Spanish dictionary, checked against the English keys. */
export declare const es: {
    question: string;
    detail: string;
    approve: string;
};
/** French dictionary, checked against the English keys. */
export declare const fr: {
    question: string;
    detail: string;
    approve: string;
};
/** German dictionary, checked against the English keys. */
export declare const de: {
    question: string;
    detail: string;
    approve: string;
};
/** Russian dictionary, checked against the English keys. */
export declare const ru: {
    question: string;
    detail: string;
    approve: string;
};
/** Portuguese dictionary, checked against the English keys. */
export declare const pt: {
    question: string;
    detail: string;
    approve: string;
};
/** Display translations resolved by the Client; wire choices stay unchanged. */
export declare const applicationAccessDisplay: {
    question: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
    detail: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
    approve: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
};
/** Window consent never grants access to sibling windows or application launch. */
export declare const windowAccessQuestion: {
    en: string;
    zh: string;
    ja: string;
    es: string;
    fr: string;
    de: string;
    ru: string;
    pt: string;
};
/** Launch consent does not grant access to resulting windows. */
export declare const launchAccessQuestion: {
    en: string;
    zh: string;
    ja: string;
    es: string;
    fr: string;
    de: string;
    ru: string;
    pt: string;
};
//# sourceMappingURL=locales.d.ts.map