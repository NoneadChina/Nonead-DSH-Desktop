/**
 * Host plugin importing a DeepSeek chat export (chat.deepseek.com
 * `deepseek_data-*.zip`) uploaded by the browser as stored DSH Sessions in a
 * chosen Workspace. The upload is processed in memory and never written to disk.
 * @module @deepseek-ai/dsh-deepseek-chat-import
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { DeepseekChatImportLimits } from './types.ts';
export { ExportEntryError, ExportSourceError } from './archive.ts';
export { ExportConversationError } from './conversation.ts';
export type { ExportArchive } from './archive.ts';
export type { ConvertConversationOptions, ConvertedConversation } from './conversation.ts';
export type { DeepseekChatImportDependencies, DeepseekChatImportRequest, DeepseekChatImportWorkspace } from './importer.ts';
export type { ImportClaim, UploadRouteHandler } from './upload.ts';
export type { DeepseekChatImportFailureReason, DeepseekChatImportLimits, DeepseekChatImportLine, DeepseekChatImportResponse, DeepseekChatImportResult, DeepseekChatImportSkip, } from './types.ts';
/** Deployment limits of the importer. */
export interface Config {
    /** Most Sessions one import writes, choosing the conversations the export index lists as most recently updated. */
    maxSessions: number;
    /** Largest export archive, in bytes, one upload may carry; the whole archive is held in memory while it is imported. */
    maxUploadBytes: number;
    /** Largest declared uncompressed size, in bytes, of one archive entry; larger entries are not decompressed. */
    maxEntryBytes: number;
    /** Largest UTF-8 size, in bytes, of an imported title, matching the session-title service's limit of the composition. */
    maxTitleBytes: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Upload route and Remote limits of the DeepSeek chat export importer. */
        deepseekChatImport: DeepseekChatImportService;
    }
}
/** Serves the owner-only export upload route and the limits the browser checks first. */
export default class DeepseekChatImportService extends TypertRemoteService {
    private readonly config;
    static inject: string[];
    static Config: Schema<Config>;
    /** The running import, which owns the single import slot. */
    private active;
    constructor(ctx: Context, config: Config);
    /**
     * Report the limits the browser checks before uploading. Only the owner may
     * import, so every other principal is refused.
     * @param signal - Client cancellation or Remote withdrawal.
     * @returns the largest accepted archive size.
     * @throws {RemoteError} `deepseekChatImport/owner-only` for a caller that is not the owner.
     */
    limits(signal: AbortSignal): DeepseekChatImportLimits;
    private claim;
}
//# sourceMappingURL=index.d.ts.map