/**
 * Upload route: one authenticated POST carries the complete export archive,
 * which is buffered in memory, imported, and released when the import ends.
 * The answer streams `application/x-ndjson` progress lines and one outcome
 * line. Nothing from the upload is written to disk.
 */
import type { DeepseekChatImportWorkspace } from './importer.ts';
import type { DeepseekChatImportResult } from './types.ts';
/** The single import slot of the owning service. */
export interface ImportClaim {
    /** Aborted when the owning service unloads. */
    readonly signal: AbortSignal;
    /** Free the slot; called exactly once when the request settles. */
    release(): void;
}
/** What the route needs from the owning service. */
export interface UploadRouteHandler {
    /** Largest accepted body, in bytes. */
    readonly maxUploadBytes: number;
    /**
     * Take the service's single import slot.
     * @returns the claim, or undefined while another import holds it.
     */
    claim(): ImportClaim | undefined;
    /**
     * Resolve the target Workspace.
     * @param workspaceId - id from the request query.
     * @returns the Workspace, or undefined when unknown.
     */
    workspace(workspaceId: string): DeepseekChatImportWorkspace | undefined;
    /**
     * Import one buffered archive.
     * @param archive - complete body bytes.
     * @param workspace - resolved target.
     * @param onProgress - Sessions imported so far and the Sessions the import tries to write.
     * @param signal - request lifetime joined with the claim.
     * @returns the import summary.
     */
    import(archive: Uint8Array, workspace: DeepseekChatImportWorkspace, onProgress: (done: number, total: number) => void, signal: AbortSignal): Promise<DeepseekChatImportResult>;
    /**
     * Report an import failure that is neither an archive failure nor a cancellation.
     * @param error - the thrown value; the response then ends without an outcome line.
     */
    failed(error: unknown): void;
}
/**
 * Serve uploads one at a time through the owning service's import slot.
 * @param handler - service operations behind the route.
 * @returns the Fetch handler registered on the Connection route.
 */
export declare function createUploadRoute(handler: UploadRouteHandler): (request: Request) => Promise<Response>;
//# sourceMappingURL=upload.d.ts.map