import type { HocShare, InjectFace, PropsLocale, PropsRenderFactories, PropsRuntime, SlotMap } from '@deepseek-ai/dsh-client-ui-slots';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace/types';
import type { DeepseekChatImportFailureReason, DeepseekChatImportResult } from '../types.ts';
import type { UploadProgress } from './upload.ts';
/** Outcome of one import request, already reduced for display. */
export type DeepseekChatImportOutcome = {
    readonly ok: true;
    readonly result: DeepseekChatImportResult;
} | {
    readonly ok: false;
    readonly reason: DeepseekChatImportFailureReason | 'upload-failed' | 'unknown';
    readonly message: string;
    /** Byte limit, present when the browser's own size pre-check rejected the file. */
    readonly limit?: number;
};
/** Callbacks injected by the plugin apply closure. */
export interface DeepseekChatImportInjected {
    /**
     * Upload one archive into a Workspace, then refresh the Session list however the attempt ends.
     * @param file - archive chosen in the browser.
     * @param workspaceId - Workspace receiving the Sessions.
     * @param onProgress - upload progress, the reading phase, then Sessions written.
     * @param signal - aborted when the dialog closes.
     * @returns the summary, or the failure category and diagnostic.
     */
    readonly importArchive: (file: File, workspaceId: WorkspaceId, onProgress: (progress: UploadProgress) => void, signal: AbortSignal) => Promise<DeepseekChatImportOutcome>;
}
/** Props composed by the `sidebar.session.action` slot, including the New-session row content it wraps. */
export type ImportSessionsActionProps = PropsRuntime<'sidebar.session.action'> & HocShare<SlotMap['sidebar.session.action']> & PropsRenderFactories & InjectFace<DeepseekChatImportInjected> & PropsLocale<'deepseekChatImport'>;
/**
 * Wrap the New-session row content with the import trigger after it and, while
 * open, its dialog.
 * @param props - the row content, column width, global hooks, the import callback, and the locale seat.
 * @returns the row content with the trigger and dialog, or only the row content when the Peer may not import.
 */
export declare function ImportSessionsAction(props: ImportSessionsActionProps): string | number | boolean | Iterable<import("react").ReactNode> | import("react").JSX.Element | null | undefined;
//# sourceMappingURL=ImportSessions.d.ts.map