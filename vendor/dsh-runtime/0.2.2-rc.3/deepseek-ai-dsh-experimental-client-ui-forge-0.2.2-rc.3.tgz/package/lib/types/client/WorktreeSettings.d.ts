import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
import type { WorktreeSettingsInjected } from './worktree-settings-form.ts';
export type WorktreeSettingsProps = PropsRuntime<'plugins.row.config'> & PropsLocale<typeof NS> & InjectFace<WorktreeSettingsInjected>;
/**
 * Render the worktree row's configuration: one switch that keeps every
 * checkout when its Session is archived. The summary view names the switch.
 * @param props - the Plugins page view, the staged form, and its actions.
 * @returns the row page's form, or the summary line.
 */
export declare function WorktreeSettings(props: WorktreeSettingsProps): string | import("react").JSX.Element;
//# sourceMappingURL=WorktreeSettings.d.ts.map