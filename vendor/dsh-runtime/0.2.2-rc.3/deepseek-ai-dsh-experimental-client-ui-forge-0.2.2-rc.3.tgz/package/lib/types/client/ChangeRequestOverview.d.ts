/**
 * Overview rows of an expanded change request card, each one line: the checks outcome, the review decision with the
 * reviewers' avatars, the merge state, and the issues linked to the change request. Details and actions open in a menu
 * from the row: the checks grouped by outcome with the rerun of the failed ones, the reviewers with review requests,
 * and the branch update.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { BranchUpdateRequest, ChangeRequestReviewer, ChangeRequestSnapshot, ForgeRerunRequest, ForgeReviewerCandidate } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgePanelChangeRequest } from '../types.ts';
import type { NS } from './locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** Requests reviews of a change request from more reviewers; settles once the outcome is reported. */
type RequestReviews = (entry: ForgePanelChangeRequest, reviewers: readonly Pick<ChangeRequestReviewer, 'kind' | 'login'>[]) => Promise<void>;
/** Lists the accounts a review of the change request at `url` can be requested from. */
type ListCandidates = (url: string, query: string, signal: AbortSignal) => Promise<readonly ForgeReviewerCandidate[]>;
/** Overview actions of a card; a surface without a Session binding omits them. */
export interface OverviewActions {
    /** Rerun the failed checks; settles once the outcome is reported. */
    readonly rerunChecks?: ((entry: ForgePanelChangeRequest, request: ForgeRerunRequest) => Promise<void>) | undefined;
    /** Request reviews from more reviewers; settles once the outcome is reported. */
    readonly requestReviews?: RequestReviews | undefined;
    /** List accounts a review can be requested from; rejects with the host's reason. */
    readonly reviewerCandidates?: ListCandidates | undefined;
    /** Bring the base branch's new commits into the head branch; settles once the outcome is reported. */
    readonly updateBranch?: ((entry: ForgePanelChangeRequest, request: BranchUpdateRequest) => Promise<void>) | undefined;
}
/**
 * The parts of one fact row: its glyph, its one-line value after the fact's name, which only assistive technology
 * reads unless the value names the fact itself, an optional trailing part, and the chevron of a row that opens something.
 * @param props - the fact's name for assistive technology, the glyph, the value with its tone, the trailing part, and
 * whether the row opens something.
 * @returns the row's cells.
 */
export declare function RowParts({ label, icon, value, tone, trailing, opens }: {
    readonly label: string | undefined;
    readonly icon: ReactNode;
    readonly value: ReactNode;
    readonly tone?: string | undefined;
    readonly trailing?: ReactNode;
    readonly opens: boolean;
}): ReactNode;
/** Props of the checks row. */
export interface ChecksRowProps {
    readonly entry: ForgePanelChangeRequest;
    readonly snapshot: ChangeRequestSnapshot;
    readonly openLink: (url: string) => void;
    /** Load complete check details independently of polling; cancellation follows the open menu. */
    readonly readChecks: ((url: string, headSha: string, signal: AbortSignal) => Promise<ChangeRequestSnapshot>) | undefined;
    readonly rerunChecks: OverviewActions['rerunChecks'];
    readonly t: Translate;
}
/**
 * Render the checks outcome as a row whose menu lists the failed, running, and cancelled checks by group, offers to
 * rerun the failed ones, and lists the passed and skipped ones on request. A list the poll read only in part is
 * completed while the menu is open.
 * @param props - the change request, its snapshot, the link and read actions, the rerun action, and copy.
 * @returns the row with its menu.
 */
export declare function ChecksRow({ entry, snapshot, openLink, readChecks, rerunChecks, t }: ChecksRowProps): ReactNode;
/** Props of the review row. */
export interface ReviewRowProps {
    readonly entry: ForgePanelChangeRequest;
    readonly snapshot: ChangeRequestSnapshot;
    /** The aggregate review outcome. */
    readonly value: string;
    /** Tone of the aggregate outcome. */
    readonly tone: string | undefined;
    readonly requestReviews: OverviewActions['requestReviews'];
    readonly reviewerCandidates: OverviewActions['reviewerCandidates'];
    readonly openLink: (url: string) => void;
    readonly t: Translate;
}
/**
 * Render the review decision as a row with the first reviewers' avatars. Its menu lists each reviewer with their
 * latest outcome or that their review is requested, and, when the signed-in user may request reviews, offers to ask a
 * reviewer again and to request a review from someone else through a search.
 * @param props - the change request, its snapshot, the aggregate outcome, the review request actions, and copy.
 * @returns the row with its menu.
 */
export declare function ReviewRow({ entry, snapshot, value, tone, requestReviews, reviewerCandidates, openLink, t }: ReviewRowProps): ReactNode;
/** Props of the merge row. */
export interface MergeRowProps {
    readonly entry: ForgePanelChangeRequest;
    readonly snapshot: ChangeRequestSnapshot;
    /** Glyph of the row. */
    readonly icon: ReactNode;
    /** The merge conflict status. */
    readonly value: string;
    /** Tone of the conflict status. */
    readonly tone: string | undefined;
    readonly updateBranch: OverviewActions['updateBranch'];
    readonly t: Translate;
}
/**
 * Render the merge state as a row: the conflict status and whether the head is behind its base. While the signed-in
 * user can update the head branch, the row opens the update menu: a title, one row per method, and the confirmation,
 * which is refused once the head moved after the menu opened.
 * @param props - the change request, its snapshot, the row glyph and status, the update action, and copy.
 * @returns the row, with its menu when the branch can be updated.
 */
export declare function MergeRow({ entry, snapshot, icon, value, tone, updateBranch, t }: MergeRowProps): ReactNode;
/**
 * A speech bubble, the glyph of review threads.
 * @param props - glyph size in pixels.
 * @returns the decorative glyph.
 */
export declare function ThreadGlyph({ size }: {
    readonly size?: number;
}): ReactNode;
/**
 * Render the issues linked to the change request, which the host closes once it merges, as one row of links, each
 * named by its number with its title in a tooltip, or nothing without one. More issues than the provider read end the
 * row with a note.
 * @param props - the snapshot, the link action, and copy.
 * @returns the row, or null.
 */
export declare function IssuesRow({ snapshot, openLink, t }: {
    readonly snapshot: ChangeRequestSnapshot;
    readonly openLink: (url: string) => void;
    readonly t: Translate;
}): ReactNode;
export {};
//# sourceMappingURL=ChangeRequestOverview.d.ts.map