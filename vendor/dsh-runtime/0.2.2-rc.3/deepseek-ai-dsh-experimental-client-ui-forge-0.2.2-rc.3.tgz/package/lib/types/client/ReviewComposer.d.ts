/** Plain-text comment editor for a frozen selection in either review tab. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ReviewQueue } from './review-queue.ts';
import { type ReviewSelection, type ReviewSource } from './review.ts';
import type { NS } from './locales.ts';
/** Actions supplied by the owning changes tab. */
export interface ReviewActions {
    /** The source currently displayed; selecting a range freezes it. */
    readonly source: ReviewSource;
    /** Browser records shared by the changes tab. */
    readonly records?: ReviewQueue;
    /** Whether the signed-in user has a pending review on the code host that the next comment joins. */
    readonly reviewStarted?: boolean;
    /** Open the confirmed publication URL. */
    readonly openLink?: (url: string) => void;
    /** A write is running or its outcome still needs confirmation. */
    readonly publishingBlocked?: boolean;
    /** Append an atomic quote without sending the Agent a message. */
    readonly addToInput: (selection: ReviewSelection) => boolean;
    /** Retain a new comment after its quote was accepted. */
    readonly onQuoted?: (selection: ReviewSelection) => void;
    /** Publish one comment; an error string preserves the editor. */
    readonly publish?: (selection: ReviewSelection) => Promise<string | undefined>;
    /** Add one comment to the pending review on the code host, starting one when needed; an error string preserves the editor. */
    readonly queue?: (selection: ReviewSelection) => Promise<string | undefined>;
}
/**
 * Render a primary action with an optional second action in its menu.
 * @param props - the main action, the optional menu action, the menu's name, and availability.
 * @returns the split button.
 */
export declare function SplitAction({ disabled, label, run, menuLabel, menu, other }: {
    readonly disabled: boolean;
    readonly label: string;
    readonly run: () => void;
    /** Accessible name of the menu button. */
    readonly menuLabel: string;
    /** Label of the action in the menu, or undefined without one. */
    readonly other: string | undefined;
    readonly menu: () => void;
}): ReactNode;
/**
 * Render the line range, plain-text editor, and explicitly named destinations.
 * @param props - frozen selection, actions, cancellation, and localized copy.
 * @returns the inline comment form.
 */
export declare function ReviewComposer({ selection, actions, close, visible, t }: PropsLocale<typeof NS> & {
    readonly visible?: boolean;
    readonly selection: ReviewSelection;
    readonly actions: ReviewActions;
    readonly close: () => void;
}): ReactNode;
//# sourceMappingURL=ReviewComposer.d.ts.map