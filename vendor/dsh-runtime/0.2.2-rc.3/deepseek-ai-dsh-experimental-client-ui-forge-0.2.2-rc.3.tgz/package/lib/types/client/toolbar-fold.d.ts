/** Width-driven folding of the changes toolbar into its More menu. */
/** Fold levels, from none to the deepest: level 1 folds the line totals, expansion, side by side, and wrapping; level 2
 * the test switch, with the progress label shortened to the bare count beside its ring; level 3 refresh. */
export declare const DEEPEST_FOLD = 3;
/**
 * Read the fold level a toolbar shows.
 * @param inside - an element inside the toolbar, such as its More button.
 * @returns the level, or the deepest level outside a measured toolbar.
 */
export declare function foldOf(inside: Element): number;
/**
 * Keep a toolbar row on one line by setting `data-fold` to the shallowest level whose items fit, measuring each level's
 * demand synchronously; the row's styles hide each level's items and show the More button. Content, size, and font
 * changes measure again.
 * @param row - the toolbar row; its children are the items, and the one with `data-fold-spacer` takes the slack.
 * @returns Disconnect the observers and the font listener.
 */
export declare function observeToolbarFold(row: HTMLElement): () => void;
//# sourceMappingURL=toolbar-fold.d.ts.map