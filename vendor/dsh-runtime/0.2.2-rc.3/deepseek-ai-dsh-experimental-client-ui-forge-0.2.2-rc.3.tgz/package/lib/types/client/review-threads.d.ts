/**
 * Where the changes view shows each review thread of a change request, the order a file shows them in, which threads
 * each filter of the thread list keeps, and the composer quote of a whole thread.
 */
import type { QuoteSummary } from '@deepseek-ai/dsh-client-ui-primitives';
import type { ForgeAnchor, ForgeReviewThread } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgeCommitRange, ForgeDiffFile } from '../types.ts';
/** The changes a view shows, which decides where a thread can sit. */
export interface ThreadView {
    /** Head commit the threads were read at. */
    readonly head: string;
    /** Commit the shown changes end at: the head, or the last chosen commit. */
    readonly end: string;
    /** Chosen consecutive commits, or null for the whole change request. */
    readonly commits: ForgeCommitRange | null;
}
/**
 * Where a thread shows in the changes view: on lines of one side, at the top of its file, in its file's outdated
 * section, or nowhere in the file because the chosen commits do not hold the lines it is on.
 */
export type ThreadPlace = {
    readonly kind: 'line';
    readonly side: 'L' | 'R';
    readonly startLine: number;
    readonly endLine: number;
} | {
    readonly kind: 'file';
} | {
    readonly kind: 'outdated';
} | {
    readonly kind: 'elsewhere';
};
/** One filter of the thread list: the threads by whether they are resolved. */
export type ThreadFilter = 'unresolved' | 'resolved' | 'all';
/** Filters of the thread list in display order. */
export declare const THREAD_FILTERS: readonly ThreadFilter[];
/**
 * Place a thread in a view. The whole change request shows a thread at its position on the head. Chosen commits show
 * only a new-side thread whose lines number the file at the last chosen commit: its position on the head when the
 * commits end at the head, else the lines it was written on at that commit. The old side of chosen commits starts
 * at the parent of the first commit, which no thread position numbers.
 * @param thread - the thread.
 * @param view - the shown changes.
 * @returns where the thread shows.
 */
export declare function placeThread(thread: ForgeReviewThread, view: ThreadView): ThreadPlace;
/**
 * Name a side and lines, such as `R12` or `L3–5`.
 * @param side - old or new side.
 * @param anchor - the lines.
 * @returns the range label.
 */
export declare function anchorRange(side: 'L' | 'R', anchor: Pick<ForgeAnchor, 'startLine' | 'endLine'>): string;
/**
 * Find the collapsed unchanged lines that hold a line: the index of the hunk they precede, or the hunk count after the last hunk.
 * @param file - the diff file.
 * @param side - side the line numbers.
 * @param line - the line.
 * @returns the gap index, or undefined when a hunk shows the line.
 */
export declare function gapOf(file: ForgeDiffFile, side: 'L' | 'R', line: number): number | undefined;
/**
 * Order a file's threads as its section shows them: threads on the whole file, then threads on lines by the row of their
 * last line, then outdated threads, then threads the chosen commits do not show. Threads on unchanged lines sort
 * by the collapsed lines that hold them.
 * @param items - threads of one file with their places.
 * @param file - the file's diff, or undefined when the shown changes lack the file.
 * @returns the threads in display order.
 */
export declare function inFileOrder<Item extends {
    readonly place: ThreadPlace;
}>(items: readonly Item[], file: ForgeDiffFile | undefined): Item[];
/**
 * Whether a thread passes a filter of the thread list.
 * @param thread - the thread.
 * @param filter - the filter.
 * @returns whether the list shows the thread.
 */
export declare function passesFilter(thread: ForgeReviewThread, filter: ThreadFilter): boolean;
/**
 * Cut a recorded diff hunk to its header and the lines that end it: the thread's lines on its side plus a few before.
 * GitHub records the hunk up to the thread's last line.
 * @param hunk - the recorded hunk, header first.
 * @param side - side the thread's lines number.
 * @param lines - how many lines the thread covers.
 * @returns the header and the kept lines.
 */
export declare function hunkExcerpt(hunk: string, side: 'L' | 'R', lines: number): {
    readonly header: string | null;
    readonly lines: readonly string[];
};
/**
 * Describe a composer quote of a thread by its file, range, and first comment.
 * @param thread - the quoted thread.
 * @param range - the thread's range label, or null for a file thread.
 * @returns the composer's display of the quote.
 */
export declare function threadQuoteSummary(thread: ForgeReviewThread, range: string | null): QuoteSummary;
/**
 * Format a whole thread for the ordinary, logged user message. Comment bodies are quoted line by line, so their
 * Markdown cannot add headings to the message.
 * @param thread - the thread.
 * @param url - web page of the change request.
 * @param index - one-based thread number in the composer.
 * @returns Markdown content for an atomic composer quote.
 */
export declare function formatThreadQuote(thread: ForgeReviewThread, url: string, index: number): string;
//# sourceMappingURL=review-threads.d.ts.map