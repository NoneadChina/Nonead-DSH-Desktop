/**
 * Reach of the changes view's file sections: a section's lines mount once the
 * section first comes within a margin of the files scrollport, and stay
 * mounted, so long diffs draw only what the reader approaches.
 */
/**
 * Watches the file sections of one changes view against its scrollport. Without
 * `IntersectionObserver` every section is reached at once.
 */
export declare class SectionReach {
    private observer;
    private readonly waiting;
    /**
     * Measure sections against `root`, or stop measuring when it unmounts. Sections that are still waiting move to the new root.
     * @param root - the files scrollport, or null.
     */
    attach(root: HTMLElement | null): void;
    /**
     * Call `reached` once when `element` comes within reach.
     * @param element - a file section inside the scrollport.
     * @param reached - runs once, from the observer's callback or at once without `IntersectionObserver`.
     * @returns the disposer that stops watching before the section is reached.
     */
    observe(element: Element, reached: () => void): () => void;
}
//# sourceMappingURL=section-reach.d.ts.map