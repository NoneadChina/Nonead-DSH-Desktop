/**
 * The right Sidebar's extension seats and its copy namespace.
 *
 * Four seats, each with a different reason to exist:
 * - `sidebar.right.pane.tab` is how a tab type contributes a body. It is keyed by
 *   the type definition's `id`, so adding a type is a registration, never an
 *   edit here. The key domain stays the open string space because a tab type may
 *   ship from outside this repository.
 * - `sidebar.right.pane.tab.title` is the same dispatch for what the chip shows
 *   as the tab's title. Registering is optional: without an entry the chip shows
 *   the title the registry captured when the tab opened.
 * - `sidebar.right.tab.guide` lets a product replace the guide tab's contents
 *   without replacing the tab. It is a chain because the replacement decides for
 *   itself whether it applies, and the shipped guide is the owner's fallback.
 * - `sidebar.right.tab.menu.item` extends a tab's actions menu. The kit owns the
 *   actions that are gestures on the layout itself; this seat is for actions that
 *   mean something about the tab's content.
 *
 * TYPE HOME RATIONALE: this package declares these slots at runtime, and anything
 * registering into one already depends on it for the declaration. The types
 * therefore live with their declarer.
 */
import type { ShortcutCatalogEntry } from '@deepseek-ai/dsh-client-shortcuts/client';
import type { RightbarOwnerProps } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { PaneId, TabId, TabRecord } from '@deepseek-ai/dsh-client-ui-dockkit';
import type { SlotHookFactory } from '@deepseek-ai/dsh-client-ui-slots';
import type { TabHookContext } from '../tab-info.ts';
import type { SidebarRightKey } from '../locales.ts';
import type { SidebarRightNavigationParams, SidebarRightResourceParams, SidebarRightTabParamsFor } from './params.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Right-Sidebar chrome, docking-kit vocabulary, and guide copy. */
        sidebarRight: SidebarRightKey;
    }
    interface SlotMap {
        /** Session content selected by the root-scoped right Sidebar controller. */
        'rightbar.session': {
            kind: 'single';
            scope: 'session';
            owner: RightbarOwnerProps & {
                readonly active: boolean;
                /** @param tabId - retained body. @param signal - tab occurrence lifetime. @returns releases the View-owned hold. */
                readonly retainTab: (tabId: TabId, signal: AbortSignal) => () => void;
            };
        };
        /**
         * One tab's body, dispatched with the `id` of the type in force for
         * `tab.kind`. A tab type registers here under its definition's `id` and
         * receives every tab of that kind, in every pane, docked or floating. A kind
         * with no type in force renders the owner's "nothing can view this" notice
         * rather than an empty pane.
         */
        'sidebar.right.pane.tab': {
            kind: 'keyed';
            scope: 'session';
            hookContext: TabHookContext;
            inject: SidebarRightTabInjected;
        };
        /**
         * A tab's title as its chip (and a floating panel's header) shows it,
         * dispatched with the same key and information hook as the body. A type with a
         * live title — a terminal named after its shell, a chat after its first
         * line — registers here and reads its own store; one without registers
         * nothing and the chip shows the registry's `title(address)` text captured
         * at open time.
         */
        'sidebar.right.pane.tab.title': {
            kind: 'keyed';
            scope: 'session';
            hookContext: TabHookContext;
            inject: SidebarRightTabInjected;
        };
        /**
         * The guide tab's body. Selectors run in chain order and the first
         * non-declining entry replaces the shipped guide entirely; with no entry, or
         * with every entry declining, the shipped guide renders.
         */
        'sidebar.right.tab.guide': {
            kind: 'chain';
            scope: 'session';
            hookContext: UseSidebarRightTabInfo;
            inject: {
                hooks: {
                    tabInfo: SlotHookFactory<'sidebar.right.tab.guide', UseSidebarRightTabInfo>;
                };
            };
        };
        /** Rows of the guide's More menu; the guide shows More only while this list has registrations. */
        'sidebar.right.tab.guide.actions': {
            kind: 'list';
            scope: 'root';
            owner: SidebarRightGuideActionsOwnerProps;
        };
        /** One provider's guide card, with the standard card as the owner's fallback. */
        'sidebar.right.tab.guide.entry': {
            kind: 'keyed';
            scope: 'session';
            owner: SidebarRightGuideEntryOwnerProps;
            hookContext: UseSidebarRightTabInfo;
            inject: {
                hooks: {
                    tabInfo: SlotHookFactory<'sidebar.right.tab.guide.entry', UseSidebarRightTabInfo>;
                };
            };
        };
        /**
         * Extra items at the end of one tab's actions menu, in registration order.
         * Entries decide their own visibility from the tab they are given. Without a
         * registrant the menu shows only the kit's own layout actions.
         */
        'sidebar.right.tab.menu.item': {
            kind: 'list';
            scope: 'session';
            owner: SidebarRightTabMenuOwnerProps;
        };
    }
}
/** Where a tab was last navigated to: what the `open` that created or revealed it carried. */
export interface SidebarRightTabNavigation {
    /** The address opened; for a tab record this is its `contentId`. */
    readonly address: string;
    /** The opener's `params` (see `contract/params.ts`); `undefined` when it gave none. */
    readonly params: SidebarRightNavigationParams;
    /**
     * Incremented on every navigation to this tab, whether or not `params`
     * changed, so a body can act on "navigated again" alone. `0` for a record
     * nobody opened by address: a seeded guide, or a tab restored by undo.
     */
    readonly revision: number;
}
/**
 * The host a resource open settles in: `'sidebar'` is the default docked pane
 * and expands the column; `'float'` is a floating panel and leaves the column
 * as it is.
 */
export type SidebarRightDestination = 'sidebar' | 'float';
/** Where an open from a tab lands. Without any of these it lands in the pane holding the tab at call time. */
export interface SidebarRightTabPlacement {
    /** Land a new tab in this pane instead. */
    readonly paneId?: PaneId;
    /** Prefer a new pane for new content; use the target pane when splitting is unavailable. */
    readonly preferNewPane?: boolean;
    /** Resource tabs reveal existing content by default; `false` permits duplicates. Pages always deduplicate within the target pane. */
    readonly revealIfOpened?: boolean;
    /**
     * `true` lands new content in this tab's place and closes this tab: a docked
     * tab lends its pane and strip slot; a floating tab is replaced in its panel,
     * and the new tab keeps the panel's pane id, rectangle, and stacking order,
     * takes focus, and leaves the column as it is. Content already open is
     * revealed as any open reveals it, and this tab stays open. Where new
     * content lands, it takes precedence over `paneId` and `preferNewPane`.
     */
    readonly replaceTab?: boolean;
}
/** Page-owned operations registered for a mounted tab body. */
export interface SidebarRightTabCommands {
    /** Refresh this page through its existing resource owner. */
    readonly refresh?: () => void;
}
/** The actions one tab may take on itself; each acts on the session the tab is in. */
export interface SidebarRightTabActions {
    /**
     * Bind page operations until the body unmounts or the tab lifetime ends.
     * @param commands - operations supported by this page; omitted operations are unavailable.
     * @returns disposer that cannot remove a newer body's registration.
     */
    bindCommands(commands: SidebarRightTabCommands): () => void;
    /**
     * Open a resource from this tab; see `ISidebarRight.openResource`. With
     * `destination`, the open ignores this tab's pane and every placement field,
     * and never closes this tab.
     * @param address - a `dsh-resource://` address.
     * @param options - placement, an explicit host, and the resource's navigation parameters.
     */
    openResource(address: string, options?: SidebarRightTabPlacement & {
        readonly params?: SidebarRightResourceParams;
        readonly destination?: SidebarRightDestination;
    }): void;
    /**
     * Open a page type from this tab; see `ISidebarRight.openTab`.
     * @param kind - the page type's kind.
     * @param options - placement and that kind's navigation parameters.
     */
    openTab<K extends string>(kind: K, options?: SidebarRightTabPlacement & {
        readonly params?: SidebarRightTabParamsFor<K>;
    }): void;
    /** Close this tab. */
    close(): void;
}
/** Live information shared by a tab's body, title, and guide replacement. */
export interface SidebarRightTabInfo {
    readonly sidebar: {
        readonly expanded: boolean;
        /** Presentation selected by manual mode or viewport width; preserved while collapsed. */
        readonly fullscreen: boolean;
    };
    readonly panel: {
        readonly id: PaneId;
        /** Whether this pane is hosted in a floating panel rather than the docked sidebar. */
        readonly isFloating: boolean;
    };
    readonly tab: TabRecord & {
        /** Effective refresh binding for this page's controls. */
        readonly refreshShortcut?: ShortcutCatalogEntry | undefined;
        /**
         * Only the foreground Session is visible. Docked bodies require expansion and selection;
         * expanded titles include inactive tabs. Floats survive collapse.
         */
        readonly visible: boolean;
        readonly navigation: SidebarRightTabNavigation;
        /** Aborted only when the record disappears or this plugin unloads, not on hide or session switch. */
        readonly signal: AbortSignal;
        readonly actions: SidebarRightTabActions;
    };
}
/**
 * Read current tab information through the slot framework's subscriptions.
 * @returns the sidebar presentation, containing pane, and live tab record.
 */
export type UseSidebarRightTabInfo = () => SidebarRightTabInfo;
/** The slot-owned hook shared by every tab body and title registration. */
export interface SidebarRightTabInjected {
    hooks: {
        tabInfo: SlotHookFactory<'sidebar.right.pane.tab', UseSidebarRightTabInfo>;
    };
}
/** Owner share of one tab-menu item occurrence. */
export interface SidebarRightTabMenuOwnerProps {
    /** The tab whose menu is open. */
    tab: TabRecord;
    /**
     * Dismiss the menu.
     *
     * An item that acts MUST call this: the menu is the kit's, and it closes on
     * its own actions only. An item that leaves it open leaves a menu floating
     * over content the action may have just replaced.
     */
    dismiss: () => void;
}
/** Resolved guide copy and entry identity supplied to a provider's card renderer. */
export interface SidebarRightGuideEntryOwnerProps {
    readonly entryId: string;
    readonly kind: string;
    readonly title: string;
    readonly description?: string;
}
/** One customizable guide card listed in the More menu. */
export interface SidebarRightGuideActionEntry {
    /** Card id, `kind:entry id`. */
    readonly id: string;
    /** Resolved card title. */
    readonly label: string;
    /** False while the card is unpinned from the guide. */
    readonly pinned: boolean;
}
/** Owner share of the guide's More menu rows. */
export interface SidebarRightGuideActionsOwnerProps {
    /** Guide cards in registry order; cards of kind `files` are never listed. */
    readonly entries: readonly SidebarRightGuideActionEntry[];
    /**
     * Open a card's tab type in the guide's place without changing its pin state.
     * @param id - Listed card id.
     */
    readonly onOpen: (id: string) => void;
    /**
     * Show (true) or unpin (false) a guide card.
     * @param id - Listed card id.
     * @param pinned - Whether the card shows on the guide.
     */
    readonly onPinnedChange: (id: string, pinned: boolean) => void;
    /** Close the More menu. */
    readonly onDismiss: () => void;
}
//# sourceMappingURL=slots.d.ts.map