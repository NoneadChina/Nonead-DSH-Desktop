/**
 * Global plugin management: grouped cards for official configuration and
 * optional bundles, the Installed group's cards for the profile's bundles,
 * their row switches, the install dialog with its guide and folded pnpm
 * output, the uninstall confirmation, and the toasts an action's outcome
 * becomes. A bundle's page lists the rows it contributes as the Host runs
 * them; a plugin's configuration renders on its own page through the slots
 * the page declares.
 */

import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import type { PluginInstallFailureKind, Registry } from '@deepseek-ai/dsh-api-remotes/client'
import {
  Button, IconCheckCircleFillRegular, IconChevronDownOutlineRegular, IconChevronLeftOutlineMedium,
  IconChevronRightOutlineRegular, IconCloseOutlineMedium,
  IconDownloadOutlineRegular, IconInfoOutlineRegular, IconPlusOutlineRegular, IconRefreshOutlineRegular, IconTrashOutlineRegular,
  IconWarningOutlineRegular, Input, Menu, MenuItemButton, Modal, pointerModality,
  PluginArtworkDefault, PluginArtworkLoop, PluginArtworkSearch, PluginArtworkSubagent, PluginArtworkTerminal,
  SegmentedTabs, StateDot, Switch, Tag, TerminalBlock, Toast, Tooltip, useDismissOnOutsidePointer,
  type IconProps, type StateDotState, type TerminalBlockLabels,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots'
import { EXTENSION_BUNDLES, HIDDEN_BUNDLES, MORE_BUNDLES } from '@deepseek-ai/dsh-official-bundles'
import type { createNavigationStore } from './navigation-store.ts'
import type { PluginHeaderLayoutFace } from './header-scroll.ts'
import { rowConfigKey, type OfficialItem } from './config-ledger.ts'
import { INSTALL_GIT_EXAMPLE, INSTALL_PATH_EXAMPLE, type PluginManagerLocaleKey } from './locales.ts'
import {
  bundleBusy, asksMirror, githubRecoveryRegistry, isInstallPending, offeredRegistries, rowKey, updateCandidate,
  type InstallInputError, type InstallState, type InstallSubject, type PackageRow, type PackageView,
  type PluginManagerFace, type PluginManagerState, type RegistryChoice, type VersionCheck,
} from './manager-store.ts'
import { managementText, noticeText, packageText, registryText, restartText, rowText, type Translate } from './presentation.ts'
import type { PluginPackageRef, PluginRowRef, PluginsSubject } from './slot-contract.ts'
import type { ConfigPageForm } from './slot-contract.ts'
import { UpdateDialog, VersionSection } from './versions.tsx'
import { BundleDetailSection } from './BundleDetailSection.tsx'
import css from './PluginManagerPage.module.css'

/** Full component props assembled by the main slot renderer. */
export type PluginManagerPageProps =
  PropsRuntime<'main'>
  & PropsLocale<'pluginManager'>
  & PropsRenderSlots<
    | 'plugins.item' | 'plugins.bundle.config' | 'plugins.row.config' | 'plugins.bundle.activation'
    | 'plugins.add.actions' | 'plugins.tab'
    | 'plugins.detail.actions' | 'plugins.detail.badge' | 'plugins.detail.section'
  >
  & InjectFace<PluginManagerFace & PluginHeaderLayoutFace>
  & PropsStore<ReturnType<typeof createNavigationStore>>

/** The page's slot renderer, narrowed to the configuration slots. */
type RenderConfig = PluginManagerPageProps['renderSlot']
type ResolveText = PluginManagerFace['resolveText']

type RowPhase = NonNullable<PackageRow['phase']>

/** The primary action installs; the adjacent menu offers every add-plugin path. */
function AddPluginMenu({ t, disabled, openInstall, renderSlot }: {
  readonly t: Translate
  readonly disabled: boolean
  readonly openInstall: () => void
  readonly renderSlot: RenderConfig
}): ReactNode {
  const [open, setOpen] = useState(false)
  const onDismiss = (): void => { setOpen(false) }
  return (
    <span className={css.addGroup} role="group" aria-label={t('addPlugin')}>
      <Tooltip label={t('addPlugin')} side="bottom" delayMs={500} focusDelayMs={500} portal disabled={disabled}>
        <Button variant="primary" size="sm" className={css.addPrimary} icon={<IconPlusOutlineRegular size={13} />}
          aria-label={t('addPlugin')} disabled={disabled} onClick={() => { onDismiss(); openInstall() }}>
          <span className={css.toolbarLabel}>{t('addPlugin')}</span>
        </Button>
      </Tooltip>
      <Menu open={open} onClose={onDismiss} align="end" portal autoFocus listClassName={css.addMenu}
        anchor={(
          <Button variant="primary" size="sm" className={css.addMore}
            disabled={disabled} aria-label={t('chooseAddMethod')} aria-haspopup="menu" aria-expanded={open}
            onClick={() => { setOpen(value => !value) }}
            onKeyDown={(event) => {
              if (!open && event.key === 'ArrowDown') { event.preventDefault(); setOpen(true) }
            }}>
            <IconChevronDownOutlineRegular size={12} aria-hidden="true" />
          </Button>
        )}>
        <MenuItemButton icon={<IconDownloadOutlineRegular size={14} />} onSelect={() => { onDismiss(); openInstall() }}>
          <span className={css.addMenuItem}>
            <span>{t('installExisting')}</span>
            <span className={css.addMenuDescription}>{t('installExistingDescription')}</span>
          </span>
        </MenuItemButton>
        {renderSlot('plugins.add.actions', { onDismiss })}
      </Menu>
    </span>
  )
}

/** How long the list marks a package an install just enabled. */
const HIGHLIGHT_MS = 2_400

/**
 * Whether any plugin row this bundle's patch declares is running.
 *
 * A default-hidden bundle's rows may run without the profile selecting it, for example through
 * `cordis.patch.yml`; that run state is the effective enablement the lists offer.
 * @param pkg - the bundle as the Host reports it.
 * @returns whether at least one declared row runs.
 */
function rowsRunning(pkg: PackageView): boolean {
  return pkg.rows.some(row => row.enabled)
}

/**
 * Whether the main list shows an official optional bundle: any bundle outside `MORE_BUNDLES`, and any held-back one the profile enabled.
 * @param pkg - the official bundle as the Host reports it.
 * @returns whether the main list shows it.
 */
function pinnedToMainList(pkg: PackageView): boolean {
  return !MORE_BUNDLES.includes(pkg.name) || pkg.enabled
}

/**
 * Where an optional bundle sits on both lists: the `EXTENSION_BUNDLES` in their order, then the bundles neither list
 * ranks, then the held-back ones in theirs, so Codex and Claude Code stay last on the More list.
 * @param name - the bundle's package name.
 * @returns the rank; bundles of equal rank keep the order the Host reported.
 */
function optionalBundleRank(name: string): number {
  const ranked = EXTENSION_BUNDLES.indexOf(name)
  if (ranked >= 0) return ranked
  const heldBack = MORE_BUNDLES.indexOf(name)
  return heldBack < 0 ? EXTENSION_BUNDLES.length : EXTENSION_BUNDLES.length + 1 + heldBack
}

/**
 * Order the official optional bundles as both lists show them, so a bundle the profile picks from the More list
 * keeps its place among the neighbours the main list already holds.
 * @param packages - the official bundles the Host offers.
 * @returns the bundles in display order.
 */
function orderOptionalBundles(packages: readonly PackageView[]): PackageView[] {
  return [...packages].sort((a, b) => optionalBundleRank(a.name) - optionalBundleRank(b.name))
}

/** How long a toast holds: long enough to read a failure that names what broke. */
function toastHoldMs(text: string): number {
  return Math.min(8_000, Math.max(3_000, text.length * 80))
}

const PHASE_KEYS = {
  pending: 'rowPhasePending',
  loading: 'rowPhaseLoading',
  active: 'rowPhaseActive',
  failed: 'rowPhaseFailed',
  unloading: 'rowPhaseUnloading',
} satisfies Record<RowPhase, PluginManagerLocaleKey>

/** Status dot naming a root-fiber phase; loading and unloading are live transitions. */
const PHASE_STATES = {
  pending: 'idle',
  loading: 'ongoing',
  active: 'done',
  failed: 'error',
  unloading: 'ongoing',
} satisfies Record<RowPhase, StateDotState>

/** The count line over a pack's components: the total, then only the states that occur. */
function partsSummary(rows: readonly PackageRow[], t: Translate): string {
  const failed = rows.filter(row => row.phase === 'failed').length
  const off = rows.filter(row => !row.enabled).length
  const running = rows.filter(row => row.enabled && row.phase === 'active').length
  return [
    t('partsCountTotal', { count: String(rows.length) }),
    ...running > 0 ? [t('partsCountRunning', { count: String(running) })] : [],
    ...off > 0 ? [t('partsCountOff', { count: String(off) })] : [],
    ...failed > 0 ? [t('partsCountFailed', { count: String(failed) })] : [],
  ].join(' · ')
}

/** Switching for a pack's rows: which rows have a write in flight, and the write. */
interface RowToggles {
  readonly busy: (row: PackageRow) => boolean
  readonly onSetEnabled: (row: PackageRow, enabled: boolean) => void
}

/** Configuration for a pack's rows: which rows registered a page of their own, and opening it. */
interface RowConfigure {
  readonly has: (row: PackageRow) => boolean
  readonly open: (row: PackageRow) => void
}

/** Rows beyond this count get a filter box above the list. */
const ROW_FILTER_THRESHOLD = 10

/** The size the 36-viewBox plugin artwork renders at inside a card's 48px frame. */
const CARD_ARTWORK_SIZE = 36

/** The size the artwork renders at inside a row's 40px frame. */
const ROW_ARTWORK_SIZE = 30

/** The artwork of the official plugins that registered their configuration, by registration id. */
const ITEM_ARTWORK = new Map<string, (props: IconProps) => ReactNode>([
  ['shell', PluginArtworkTerminal],
  ['agent-loop', PluginArtworkLoop],
  ['subagent', PluginArtworkSubagent],
  ['web-search', PluginArtworkSearch],
])

/** An official plugin's card and page artwork; plugins without their own get the default. */
function itemArtwork(id: string): ReactNode {
  const Artwork = ITEM_ARTWORK.get(id) ?? PluginArtworkDefault
  return <Artwork size={CARD_ARTWORK_SIZE} />
}

/** Manifest images remain isolated from the page DOM; a failed decode keeps the position's default artwork. */
function PackageArtwork({ src, row = false, size = row ? ROW_ARTWORK_SIZE : CARD_ARTWORK_SIZE }: {
  readonly src: string | undefined
  readonly row?: boolean
  readonly size?: number
}): ReactNode {
  const [failedSource, setFailedSource] = useState<string>()
  const Fallback = row ? PluginArtworkSubagent : PluginArtworkDefault
  return src === undefined || src === failedSource
    ? <Fallback size={size} />
    : <img className={css.packageImage} src={src} width={size} height={size} alt="" onError={() => { setFailedSource(src) }} />
}

/** A row's switch: locked, saying why, when the Host refuses to address the row through the profile patch. */
function RowSwitch({ row, title, t, busy, onChange }: {
  readonly row: PackageRow
  readonly title: string
  readonly t: Translate
  readonly busy: boolean
  readonly onChange: (enabled: boolean) => void
}): ReactNode {
  const locked = row.readOnlyReason !== undefined || row.entryId === undefined
  return (
    <Switch
      checked={row.enabled}
      label={t('partToggle', { name: title })}
      disabled={busy || locked}
      {...row.readOnlyReason === undefined ? {} : { title: managementText({ code: row.readOnlyReason }, t) }}
      onChange={onChange}
    />
  )
}

/** What a row's state line says: off, or the phase its fiber is in. */
function rowStateText(row: PackageRow, t: Translate): string {
  if (!row.enabled) return t('partOff')
  return row.phase === null ? t('rowStateIdle') : t(PHASE_KEYS[row.phase])
}

/** The dot beside a row: its fiber phase, or idle. */
function rowDotState(row: PackageRow): StateDotState {
  if (!row.enabled || row.phase === null) return 'idle'
  return PHASE_STATES[row.phase]
}

/** A Host metadata diagnostic does not change the package's management permissions. */
function MetadataError({ error, t }: { readonly error: string | undefined; readonly t: Translate }): ReactNode {
  return error === undefined ? null : <p className={css.reason} role="status" data-package-meta-error>{t('metadataError', { error })}</p>
}

/** A failed component keeps its current Host diagnostic beside its controls. */
function RuntimeError({ error, t }: { readonly error: string | undefined; readonly t: Translate }): ReactNode {
  return error === undefined ? null : <p className={css.reason} role="status" data-plugin-runtime-error>{t('reasonLabel')}: {error}</p>
}

/**
 * A pack's rows as a list in the order the pack declares them: a state dot,
 * the row id, one line saying its state, a configure control for a row that
 * registered a page, and, when the pack is on, a switch. A pack like base
 * carries close to a hundred rows, so a long list gets a filter.
 */
function RowsSection({ rows, t, resolveText, toggle, configure }: {
  readonly rows: readonly PackageRow[]
  readonly t: Translate
  readonly resolveText: ResolveText
  readonly toggle?: RowToggles | undefined
  readonly configure?: RowConfigure | undefined
}): ReactNode {
  const [filter, setFilter] = useState('')
  const query = filter.trim().toLowerCase()
  const localized = rows.map(row => ({ row, ...rowText(row, resolveText) }))
  const shown = query === '' ? localized : localized.filter(({ row, title, description }) =>
    [title, description, row.rowId, row.moduleName].some(value => value?.toLowerCase().includes(query)))
  return (
    <section className={css.detailSection} data-plugin-rows>
      <div className={css.sectionHead}>
        <h4 className={css.sectionTitle}>{t('partsLabel')}</h4>
        {rows.length === 0 ? null : <span className={css.sectionCount}>{partsSummary(rows, t)}</span>}
      </div>
      {rows.length === 0 ? <p className={css.status}>{t('partsEmpty')}</p> : null}
      {rows.length > ROW_FILTER_THRESHOLD
        ? (
          <Input
            type="search"
            className={css.partsFilter as string}
            placeholder={t('partsFilter')}
            aria-label={t('partsFilter')}
            value={filter}
            onChange={(event) => { setFilter(event.target.value) }}
          />
        )
        : null}
      {rows.length > 0 && shown.length === 0 ? <p className={css.status}>{t('partsFilterEmpty')}</p> : null}
      {shown.length === 0
        ? null
        : (
          <ul className={css.rows}>
            {shown.map(({ row, title, description }) => (
              <li
                key={row.rowId}
                className={css.row}
                data-plugin-row={row.entryId ?? row.rowId}
                {...row.phase === 'failed' ? { 'data-state': 'failed' } : row.enabled ? {} : { 'data-state': 'off' }}
              >
                <div className={css.rowLine}>
                  <span className={css.rowIcon} aria-hidden="true"><PackageArtwork key={row.meta?.icon} src={row.meta?.icon} row /></span>
                  <div className={css.rowMain}>
                    {configure?.has(row) === true
                      ? (
                        <button type="button" className={css.rowOpen} aria-label={t('configureRow', { name: title })} onClick={() => { configure.open(row) }}>
                          <span className={css.rowId}>{title}</span>
                          <IconChevronRightOutlineRegular className={css.rowOpenIcon} aria-hidden="true" />
                        </button>
                      )
                      : <span className={css.rowId}>{title}</span>}
                    {description === undefined ? null : <span className={css.rowModule}>{description}</span>}
                    {title === row.rowId ? null : <code className={css.rowModule}>{row.rowId}</code>}
                    {title === row.moduleName ? null : <code className={css.rowModule}>{row.moduleName}</code>}
                  </div>
                  <span className={css.rowState}>
                    <StateDot state={rowDotState(row)} />
                    {rowStateText(row, t)}
                  </span>
                  {toggle === undefined
                    ? null
                    : <RowSwitch
                      row={row} title={title} t={t} busy={toggle.busy(row)}
                      onChange={(enabled) => { toggle.onSetEnabled(row, enabled) }}
                    />}
                </div>
                <MetadataError error={row.meta?.error} t={t} />
                <RuntimeError error={row.diagnostic} t={t} />
              </li>
            ))}
          </ul>
        )}
    </section>
  )
}

/** Declared install source and versions; unavailable files retain their recorded dependency spec. */
function SourceSection({ pkg, t }: { readonly pkg: PackageView; readonly t: Translate }): ReactNode {
  if (pkg.source === undefined && !pkg.installed && pkg.availability === 'installation' && !pkg.optional) return null
  return (
    <section className={css.detailSection} data-plugin-source>
      <h4 className={css.sectionTitle}>{t('sourceTitle')}</h4>
      <dl className={css.facts}>
        <div>
          <dt>{t('sourceSpec')}</dt>
          <dd>{pkg.source !== undefined ? <code>{pkg.source}</code> : pkg.availability === 'missing'
            ? t(pkg.installed ? 'statusMissingFiles' : 'sourceNotInstalled') : t('sourceBuiltIn')}</dd>
        </div>
        {pkg.version === undefined
          ? null
          : (
            <div>
              <dt>{t('sourceVersion')}</dt>
              <dd>{pkg.version}</dd>
            </div>
          )}
        {pkg.installTarget === undefined ? null : (
          <>
            <div>
              <dt>{t('sourceTargetSpec')}</dt>
              <dd><code>{pkg.installTarget.spec}</code></dd>
            </div>
            <div>
              <dt>{t('sourceTargetVersion')}</dt>
              <dd>{pkg.installTarget.version}</dd>
            </div>
          </>
        )}
      </dl>
    </section>
  )
}

/**
 * A bundle's enable switch on its card and its page: locked, saying why, for
 * one the Host protects; off and locked for one it cannot read.
 */
function EnableSwitch({ pkg, title, t, busy, onSetEnabled }: {
  readonly pkg: PackageView
  readonly title: string
  readonly t: Translate
  readonly busy: boolean
  readonly onSetEnabled: (enabled: boolean) => void
}): ReactNode {
  return (
    <span className={css.bundleToggle}>
      <span className={css.toggleProgress} role="status">
        <span className={css.progressAnnouncement}>{busy ? t('applyingChange', { name: title }) : ''}</span>
        {busy ? <StateDot state="ongoing" /> : null}
      </span>
      <Switch
        checked={pkg.enabled}
        label={t('enableToggle', { name: title })}
        disabled={busy || pkg.readOnlyReason !== undefined || (!pkg.enabled && pkg.error !== undefined
          && (pkg.error.code === 'unsupported-platform' || !(pkg.availability === 'missing' && pkg.installTarget !== undefined)))}
        {...pkg.readOnlyReason === undefined ? {} : { title: managementText({ code: pkg.readOnlyReason }, t) }}
        onChange={onSetEnabled}
      />
    </span>
  )
}

/** The status one card carries: running, off, not running because the Host skipped a selected bundle's layer, or another problem. */
type PackageStatus = 'running' | 'disabled' | 'not-running' | 'problem'

/** The tag each status shows beside the title on a card and on its page; running and off show none. */
const STATUS_TAG_KEYS = {
  'running': undefined,
  'disabled': undefined,
  'not-running': 'statusNotRunning',
  'problem': 'statusProblem',
} satisfies Record<PackageStatus, PluginManagerLocaleKey | undefined>

/** A selected bundle the Host reports an error for is not running when none of its rows has a live entry. */
function packageStatus(pkg: PackageView): PackageStatus {
  if (pkg.enabled && pkg.error !== undefined && pkg.rows.every(row => row.entryId === undefined)) return 'not-running'
  if (pkg.error !== undefined || (pkg.enabled && pkg.rows.some(row => row.phase === 'failed'))) return 'problem'
  return pkg.enabled ? 'running' : 'disabled'
}

/** The danger tag a status carries. */
function StatusTag({ status, t }: { readonly status: PackageStatus; readonly t: Translate }): ReactNode {
  const key = STATUS_TAG_KEYS[status]
  return key === undefined ? null : <Tag className={css.statusTag} tone="danger">{t(key)}</Tag>
}

/** The head every card shares: the artwork, the name that opens the page beside its tags, its one-liner, and what sits at the end. */
function CardHead({ title, t, onOpen, icon, tags, description, end }: {
  readonly title: string
  readonly t: Translate
  readonly onOpen: () => void
  readonly icon: ReactNode
  readonly tags?: ReactNode
  readonly description: ReactNode
  readonly end?: ReactNode
}): ReactNode {
  const descriptionId = useId()
  return (
    <div className={css.cardHead}>
      <span className={css.cardIcon} aria-hidden="true">{icon}</span>
      <div className={css.cardMain}>
        <div className={css.titleRow}>
          <button type="button" className={`${css.cardTitle} ${css.cardOpen}`} aria-label={t('openDetail', { name: title })} aria-describedby={description === undefined ? undefined : descriptionId} onClick={onOpen}>{title}</button>
          {tags}
        </div>
        {description === undefined ? null : <span className={css.cardDesc} id={descriptionId}>{description}</span>}
      </div>
      {end === undefined ? null : <div className={css.cardEnd}>{end}</div>}
    </div>
  )
}

/** First-read placeholders share the core configuration group's card and text-line layout. */
function ListSkeleton({ label }: { readonly label: string }): ReactNode {
  return (
    <section className={css.group} role="status" aria-label={label} data-plugin-loading>
      <div className={css.groupHead} aria-hidden="true">
        <span className={`${css.groupTitle} ${css.skeletonText} ${css.skeletonHeading}`}>
          <span className={`${css.skeletonFill} ${css.skeletonBar}`} />
        </span>
      </div>
      <ul className={css.cards} aria-hidden="true">
        {[0, 1, 2, 3].map(index => (
          <li key={index} className={css.card}>
            <div className={css.cardHead}>
              <span className={`${css.cardIcon} ${css.skeletonFill} ${css.skeletonIcon}`} />
              <div className={css.cardMain}>
                <div className={css.titleRow}>
                  <span className={`${css.cardTitle} ${css.skeletonText} ${css.skeletonTitle}`}>
                    <span className={`${css.skeletonFill} ${css.skeletonBar}`} />
                  </span>
                </div>
                <span className={`${css.cardDesc} ${css.skeletonText} ${css.skeletonDescription}`}>
                  <span className={`${css.skeletonFill} ${css.skeletonBar}`} />
                </span>
              </div>
              <div className={`${css.cardEnd} ${css.skeletonActions}`} />
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}

/** The top every page shares: the crumb that leads back, then the icon with the page's actions at its right. */
function DetailTop({ crumbLabel, crumbText, onBack, icon, actions }: {
  readonly crumbLabel: string
  readonly crumbText: string
  readonly onBack: () => void
  readonly icon: ReactNode
  readonly actions?: ReactNode
}): ReactNode {
  return (
    <div className={css.detailTop} data-window-drag>
      <button type="button" className={css.crumb} aria-label={crumbLabel} onClick={onBack}>
        <IconChevronDownOutlineRegular className={css.crumbIcon} aria-hidden="true" />
        <span>{crumbText}</span>
      </button>
      <div className={css.detailHead}>
        <span className={css.cardIcon} aria-hidden="true">{icon}</span>
        {actions}
      </div>
    </div>
  )
}

/** The registry version a finished version check offers for a package, when it offers one. */
function versionUpdate(check: VersionCheck | undefined): string | undefined {
  return check?.phase === 'done' ? updateCandidate(check.list)?.version : undefined
}

/** The list toolbar's sentence about the last update check of every registry package. */
function updatesNote(packages: readonly PackageView[], versions: PluginManagerState['versions'], t: Translate): { text: string; tone?: 'info' | 'error' } | undefined {
  const checks = packages.filter(pkg => pkg.update === 'registry').map(pkg => versions[pkg.name])
  if (checks.length === 0 || checks.some(check => check === undefined || check.phase === 'checking')) return undefined
  const available = checks.filter(check => versionUpdate(check) !== undefined).length
  if (available > 0) return { text: t('updatesAvailable', { count: String(available) }), tone: 'info' }
  if (checks.some(check => check?.phase === 'done' && check.list.status === 'refused')) return { text: t('updatesFailed'), tone: 'error' }
  return { text: t('updatesNone') }
}

function updateAvailable(pkg: PackageView): boolean {
  const target = pkg.installTarget
  // An update removes the installed package first, so a package that cannot be removed offers none.
  if (!pkg.installed || !pkg.removable || pkg.availability === 'installation' || target === undefined) return false
  return pkg.version !== target.version
    || ((target.spec.startsWith('link:') || pkg.source?.startsWith('link:') === true) && pkg.source !== target.spec)
}

/**
 * One package as a card that opens its page: its name, its one-liner, its tags, its bundle switch, and why the Host
 * skipped it or does not support its platform.
 */
function PackageCard({ pkg, t, resolveText, busy, highlighted, newer, onOpen, onSetEnabled }: {
  readonly pkg: PackageView
  /** The newer registry version a version check offers. */
  readonly newer: string | undefined
  readonly t: Translate
  readonly resolveText: ResolveText
  readonly busy: boolean
  readonly highlighted: boolean
  readonly onOpen: () => void
  readonly onSetEnabled: (enabled: boolean) => void
}): ReactNode {
  const { title, description, beta } = packageText(pkg, resolveText)
  const status = packageStatus(pkg)
  return (
    <li
      className={`${css.card} ${css.cardLink}`}
      data-plugin-package={pkg.name}
      data-plugin-status={status}
      {...highlighted ? { 'data-plugin-highlight': '' } : {}}
    >
      <CardHead
        title={title}
        t={t}
        onOpen={onOpen}
        icon={<PackageArtwork key={pkg.meta?.icon} src={pkg.meta?.icon} />}
        tags={(
          <>
            {beta ? <Tag className={css.statusTag} tone="info">{t('statusBeta')}</Tag> : null}
            <StatusTag status={status} t={t} />
            {pkg.availability === 'missing' ? <Tag className={css.statusTag}>{t(pkg.installed ? 'statusMissingFiles' : 'statusNotInstalled')}</Tag> : null}
            {updateAvailable(pkg) || newer !== undefined ? <Tag className={css.statusTag} tone="info">{t('statusUpdateAvailable')}</Tag> : null}
          </>
        )}
        description={description}
        end={<EnableSwitch pkg={pkg} title={title} t={t} busy={busy} onSetEnabled={onSetEnabled} />}
      />
      <MetadataError error={pkg.meta?.error} t={t} />
      {/* The card names an incompatibility without its requirement list; the page lists them. */}
      {pkg.error !== undefined && (status === 'not-running' || pkg.error.code === 'unsupported-platform')
        ? <p className={css.reason} role="status">{managementText({ ...pkg.error, incompatible: [] }, t)}</p>
        : null}
    </li>
  )
}

/**
 * One official plugin as a card that opens its page: its icon, its title from
 * the registration, and the one-liner the entry renders in its summary view.
 */
function ItemCard({ item, t, onOpen, renderSlot }: {
  readonly item: OfficialItem
  readonly t: Translate
  readonly onOpen: () => void
  readonly renderSlot: RenderConfig
}): ReactNode {
  return (
    <li className={`${css.card} ${css.cardLink}`} data-plugin-item={item.id}>
      <CardHead title={item.label} t={t} onOpen={onOpen} icon={itemArtwork(item.id)} description={renderSlot('plugins.item', { view: 'summary' }, { only: item.id })} />
    </li>
  )
}

/** One row as the detail slots see it. */
function rowRef(row: PackageRow): PluginRowRef {
  return { rowId: row.rowId, moduleName: row.moduleName, enabled: row.enabled }
}

/** One bundle as the detail slots see it. */
function packageRef(pkg: PackageView): PluginPackageRef {
  return {
    name: pkg.name,
    ...pkg.version === undefined ? {} : { version: pkg.version },
    installed: pkg.installed,
    availability: pkg.availability,
    official: pkg.official,
    enabled: pkg.enabled,
    rows: pkg.rows.map(rowRef),
  }
}

/**
 * An official plugin's page: the crumb back to the cards, its icon with the
 * contributed actions, its title with the contributed badges over its
 * one-liner, the form the entry renders, and the contributed sections.
 */
function ItemDetail({ item, t, onBack, renderSlot, form }: {
  readonly item: OfficialItem
  readonly t: Translate
  readonly onBack: () => void
  readonly renderSlot: RenderConfig
  readonly form: ConfigPageForm | undefined
}): ReactNode {
  const subject: PluginsSubject = { kind: 'item', id: item.id }
  return (
    <div className={css.detail} data-plugin-item-detail={item.id}>
      <DetailTop
        crumbLabel={t('backToList')}
        crumbText={t('crumbRoot')}
        onBack={onBack}
        icon={itemArtwork(item.id)}
        actions={<div className={css.detailActions}>{renderSlot('plugins.detail.actions', { subject })}</div>}
      />
      <div className={css.detailMain}>
        <div className={css.titleRow}>
          <h3 className={css.detailTitle}>{item.label}</h3>
          {renderSlot('plugins.detail.badge', { subject })}
        </div>
        <p className={css.detailDesc}>{renderSlot('plugins.item', { view: 'summary' }, { only: item.id })}</p>
      </div>
      <div className={css.detailSections}>
        <section className={css.detailSection} data-plugin-config>
          {renderSlot('plugins.item', { view: 'page', form }, { only: item.id })}
        </section>
        {renderSlot('plugins.detail.section', { subject })}
      </div>
    </div>
  )
}

/**
 * A row's configuration page keeps its technical identity beside local package
 * text and the form supplied by its configuration entry.
 */
function RowDetail({ pkg, row, t, resolveText, onBack, renderSlot, form }: {
  readonly pkg: PackageView
  readonly row: PackageRow
  readonly t: Translate
  readonly resolveText: ResolveText
  readonly onBack: () => void
  readonly renderSlot: RenderConfig
  readonly form: ConfigPageForm | undefined
}): ReactNode {
  const { title } = packageText(pkg, resolveText)
  const { title: rowTitle, description } = rowText(row, resolveText)
  const key = rowConfigKey(pkg.name, row.rowId)
  const subject: PluginsSubject = { kind: 'row', pkg: packageRef(pkg), row: rowRef(row) }
  return (
    <div className={css.detail} data-plugin-row-detail={key}>
      <DetailTop
        crumbLabel={t('backToPackage', { name: title })}
        crumbText={title}
        onBack={onBack}
        icon={<PackageArtwork key={row.meta?.icon} src={row.meta?.icon} row size={CARD_ARTWORK_SIZE} />}
        actions={<div className={css.detailActions}>{renderSlot('plugins.detail.actions', { subject })}</div>}
      />
      <div className={css.detailMain}>
        <div className={css.titleRow}>
          <h3 className={css.detailTitle}>{rowTitle}</h3>
          {renderSlot('plugins.detail.badge', { subject })}
        </div>
        {rowTitle === row.rowId ? null : <p className={css.detailName}><code>{row.rowId}</code></p>}
        <p className={css.detailName}><code>{row.moduleName}</code></p>
        <p className={css.detailDesc}>{description ?? renderSlot('plugins.row.config', { view: 'summary' }, { entryKey: key })}</p>
      </div>
      <MetadataError error={row.meta?.error} t={t} />
      <RuntimeError error={row.diagnostic} t={t} />
      <div className={css.detailSections} data-plugin-config>
        {renderSlot('plugins.row.config', { view: 'page', form }, { entryKey: key })}
        {renderSlot('plugins.detail.section', { subject })}
      </div>
    </div>
  )
}

/**
 * One package's page: the crumb back to the list; its icon with its switch
 * and, for a package the profile installed or a selection the Host can remove, uninstall; its title beside its
 * version tag, its beta tag, and its problem or not-running tag; the package name the title
 * stands for; its one-liner; the Host's problem when it reports one; the
 * configuration the bundle registered for itself; its rows with their switches
 * and configure controls, unless the Host reports an error and no rows; and where it comes from.
 */
function PackageDetail({
  pkg, t, resolveText, busy, rowBusy, configured, configure, renderSlot, inMore, versions, detail,
  onBack, onSetEnabled, onUninstall, onUpdate, onSetRowEnabled, onEnsureVersions, onCheckVersions, onUpdateVersion,
}: {
  readonly pkg: PackageView
  /** The package's version check, when one started. */
  readonly versions: VersionCheck | undefined
  /** The bundle's detail document section, shown first among the page's sections. */
  readonly detail: ReactNode
  readonly t: Translate
  readonly resolveText: ResolveText
  readonly busy: boolean
  /** Whether a row has a write in flight. */
  readonly rowBusy: (row: PackageRow) => boolean
  /** Whether the bundle registered a configuration of its own. */
  readonly configured: boolean
  readonly configure: RowConfigure
  readonly renderSlot: RenderConfig
  readonly inMore: boolean
  readonly onBack: () => void
  readonly onSetEnabled: (enabled: boolean) => void
  readonly onUninstall: () => void
  readonly onUpdate: () => void
  readonly onSetRowEnabled: (row: PackageRow, enabled: boolean) => void
  /** Check a package's versions unless a check already started. */
  readonly onEnsureVersions: (packageName: string) => void
  readonly onCheckVersions: () => void
  /** Ask before installing one listed newer version. */
  readonly onUpdateVersion: (version: string) => void
}): ReactNode {
  const { title, description, beta } = packageText(pkg, resolveText)
  const newer = versionUpdate(versions)
  const status = packageStatus(pkg)
  const subject: PluginsSubject = { kind: 'bundle', pkg: packageRef(pkg) }
  return (
    <div className={css.detail} data-plugin-detail={pkg.name}>
      <DetailTop
        crumbLabel={inMore ? t('backToPackage', { name: t('moreTitle') }) : t('backToList')}
        crumbText={t(inMore ? 'moreTitle' : 'crumbRoot')}
        onBack={onBack}
        icon={<PackageArtwork key={pkg.meta?.icon} src={pkg.meta?.icon} />}
        actions={(
          <div className={css.detailActions}>
            {renderSlot('plugins.detail.actions', { subject })}
            {updateAvailable(pkg) ? (
              <Button variant="outline" size="sm" icon={<IconRefreshOutlineRegular size={13} />}
                disabled={busy} aria-label={t('updateLabel', { name: title })} onClick={onUpdate}>
                {t('update')}
              </Button>
            ) : null}
            {newer === undefined ? null : (
              <Button variant="primary" size="sm" icon={<IconRefreshOutlineRegular size={13} />}
                disabled={busy} aria-label={t('versionsUpdateLabel', { version: newer })} onClick={() => { onUpdateVersion(newer) }}>
                {t('versionsUpdateLabel', { version: newer })}
              </Button>
            )}
            {pkg.installed || pkg.removable
              ? (
                <Button
                  variant="outline"
                  size="sm"
                  className={css.danger}
                  icon={<IconTrashOutlineRegular size={13} />}
                  aria-label={t('uninstallLabel', { name: title })}
                  disabled={busy || !pkg.removable || pkg.readOnlyReason !== undefined}
                  onClick={onUninstall}
                >
                  {t('uninstall')}
                </Button>
              )
              : null}
            <EnableSwitch pkg={pkg} title={title} t={t} busy={busy} onSetEnabled={onSetEnabled} />
          </div>
        )}
      />
      <div className={css.detailMain}>
        <div className={css.titleRow}>
          <h3 className={css.detailTitle}>{title}</h3>
          {pkg.version === undefined ? null : <Tag className={css.versionTag} tone="neutral">{t('versionTag', { version: pkg.version })}</Tag>}
          {beta ? <Tag className={css.statusTag} tone="info">{t('statusBeta')}</Tag> : null}
          <StatusTag status={status} t={t} />
          {pkg.availability === 'missing' ? <Tag className={css.statusTag}>{t(pkg.installed ? 'statusMissingFiles' : 'statusNotInstalled')}</Tag> : null}
          {updateAvailable(pkg) || newer !== undefined ? <Tag className={css.statusTag} tone="info">{t('statusUpdateAvailable')}</Tag> : null}
          {renderSlot('plugins.detail.badge', { subject })}
        </div>
        <p className={css.detailName}><code data-plugin-name>{pkg.name}</code></p>
        {description === undefined ? null : <p className={css.detailDesc}>{description}</p>}
      </div>
      <MetadataError error={pkg.meta?.error} t={t} />
      {pkg.error === undefined ? null : <p className={css.reason} role="status">{t('reasonLabel')}: {managementText(pkg.error, t)}</p>}
      {pkg.readOnlyReason === undefined ? null : <p className={css.reason} role="status">{managementText({ code: pkg.readOnlyReason }, t)}</p>}
      <div className={css.detailSections}>
        {detail}
        {configured
          ? (
            <section className={css.detailSection} data-plugin-config>
              {renderSlot('plugins.bundle.config', { view: 'page' }, { entryKey: pkg.name })}
            </section>
          )
          : null}
        {/* A Host error with no rows can mean the Host never read the patch, so the page does not claim the bundle has no components. */}
        {pkg.availability === 'missing' || (pkg.error !== undefined && pkg.rows.length === 0) ? null : (<RowsSection
          rows={pkg.rows}
          t={t}
          resolveText={resolveText}
          toggle={pkg.enabled ? { busy: row => busy || rowBusy(row), onSetEnabled: onSetRowEnabled } : undefined}
          configure={configure}
        />)}
        <VersionSection
          pkg={pkg} check={versions} t={t} busy={busy} onEnsure={onEnsureVersions} onCheck={onCheckVersions} onUpdate={onUpdateVersion}
        />
        <SourceSection pkg={pkg} t={t} />
        {renderSlot('plugins.detail.section', { subject })}
      </div>
    </div>
  )
}

/** Output lines an install run's terminal shows before its middle folds: the first and last six of a long pnpm log. */
const INSTALL_TERMINAL_LINES = 12

/** The install terminal's display copy, from the tab's dictionary. */
function terminalLabels(t: Translate): TerminalBlockLabels {
  return {
    commandLine: line => t('terminalCommandLine', { n: String(line) }),
    /* v8 ignore next -- the Host reports a killed pnpm as a null exit code, never a signal name; the label interface needs one */
    signal: signal => t('terminalSignal', { signal }),
    exitCode: code => t('terminalExitCode', { code: String(code) }),
    noExitCode: t('terminalNoExitCode'),
    running: t('terminalRunning'),
    failed: t('terminalFailed'),
    done: t('terminalDone'),
    copy: t('terminalCopy'),
    copied: t('terminalCopied'),
    noOutput: t('terminalNoOutput'),
    collapseAria: t('terminalCollapseAria'),
    collapse: t('terminalCollapse'),
    expandAria: hidden => t('terminalExpandAria', { n: String(hidden) }),
    expand: hidden => t('terminalExpand', { n: String(hidden) }),
  }
}

/** The sentence under the field for a spec the check refused. */
const INPUT_PROBLEM_KEYS = {
  'invalid-spec': 'installProblemInvalid',
  'already-installed': 'installProblemInstalled',
  'shipped': 'installProblemShipped',
  'not-found': 'installProblemNotFound',
  'not-a-package': 'installProblemNotPackage',
  'not-a-bundle': 'installProblemNotBundle',
  'network': 'installProblemNetwork',
  'unknown': 'installProblemUnknown',
} satisfies Record<InstallInputError['problem'], PluginManagerLocaleKey>

/** One row of the install guide: a spec form's title, its example, and where the person finds it. */
interface GuideExample {
  readonly key: string
  readonly titleKey: PluginManagerLocaleKey
  readonly exampleKey: PluginManagerLocaleKey
  readonly hintKey: PluginManagerLocaleKey
}

/** The spec form the install guide shows, with an example the person can drop into the field. */
const GUIDE_EXAMPLES = [
  { key: 'id', titleKey: 'installGuideIdTitle', exampleKey: 'installGuideIdExample', hintKey: 'installGuideIdHint' },
] as const satisfies readonly GuideExample[]

/** The one-line reading of a classified pnpm failure. */
const FAILURE_KIND_KEYS = {
  'pnpm-missing': 'installFailurePnpmMissing',
  'timeout': 'installFailureTimeout',
  'not-found': 'installFailureNotFound',
  'no-matching-version': 'installFailureNoMatchingVersion',
  'network': 'installFailureNetwork',
  'disk-full': 'installFailureDiskFull',
  'permission': 'installFailurePermission',
  'build-blocked': 'installFailureBuildBlocked',
  'integrity': 'installFailureIntegrity',
  'unknown': 'installFailureGeneric',
} satisfies Record<PluginInstallFailureKind, PluginManagerLocaleKey>

/** The navigation value of the page's own tab; contributed tabs use their registration ids. */
const INSTALLED_TAB = 'installed'

/** The heading of each screen past the spec. */
const SCREEN_TITLE_KEYS = {
  starting: 'installStarting',
  running: 'installingTitle',
  cancelling: 'installCancelling',
  applying: 'installApplying',
  unconfirmed: 'installUnconfirmedTitle',
  unknown: 'installUnknownTitle',
  done: 'installedTitle',
  failed: 'installFailedTitle',
} satisfies Record<Exclude<InstallState['phase'], 'idle' | 'checking'>, PluginManagerLocaleKey>

/** What the spec's kind reads as when the package carries no description of its own. */
const SUBJECT_KIND_KEYS = {
  registry: undefined,
  path: 'installSubjectPath',
  git: 'installSubjectGit',
  tarball: 'installSubjectTarball',
} satisfies Record<InstallSubject['kind'], PluginManagerLocaleKey | undefined>

/** A check no registry answered names every registry asked; any other refusal reads by its problem. */
function inputProblemSentence(problem: InstallInputError, t: Translate, resolved: string | null): string {
  const asked = problem.registries ?? []
  return problem.problem === 'network' && asked.length > 1
    ? t('installProblemNetworkAll', { registries: registryList(asked, t, resolved) })
    : t(INPUT_PROBLEM_KEYS[problem.problem], { reason: problem.reason })
}

/** The registries asked, by name, in the dictionary's list form. */
function registryList(registries: readonly Registry[], t: Translate, resolved: string | null): string {
  return registries.map(registry => registryText(registry, t, resolved).name).join(t('registryListSeparator'))
}

/** An option's name with its host in tertiary text, unless the host is the name. */
function registryOption(registry: Registry, t: Translate, resolved: string | null): ReactNode {
  const { name, host } = registryText(registry, t, resolved)
  return name === host ? name : <>{name}{' '}<span className={css.registryHint}>{host}</span></>
}

/**
 * The failed screen's one line: a pnpm failure by its kind, a refusal by its
 * code, any other failure in the Host's words; the run's output stays behind the details.
 * A run the Host laid at the spec's own host says so; one it laid at a registry
 * names every registry asked when there were several.
 */
function failureText(failure: InstallState['failure'], t: Translate, install?: Pick<InstallState, 'attempts' | 'subject' | 'registries'>): string {
  if (failure === null) return t('installFailureGeneric')
  // A compatibility refusal is the package's own answer, whatever pnpm's exit classified the run as.
  if (failure.code === 'incompatible-version') {
    const incompatible = failure.incompatible === undefined ? {} : { incompatible: failure.incompatible }
    return managementText({ code: failure.code, installing: true, ...incompatible }, t)
  }
  // Blocked scripts the Host could not name leave the person to allow them in the profile's pnpm settings by hand.
  if (failure.kind === 'build-blocked' && !failure.pendingBuilds?.length) return t('installFailureBuildBlockedManual')
  const host = install?.subject?.host
  if (failure.failedAt === 'spec-host' && host !== undefined) return t('installFailureNetworkHost', { host })
  const asked = install?.attempts?.registries ?? []
  if (failure.failedAt === 'registry' && (failure.kind === 'network' || failure.kind === 'timeout') && asked.length > 1) {
    return t('installFailureNetworkAll', { registries: registryList(asked, t, install?.registries?.resolved ?? null) })
  }
  if (failure.kind !== undefined) return t(FAILURE_KIND_KEYS[failure.kind])
  if (failure.code !== undefined) return managementText({ code: failure.code, diagnostic: failure.reason }, t)
  if (failure.reason !== '') return failure.reason
  // An enabled install that failed applying the bundle names that step, never the install command it already finished.
  return failure.stage === 'enable' && failure.enabled === true ? t('installFailedEnabling') : t('installFailureGeneric')
}

interface SubjectLines {
  readonly spec: string
  readonly title: string
  readonly description?: string | undefined
  readonly version?: string | undefined
  /** A confirmed version is named by its tab, so the spec follows as reference text. */
  readonly showSpec: boolean
}

/** The package an install is about: its name, one-liner, version, and, when `showSpec` is set, its spec. */
function SubjectBlock({ lines, t }: { readonly lines: SubjectLines; readonly t: Translate }): ReactNode {
  return (
    <div className={css.subject} data-install-subject={lines.spec}>
      <p className={css.subjectName}>{lines.title}</p>
      {lines.description === undefined ? null : <p className={css.subjectDesc}>{lines.description}</p>}
      {lines.version === undefined ? null : <p className={css.subjectMeta}>{t('installVersion', { version: lines.version })}</p>}
      {lines.showSpec ? <p className={css.subjectSpec}>{lines.spec}</p> : null}
    </div>
  )
}

/** The checked package as the Host read it before installing; a confirmed version keeps its tab's name and version. */
function SubjectCard({ subject, confirmed, t }: {
  readonly subject: InstallSubject
  readonly confirmed: InstallState['confirmed']
  readonly t: Translate
}): ReactNode {
  const kindKey = SUBJECT_KIND_KEYS[subject.kind]
  return (
    <SubjectBlock t={t} lines={{
      spec: subject.spec,
      title: confirmed?.title ?? subject.name ?? subject.spec,
      description: subject.description ?? (kindKey === undefined ? undefined : t(kindKey)),
      version: subject.version ?? confirmed?.version,
      showSpec: confirmed !== undefined,
    }} />
  )
}

/** Track one install field's composition, including Safari's 10ms post-composition Enter window. */
function useInstallComposition(active: boolean) {
  const composition = useRef({ active: false, until: 0 })
  useEffect(() => { composition.current = { active: false, until: 0 } }, [active])
  return {
    onCompositionStart: () => { composition.current.active = true },
    onCompositionEnd: () => { composition.current = { active: false, until: Date.now() + 10 } },
    onBlur: () => { composition.current = { active: false, until: 0 } },
    isComposing: (event: KeyboardEvent) => event.isComposing || Reflect.get(event, 'keyCode') === 229
      || composition.current.active || Date.now() < composition.current.until,
  }
}

/**
 * The install dialog: the spec and its check, then the installing, installed,
 * and failed screens over the same subject card. A failed run that left
 * install scripts undecided shows them for approval in place of plain retry.
 */
function InstallDialog({
  install, t, onClose, onEditSpec, onRun, onCancel, onReconcile, onToggleDetails, onEnableNow, onApproveBuilds,
  onToggleRegistry, onChooseRegistry, onChangeRegistry, onUseGithubMirror,
}: {
  readonly install: InstallState
  readonly t: Translate
  readonly onClose: () => void
  readonly onEditSpec: (text: string) => void
  readonly onRun: () => void
  readonly onCancel: () => void
  readonly onReconcile: () => void
  readonly onToggleDetails: () => void
  readonly onEnableNow: () => void
  readonly onApproveBuilds: () => void
  readonly onToggleRegistry: () => void
  readonly onChooseRegistry: (choice: RegistryChoice) => void
  /** From the failed screen: back to the spec with the registry options unfolded. */
  readonly onChangeRegistry: () => void
  readonly onUseGithubMirror: () => void
}): ReactNode {
  const errorId = useId()
  const templateHintId = useId()
  const guideId = useId()
  const approvalId = useId()
  const registryId = useId()
  const registryErrorId = useId()
  const [guideOpen, setGuideOpen] = useState(false)
  const [customRegistryDraft, setCustomRegistryDraft] = useState('')
  const { phase } = install
  // The registry options float over the dialog from their toggle, so unfolding them never adds to its height;
  // the store folds them when a run starts, so they show at the spec only.
  const registryToggleRef = useRef<HTMLButtonElement | null>(null)
  const registryPanelRef = useRef<HTMLFieldSetElement | null>(null)
  const registryCustomRef = useRef<HTMLInputElement | null>(null)
  const registryShown = install.registryOpen && phase === 'idle'
  const specComposition = useInstallComposition(install.open && phase === 'idle')
  const registryComposition = useInstallComposition(install.open && registryShown)
  const registryAnchorName = `--dsh-registry-${registryId.replaceAll(':', '')}`
  useEffect(() => {
    if (registryShown && install.registryError) registryCustomRef.current?.focus()
  }, [registryShown, install.registryError])
  // The hook only ever asks to close.
  useDismissOnOutsidePointer(registryToggleRef, registryShown, onToggleRegistry, registryPanelRef)
  useEffect(() => {
    if (!registryShown) return
    // Escape folds the options and goes no further: the dialog under them listens for the same key.
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key !== 'Escape') return
      event.stopPropagation()
      onToggleRegistry()
    }
    document.addEventListener('keydown', onKeyDown, true)
    return () => { document.removeEventListener('keydown', onKeyDown, true) }
  }, [registryShown, onToggleRegistry])
  if (githubRecoveryRegistry(install) !== undefined) {
    const anotherWay = asksMirror(install)
    return (
      <Modal
        open={install.open}
        onClose={onClose}
        title={t(install.failure?.kind === 'timeout' ? 'installGithubTimeoutTitle' : 'installGithubFailedTitle')}
        closeLabel={t('close')}
        description={t('installGithubFailedDescription')}
        footer={(
          <>
            <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
            <Button
              variant="primary"
              autoFocus
              onClick={() => {
                // The mirror is already asked, so the form opens with the package-name guide.
                if (anotherWay) setGuideOpen(true)
                onUseGithubMirror()
              }}
            >
              {t(anotherWay ? 'installTryAnotherWay' : 'installUseGithubMirror')}
            </Button>
          </>
        )}
      />
    )
  }
  if ((phase === 'idle' || phase === 'checking') && install.confirmed !== undefined) {
    // A confirmed spec has no form to return to: the dialog names the plugin and version above the spec, with its
    // check, a refusal with a retry, or, after a cancelled run, Install.
    const checking = phase === 'checking'
    const problem = install.inputError
    return (
      <Modal
        open={install.open}
        onClose={onClose}
        title={t(problem === null ? 'installConfirmedTitle' : 'installConfirmedRefused')}
        closeLabel={t('close')}
        className={css.installDialog as string}
        footer={checking ? undefined : (
          <>
            <Button variant="outline" onClick={onClose}>{t('close')}</Button>
            <Button variant="primary" autoFocus onClick={onRun}>{t(problem === null ? 'installRun' : 'retry')}</Button>
          </>
        )}
      >
        <div className={css.installBody} data-install-phase={phase}>
          <SubjectBlock t={t} lines={{ spec: install.spec, ...install.confirmed, showSpec: true }} />
          {checking
            ? <p className={`${css.status} ${css.statusWithDot}`} role="status"><StateDot state="ongoing" />{t('installChecking')}</p>
            : problem === null
              ? null
              : (
                <p className={css.inputError} role="alert">{inputProblemSentence(problem, t, install.registries?.resolved ?? null)}</p>
              )}
        </div>
      </Modal>
    )
  }
  if (phase === 'idle' || phase === 'checking') {
    const checking = phase === 'checking'
    const empty = install.spec.trim() === ''
    const choice = install.registry
    const resolved = install.registries?.resolved ?? null
    const chosenTitle = choice.kind === 'custom' ? t('registryCustom') : registryText(choice.registry, t, resolved).name
    const inputSentence = install.inputError === null ? null : inputProblemSentence(install.inputError, t, resolved)
    const templateHint = install.spec === INSTALL_GIT_EXAMPLE
      ? t('installGitTemplateHint')
      : install.spec === INSTALL_PATH_EXAMPLE ? t('installPathTemplateHint') : null
    return (
      <Modal
        open={install.open}
        onClose={onClose}
        title={t('installTitle')}
        closeLabel={t('close')}
        {...install.mirrorRecovery ? {} : { description: t('installDescription') }}
        className={css.installDialog as string}
        contentClassName={css.installContent as string}
        footer={(
          <div className={css.installFooter}>
            <p className={css.installSafety} role="note">
              <IconWarningOutlineRegular size={14} aria-hidden="true" />
              <span className={css.installSafetyText}>
                <span>{t('installGuideSafety')}</span>
                <span>{t('installUpgradeNotice')}</span>
              </span>
            </p>
            <Button variant="primary" className={css.wide} disabled={checking || empty} aria-busy={checking} onClick={onRun}>
              {checking ? <StateDot state="ongoing" /> : null}
              {t(checking ? 'installChecking' : 'installRun')}
            </Button>
          </div>
        )}
      >
        <div className={css.installBody}>
          <div className={css.installField}>
            <input
              type="text"
              autoFocus={install.mirrorRecovery === true}
              data-modal-autofocus
              value={install.spec}
              placeholder={t('installSpecPlaceholder')}
              disabled={checking}
              aria-label={t(install.mirrorRecovery ? 'installPackageLabel' : 'installSpecLabel')}
              aria-invalid={install.inputError !== null}
              aria-describedby={inputSentence !== null ? errorId : templateHint !== null ? templateHintId : undefined}
              onChange={(event) => { onEditSpec(event.currentTarget.value) }}
              onCompositionStart={specComposition.onCompositionStart}
              onCompositionEnd={specComposition.onCompositionEnd}
              onBlur={specComposition.onBlur}
              onKeyDown={(event) => {
                if (specComposition.isComposing(event.nativeEvent)) return
                if (event.key === 'Enter' && !empty && !checking) onRun()
              }}
            />
          </div>
          {inputSentence === null
            ? null
            : <p id={errorId} className={css.inputError} role="alert">{inputSentence}</p>}
          {inputSentence === null && templateHint !== null
            ? <p id={templateHintId} className={css.templateHint} role="status">{templateHint}</p>
            : null}
          <div className={css.optionsRow}>
            <button
              type="button"
              className={css.guideToggle}
              aria-expanded={guideOpen}
              aria-controls={guideId}
              onClick={() => { setGuideOpen(open => !open) }}
            >
              <IconChevronDownOutlineRegular className={css.guideChevron} aria-hidden="true" />
              <span>{t(guideOpen ? 'installGuideHide' : 'installGuideToggle')}</span>
            </button>
            <button
              ref={registryToggleRef}
              style={{ anchorName: registryAnchorName }}
              type="button"
              className={css.registryToggle}
              aria-expanded={install.registryOpen}
              aria-controls={registryId}
              aria-haspopup="dialog"
              disabled={checking}
              onClick={onToggleRegistry}
            >
              <span>{t('registryToggle')}</span>
              {' '}
              <span className={css.registryChosen}>{chosenTitle}</span>
              <IconChevronDownOutlineRegular className={css.guideChevron} aria-hidden="true" />
            </button>
          </div>
          {guideOpen
            ? (
              <div id={guideId} className={css.guide} data-install-guide>
                <ol className={css.guideList}>
                  {GUIDE_EXAMPLES.map(({ key, titleKey, exampleKey, hintKey }) => (
                    <li key={key} className={css.guideItem}>
                      <div className={css.guideMain}>
                        <span className={css.guideTitle}>{t(titleKey)}</span>
                        <span className={css.guideHint}>{t(hintKey)}</span>
                        <span className={css.guideExample}>
                          <span className={css.guideExampleLabel}>{t('installGuideExampleLabel')}</span>
                          <code>{t(exampleKey)}</code>
                        </span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        aria-label={t('installGuideFillAria', { example: t(exampleKey) })}
                        disabled={checking}
                        onClick={() => { onEditSpec(t(exampleKey)) }}
                      >
                        {t('installGuideFill')}
                      </Button>
                    </li>
                  ))}
                </ol>
              </div>
            )
            : null}
          {registryShown
            ? createPortal(
              <fieldset
                ref={registryPanelRef}
                id={registryId}
                className={css.registry}
                style={{ positionAnchor: registryAnchorName }}
                data-install-registry
                aria-label={t('registryLegend')}
                onKeyDown={(event) => {
                  if (event.key !== 'Tab' || event.ctrlKey || event.altKey || event.metaKey || event.nativeEvent.isComposing) return
                  event.preventDefault()
                  event.stopPropagation()
                  const radio = event.currentTarget.querySelector<HTMLInputElement>('input[type="radio"]:checked')
                  const field = registryCustomRef.current
                  if (event.shiftKey && event.target === field) radio?.focus()
                  else if (!event.shiftKey && event.target !== field) field?.focus()
                  else {
                    onToggleRegistry()
                    registryToggleRef.current?.focus()
                  }
                }}
              >
                {offeredRegistries(install.registries).map((registry) => {
                  const checked = choice.kind === 'offered' && choice.registry === registry
                  return (
                    <label key={registry ?? ''} className={css.registryOption} data-checked={checked}>
                      <input type="radio" name={registryId} checked={checked} onChange={() => {
                        if (choice.kind === 'custom') setCustomRegistryDraft(choice.url)
                        onChooseRegistry({ kind: 'offered', registry })
                      }} />
                      <span className={css.registryTitle}>{registryOption(registry, t, resolved)}</span>
                    </label>
                  )
                })}
                <div className={css.registryOption} data-checked={choice.kind === 'custom'}
                  onClick={(event) => {
                    // Keep label activation from moving focus back to the radio.
                    if (!(event.target instanceof HTMLInputElement)) event.preventDefault()
                    registryCustomRef.current?.focus()
                  }}>
                  <label className={css.registryCustomPick}>
                    <input
                      type="radio"
                      name={registryId}
                      checked={choice.kind === 'custom'}
                      onChange={() => {
                        onChooseRegistry({ kind: 'custom', url: customRegistryDraft })
                        registryCustomRef.current?.focus()
                      }}
                    />
                    <span className={css.registryTitle}><span>{t('registryCustom')}</span></span>
                  </label>
                  <input
                    ref={registryCustomRef}
                    type="text"
                    className={css.registryCustomField}
                    aria-label={t('registryCustom')}
                    placeholder={t('registryCustomPlaceholder')}
                    value={choice.kind === 'custom' ? choice.url : customRegistryDraft}
                    aria-invalid={install.registryError}
                    aria-describedby={install.registryError ? registryErrorId : undefined}
                    onFocus={() => {
                      if (pointerModality() && choice.kind !== 'custom') onChooseRegistry({ kind: 'custom', url: customRegistryDraft })
                    }}
                    onChange={(event) => { onChooseRegistry({ kind: 'custom', url: event.currentTarget.value }) }}
                    onCompositionStart={registryComposition.onCompositionStart}
                    onCompositionEnd={registryComposition.onCompositionEnd}
                    onBlur={registryComposition.onBlur}
                    onKeyDown={(event) => {
                      if (registryComposition.isComposing(event.nativeEvent)) return
                      if (event.key === 'Enter' && !empty) onRun()
                    }}
                  />
                  {install.registryError
                    ? <p id={registryErrorId} className={css.inputError} role="alert">{t('registryCustomInvalid')}</p>
                    : null}
                  <span className={css.registryHint}>{t('registryCustomHint')}</span>
                </div>
              </fieldset>,
              document.body,
            )
            : null}
        </div>
      </Modal>
    )
  }
  const heading = t(phase === 'done' && install.subject?.bundled ? 'installBundledTitle' : SCREEN_TITLE_KEYS[phase])
  const pending = isInstallPending(phase)
  // A settled screen whose install never reported a run can say the details received no terminal output.
  const settledDetails = phase === 'failed' || phase === 'done' || phase === 'unknown'
  const cancellable = phase === 'starting' || phase === 'running' || phase === 'unconfirmed'
  const stoppable = cancellable || phase === 'failed' || phase === 'unknown'
  const failure = install.failure
  const uncertainty = failure?.uncertainty
  const uncertaintyText = failure?.uncertainty === undefined ? null : t(({
    result: 'installResultUnconfirmed',
    cancellation: phase === 'applying' ? 'installApplyingCancellationError' : 'installCancelUnconfirmed',
    acceptance: 'installAwaitingAcceptance',
  } as const)[failure.uncertainty], { reason: failure.reason })
  const pendingBuilds = phase === 'failed' ? install.failure?.pendingBuilds ?? [] : []
  const approvable = pendingBuilds.length > 0
  const firstRun = install.runs[0]
  // The registries the Host asked, once there is more than one: the attempt under way while it runs, a badge on each run.
  const asked = install.attempts !== null && install.attempts.registries.length > 1 ? install.attempts : null
  const current = asked === null ? undefined : asked.registries.at(-1)
  const previous = asked === null ? undefined : asked.registries.at(-2)
  const resolved = install.registries?.resolved ?? null
  const attemptLine = pending && asked !== null && current !== undefined && previous !== undefined
    ? t('installAttempt', {
      previous: registryText(previous, t, resolved).name, registry: registryText(current, t, resolved).name,
      index: String(asked.registries.length), total: String(asked.total),
    })
    : null
  // Another registry is worth offering only for a failure the Host laid at the one it asked.
  const changeable = phase === 'failed' && !approvable && install.failure?.failedAt === 'registry' && install.confirmed === undefined
  const subject = install.subject
  return (
    <Modal open={install.open} onClose={onClose} title={heading} headless className={css.installDialog as string}>
      <div className={css.wizard} data-install-phase={phase}>
        <div className={css.wizardHead}>
          {phase === 'done' || (install.confirmed !== undefined && !pending)
            ? <span />
            : (
              <button type="button" className={css.wizardBack} aria-label={t(install.confirmed !== undefined ? 'cancel' : pending ? 'installCancelAndEdit' : 'installEditAria')}
                disabled={!stoppable} onClick={onCancel}>
                <IconChevronLeftOutlineMedium aria-hidden="true" />
                <span>{t(install.confirmed !== undefined ? 'cancel' : pending ? 'installCancelAndEdit' : 'installEdit')}</span>
              </button>
            )}
          <button
            type="button"
            className={css.wizardClose}
            aria-label={t(cancellable ? 'installCloseCancels' : 'close')}
            onClick={onClose}
          >
            <IconCloseOutlineMedium size={14} />
          </button>
        </div>
        <div className={css.wizardScroll}>
          <div className={css.wizardHero}>
            <span className={css.wizardIcon} data-state={pending ? 'ongoing' : phase === 'done' ? 'done' : 'error'} aria-hidden="true">
              {pending
                ? <StateDot state="ongoing" size={28} />
                : phase === 'done'
                  ? <IconCheckCircleFillRegular size={28} />
                  : <IconWarningOutlineRegular size={28} />}
            </span>
            <h2 className={css.wizardTitle} role={phase === 'failed' ? 'alert' : 'status'}>{heading}</h2>
            {phase === 'done' && subject?.bundled ? <p className={css.wizardSub}>{t('installBundledDescription')}</p> : null}
            {phase === 'failed' ? <p className={css.wizardSub}>{failureText(install.failure, t, install)}</p> : null}
            {phase === 'failed' && failure?.stage === 'enable' && failure.enabled === true
              && (failure.code !== undefined || failure.reason !== '')
              ? <p className={css.wizardSub}>{t('installFailedEnabling')}</p>
              : null}
            {attemptLine === null ? null : <p className={css.wizardSub}>{attemptLine}</p>}
            {uncertaintyText === null ? null : <p className={css.wizardSub} role="alert">{uncertaintyText}</p>}
            {phase === 'unknown' ? <p className={css.wizardSub}>{t('installUnknownDescription')}</p> : null}
          </div>
          {subject === null
            ? null
            : <SubjectCard subject={phase === 'done' && install.installedVersion !== null ? { ...subject, version: install.installedVersion } : subject} confirmed={install.confirmed} t={t} />}
          {approvable
            ? (
              <section className={css.approval} role="group" aria-labelledby={approvalId} data-install-approval>
                <h3 id={approvalId} className={css.approvalTitle}>{t('installApprovalTitle')}</h3>
                <p className={css.approvalText}>{t('installApprovalDescription')}</p>
                <ul className={css.approvalList}>
                  {pendingBuilds.map(name => <li key={name}><code>{name}</code></li>)}
                </ul>
                <p className={css.approvalText}>{t('installApprovalConsequence')}</p>
                <p className={css.approvalCaution}>{t('installApprovalCaution')}</p>
                <Button variant="primary" className={css.wide} onClick={onApproveBuilds}>{t('installApproveAndRetry')}</Button>
              </section>
            )
            : null}
          {phase === 'done' && install.installed === null
            ? <p className={css.result} role="status">{t('installDoneNothing')}</p>
            : null}
          {phase === 'done' && install.restartRequired
            ? <p className={css.resultWarn} role="status">{restartText('installDoneRestart', install.restartReason, t)}</p>
            : null}
          {phase === 'done' && subject?.kind === 'registry' && subject.name !== undefined && subject.version !== undefined
            && install.installedVersion !== null && install.installedVersion !== subject.version
            // A fallback registry can serve another release than the one inspected, so only a single-registry run is explained.
            && (install.attempts?.registries.length ?? 1) === 1
            ? (
              <p className={css.resultWarn} role="status">
                {t('installDoneOtherVersion', {
                  installed: install.installedVersion, version: subject.version, exact: `${subject.name}@${subject.version}`,
                })}
              </p>
            )
            : null}
          {phase === 'done' && install.approvedBuilds.length > 0
            ? <p className={css.result} role="status">{t('installDoneApproved', { names: install.approvedBuilds.join(', ') })}</p>
            : null}
          <div className={css.wizardFoot}>
            {subject?.bundled ? null : (
              <button type="button" className={css.detailsToggle} aria-expanded={install.detailsOpen} onClick={onToggleDetails}>
                <span>{t(install.detailsOpen ? 'installDetailsHide' : 'installDetailsShow')}</span>
                <IconChevronDownOutlineRegular className={css.detailsChevron} aria-hidden="true" />
              </button>
            )}
            {uncertainty === 'result' ? <Button variant="outline" size="sm" className={css.footAction} onClick={onReconcile}>{t('installReconcile')}</Button> : null}
            {pending
              ? (
                <Button variant="outline" size="sm" className={css.footAction} disabled={!cancellable} onClick={onCancel}>
                  {t(phase === 'cancelling' ? 'installCancelling' : 'installCancel')}
                </Button>
              )
              : null}
            {phase === 'failed' && !approvable
              ? (
                <span className={css.wizardActions}>
                  {changeable
                    ? <Button variant="outline" size="sm" className={css.footAction} onClick={onChangeRegistry}>{t('installChangeRegistry')}</Button>
                    : null}
                  <Button variant="primary" size="sm" className={css.footAction} onClick={onRun}>{t('installRetry')}</Button>
                </span>
              )
              : null}
          </div>
          {install.detailsOpen
            ? (
              <div className={css.detailsBody}>
                {firstRun !== undefined
                  ? <p className={css.installLocation}>{t('installLocation', { dir: firstRun.cwd })}</p>
                  : settledDetails
                    ? <p className={css.installLocation}>{t('installDetailsNoOutput')}</p>
                    : null}
                {install.runs.map((run, index) => {
                  const registry = asked?.registries[index]
                  return (
                    <div key={run.jobId} className={css.run}>
                      {registry === undefined
                        ? null
                        : <p className={css.attemptBadge}>{t('installAttemptBadge', { index: String(index + 1), registry: registryText(registry, t, resolved).name })}</p>}
                      <TerminalBlock
                        command={run.command}
                        output={run.output}
                        running={run.exitCode === undefined}
                        exitCode={run.exitCode}
                        maxLines={INSTALL_TERMINAL_LINES}
                        labels={{ ...terminalLabels(t), ...phase === 'cancelling' ? { failed: t('installCancelledShort') } : {} }}
                        className={css.terminal}
                      />
                    </div>
                  )
                })}
                {install.logPath === null
                  ? null
                  : <p className={css.installLocation}>{t('installLogPath', { path: install.logPath })}</p>}
              </div>
            )
            : null}
          {phase !== 'done'
            ? null
            : install.installed !== null && install.subject?.selection === undefined
              ? <Button variant="primary" className={css.wide} disabled={install.enabling} aria-busy={install.enabling} onClick={onEnableNow}>{t('installEnableNow')}</Button>
              : <Button variant="primary" className={css.wide} onClick={onClose}>{t('installClose')}</Button>}
        </div>
      </div>
    </Modal>
  )
}

/** The confirmation an uninstall waits on. */
function ConfirmDialog({ name, t, onConfirm, onCancel }: {
  readonly name: string
  readonly t: Translate
  readonly onConfirm: () => void
  readonly onCancel: () => void
}): ReactNode {
  return (
    <Modal
      open
      onClose={onCancel}
      title={t('confirmUninstallTitle', { name })}
      closeLabel={t('close')}
      description={t('confirmUninstallDescription')}
      footer={(
        <>
          <Button variant="outline" onClick={onCancel}>{t('cancel')}</Button>
          <Button variant="primary" className={css.dangerButton} onClick={onConfirm}>
            {t('confirmUninstall')}
          </Button>
        </>
      )}
    />
  )
}

/** Render the plugin manager: the official plugins and installed bundles, their pages, the install dialog, and the confirmation. */
export function PluginManagerPage(props: PluginManagerPageProps): ReactNode {
  const { t, ensure, renderSlot, resolveText } = props
  const configurations = props.useConfigurations(snapshot => snapshot.view?.namespaces)
  const formFor = (id: string): ConfigPageForm | undefined => {
    if (!configurations?.some(view => view.ns === id)) return undefined
    const form = props.configForm<Record<string, unknown>>(id)
    return { state: form.getSnapshot(), mutate: (ops, revision) => form.mutate(ops, revision) }
  }
  const state = props.usePluginManager(snapshot => snapshot)
  const ledger = props.useConfigLedger(snapshot => snapshot)
  // What is open; a package that leaves the list (uninstalled) drops back to the cards.
  const view = props.useStore(state => state.view), { setView, setTab } = props.actions
  const tabs = props.usePluginTabs(snapshot => snapshot)
  const bundleDetails = props.useBundleDetails(snapshot => snapshot)
  const language = props.useLocale(snapshot => snapshot.active)
  const selectedTab = props.useStore(state => state.tab)
  // A contributed tab that left the ledger falls back to Installed, and stays there when it returns.
  const tab = tabs.some(item => item.id === selectedTab) ? selectedTab : INSTALLED_TAB
  useEffect(() => { if (tab !== selectedTab) setTab(tab) }, [tab, selectedTab, setTab])
  const tabsId = useId()
  const [activation, setActivation] = useState<string | null>(null)
  const [headerRef] = useState(props.createHeaderRef)
  useEffect(() => { ensure() }, [ensure])
  // Installation highlights visible cards without changing the user's current page.
  const { highlight, clearHighlight } = { highlight: state.highlight, clearHighlight: props.clearHighlight }
  useEffect(() => {
    if (highlight === null) return
    const card = document.querySelector(`[data-plugin-package="${highlight}"]`)
    if (card !== null && typeof card.scrollIntoView === 'function') card.scrollIntoView({ block: 'center', behavior: 'smooth' })
    const timer = setTimeout(clearHighlight, HIGHLIGHT_MS)
    return () => { clearTimeout(timer) }
  }, [highlight, clearHighlight])
  const noticeLine = state.notice === null || state.notice.kind === 'refresh-failed' ? null : noticeText(state.notice, t)

  // The page omits profile bundles and persistent terminals. Other installed or offered bundles and
  // unreadable selections remain manageable; Settings' Plugin list inspects the full Host inventory.
  const listed = state.packages.filter(pkg => !HIDDEN_BUNDLES.has(pkg.name)
    && (pkg.listedByDefault !== false || pkg.enabled || pkg.installed || rowsRunning(pkg))
    && (pkg.installed || pkg.official || pkg.error !== undefined))
  const mine = listed.filter(pkg => !pkg.official)
  const official = listed.filter(pkg => pkg.official)
  // Both lists read one order over the eligible bundles: the main list holds the always-held ones plus the held-back
  // ones the profile enabled, and the More list holds the eligible ones, so enabling a bundle from the More list pins it
  // to the main list without moving it among its neighbours there.
  const ordered = orderOptionalBundles(official)
  const pinned = new Set(official.filter(pinnedToMainList).map(pkg => pkg.name))
  const extensions = ordered.filter(pkg => pinned.has(pkg.name))
  const more = ordered
  const loaded = state.status === 'ready' || state.status === 'error'
  const refreshing = state.refreshStatus === 'refreshing'
  const openPkg = view.kind === 'package' || view.kind === 'row'
    ? listed.find(pkg => pkg.name === view.name)
    : undefined
  const openItem = view.kind === 'item' ? ledger.items.find(item => item.id === view.id) : undefined
  const openRow = view.kind === 'row' && openPkg !== undefined ? openPkg.rows.find(row => row.rowId === view.rowId) : undefined
  const onInstalled = tab === INSTALLED_TAB
  const showsCards = !onInstalled || (openPkg === undefined && openItem === undefined)
  const detailFromMore = (view.kind === 'package' || view.kind === 'row')
    && (view.from === 'more' || (openPkg !== undefined && MORE_BUNDLES.includes(view.name) && !pinned.has(view.name)))
  const showsMoreList = onInstalled && showsCards && (view.kind === 'more' || detailFromMore)
  const showsMainList = showsCards && !showsMoreList
  const installedCards = onInstalled && showsCards
  const openPkgInMore = openPkg !== undefined && openPkg.official && detailFromMore
  const returnTab = view.kind === 'package' || view.kind === 'row' ? view.returnTab : undefined
  const backToMore = openPkgInMore && returnTab === undefined
  const pkgOrigin = returnTab !== undefined ? { returnTab } : backToMore ? { from: 'more' as const } : {}
  // The Installed tab's panel, whatever it currently shows; the More list is not a tab panel.
  const installedPanel = tabs.length === 0 || showsMoreList
    ? {}
    : { role: 'tabpanel', id: `${tabsId}-${INSTALLED_TAB}-panel`, 'aria-labelledby': `${tabsId}-${INSTALLED_TAB}` }
  const activated = listed.find(pkg => pkg.name === activation && pkg.enabled && !state.busy.includes(pkg.name))
  const setBundleEnabled = (name: string, enabled: boolean): void => {
    setActivation(enabled ? name : null)
    props.setEnabled(name, enabled)
  }
  const setRowEnabled = (row: PackageRow, enabled: boolean): void => {
    /* v8 ignore next -- a row without a live entry has its switch disabled */
    if (row.entryId !== undefined) props.setRowEnabled(row.entryId, enabled)
  }
  const configure = (pkg: PackageView): RowConfigure => ({
    has: row => ledger.rows.has(rowConfigKey(pkg.name, row.rowId)),
    open: (row) => { setView({ kind: 'row', name: pkg.name, rowId: row.rowId, ...pkgOrigin }) },
  })
  const updates = updatesNote(mine, state.versions, t)
  const updatePkg = state.update === null ? undefined : state.packages.find(pkg => pkg.name === state.update?.packageName)
  const packageBusy = (pkg: PackageView): boolean => bundleBusy(state, pkg.name)
  const packageCard = (pkg: PackageView): ReactNode => (
    <PackageCard
      key={pkg.name}
      pkg={pkg}
      t={t}
      resolveText={resolveText}
      busy={packageBusy(pkg)}
      highlighted={state.highlight === pkg.name}
      newer={versionUpdate(state.versions[pkg.name])}
      onOpen={() => { setActivation(null); setView({ kind: 'package', name: pkg.name, ...showsMoreList ? { from: 'more' } : {} }) }}
      onSetEnabled={(enabled) => { setBundleEnabled(pkg.name, enabled) }}
    />
  )
  const basicCards = ledger.items.map(item => (
    <ItemCard key={`item:${item.id}`} item={item} t={t} renderSlot={renderSlot} onOpen={() => { setView({ kind: 'item', id: item.id }) }} />
  ))
  const renderGroup = (id: 'basic' | 'extensions' | 'bundles', heading: string, cards: readonly ReactNode[]): ReactNode => {
    const offersMore = id === 'extensions' && more.length > 0
    if (cards.length === 0 && !offersMore) return null
    return (
      <section className={css.group} data-plugin-scope="global" data-plugin-group={id}>
        <div className={css.groupHead}>
          <h3 className={css.groupTitle}>{heading}</h3>
          {offersMore ? (
            <Button size="sm" className={css.groupMore} onClick={() => { setView({ kind: 'more' }) }}>
              {t('moreAction')}<IconChevronRightOutlineRegular size={14} aria-hidden="true" />
            </Button>
          ) : null}
        </div>
        {cards.length > 0 ? <ul className={css.cards}>{cards}</ul> : null}
      </section>
    )
  }

  return (
    <section className={css.page} data-plugin-panel aria-busy={state.status === 'loading' || refreshing}>
      {showsMoreList ? (
        <header className={css.moreHead} data-window-drag>
          <Button size="sm" className={css.moreBack} aria-label={t('backToList')} onClick={() => { setView({ kind: 'list' }) }}>
            <IconChevronLeftOutlineMedium size={20} aria-hidden="true" />
          </Button>
          <h1 className={css.pageTitle}>{t('moreTitle')}</h1>
        </header>
      ) : null}
      <div className={css.pageBody} data-plugin-body>
        {showsMainList
          ? (
            <div
              className={`${css.pageBar}${tabs.length > 0 ? ` ${css.pageBarWithTabs}` : ''}`}
              data-plugin-bar
              ref={headerRef}
            >
              <header className={css.pageHead} data-window-drag>
                <div className={css.pageHeading}>
                  <h1 className={css.pageTitle} data-plugin-header-part="title">{t('title')}</h1>
                  <div className={css.pageIntro} data-plugin-header-part="intro">
                    <span>{t('intro')}</span>
                    <Tooltip label={t('infoDescription')} side="bottom" delayMs={300} maxWidth={300} portal openOnClick>
                      <Button variant="ghost" size="sm" className={css.infoButton} aria-label={t('infoLabel')}>
                        <IconInfoOutlineRegular size={11} aria-hidden="true" />
                      </Button>
                    </Tooltip>
                  </div>
                </div>
                <div className={css.toolbar} data-plugin-toolbar data-plugin-header-part="toolbar" hidden={!onInstalled}>
                  {updates === undefined ? null : <span className={css.updatesNote} data-tone={updates.tone}>{updates.text}</span>}
                  <Tooltip label={t('refresh')} delayMs={500} focusDelayMs={500} side="bottom" portal disabled={!loaded || refreshing}>
                    <Button variant="outline" size="sm" className={css.addButton} aria-label={t('refresh')} aria-busy={refreshing}
                      disabled={!loaded || refreshing} onClick={props.refresh}
                      icon={refreshing ? <StateDot state="ongoing" size={13} /> : <IconRefreshOutlineRegular size={13} />}>
                      <span className={css.toolbarLabel}>{t('refresh')}</span>
                    </Button>
                  </Tooltip>
                  {state.install.requestId === undefined
                    ? <AddPluginMenu t={t} disabled={!loaded} openInstall={props.openInstall} renderSlot={renderSlot} />
                    : (
                      <Tooltip label={t('installViewTask')} side="bottom" delayMs={500} focusDelayMs={500} portal disabled={!loaded}>
                        <Button variant="primary" size="sm" className={css.addButton} icon={<IconPlusOutlineRegular size={13} />}
                          aria-label={t('installViewTask')} disabled={!loaded} onClick={props.openInstall}>
                          <span className={css.toolbarLabel}>{t('installViewTask')}</span>
                        </Button>
                      </Tooltip>
                    )}
                </div>
                {tabs.length > 0
                  ? (
                    <div className={css.pageTabs} data-plugin-header-part="tabs">
                      <SegmentedTabs
                        size="sm"
                        className={css.pageTabList}
                        label={t('tabsLabel')}
                        value={tab}
                        onChange={(next) => { setTab(next) }}
                        items={[
                          { value: INSTALLED_TAB, label: t('installedTab'), id: `${tabsId}-${INSTALLED_TAB}`, panelId: `${tabsId}-${INSTALLED_TAB}-panel` },
                          ...tabs.map(item => ({ value: item.id, label: item.label, id: `${tabsId}-${item.id}`, panelId: `${tabsId}-${item.id}-panel` })),
                        ]}
                      />
                    </div>
                  )
                  : null}
              </header>
            </div>
          )
          : null}

        {!onInstalled
          ? (
            <div role="tabpanel" id={`${tabsId}-${tab}-panel`} aria-labelledby={`${tabsId}-${tab}`} className={css.tabPanel}>
              {renderSlot('plugins.tab', {
                install: props.installFrom,
                update: props.openGitUpdate,
                openPackage: (name) => { setTab(INSTALLED_TAB); setView({ kind: 'package', name, returnTab: tab }) },
              }, { only: tab })}
            </div>
          )
          : null}
        {installedCards && !loaded ? (
          <div className={css.installedPanel} {...installedPanel}>
            {state.status === 'loading' ? <ListSkeleton label={t('loading')} /> : null}
            {state.status === 'unavailable' ? (
              <p className={`${css.status} ${css.statusWithDot}`} role="status">
                <StateDot state="idle" />{t('unavailable')}
              </p>
            ) : null}
          </div>
        ) : null}
        {state.notice === null || noticeLine === null
          ? null
          : (
            <Toast
              key={state.notice.seq}
              text={noticeLine}
              icon={<IconWarningOutlineRegular />}
              holdMs={toastHoldMs(noticeLine)}
              onDone={props.dismissNotice}
            />
          )}
        {!showsCards && state.status === 'error' && !refreshing
          ? (
            <div className={css.failure}>
              <p className={css.statusWithDot} role="alert">
                <StateDot state="error" />{t(state.refreshStatus === 'failed' ? 'refreshError' : 'error')}
              </p>
              <Button variant="outline" size="sm" onClick={props.refresh}>{t('retry')}</Button>
            </div>
          )
          : null}
        {onInstalled && loaded && openPkg !== undefined && openRow !== undefined
          ? (
            <RowDetail
              pkg={openPkg}
              row={openRow}
              form={formFor(openRow.rowId)}
              t={t}
              resolveText={resolveText}
              renderSlot={renderSlot}
              onBack={() => { setView({ kind: 'package', name: openPkg.name, ...pkgOrigin }) }}
            />
          )
          : null}
        {onInstalled && loaded && openPkg !== undefined && openRow === undefined
          ? (
            <PackageDetail
              pkg={openPkg}
              t={t}
              resolveText={resolveText}
              busy={packageBusy(openPkg)}
              rowBusy={row => row.entryId !== undefined && state.busy.includes(rowKey(row.entryId))}
              configured={ledger.bundles.has(openPkg.name)}
              configure={configure(openPkg)}
              renderSlot={renderSlot}
              inMore={backToMore}
              detail={(
                <BundleDetailSection name={openPkg.name} version={openPkg.version} fromNpm={openPkg.availability === 'missing'}
                  language={language} details={bundleDetails} t={t}
                  load={props.loadDetail} retry={props.retryDetail} image={props.detailImage} />
              )}
              onBack={() => {
                if (returnTab !== undefined) setTab(returnTab)
                setView({ kind: backToMore ? 'more' : 'list' })
              }}
              onSetEnabled={(enabled) => { setBundleEnabled(openPkg.name, enabled) }}
              onUninstall={() => { props.uninstall(openPkg.name) }}
              onUpdate={() => { props.update(openPkg.name) }}
              onSetRowEnabled={setRowEnabled}
              versions={state.versions[openPkg.name]}
              onEnsureVersions={props.ensureVersions}
              onCheckVersions={() => { props.checkVersions(openPkg.name) }}
              onUpdateVersion={(version) => { props.openUpdate(openPkg.name, version) }}
            />
          )
          : null}
        {onInstalled && loaded && openItem !== undefined
          ? <ItemDetail form={formFor(openItem.id)} item={openItem} t={t} renderSlot={renderSlot} onBack={() => { setView({ kind: 'list' }) }} />
          : null}
        {loaded && installedCards
          ? basicCards.length === 0 && official.length === 0 && mine.length === 0 && state.status !== 'error'
            ? <div className={css.installedPanel} {...installedPanel}><p className={css.empty}>{t('empty')}</p></div>
            : (
              <div className={css.installedPanel} {...installedPanel}>
                {showsMoreList ? (
                  <section className={css.group} data-plugin-scope="global" data-plugin-group="more">
                    <ul className={css.cards}>{more.map(packageCard)}</ul>
                  </section>
                ) : (
                  <>
                    {renderGroup('basic', t('basicTitle'), basicCards)}
                    {renderGroup('extensions', t('extensionsTitle'), extensions.map(packageCard))}
                    {renderGroup('bundles', t('bundlesTitle'), mine.map(packageCard))}
                  </>
                )}
                {/* A failed package read trails the groups it left incomplete: right under the groups on a
                    first-load failure, and after the kept cards when a refresh fails over stale data. */}
                {state.status === 'error' && !refreshing
                  ? (
                    <div className={css.failure}>
                      <p className={css.statusWithDot} role="alert">
                        <StateDot state="error" />{t(state.refreshStatus === 'failed' ? 'refreshError' : 'error')}
                      </p>
                      <Button variant="outline" size="sm" onClick={props.refresh}>{t('retry')}</Button>
                    </div>
                  )
                  : null}
              </div>
            )
          : null}
        {onInstalled && activated !== undefined && !state.install.open
          ? renderSlot('plugins.bundle.activation', {
            packageName: activated.name,
            onDismiss: () => { setActivation(null) },
            onOpenDetails: () => {
              setActivation(null)
              setView({ kind: 'package', name: activated.name, ...showsMoreList ? { from: 'more' } : {} })
            },
          }, { entryKey: activated.name }) : null}
      </div>
      {state.update === null ? null : (
        <UpdateDialog
          update={state.update}
          title={updatePkg === undefined ? state.update.packageName : packageText(updatePkg, resolveText).title}
          t={t}
          onRun={props.runUpdate}
          onClose={props.closeUpdate}
          onToggleOutput={props.toggleUpdateOutput}
        />
      )}
      <InstallDialog
        install={state.install}
        t={t}
        onClose={props.closeInstall}
        onEditSpec={props.editInstallSpec}
        onRun={props.runInstall}
        onCancel={props.cancelInstall}
        onReconcile={props.reconcileInstall}
        onToggleDetails={props.toggleInstallDetails}
        onEnableNow={() => { setActivation(state.install.installed); props.enableInstalled() }}
        onApproveBuilds={props.approveBuildsAndRetry}
        onToggleRegistry={props.toggleRegistryOptions}
        onChooseRegistry={props.chooseRegistry}
        onChangeRegistry={props.changeRegistry}
        onUseGithubMirror={props.useGithubMirror}
      />
      {state.confirm === null
        ? null
        : (
          <ConfirmDialog
            name={packageText(
              state.packages.find(pkg => pkg.name === state.confirm?.packageName) ?? { name: state.confirm.packageName },
              resolveText,
            ).title}
            t={t}
            onConfirm={props.confirm}
            onCancel={props.cancelConfirm}
          />
        )}
    </section>
  )
}
