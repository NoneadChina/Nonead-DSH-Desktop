import type { ContextMenuTriggerProps } from '@deepseek-ai/dsh-client-ui-context-menu/client';
/** File identity, Sidebar preview, and contributed native actions for one delivery. */
import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { PresentedHost } from '../presented.ts';
import type { PresentedOpenPhase } from './present-open.ts';
import { type PresentedPath } from './turn-deliverables.ts';
import type { NS } from './locales.ts';
/**
 * Render independent file actions without nesting buttons inside a clickable card.
 * @param props - durable file metadata, Sidebar preview, Host capabilities, gesture status, and localized copy.
 * @returns the file card and its anchored action menu.
 */
export declare function PresentedFileCard({ file, cwd, phase, host, onPreview, contextMenuProps, actions, t }: {
    file: PresentedPath;
    cwd: string | undefined;
    phase: PresentedOpenPhase | undefined;
    host: PresentedHost | null;
    onPreview: () => void;
    contextMenuProps: ContextMenuTriggerProps;
    actions: ReactNode;
} & PropsLocale<typeof NS>): import("react").JSX.Element;
//# sourceMappingURL=PresentedFileCard.d.ts.map