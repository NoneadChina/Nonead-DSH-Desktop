/** Native directory reveal contributed to the captured Session's structured menu. */
import type { Context } from '@deepseek-ai/cordis';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { OpenInAppController } from './controller.ts';
import type { OpenInAppToastSource } from './open-toast.tsx';
/**
 * Share directory availability and launch feedback with the existing application controls.
 * @param ctx - owning plugin context.
 * @param controller - directory application catalog and launcher.
 * @param t - localized action and failure labels.
 * @param report - native operation feedback shared with the application controls.
 */
export declare function registerSessionReveal(ctx: Context, controller: OpenInAppController, t: PropsLocale<'open-in-app'>['t'], report: OpenInAppToastSource['report']): void;
//# sourceMappingURL=session-reveal.d.ts.map