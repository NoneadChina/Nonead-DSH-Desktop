/** GitHub GraphQL documents and their mapping into provider-neutral results. */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { ChangeRequestKey, ChangeRequestRef, ChangeRequestSnapshot, ForgeCheckId, ForgeFailure, ForgeRepository } from '@deepseek-ai/dsh-experimental-forge';
import { z } from 'zod';
/** Continue reading the same commit's rollup even if the pull request head moves. */
export declare const CHECKS_QUERY = "query($id: ID!, $cursor: String!) {\n  node(id: $id) { ... on StatusCheckRollup { contexts(first: 100, after: $cursor) { pageInfo { hasNextPage endCursor }\n  nodes {\n    __typename\n    ... on CheckRun {\n      id databaseId name status conclusion detailsUrl startedAt completedAt\n      checkSuite { app { id } workflowRun { databaseId event workflow { id name } } }\n    }\n    ... on StatusContext { context state targetUrl createdAt }\n  } } } }\n}";
/** Continue counting a pull request's review threads; variables `id`, `cursor`, and the integer `first`. */
export declare const THREADS_QUERY = "query($id: ID!, $cursor: String!, $first: Int!) {\n  node(id: $id) { ... on PullRequest { reviewThreads(first: $first, after: $cursor) { pageInfo { hasNextPage endCursor } nodes { isResolved } } } }\n}";
/** Head-branch lookup; variables `owner`, `name`, and `branch` are passed as strings. */
export declare const HEAD_QUERY = "query($owner: String!, $name: String!, $branch: String!) {\n  repository(owner: $owner, name: $name) {\n    defaultBranchRef { name }\n    pullRequests(headRefName: $branch, states: OPEN, first: 20, orderBy: { field: CREATED_AT, direction: DESC }) { nodes { number isCrossRepository } }\n  }\n}";
/** Head and base commits of one pull request; variables `owner` and `name` are strings, `number` is an integer. */
export declare const PULL_REQUEST_COMMITS_QUERY = "query($owner: String!, $name: String!, $number: Int!) {\n  repository(owner: $owner, name: $name) { pullRequest(number: $number) { headRefOid baseRefOid } }\n}";
declare const checkPageSchema: z.ZodObject<{
    pageInfo: z.ZodObject<{
        hasNextPage: z.ZodBoolean;
        endCursor: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    nodes: z.ZodArray<z.ZodUnknown>;
}, z.core.$strip>;
declare const threadPageSchema: z.ZodObject<{
    pageInfo: z.ZodObject<{
        hasNextPage: z.ZodBoolean;
        endCursor: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    nodes: z.ZodArray<z.ZodObject<{
        isResolved: z.ZodBoolean;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One validated connection page or a failure that prevents publishing a partial count. */
export type PageResult<T> = {
    readonly ok: true;
    readonly page: T;
} | {
    readonly ok: false;
    readonly failure: ForgeFailure;
};
/** One validated page of check contexts or a failure that prevents publishing a partial count. */
export type CheckPageResult = PageResult<z.infer<typeof checkPageSchema>>;
/** One validated page of review threads or a failure that prevents publishing a partial count. */
export type ThreadPageResult = PageResult<z.infer<typeof threadPageSchema>>;
/** Opaque GitHub node id that pins check pagination to one commit's rollup. */
type RollupId = Branded<'GitHubStatusCheckRollupId'>;
/** Opaque GitHub node id of a pull request. */
type PullRequestId = Branded<'GitHubPullRequestId'>;
/** Continuation reads that complete one snapshot response. */
export interface SnapshotPages {
    /** Read the next page of a pull request's review threads, holding at most `first` threads. */
    readonly threads: (id: PullRequestId, cursor: string, first: number) => Promise<ThreadPageResult>;
    /** Read the next check page of a rollup; omission keeps the first check page with its truncation flag. */
    readonly checks?: (id: RollupId, cursor: string) => Promise<CheckPageResult>;
}
/**
 * Distinguish GraphQL response fields from HTTP error bodies.
 * @param body - parsed JSON returned by GitHub.
 * @returns whether the object carries GraphQL data or errors; field validation remains with the query mapper.
 */
export declare function hasGraphqlFields(body: unknown): boolean;
/** One batched snapshot query and the change request behind each alias. */
export interface SnapshotQuery {
    /** GraphQL document with one aliased field per change request. */
    readonly document: string;
    /** Change requests keyed by alias path `r<i>.p<j>`. */
    readonly targets: ReadonlyMap<string, ChangeRequestRef>;
    /** Most review threads counted per change request. */
    readonly maxReviewThreads: number;
}
/**
 * Build one query that reads every change request in `refs`, grouping them by
 * repository. Owners, names, and numbers are validated before they are inlined.
 * @param refs - change requests on one host.
 * @param maxReviewThreads - positive integer bound on the review threads counted per change request.
 * @returns the document and its alias targets.
 * @throws when an owner, name, or number cannot be inlined safely.
 */
export declare function snapshotQuery(refs: readonly ChangeRequestRef[], maxReviewThreads: number): SnapshotQuery;
/**
 * Map a snapshot response, including GitHub's partial-error form, into one
 * result per alias target. Path-scoped errors apply to their repository or
 * pull request; errors without a path apply to every unresolved target. A
 * repository without readable merge settings offers no merge. Review threads
 * are counted across pages up to `query.maxReviewThreads`. Polling returns
 * the first check page; an explicit detail read can complete its pagination.
 * A continuation page that fails or does not advance fails its target.
 * @param body - parsed JSON printed by `gh api graphql`.
 * @param query - the query that produced the response.
 * @param pages - continuation reads of review threads and, for a detail read, of checks on the same commit.
 * @returns a snapshot with its check and thread truncation flags, or a failure, for every target.
 */
export declare function mapSnapshotResponse(body: unknown, query: SnapshotQuery, pages: SnapshotPages): Promise<Map<ChangeRequestKey, ChangeRequestSnapshot | ForgeFailure>>;
/**
 * Validate a continuation response before adding its checks to the snapshot.
 * @param body - parsed GraphQL response for a rollup node.
 * @returns the complete page or a failure; partial-error pages are not accepted.
 */
export declare function mapCheckPageResponse(body: unknown): CheckPageResult;
/**
 * Validate a continuation response of {@link THREADS_QUERY} before counting its review threads.
 * @param body - parsed GraphQL response for a pull request node.
 * @returns the complete page or a failure; partial-error pages are not accepted.
 */
export declare function mapThreadPageResponse(body: unknown): ThreadPageResult;
/** Head and base commits of a pull request as one read of {@link PULL_REQUEST_COMMITS_QUERY} named them. */
export interface PullRequestCommits {
    /** Commit at the head of the pull request. */
    readonly head: string;
    /** Commit of the base branch GitHub recorded with that head, whose merge base with it starts the pull request's diff. */
    readonly base: string;
}
/**
 * Map a read of {@link PULL_REQUEST_COMMITS_QUERY}.
 * @param body - parsed JSON printed by `gh api graphql`.
 * @returns both commits, or undefined when the response does not name them as full commit object names.
 */
export declare function mapPullRequestCommitsResponse(body: unknown): PullRequestCommits | undefined;
/**
 * Map a head-branch lookup of {@link HEAD_QUERY}, which selects open pull requests, into change requests.
 * @param body - parsed JSON printed by `gh api graphql`.
 * @param repository - repository that was queried.
 * @param branch - head branch that was queried.
 * @returns open non-fork change requests for `branch`, or none when it is the default branch.
 * @throws when the response is malformed or the repository is not visible.
 */
export declare function mapHeadResponse(body: unknown, repository: ForgeRepository, branch: string): ChangeRequestRef[];
/**
 * Read the workflow run database id from a check's rerun identity.
 * @param id - identity a snapshot of this provider named.
 * @returns the workflow run id, or undefined for an identity this provider did not build.
 */
export declare function actionsRunOf(id: ForgeCheckId): number | undefined;
export {};
//# sourceMappingURL=graphql.d.ts.map