/** Connect retained application objects to the calling program's current logged tool binding. */
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { CuaApi, CuaOperation } from './types.ts';
/** Standard tools.cua binding; its image content is admitted by the host tool pipeline. */
export type CuaToolBinding = (operation: CuaOperation) => Promise<JsonValue>;
/**
 * Connect the object API without owning an evaluator or its lifetime.
 * @param getTool - Resolves the current execution's tools.cua binding on every operation; do not capture a completed execution's binding.
 * @param onText - Optional text output captured by the caller's execution environment.
 * @returns Application and window objects using the current tool binding. Rejections propagate without retries.
 */
export declare function connectCua(getTool: () => CuaToolBinding, onText?: (text: string) => void | Promise<void>): CuaApi;
//# sourceMappingURL=bridge.d.ts.map