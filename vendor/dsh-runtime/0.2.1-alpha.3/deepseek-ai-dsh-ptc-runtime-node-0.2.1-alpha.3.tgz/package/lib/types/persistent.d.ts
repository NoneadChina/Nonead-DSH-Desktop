import { Context } from '@deepseek-ai/cordis';
import type { PtcRunRequest, PtcRunSpec, PtcRunResult } from '@deepseek-ai/dsh-ptc-runtime';
import type { PolicyProcesses } from './policy-processes.ts';
import type { ResolvedConfig } from './config.ts';
/** Sandboxed, best-effort retained state; restart, disposal, and interrupted execution clear it. */
export declare class InMemoryExecution {
    private readonly ctx;
    private readonly config;
    private readonly processes;
    /**
     * Model-facing rules for retained variables, authority, output, and recovery.
     * @returns Usage guidance appended to the run_code schema.
     */
    get executionInstructions(): string;
    private readonly owners;
    private readonly kernels;
    private disposed;
    /**
     * Own retained execution resources under the existing Node provider.
     * @param ctx - Provider lifecycle and execution services.
     * @param config - Validated limits and selected executable.
     * @param processes - Provider-owned policy invalidation and cleanup.
     */
    constructor(ctx: Context, config: ResolvedConfig, processes: PolicyProcesses);
    /**
     * Resolve the file policy, directory and deadline for a retained REPL.
     * @param request - Program, bindings, owner, directory and elapsed budget.
     * @returns Resolved inputs with the selected file policy.
     */
    resolve(request: PtcRunRequest): PtcRunSpec;
    /**
     * Evaluate statements using this owner's process, or a temporary process without an owner.
     * @param spec - Resolved request; concurrent calls for one owner are rejected.
     * @returns Logs, a final JSON expression, or a structured execution failure.
     */
    run(spec: PtcRunSpec): Promise<PtcRunResult>;
    /**
     * Release retained state and await its process cleanup.
     * @param owner - Exact object supplied to run.
     * @returns Completion after the owned process and output streams stop.
     */
    release(owner: object): Promise<void>;
}
//# sourceMappingURL=persistent.d.ts.map