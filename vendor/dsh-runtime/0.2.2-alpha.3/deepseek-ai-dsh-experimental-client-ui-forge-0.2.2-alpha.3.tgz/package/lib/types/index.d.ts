/** Host Remote of the forge panel: checkout, code host, sign-in, change request, and worktree state per Session. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ChangeRequestSnapshot, ForgeReviewRequest, ForgeReviewResult, MergeMethod } from '@deepseek-ai/dsh-experimental-forge';
import type { Session } from '@deepseek-ai/dsh-session';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Config, ForgeBranches, ForgeChangeRequestDiff, ForgeChangeRequestStatesFrame, ForgeLocalDiff, ForgeLocalScope, ForgePanelState } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Remote that serves the forge panel of the GUI. */
        forgePanel: ForgePanelController;
    }
}
/**
 * Serves the forge panel. Following a Session inspects the checkout of its
 * current directory using the Session's permissions and execution world, recognizes the
 * code host of the upstream remote or `origin`, probes sign-in for that host,
 * and polls the Session's bound change requests through `ctx.forge` until the
 * last follower of that Session leaves. A worktree request makes the panel
 * create a branch and checkout through an optional `ctx.worktrees` and enter
 * it while the Session's first message waits in the inbox, or at the first
 * step proposal of a message no wait took. After a failed or stopped attempt
 * the message keeps waiting for another attempt or for the request to be
 * withdrawn. A message also waits while the worktree the Session works in is
 * gone, until that worktree is checked out again or left for the source
 * checkout. Changes to a Session's checkout run as Agent maintenance, so a
 * message that arrives meanwhile waits for them.
 */
export declare class ForgePanelController extends TypertRemoteService {
    static inject: string[];
    static Config: z<Config>;
    private readonly home;
    private readonly config;
    private readonly panels;
    private worktreeStates;
    private creations;
    private readonly patches;
    private states;
    private readonly stopPanels;
    private readonly stopStates;
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    /**
     * Stream the panel state of a Session: the current state first, then each
     * later state. Intermediate states may be skipped when the reader is slower
     * than the updates. The stream ends when `signal` aborts or the Remote stops.
     * @param session - Session to follow.
     * @param signal - ends the stream.
     * @returns panel states in publication order.
     */
    follow(session: Session, signal: AbortSignal): AsyncIterable<ForgePanelState>;
    /**
     * Stream the last known state of every change request that a listed
     * Session the caller may read binds: the stored states first, then each
     * state a poll changes or a new binding reveals. Listing reads no Session
     * log: loaded Sessions report their bindings, others the cached Session
     * summary, and a Session without one shows nothing until it is opened.
     * Closed requests are polled at the idle cadence so reopening is observed. The
     * stream ends when `signal` aborts or the Remote stops.
     * @param signal - ends the stream.
     * @returns frames in publication order.
     * @throws when the Host lacks the Session query, projection cache, storage, or Session store service.
     */
    changeRequestStates(signal: AbortSignal): AsyncIterable<ForgeChangeRequestStatesFrame>;
    /**
     * List the local branches that can start a worktree of the Session's current checkout.
     * @param session - Session whose current directory is listed.
     * @param signal - request cancellation.
     * @returns the checked-out branch and at most `maxBranches` local branches, the checked-out one first.
     * @throws when the current directory is not inside a checkout or Git fails.
     */
    branches(session: Session, signal: AbortSignal): Promise<ForgeBranches>;
    /**
     * Bind a change request to a Session by URL, or restore a dismissed binding.
     * @param session - Session that receives the binding.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no registered provider serves the URL.
     */
    track(session: Session, url: string, signal: AbortSignal): Promise<void>;
    /**
     * Hide a visible binding of a Session; other URLs leave the Session unchanged.
     * @param session - Session that owns the binding.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     */
    dismiss(session: Session, url: string, signal: AbortSignal): Promise<void>;
    /**
     * Reinspect a followed Session's checkout, probe sign-in again, and poll its
     * change requests at once; an unfollowed Session is unchanged.
     * @param session - Session whose panel refreshes.
     * @param signal - request cancellation.
     * @returns settles once the inspection and the sign-in probe have ended; poll results reach the panel stream later.
     */
    refresh(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Read the changes one scope covers in the checkout of the Session's
     * current directory, with Git using the Session's sandbox policy.
     * @param session - Session whose checkout is read.
     * @param scope - which changes to read.
     * @param signal - request cancellation.
     * @returns the files, the base of the `branch` scope, and the untracked files left out.
     * @throws `forgePanel/not-a-checkout` outside a checkout; `forgePanel/no-fork-point` for the `branch`
     * scope of a checkout without one; `forgePanel/filter-config-failed` when filter configuration cannot be read
     * completely, before any comparison; `forgePanel/diff-too-large` over `maxDiffBytes`; the Git error when Git fails.
     */
    localDiff(session: Session, scope: ForgeLocalScope, signal: AbortSignal): Promise<ForgeLocalDiff>;
    /**
     * Read the new side of one changed file in a scope, which supplies the
     * unchanged lines between its hunks: the index for `staged`, else the working tree.
     * @param session - Session whose checkout is read.
     * @param scope - the scope the diff was read in.
     * @param path - path relative to the checkout's top-level directory, as the diff names it.
     * @param signal - request cancellation.
     * @returns the text.
     * @throws `forgePanel/not-a-checkout` outside a checkout; `forgePanel/diff-too-large` over `maxDiffBytes`;
     * an error for a path outside the checkout, binary content, or a failed read.
     */
    localText(session: Session, scope: ForgeLocalScope, path: string, signal: AbortSignal): Promise<string>;
    /**
     * Load complete checks for the change request whose list the user opened.
     * @param session - Session retaining the visible binding.
     * @param url - binding URL.
     * @param headSha - commit displayed by the card; a different head rejects the result.
     * @param signal - cancellation when the list closes.
     * @returns the complete snapshot at the displayed head.
     * @throws `forgePanel/not-bound` for an invisible binding, `forgePanel/stale-head` for a moved head,
     * or `forgePanel/checks-failed` when the provider cannot complete the read.
     */
    changeRequestChecks(session: Session, url: string, headSha: string, signal: AbortSignal): Promise<ChangeRequestSnapshot>;
    /**
     * Read the changes of a change request of a Session as its code host
     * computes them, at the head commit of its latest status. A patch already
     * read at the same head commit and base branch is reused from memory, for
     * any Session, until `maxCachedDiffBytes` evicts it.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param signal - request cancellation.
     * @returns the files, the head commit, each file's web page, and the commits the checkout has beyond the head.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/diff-too-large` when the host or its provider refuses the diff over a size limit;
     * `forgePanel/diff-failed` before its status was read and when the host does not provide the diff otherwise.
     */
    changeRequestDiff(session: Session, url: string, signal: AbortSignal): Promise<ForgeChangeRequestDiff>;
    /**
     * Read one file of a change request's repository at a commit, which
     * supplies the unchanged lines between the hunks of its diff.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param commit - commit object name, the head commit of the diff.
     * @param path - path relative to the repository root.
     * @param signal - request cancellation.
     * @returns the text.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/diff-too-large` when the host or its provider refuses the file over a size limit;
     * `forgePanel/diff-failed` when the host does not provide the file otherwise.
     */
    changeRequestText(session: Session, url: string, commit: string, path: string, signal: AbortSignal): Promise<string>;
    /**
     * Publish a line comment or completed review for a visible Session binding.
     * @param session - Session retaining the change request.
     * @param url - visible binding URL.
     * @param request - reviewed head, ranges, plain text, and explicit review decision.
     * @param signal - request cancellation.
     * @returns confirmed publication or a typed failure; unknown outcomes require reconciliation on the host.
     */
    submitReview(session: Session, url: string, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Mark a draft change request of a Session ready for review; the change
     * request is polled again once the host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/action-failed` with the host's reason when the host refuses or cannot be reached.
     */
    markReady(session: Session, url: string, signal: AbortSignal): Promise<void>;
    /**
     * Merge a change request of a Session while its head is still `headSha`;
     * the change request is polled again once the host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param method - how the commits enter the base branch.
     * @param headSha - head commit the user confirmed.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the head moved past `headSha`; `forgePanel/action-failed` with the host's
     * reason when the host refuses otherwise or cannot be reached.
     */
    merge(session: Session, url: string, method: MergeMethod, headSha: string, signal: AbortSignal): Promise<void>;
    /**
     * Ask for a new worktree before the Session's first turn, replacing an open
     * request and forgetting a failed attempt. While the next message waits in
     * the inbox, or else at the first step proposal, the panel creates a branch
     * from `from`, or from HEAD of the current checkout when it is null, and
     * enters its checkout. A message that already waits after a failed or
     * stopped attempt keeps waiting for {@link ForgePanelController.retryWorktree}.
     * @param session - Session without a started turn.
     * @param from - local base branch, or null for HEAD.
     * @param signal - request cancellation.
     * @throws `forgePanel/invalid-branch` when `from` is empty; `forgePanel/worktrees-unavailable`
     * without a worktree service; `forgePanel/session-started` after a turn started or the worktree was
     * created; `forgePanel/session-busy` while the worktree is being created.
     */
    requestWorktree(session: Session, from: string | null, signal: AbortSignal): Promise<void>;
    /**
     * Withdraw the open worktree request of a Session with its failed attempt,
     * which lets a waiting message go on in the current checkout; without a
     * request the Session is unchanged. Withdrawing needs no worktree service.
     * @param session - Session without a started turn.
     * @param signal - request cancellation.
     * @throws `forgePanel/session-started` after a turn started or the worktree was created;
     * `forgePanel/session-busy` while the worktree is being created.
     */
    cancelWorktree(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Stop the creation a message of the Session waits for; the message keeps
     * waiting with the request still open. Without such a creation the Session
     * is unchanged.
     * @param session - Session whose creation stops.
     * @param signal - request cancellation.
     */
    stopCreation(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Make another attempt, with a new branch name, at the worktree a message
     * of the Session waits for after a failed or stopped attempt.
     * @param session - Session whose message waits.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-waiting` when no message waits or an attempt is running.
     */
    retryWorktree(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Check out the created worktree of a Session again at its recorded
     * directory when that directory is gone: its branch when the branch still
     * exists, otherwise a new branch of the same name at the base commit. Changes
     * that were never committed are not recovered. Runs as Agent maintenance,
     * inside the wait of a message that waits for the restoration, which then
     * goes on; without a missing directory the Session is unchanged.
     * @param session - Session whose worktree directory is gone.
     * @param signal - request cancellation, which aborts the restoration.
     * @throws `forgePanel/no-worktree` without a created worktree; `forgePanel/worktrees-unavailable`
     * without a worktree service; `forgePanel/session-busy` while the Session's Agent is not loaded or
     * has other work; `forgePanel/restore-failed` when Git fails.
     */
    restoreWorktree(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Move a Session from its created worktree to the source checkout the
     * worktree came from; the Session no longer works in the worktree. Runs as
     * Agent maintenance, inside the wait of a message that waits for the removed
     * worktree, which then goes on.
     * @param session - Session with a created worktree.
     * @param signal - request cancellation.
     * @throws `forgePanel/no-worktree` without a created worktree; `forgePanel/session-busy` while the
     * Session's Agent is not loaded or has other work; the working-directory service's error when the
     * source checkout no longer exists.
     */
    continueInProject(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Hold the turn of a message entering a Session's inbox while the
     * Session's requested worktree does not exist yet, or while the worktree
     * the Session works in is checked and, when gone, until it is restored or
     * left. The message is entering, so the delivery has not woken the Agent
     * yet and its wake waits for the hold.
     * @param agent - Agent whose inbox receives the message.
     */
    private holdTurn;
    /**
     * Check whether the worktree the Session works in is gone.
     * @param session - Session to check.
     * @param signal - cancellation of the check.
     * @returns the missing worktree, or null while it exists or once the Session works elsewhere.
     * @throws when the filesystem or Git cannot answer.
     */
    private missingFor;
    /** Inspect the checkout of the Session's current directory, which local diffs read. */
    private checkoutOf;
    /** A visible binding of the Session that a provider serves, which actions and reads are limited to. */
    private bound;
    private worktreeState;
    private editableWorktree;
    /** The worktree state of a Session whose request may still change: no turn started, nothing created, and no attempt running. */
    private changeableWorktree;
    private createdWorktree;
    /**
     * Run work as maintenance of the Session's Agent: inside the wait of a
     * message that waits for the removed worktree, else as a task of its own,
     * which the Agent refuses while it has other work.
     */
    private maintain;
    /** The shared change request states, created for the first stream from the Host's Session and storage services. */
    private changeRequestStatesHub;
    private panelOf;
}
export default ForgePanelController;
//# sourceMappingURL=index.d.ts.map