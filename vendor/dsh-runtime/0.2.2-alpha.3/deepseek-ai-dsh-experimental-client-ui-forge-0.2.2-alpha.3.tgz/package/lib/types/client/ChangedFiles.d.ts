/** Changed-file navigation shared by the toolbar menu and wide diff pane, with a disclosure column on every row. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeDiffFile } from '../types.ts';
import type { NS } from './locales.ts';
/** Viewing choices remain owned by the changes tab while either navigation surface is hidden. */
export interface ChangedFilesState {
    readonly query: string;
    readonly collapsed: Readonly<Record<string, boolean>>;
    readonly selected: string | null;
}
/** Data and actions of the changed-file navigator. */
export interface ChangedFilesProps extends PropsLocale<typeof NS> {
    readonly files: readonly ForgeDiffFile[];
    readonly state: ChangedFilesState;
    readonly filter: (query: string) => void;
    readonly toggle: (path: string) => void;
    readonly jump: (path: string) => void;
    /** A menu row participates in the shared menu's keyboard walk. */
    readonly menu?: boolean;
}
/**
 * Render searchable directory navigation without reading file contents.
 * @param props - changed files, per-tab choices, navigation actions, and localized copy.
 * @returns the search field and matching branches.
 */
export declare function ChangedFiles(props: ChangedFilesProps): ReactNode;
/**
 * Open directory navigation through the existing files toolbar entry.
 * @param props - navigator data and whether its owning tab is visible.
 * @returns the toolbar entry and its portalled menu.
 */
export declare function ChangedFilesMenu({ visible, ...props }: ChangedFilesProps & {
    readonly visible: boolean;
}): ReactNode;
//# sourceMappingURL=ChangedFiles.d.ts.map