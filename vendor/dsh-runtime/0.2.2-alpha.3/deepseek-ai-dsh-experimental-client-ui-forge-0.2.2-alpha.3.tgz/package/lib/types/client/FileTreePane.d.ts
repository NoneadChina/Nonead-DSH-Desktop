/** Resizable file navigation; width belongs to the mounted tab and survives hiding the pane. */
import { type ReactNode } from 'react';
import { type ChangedFilesProps } from './ChangedFiles.tsx';
/** Placement of a tab's file navigator; hiding it retains its viewing choices. */
export type FileTreePosition = 'right' | 'left' | 'hidden';
/**
 * Render a keyboard- and pointer-resizable tree beside the diff.
 * @param props - tree rows, pane position, and the toggle's controlled element id.
 * @returns the bounded pane and its resize separator.
 */
export declare function FileTreePane({ position, id, ...props }: ChangedFilesProps & {
    readonly position: FileTreePosition;
    readonly id: string;
}): ReactNode;
//# sourceMappingURL=FileTreePane.d.ts.map