/** Inline comment records and editing of a pending review at its captured code location. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ReviewActions } from './ReviewComposer.tsx';
import { type FileReviewState, type ReviewThread as Thread } from './review-queue.ts';
import type { NS } from './locales.ts';
/**
 * Subscribe only to comments that belong to the displayed file and source.
 * @param actions - review actions and their browser store.
 * @param path - displayed file path.
 * @returns stable file-scoped comments and write availability.
 */
export declare function useFileReview(actions: ReviewActions | undefined, path: string): FileReviewState;
/**
 * Render a saved comment at its line, with pending edits kept in the browser queue.
 * @param props - record, edit availability, source actions, and localized copy.
 * @returns one compact inline comment card.
 */
export declare function ReviewThread({ thread, actions, locked, outdated, split, t }: PropsLocale<typeof NS> & {
    readonly thread: Thread;
    readonly actions: ReviewActions;
    readonly locked: boolean;
    readonly outdated: boolean;
    readonly split: boolean;
}): ReactNode;
//# sourceMappingURL=ReviewThread.d.ts.map