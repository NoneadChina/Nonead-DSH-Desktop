import type { ForgeDiffFile } from '../types.ts';
/** A changed file or a compacted chain of directories containing changed files. */
export type ChangedFileNode = {
    readonly kind: 'file';
    readonly path: string;
    readonly name: string;
    readonly file: ForgeDiffFile;
} | {
    readonly kind: 'directory';
    readonly path: string;
    readonly name: string;
    readonly children: readonly ChangedFileNode[];
};
/**
 * Build a directory-first tree, compacting directories with a single directory child.
 * @param files - changed files; Git paths use forward slashes, including on Windows.
 * @returns the root's children in stable name order.
 */
export declare function changedFileTree(files: readonly ForgeDiffFile[]): readonly ChangedFileNode[];
/**
 * Read every file in the tree's depth-first display order, independent of navigation folds and filtering.
 * @param nodes - the complete directory-first tree.
 * @returns the original file objects in display order.
 */
export declare function filesInTreeOrder(nodes: readonly ChangedFileNode[]): readonly ForgeDiffFile[];
/**
 * Keep matching files and their ancestors without changing directory identities.
 * @param nodes - the complete compacted tree.
 * @param query - case-insensitive text matched against current and previous paths.
 * @returns matching branches, or the original tree for an empty query.
 */
export declare function filterFileTree(nodes: readonly ChangedFileNode[], query: string): readonly ChangedFileNode[];
//# sourceMappingURL=file-tree.d.ts.map