/**
 * Answer one Node internal module.
 * @param moduleId - Node internal module id.
 * @returns The Worker's module object for that id.
 * @throws Error with `ERR_FEATURE_UNAVAILABLE_ON_PLATFORM` for an id the Worker does not provide.
 */
export declare function requireBuiltin(moduleId: string): object;
//# sourceMappingURL=node-addon-require-builtin.d.ts.map