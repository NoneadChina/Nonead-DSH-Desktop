"""Connector core primitives."""
