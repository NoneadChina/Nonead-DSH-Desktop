# Runtime：发现、读取与实时同步

## 当前实现

当前支持文本、图片和普通文件、模型与权限配置、用户问答、计划审批及工具权限审批，并提供运行日志和单会话历史读取失败隔离。读取继续使用官方 `ctx.sessionQuery`，不会直接解析、修复或改写原生日志。当前验证状态见 [验证记录](https://github.com/anywhere-labs/Agents-Anywhere/blob/edeb4f6c/dsh-bridge-next/VERIFICATION.md)。

插件 Host 独立挂载 `agentsAnywhereRuntime`，要求官方 `sessions`、`sessionQuery`、`workspaceRegistry` 服务就绪。官方 `sessionController` 服务存在时提供消息发送和配置；目录与附件能力按对应官方服务分别声明。是否登录、是否打开手机连接弹窗、是否发现 AA Desktop，都不会决定 runtime 端口是否启动。

```text
平台 → Connector RuntimeProtocol → Python DSH 适配器
  → 本机鉴权 JSON-RPC → 插件 host/dsh-runtime
  → DSH 官方 SessionQuery → 原生 Session / SessionPersistence
```

- `server.ts`：仅监听 `127.0.0.1`，随机端口和随机 token；负责鉴权、8 MiB 帧限制、独立取消及超时、连接与卸载清理。单请求失败返回结构化错误，不关闭已鉴权连接。
- `router.ts`：会话查询、当前状态、分页捕获、订阅、图片/文本请求与配置目录；纯读取不调用 Agent create/resume。
- `native.ts`、`visibility.ts`、`sync.ts`：官方事件与读写、侧栏过滤、初始校准及实时推送。
- `sessions/source.ts`：官方会话清单、明确的归档/不可见/缺失状态及即时可用性检查。
- `history.ts`、`tools.ts`：原始事件转换为统一 Timeline。Python 不解释 DSH 原始消息。
- `identity.ts`：沿用共享协议的会话 ID、Timeline ID 和内容哈希算法；握手传入 runtime instance 的 `sessionNamespace`，区分平台归属。

当前开发依赖与自动化检查使用 DSH SDK `0.2.0-rc.2`，支持范围见[技术说明](TECHNICAL.md)。Host 完整日志通过 `sessionQuery.observeSession(id, { projectionMode: 'none' })` 的不可变 observation 读取；无 Host 的兼容 reader 仍使用 `readSession`，不使用仅代表当前模型上下文的 `readSurface`。不创建新的会话内容数据库。

## 发现与添加

发现文件固定为 `<操作系统用户主目录>/.agents-anywhere/dsh-bridge/endpoint.json`（Node 使用 `os.userInfo().homedir`，Python 使用 `runtime_owner.system_home()`），`DSH_HOME`、`HOME` 和插件 `stateRoot` 都不改变它，Connector 不需要查找 DSH 数据目录。因此同一操作系统用户同时只能有一个 DSH Host 发布端点。同目录下的 `create-intents/` 和 `attachments/` 也随之迁移。

为兼容旧插件，Connector 依次尝试固定位置和旧位置 `<dshHome>/agents-anywhere/bridge/endpoint.json`（`dshHome` 未配置时为 `$DSH_HOME` 或 `~/.dsh`）：固定位置的文件缺失、格式无效、进程已退出或鉴权连接失败时，继续尝试旧位置；两者都不可用时报告固定位置的错误（固定位置缺失时报告旧位置的错误）。每次重连都重新按此顺序尝试。附件暂存目录跟随实际连接的端点所在目录。会话来源键始终使用旧位置的路径字符串，因此升级前后会话 ID 不变。插件把 `dshHome` 传给自己启动的 Connector；外部 Connector 使用相同的 `dshHome` 配置。2.0.3 之前的 Connector 只读取旧位置，所以插件在持有固定位置的锁后，再把同一份端点写到旧位置（目录按旧插件的方式解析：`dshHome`、`$DSH_HOME`，否则 `~/.dsh`），关闭时只删除自己写的那份。旧位置的锁仍被 2.0.3 之前的插件持有时不写，交给那个插件；写入失败只记录警告，不影响启动。这些 Connector 把附件暂存在旧端点旁的 `attachments/staging/`，插件在固定位置找不到某个上传 ID 时会去那里找，固定位置优先。

文件包含版本、回环地址、端口、进程 ID 和连接 token；在 POSIX 上以 `0600` 发布。进程级 OS 租约保护端点所有权与崩溃后的旧记录回收；卸载只删除自身的记录。另一实例不能覆盖仍有效的端点。

Connector 先验证发现文件、进程与回环地址，再执行限时鉴权和 `ping`。临时探测连接不会关闭现有连接。添加时沿用平台的单实例一键配置，启动读取 capability set，并独立尝试预热可用的模型/权限目录；目录失败不会中断其他运行时操作。

## 会话列表与详情

列表通过 `sessionQuery.listSessions()` 合并 live 和 persisted 会话，使用官方顺序，并按官方侧栏规则排除子代理、归档和非当前空会话。按页批量调用 `readTitleSnapshots`，标题读取失败时保留错误标记。详情与分页也校验可见性，不把 live 标记当作正在运行。

`session.getState` 返回 sourceState；归档时返回 blocked，不尝试加载 Agent。发送前再次检查来源。明确归档状态通过现有通知同步到 AA，AA 元数据操作不会修改 DSH。插件不推送 DSH 项目名称或分组，后端沿用 CWD 分类和末段命名。

状态读取、发送消息、配置修改和会话 ID 解析共享本次 Host 启动的会话清单，后续由原生事件维护，不为单个 RPC 重列整个 corpus。配置与最后轮次结果按日志身份缓存：live 会话使用 `session.seq`，冷会话使用官方 `locate(header)` 指向的单个文件的 stat 身份，不通过 `listSnapshots()` 扫描全部日志。空白可见性判断也随日志身份变化而失效。

未实现功能的空占位目录已移除；`sessions/` 承载实际使用的来源状态模块，其余文件按当前职责保留，后续有实现再拆分目录。

详情先取得官方校验过的完整 raw log，再执行纯转换。消息类型与处理如下：

| DSH 原始记录 | 统一 Timeline | 处理方式 |
|---|---|---|
| 真正用户的 `user/message` 文本 | `message`，role=user | 保留消息来源 |
| 插件注入的 user-role 消息 | 不输出 | 环境、技能等内部注入不进入 Timeline |
| assistant 文本 | `message / markdown` | 流式片段和最终消息使用相同 ID、顺序 |
| reasoning | `system / reasoning` | 与普通文本分开 |
| image | 附件引用及必要的占位 | AA 发送的图片通过持久化回执恢复平台附件 ID；原生图片保留原生引用，不伪造平台文件 ID |
| `tool-call`、`tool/call`、`tool/result` | 同一条 `tool` | 以 callId 合并输入、结果、错误与最终状态 |
| bash / pwsh | `tool / command` | 保留 command；没有事实依据时不猜退出码 |
| write / edit / str_replace_editor | `tool / file_change` 或通用工具 | 有合法原生 diff meta 时使用上下文片段，绝不读取当前磁盘拼历史 |
| web_search | `tool / web_search` | 保留查询和结果 |
| subagent / subagent_fork / send_message 等 | `tool / agent_call` | 保留动作和输入 |
| MCP | `tool / mcp` | 保留完整注册工具名 |
| ask_user_question / exit_plan_mode | `tool / input_request` | 历史只读，不发起新交互 |
| run_code 子调用 | 独立 `tool` | 保留 rootCallId、parentItemId |
| approval/asked、approval/decided | 同一条 `tool / permission` | 合并审批历史，不重新弹审批框 |
| turn/start、turn/end | 状态/结束通知 | 投影内用于归并，后端不保存轮次标记 |
| compaction | `marker / compact` | 原始历史保留，不以压缩后上下文覆盖聊天记录 |
| 其他内部信息事件 | 不输出 | 不生成兜底 notice |

请求配置、系统提示词和模型 replayState 不输出到时间线。损坏或不兼容的原生日志由官方读取层拒绝，再转成稳定错误；不会伪装成空历史。

读取、投影、图片回执和配置状态异常按会话隔离；快照不能完成时撤销该捕获，保留 AA 已接收的历史。全局清单或交付失败只替换同步订阅，Connector 延迟后重新订阅；普通 RPC 继续使用同一连接。会话刷新、后续原生事件和新的清单均可触发重试，不需要重启进程来清除错误。

主动读取的历史按同一捕获分页，每帧最多 1,000 条且内容小于 7 MiB；单条超限明确失败。游标绑定连接、会话和捕获，120 秒后过期。Python 收齐所有页才返回完整快照；指定 limit 截断时 complete=false。事件订阅的初始历史每页最多 250 条，收齐后通过现有 timeline.sync 完整替换；随后只推增量，断线重连重新校准，不再定时扫描 DSH。详见 [事件同步方案](https://github.com/anywhere-labs/Agents-Anywhere/blob/edeb4f6c/dsh-bridge-next/RUNTIME_SYNC_PLAN.md)。

## 验证与本地试用

```bash
cd dsh-bridge-next
corepack yarn check
cd ../connector
uv run pytest tests/test_dsh_contracts.py tests/test_dsh_provider.py tests/test_dsh_bridge_client.py -q
```

测试在临时目录组装官方 Session、JSONL、SessionQuery 与编译后的插件，再运行真实 Python Provider/Runtime；覆盖空闲会话、持久化会话、1,005 条跨页历史、内容哈希、鉴权、探测共存、依赖服务卸载/恢复和端点清理。无需 GUI 或模型密钥。

链接安装的插件完成构建后，手动重启 DSH Host 以加载新后端；正在运行的旧 Connector 也需要重新启动以加载新的 Python 适配器。在 Web 设备页面或 onboarding 点击 DeepSeek Harness 的“一键配置”，然后查看该设备已有的 DSH 会话与历史。

纯文本新建/续聊、实时消息、工具状态与中断已接入官方 Agent 服务。`ask_user_question` 已接入平台现有问答表单，包含回答、取消、多端收起和断线恢复，见 [用户问答](https://github.com/anywhere-labs/Agents-Anywhere/blob/39043f6a/dsh-bridge-next/USER_QUESTIONS.md)。附件、模型与权限目录、工具权限审批及计划审批也已接入；实际可用能力取决于宿主提供的官方服务。Windows 实机、长时间运行及真实模型界面验收仍需手动进行。


## 性能优化（2026-09-10）

- 首次订阅仍完整同步历史。并发初始化共享一次清单读取；同步逐个读取、投影和提交会话，使可见性检查与快照生成复用同一个 observation。
- observation、配置结果和 feed 投影缓存暂不设置容量上限。原生事件使对应 observation 失效，冷会话目标文件变化使缓存失效；关闭 Host/feed 时释放缓存和 observation lease。缓存不持久化。
- 同一 Host、同一 session namespace 的已确认同步 revision 在重订阅时复用：未变化会话只校准状态，变化会话补快照。显式单会话刷新先删除其 checkpoint，失败重试不会误判为已同步。新 Host 没有 checkpoint，仍完整导入。
- 流式工具参数只在 drain/snapshot 或非 chunk 事件边界解析，避免每个 token 重复解析增长中的 JSON。历史投影以约 5 ms 为目标分片让出事件循环；单个原生读取、单个事件处理和最终内容哈希仍可能超过此时间。
- 同步/RPC 字节预算直接遍历 JSON 数据计数，不再为计数分配完整 JSON 字符串。socket 写入仍序列化一次，跨语言内容哈希校验保留。
- Connector 对小快照复用已解析对象；暂存数据超过约 8 MiB 才写内部二进制临时文件，文件读写在线程中完成。现有完整提交 API 在最终提交时仍会组装全部条目。

### 可重复基准

`tests/benchmarks/startup.ts <旧版 host/dsh-runtime 绝对路径>` 通过 tsx 运行。它创建真实 SessionStore、JSONL、SessionQuery 服务，写入 12 个包含约 3,000 个工具参数 chunk 的会话，加上 fixture 的两个持久化会话。每轮销毁并新建服务图和 NativeRuntime；只复用同一批磁盘数据，操作系统文件缓存是热的。接收端进行 JSON 编解码后立即 ACK，不包含 Python、实际网络或后端延迟。

2026-09-10 本机交替运行三轮，结果如下：

| 指标 | 修改前 | 修改后 |
| --- | --- | --- |
| 首次完整同步耗时中位数 | 5,146 ms | 2,154 ms |
| 每轮最大事件循环延迟范围 | 241.6–265.4 ms | 9.8–13.6 ms |
| 每轮持久化列表读取 | 29 | 1 |
| 每轮 readSession / observation 调用 | 28 / 0 | 0 / 14 |
| 每轮 JSON.parse 次数（含接收端帧解析） | 39,769 | 2,249 |
| 完整快照 / Timeline 条目 / 批次 | 14 / 1,033 / 62 | 14 / 1,033 / 62 |

`scripts/benchmark-history.ts` 可单独比较历史投影：3,003 个事件、180 KB 工具参数，五次运行中位数从 229.92 ms 降至 2.10 ms，JSON.parse 从 3,001 次降至 1 次。传入旧 checkout 的 `history.ts` 绝对路径即可对比相同输入。

以上结果针对工具参数较多的合成历史，不代表所有用户历史或 DSH 界面的固定提速比例。验证包括插件 125 项测试、Connector 相关 37 项测试，以及 TypeScript 检查和 Connector 修改文件的 Ruff 检查；未启动用户的 DSH 或开发服务。

## 本机连接启动失败与运行日志

本机 RPC 或本机管理锁初始化失败时，管理 Gateway 保持可用。连接页面会显示原因和下一步：占用冲突提示退出其他 DSH，权限和磁盘错误提供对应处理建议；“尝试重启”会重建当前插件的本机服务，必要时重新初始化管理器，不会终止其他进程。并发重试合并为一次操作。

“运行日志”默认每条只显示时间、方法名和结果，点击展开事件名、日志级别与诊断详情。结果区分成功、失败、进行中和普通记录；RPC 返回 `ok: false` 也标为失败。日志刷新保留已有条目的展开状态，继续使用原有最近 200 条及敏感信息过滤规则。

## DSH 0.1.7-rc.2 适配

工具结果从 tool-role 消息的 `toolCallId`、`content`、`isError` 读取，空结果也能结束原工具卡片；旧的嵌套 `tool-result` 日志继续支持。`tool/ptc-dispatch-start` 与 `tool/ptc-dispatch` 按子调用 ID 合并，保留父调用关联和结构化错误；旧 `tool/code-dispatch*` 仍可回放。投影 v3 不复用旧 v2 检查点，避免旧映射错误长期留在平台历史中。
