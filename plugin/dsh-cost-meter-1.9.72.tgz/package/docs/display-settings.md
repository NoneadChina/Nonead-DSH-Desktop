# 显示设置预览

## 图标 / Icons

在“费用 → 显示 → 侧栏 → 侧栏布局”主动选择“图标”。原有布局、简洁模式和查询偏好不会自动迁移。图标行沿用上游费用区块，在设置入口上方占用原有区域；不定位或重排设置按钮及其他插件。

每个已启用的余额、预算、Coding Plan、Go、Codex、网关、模型或本地节省组件保留一个图标入口。官方余额使用 DeepSeek Logo，Codex 使用 OpenAI 品牌标识，Go 使用 OpenCode Logo；有 Claude 用量时今日入口使用 Claude Logo。13 个常见套餐来源使用对应的单色品牌 Logo：Claude、Z.ai/GLM、MiniMax、Kimi、OpenRouter、SiliconFlow、CommandCode、Cline、火山引擎、Qwen、小米 MiMo、百度智能云、WorkBuddy。未确认素材的 OpenDesign、SCNet、Factory 保留简写；自定义余额保留中性图形，网关保留来源名称标识，不按用户标签冒认品牌。全部 16 个套餐来源仍保留入口和完整名称提示。Logo 随可选分块内嵌，继承主题前景色，无外部图片请求；素材来源、固定版本和 MIT 许可见 [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md)。点击图标展开原有组件，继续使用完整的账户列表、充值链接、刷新、错误与重试操作；再次点击、“收起”或 Escape 关闭。今日用量复用原币种、精度和费用/Token/双项设置；有 Claude 用量时，今日图标的圆环表示 Claude 在今日费用中的占比。图标模式中，今日用量图标与数字作为金额组固定在行末，金额后不再排列其他图标；其他图标之间保持已保存的相对顺序，其他布局的排序不变。数字仍紧跟自身图标，不靠额外留白吸附侧栏最右；图标较多可横向滚动。开启“今日消费与余额同行”时，点击今日或配对余额图标会在明细中同时展开原有两个组件，继续使用上游同行布局。

峰谷圆环不是整个计价阶段的归一化进度：它是固定的 8 小时感知窗口。距下一次切换超过 8 小时时保持满环，提示“距切换超过 8 小时”，不显示动态倒计时；剩余不超过 8 小时才按“剩余时间 / 8 小时”缩短。实际阶段和切换点复用渠道、周末、节假日和自定义时段规则，不修改计价。展开的原有峰谷组件保留其完整信息与原样式设置。

窄栏、1023px 及以下视口、粗指针触屏和强制 `data-dsh-pocket-layout="mobile"` 暂使用原有卡片；可随时切回其他布局。可选图标分块加载中或失败时也保留原有组件，失败可重试。样式随组件卸载移除，未新增账户请求或轮询器。

Choose **Cost → Display → Sidebar → Sidebar layout → Icons** explicitly. Existing layout preferences are not migrated. The existing full-width cost footer owns placement; this mode adds no host/sidebar class selectors. Every enabled sidebar component keeps an icon entry; click it to disclose its original component and actions, including all account rows, links, refresh, errors and retries. Collapse, the same icon or Escape closes details. Currency, decimal places and cost/token choices remain effective. In Icons, the Today icon/value group is always last, so no icons follow the amount; all other icons retain their saved relative order, and other layouts keep their original ordering. Values sit immediately after their own icon, without blank space pinning them to the sidebar edge. When Today and balance on one line is enabled, opening either paired icon discloses both original cards in the upstream same-line container. The optional Claude share ring uses the existing cost conversion helper. Common providers use bundled monochrome brand logos (13 plan sources plus DeepSeek/OpenAI/OpenCode); OpenAI identifies the Codex provider. OpenDesign, SCNet and Factory retain initials; custom balances/gateways keep neutral/name fallbacks rather than inferring a brand from user labels. Geometry follows the theme foreground color and adds no remote image requests; source/version/MIT attribution is in [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md).

The peak ring uses a fixed eight-hour countdown horizon, not whole-period progress. Above eight hours it stays full with a threshold message; inside the window it shrinks as remaining time divided by eight hours. Provider calendars and switching times remain upstream-owned. The expanded original peak component keeps its saved presentation and full information.

Collapsed rails, viewports up to 1023px, coarse pointers and forced Pocket mobile mode retain the original cards. Loading/failure of the optional icon chunk also retains native content with retry. Cross-platform/theme geometry and real touch interaction require running-UI acceptance; logic/static tests alone do not certify them.


在“费用 → 显示 → 输入区 → 套餐进度条”关闭“显示套餐余额”，输入框上方只保留套餐进度条与百分比，隐藏余额等文本段。默认开启，悬浮详情保留完整信息；该开关不会修改侧栏或账户查询。设置预览同步显示开关效果，保存后重启仍生效。

在“费用 → 显示 → 通用设置”（或“侧栏 → 调整组件 → 通用设置”）的“货币单位”中可选择 26 种展示币种。切换时更新符号与该币种的每日参考汇率，小数位保持当前设置；关闭自动更新后使用输入的手动值，切换币种则改用该币种的目录汇率。旧版本保存的自定义币种仍作为一条选项显示。人民币与欧元保留调用时记录的金额，其他币种按最新参考汇率折算；完整说明见[每日汇率与历史金额](exchange-rates.md)。

**Display currency:** the **Currency** field in **Cost → Display → General** (also in **Sidebar → Customize → General**) lists 26 reference currencies. Selecting one updates the symbol and that currency's daily rate; the decimal places stay as configured. With auto-update off the manual rate applies, and switching currency falls back to the catalog rate. A custom currency saved by an older version stays listed. CNY and EUR keep the amount recorded per call, other currencies follow the latest daily rate — see [daily rates and historical amounts](exchange-rates.md).

在“侧栏 → 调整组件 → 官方余额 → 余额显示币种”可单独选择余额金额的展示币种:原币种(默认)、跟随显示币种或币种目录中的任一代码。换算使用当前每日参考汇率;金额使用币种目录中的符号显示。进度比例与预算上限仍按余额记账币种计算，金额随所选币种换算展示。详见[自定义余额来源](custom-balance-sources.md)。

**Balance currency:** under **Sidebar → Customize → Official balance → Balance currency** the balance amount can be shown in its native currency (default), the display currency, or any catalog code. Conversion uses the current daily reference rate, and amounts use the symbol from the currency catalog. Progress percentages and budget limits stay in the balance's own currency. See [custom balance sources](custom-balance-sources.en.md).

在“费用 → 显示 → 侧栏”打开“隐藏进度条，仅显示紧凑文本”，可去掉峰谷时段、套餐额度、余额、预算和模型占比的图形条。额度保留窗口名与百分比，峰谷保留当前时段、倒计时和切换时间；悬停详情、点击刷新与超额警告仍可使用。偏好会保存，重启后保留。此选项只影响侧栏和侧栏预览，不改变用量查询、账本、计价、输入区额度条或原有布局/条形方向；关闭后恢复原样式。在峰谷组件里仍可选择只显示倒计时或切换时间。

**Compact text:** In **Cost → Display → Sidebar**, enable **Hide progress bars, show compact text** to hide sidebar pricing-period, quota, balance, budget and model-share bars. Window labels, percentages, period times, hover details, refresh actions and warnings remain available. The preference survives restart, applies to the sidebar preview, and never changes billing, account queries, composer bars or the saved graphical style. Disable it to restore the existing bars.

在“费用 → 额度”展开自定义余额条目，可设置“跳转链接（可选）”。填写账户、充值或控制台的 HTTP(S) 地址后，侧栏该条余额名称旁显示跳转箭头；余额行、进度卡和查询失败提示均可使用。点击箭头在新标签页打开，不触发余额刷新。每条链接独立保存，留空时不显示箭头；不从余额查询接口或请求头推导链接。

选择“侧栏 → 调整组件 → 余额”，可开启“仅官方渠道显示”（`balance.officialChannelOnly`，默认关闭）。开启后，侧栏官方余额只在当前会话使用 `deepseek`、`deepseek-official` 或 `deepseek-account` 渠道时显示；带 `llm-` 前缀的名称按相同渠道识别。无活跃会话或宿主未提供渠道投影时，按今日账本是否有官方渠道调用判断，包括零费用调用。当前会话明确使用其他渠道时，即使今天调用过官方渠道也隐藏；切换渠道后下一次调用更新显示。设置页官方余额面板和显示预览不受渠道限制，“隐藏官方余额”、显示位置与来源标注继续独立生效。

会话列表行末金额默认关闭。在“侧栏 → 调整组件 → 会话列表金额”打开“显示此组件”，选择累计或今日。金额沿用显示币种、精度与汇率设置；没有记录显示“—”，悬停查看输入、缓存和输出 Token。仅合并查询当前可见行，结果缓存五秒，显示期间每十秒刷新；关闭功能或隐藏页面时停止定时查询，收起为图标侧栏时不显示。

关闭输入框上方的 Codex 额度条：选择“输入区 → 调整组件 → Codex 额度”，取消“在输入区显示 Codex 额度”。该开关与侧栏额度独立，不影响预算、Go 或其他套餐的额度条；两个 Codex 显示位置都隐藏时停止查询。

Codex 额度的真实数据来自已启用并登录的 `dsh-codex-subscription`、DSH 内置 pi-ai 登录、`dsh-chatgpt-sub`、`@eddyskywalker/dsh-chatgpt-subscription` 或 `dsh-codex-connect`。自动检测按上述顺序尝试；在 Codex 显示设置中指定数据源后，只读取所选来源当前账号的额度。侧栏以“周额度 · 剩余 83% · 10/25 08:10 重置”显示，5h 窗口单列一行；会话额度条也标明“剩余”。只返回周额度的账号仅显示周窗口。重置时间按本机时区显示，Codex 不随其他套餐的进度条方向切换口径。示例百分比只用于预览；真实查询未成功时，已开启的侧栏卡片会显示登录与重试提示，可以点击重新查询。启用期间每分钟检查一次，成功数据缓存五分钟，失败一分钟后重试；两个显示位置都关闭后停止检查。查询只读取额度，不发送模型请求。

`dsh-chatgpt-sub` 与 `@eddyskywalker/dsh-chatgpt-subscription` 是两个独立插件。前者只提供登录绑定状态：费用插件先确认它已绑定且通道可用，再由服务端用 DSH 中该插件管理的凭据查询额度；不会读取共享的 Codex 登录文件，也不要求安装 Bottom Info Bar。后者沿用 `/api/dsh-chatgpt-subscription/status` 与 `/quota/refresh` 接口。使用 `dsh-chatgpt-sub` 时，在“侧栏 → 调整组件 → Codex 额度”中开启显示并选择同名数据源，也可单独开启输入区额度条。该设置与计费归类独立。

进入 DSH 设置 → 费用 → 显示。默认勾选“使用示例数据”，展示余额、预算、Go、套餐、峰谷和三种模型的完整效果。选中 Codex 或自定义余额时也提供对应示例。取消勾选后展示当前缓存数据，缺失的会话值显示“—”。数据来源的选择仅保存在本机预览偏好中，不更改插件配置或账本。

预览分为侧栏、输入区和会话内容三个区域，使用正常字号，只渲染当前区域。点击虚线框，在右侧调整对应组件。示例模式下隐藏的组件保留淡化效果，方便再次选中；当前数据模式下未显示的组件保留淡色标签。组件菜单只列出可调整的组件，操作提示不再作为菜单选项。显示设置的更改自动保存。

右侧的“侧栏布局”默认展开，展示图标、合并卡片、简洁、标准和紧凑五种样式的小预览，复用实际预算与多时段额度的进度卡片。小预览标记为样式示例，未配置的额度使用本地示例数值。紧凑样式将多时段额度排成两列，预算卡片保持完整。点击峰谷条可切换细条或分段样式；点击“今日金额 · 模型数”可调整模型卡片的展开、周期、摘要、位置、行数、Token 和费用占比条。预算、余额、会话费用和额度条的选项各自放在对应组件旁。金额格式、换算和语言集中在下方。宽窗口将样式缩略图横向排列，窄窗口再改为竖向；右侧面板在空间不足时排到预览下方。放大预览中按 Escape 返回。

侧栏预览和真实侧栏共用完整的呈现函数与当前缓存数据，包含余额错误状态、独立的 Go 与预算卡片、预算摘要、今日用量和峰谷条、模型花费卡片。选择框使用独立覆盖层，不改变组件 DOM 层级和紧凑布局。打开时最多读取三个宿主表面的背景、圆角、字体等六项外观属性；主题属性变化时更新。共用插件组件、DSH 图标和主题变量，跟随这些外观的皮肤修改；其他插件的独立控件不重复挂载。

两种数据来源共用实际展示组件。示例状态只传给预览，不写入配置、余额、额度或账本，也不会启用账户查询或 Codex 探测。预览不复制会话内容，不遍历整页 DOM，不创建 iframe，不解码图片，不订阅会话投影。选择框只测量当前预览内最多 32 个标记节点，使用一个局部尺寸监听器；关闭时清理尺寸与主题监听器。异常组件由预览内部的错误边界隔离，仍可使用详细显示选项。

预算显示和预算统计分别控制。隐藏预算卡片不会关闭预算统计；隐藏峰谷条不会关闭峰谷计价；显示 Go 占位不会启用账户查询。

原生图标的来源和许可证见仓库根目录 THIRD_PARTY_NOTICES.md。

侧栏区域上方直接提供预算、今日用量、峰谷时段和模型花费四个显示开关，不必先选中组件。今日用量单行与“今日金额 · 模型数”摘要分别控制；关闭其中一个不影响其他组件，没有其他组件时也可以只显示峰谷条。隐藏侧栏今日用量不会隐藏概览里的今日费用，预算详细信息开关也不影响今日用量。所有组件关闭时不保留空白区域。

选择套餐进度条后，可以在同一面板选择 MiniMax 等账户、调整该账户的显示位置和侧栏开关。切换账户只切换编辑对象，不启用额度查询；进度条方向统一应用于所有套餐。需要修改凭据或查询参数时，点击“账户与额度设置”直接展开并定位到所选账户。

价格 → 模型定价中，每个模型下方的“计入统计”可展开三个独立开关：今日费用、月度与累计、预算。开关按渠道和模型保存，只改变对应汇总，不删除原始调用或重新定价。重新勾选可恢复统计。今日模型花费摘要跟随今日费用的选择；月度与累计、预算各用自己的选择。

模型定价以固定排序的紧凑列表展示，宽窗口中三项单价按列对齐，窄窗口在模型名下方排列。切换价格来源时模型保留原位置；选择自定义后，只定位一次到自定义编辑区的开头。保存价格或修改币种时不重新滚动。

峰谷时段新增“进度条”样式，显示当前计价时段已过的比例。峰时使用橙色，平价、周末和节假日使用 DSH 主题蓝色。标准侧栏显示完整信息，简洁侧栏使用两行，紧凑侧栏使用单行；可选择倒计时、切换时间或同时显示两者，悬停查看完整说明。周末和节假日会显示下一次切换的星期或日期，进度从连续谷价时段真正开始的时刻计算。

选中峰谷时段后，右侧以三张紧凑的实际效果卡片展示进度条、细条和分段样式，复用侧栏呈现函数，包含当前时段文字、橙蓝轨道和倒计时。蓝色边框和“已选”标明当前选择，样式说明放在悬停提示中，点击后立即更新左侧预览。右侧收窄并减少内边距和重复说明；桌面设置保持左侧预览、右侧调整，与其他组件使用相同的窄屏换行条件。显示时间的完整选项放在右侧卡片下方。预览中超长的时段文字以省略号收起，保留可见轨道，悬停或键盘聚焦可读取完整说明。样式示例只渲染峰谷组件，不挂载余额、额度和模型卡片，也不会把示例开关写入配置。

1.9.43 起，五个显示介绍合并为一个可关闭的首次提示，统一指向「设置 → 费用 → 显示」。已有任一介绍的已读记录会抑制新提示；关闭不会修改显示、查询或计费偏好。峰谷三种布局及预览仍可随时在显示设置中选择，原细条和分段样式保留。预览只读取配置和本机时间，不查询余额、不发送模型请求、不改变计价或历史记录。界面按需加载，页面隐藏时停止刷新，关闭组件时清理定时器和监听器。

“费用 → 显示”提供“跟随皮肤透明度”，默认关闭。开启后，费用页共用设置窗口的背景，统计正文不再另铺实心底色；费用明细、引导、提醒与下拉浮层使用皮肤层色，保留至少 90% 不透明度。关闭后立即恢复不透明遮挡效果。该开关只修改插件自己的界面，保存后重启仍生效。

“今日用量”右侧提供“费用”和“Token 用量”两个开关，至少保留一项；两项开启时金额与 Token 右对齐并列，空间不足时换行。选中“今日用量”后，两个子项各有虚线，点击对应虚线会定位到该项开关。

拖动排序仅在显示设置的侧栏预览中提供，主界面侧栏按保存顺序正常展示，不显示拖动手柄。预览中可拖动组件，拖到目标卡片的上半部或下半部决定放在前面或后面。手柄聚焦后也可用上下方向键移动。顺序保存到 `sidebarOrder`，重启、切换样式和暂时隐藏组件后保留；不同 Coding Plan 与网关卡片分别排序。Go 与预算使用独立卡片。原模型花费位置选项用于旧配置；手动使用该选项会清除拖动顺序并恢复原位置规则。

“合并卡片”将今日 Token 与费用、余额和峰谷进度放入同一外框。选择时默认开启今日双项显示，之后仍可分别关闭。Codex 组件提供额度查询总开关；显式开启其显示时会启用查询。billion-context 的统计偏差说明放在“费用 → 概览”，使用普通灰色文字，不再自动弹窗或提供弹窗开关。

“费用 → 显示 → 侧栏”中的“今日消费与余额同行”是独立开关，可与现有布局组合使用。开启时默认只显示今日费用，Token 可在今日组件中单独开启；两项保留悬停详情，余额进度条照常显示，隐藏官方余额时使用第一条可见的自定义余额。排序在设置预览中调整，关闭开关恢复各组件独立排列。

## 点击名称隐藏余额

1.9.45 起，在“设置 → 费用 → 显示 → 侧栏 → 调整组件 → 余额（或自定义余额）”中可以开启“点击名称快速隐藏余额”。默认关闭。开启后，点击余额名称隐藏或显示金额，点击金额继续刷新。隐藏时不显示进度条及悬停金额；四种侧栏布局、同行显示和收起样式共用隐藏状态。本机浏览器记住隐藏状态；关闭选项即恢复原有点击刷新方式。

In Settings → Cost → Display → Sidebar → Balance (or Custom balance), enable **Click name to hide balance**. This is off by default. Click the label to hide/show the amount; click the amount to refresh. Hidden balances also hide progress bars and tooltip amounts across sidebar layouts. The browser remembers hidden state. Disabling this option restores the original click-to-refresh behavior.

## 套餐额度圆环

1.9.49 起，在“设置 → 费用 → 显示 → 侧栏 → 调整组件 → 套餐进度条”选择“套餐额度样式 → 开口圆环”，可将多个额度窗口并排显示。默认保留横向进度条；所有套餐共用样式选择，已用／剩余方向继续由原选项控制。鼠标悬停查看完整额度和重置时间，点击或按回车刷新。“隐藏进度条，仅显示紧凑文本”开启时优先显示文本，收起侧栏仍使用原有数字布局。

In **Settings → Cost → Display → Sidebar → Plan quota style**, select **Open rings**. The choice applies to Coding Plan cards; used/remaining direction, reset tooltips and refresh remain available. Compact text takes precedence, and collapsed sidebars retain their numeric layout.

Go 额度入口支持点击展开详情，展示滚动 5 小时、本周、本月的用量与重置时间。输入区入口的刷新按钮放在详情中，展开本身不发起查询；再次点击入口或按 Escape 收起。桌面悬停提示继续保留在侧栏。
