window.__ModuleLoader__.load({
	id: "@yolk_vat-y/dsh-project-memory",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region \0rolldown/runtime.js
		var __create = Object.create;
		var __defProp = Object.defineProperty;
		var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
		var __getOwnPropNames = Object.getOwnPropertyNames;
		var __getProtoOf = Object.getPrototypeOf;
		var __hasOwnProp = Object.prototype.hasOwnProperty;
		var __copyProps = (to, from, except, desc) => {
			if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
					get: ((k) => from[k]).bind(null, key),
					enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
				});
			}
			return to;
		};
		var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
			value: mod,
			enumerable: true
		}) : target, mod));
		//#endregion
		let react = require("react");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		_deepseek_ai_dsh_client_ui_primitives = __toESM(_deepseek_ai_dsh_client_ui_primitives, 1);
		let react_jsx_runtime = require("react/jsx-runtime");
		//#region src/client/icons.ts
		/**
		* 宿主图标兼容层（dsh 0.1.5 ↔ 0.1.7+）。
		*
		* 命名契约变过一次：
		*   - dsh 0.1.5（含 0.1.5-rc.x）：尺寸写进名字，如 `IconFolderOpenOutline16`；
		*   - dsh 0.1.7+：去掉尺寸后缀、改为字重后缀，如 `IconFolderOpenOutlineRegular` /
		*     `IconFolderOpenOutlineMedium`，尺寸改由 `size` prop 传入。
		* ui-primitives 是 web shell 的冻结 seed 模块（不是插件行），插件无法固定它，
		* 同一份产物会拿到宿主那一版的导出；直接按某一版的名字解构会在另一版上得到
		* `undefined`，React 渲染时抛 "Element type is invalid" 把面板整个打崩。
		*
		* 因此这里按旧名导出同名组件，运行时在两个名字里取存在的那个，并把旧名里的
		* 尺寸作为默认 `size`（两版的图标都接受 `size` prop，0.1.5 的默认值正是旧名后缀）。
		* 两版都没有该名字时降级为空组件并告警，而不是让面板崩溃。
		*/
		const table = _deepseek_ai_dsh_client_ui_primitives;
		function resolveIcon(names) {
			for (const name of names) {
				const candidate = table[name];
				if (typeof candidate === "function" || typeof candidate === "object" && candidate !== null) return candidate;
			}
			return null;
		}
		function icon(legacyName, currentName, defaultSize) {
			const impl = resolveIcon([legacyName, currentName]);
			if (impl === null) {
				console.warn(`[dsh-project-memory] host ui-primitives exports neither ${legacyName} nor ${currentName}; that icon renders nothing`);
				return function MissingIcon() {
					return null;
				};
			}
			function CompatIcon({ size = defaultSize, ...rest }) {
				return (0, react.createElement)(impl, {
					size,
					...rest
				});
			}
			CompatIcon.displayName = legacyName;
			return CompatIcon;
		}
		const IconChevronDownOutline14 = icon("IconChevronDownOutline14", "IconChevronDownOutlineRegular", 14);
		const IconChevronUpOutline14 = icon("IconChevronUpOutline14", "IconChevronUpOutlineRegular", 14);
		const IconQuestionOutline14 = icon("IconQuestionOutline14", "IconQuestionOutlineRegular", 14);
		const IconCloseOutline16 = icon("IconCloseOutline16", "IconCloseOutlineRegular", 16);
		const IconFolderOpenOutline16 = icon("IconFolderOpenOutline16", "IconFolderOpenOutlineRegular", 16);
		const IconCheckOutline16 = icon("IconCheckOutline16", "IconCheckOutlineRegular", 16);
		const IconPlayOutline16 = icon("IconPlayOutline16", "IconPlayOutlineRegular", 16);
		const IconChecklistOutline16 = icon("IconChecklistOutline14", "IconChecklistOutlineRegular", 14);
		const IconLightOutline16 = icon("IconLightOutline16", "IconLightOutlineRegular", 16);
		const IconGlobeOutline16 = icon("IconGlobeOutline14", "IconGlobeOutlineRegular", 14);
		//#endregion
		//#region src/client/locales.ts
		/**
		* Locale dictionaries for Task Panel
		*/
		const zh = {
			"panel.title": "工作流任务",
			"panel.active": "进行中",
			"panel.total": "总计",
			"panel.minimize": "收起为顶部迷你条",
			"panel.close": "关闭面板（隐藏，/task 可唤起）",
			"panel.refresh": "同步最新任务",
			"panel.style": "切换面板风格",
			"style.native": "原生",
			"style.glass": "玻璃",
			"style.brutal": "粗野",
			"style.mono": "终端",
			"panel.syncing": "同步中…",
			"panel.sync-failed": "同步失败",
			"panel.hints-on": "显示提示信息",
			"panel.hints-off": "隐藏提示信息",
			"drag.cancel": "取消拖拽",
			"panel.empty": "暂无任务",
			"panel.empty-desc": "让模型开始工作并维护 todo 清单后会自动建档",
			"panel.no-session": "还没有会话",
			"panel.no-channel": "数据通道不可用（客户端服务缺失）",
			"panel.degraded": "插件降级：缺少客户端服务 {names}",
			"task.progress": "进度",
			"task.steps": "步骤",
			"task.files": "文件",
			"task.current": "当前",
			"task.title-edit": "双击修改标题",
			"task.switch": "切换到此任务",
			"task.unbind": "取消当前任务",
			"task.archive": "归档",
			"task.drag": "拖拽移动",
			"step.completed": "已完成",
			"step.in-progress": "进行中",
			"step.pending": "待办",
			"step.edit-hint": "双击编辑步骤文案；点击图标循环 待办/进行中/已完成",
			"file.copy": "复制路径",
			"file.copied": "已复制路径",
			"minibar.current": "当前任务",
			"minibar.click-expand": "点击展开并同步",
			"minibar.tasks": "个任务",
			"minibar.no-task": "暂无任务 · 点击查看",
			"view.cycle": "切换视图：任务 / 项目记忆 / 全局记忆",
			"view.task": "任务",
			"view.project": "项目记忆",
			"view.global": "全局记忆",
			"mem.scope.task": "本任务草稿",
			"mem.scope.project": "项目记忆",
			"mem.scope.global": "全局记忆",
			"mem.empty": "暂无记忆条目（反思或 save_lesson 后出现）",
			"mem.confirm": "审核",
			"mem.promote": "提升",
			"mem.demote": "降级",
			"mem.archive": "归档",
			"mem.restore": "恢复",
			"mem.delete": "删除",
			"mem.draft": "草稿",
			"mem.archived": "已归档",
			"mem.loading": "加载中…",
			"mem.loadingMore": "加载中…",
			"mem.loadMore": "加载更多",
			"mem.progress": "已显示 {loaded} / {total}",
			"mem.allLoaded": "已全部加载（{total} 条）",
			"mem.retry": "重试",
			"mem.error": "同步失败",
			"mem.kind.lesson": "坑",
			"mem.kind.decision": "权衡",
			"mem.kind.procedure": "指南",
			"mem.kind.experience": "经验",
			"mem.needs-bound": "需绑定任务后可降级",
			"mem.new": "新建",
			"mem.save": "保存",
			"mem.cancel": "取消",
			"mem.f.title": "标题（教训模式/主题/指南名）",
			"mem.f.kind": "类型",
			"mem.f.body": "做法 / 理由 / 解法",
			"mem.f.steps": "步骤（每行一步）",
			"mem.f.trigger": "作为 Skill：触发关键词（逗号分隔）",
			"mem.saved": "已保存",
			"mem.edit": "编辑",
			"mem.section-label": "任务记忆",
			"slash.group": "工作流",
			"slash.tasks-desc": "任务清单：步骤进度、涉及文件、当前会话绑定",
			"slash.project-desc": "项目记忆：本项目的教训 / 决策 / 流程",
			"slash.global-desc": "全局记忆：跨项目的经验条目",
			"settings.title": "常用设置",
			"settings.subtitle": "保存后立即生效（启动时全量索引除外）；其余配置在 profile 的 cordis.patch.yml 里。",
			"settings.unsaved": "未保存",
			"settings.autoIndexOnFirstUse.title": "启动时全量索引",
			"settings.autoIndexOnFirstUse.hint": "插件加载后扫描当前工作目录；打开后从下次启动开始生效。",
			"settings.watchInterval.title": "刷新间隔",
			"settings.watchInterval.hint": "后台自动刷新索引的频率（秒）。回合进行中降频，空闲时最多退避到 2 分钟。",
			"settings.llmQueryExpansion.title": "检索时扩展查询",
			"settings.llmQueryExpansion.hint": "让模型先改写几条变体查询再检索，命中更准，但会消耗 token。",
			"settings.unit.seconds": "秒",
			"settings.form.unavailable": "设置不可用：宿主没有提供本插件的配置命名空间。",
			"settings.form.readOnly": "当前部署只读，改动无法保存。",
			"settings.form.saveFailed": "宿主没有接受这次保存，请检查取值。",
			"settings.form.save": "保存",
			"settings.form.saving": "保存中…"
		};
		const en = {
			"panel.title": "Task Flow",
			"panel.active": "Active",
			"panel.total": "Total",
			"panel.minimize": "Collapse to mini bar",
			"panel.close": "Close panel (hidden; /task reopens)",
			"panel.refresh": "Sync latest tasks",
			"panel.style": "Panel style",
			"style.native": "Native",
			"style.glass": "Glass",
			"style.brutal": "Brutal",
			"style.mono": "Mono",
			"panel.syncing": "Syncing…",
			"panel.sync-failed": "Sync failed",
			"panel.hints-on": "Show hints",
			"panel.hints-off": "Hide hints",
			"drag.cancel": "Cancel drag",
			"panel.empty": "No Tasks",
			"panel.empty-desc": "Tasks are created automatically when the model maintains a todo list",
			"panel.no-session": "No session yet",
			"panel.no-channel": "data channel unavailable (missing client service)",
			"panel.degraded": "Plugin degraded — missing client service(s): {names}",
			"task.progress": "Progress",
			"task.steps": "Steps",
			"task.files": "Files",
			"task.current": "Current",
			"task.title-edit": "Double-click to rename",
			"task.switch": "Switch to this task",
			"task.unbind": "Unbind current task",
			"task.archive": "Archive",
			"task.drag": "Drag to move",
			"step.completed": "Completed",
			"step.in-progress": "In Progress",
			"step.pending": "Pending",
			"step.edit-hint": "Double-click to edit; click the icon to cycle status",
			"file.copy": "Copy path",
			"file.copied": "Path copied",
			"minibar.current": "Current task",
			"minibar.click-expand": "Click to expand & sync",
			"minibar.tasks": "tasks",
			"minibar.no-task": "No tasks · click to view",
			"view.cycle": "Switch view: tasks / project memory / global memory",
			"view.task": "Tasks",
			"view.project": "Project Memory",
			"view.global": "Global Memory",
			"mem.scope.task": "Task drafts",
			"mem.scope.project": "Project memory",
			"mem.scope.global": "Global memory",
			"mem.empty": "No memory entries yet (created by reflection or save_lesson)",
			"mem.confirm": "Approve",
			"mem.promote": "Promote",
			"mem.demote": "Demote",
			"mem.archive": "Archive",
			"mem.restore": "Restore",
			"mem.delete": "Delete",
			"mem.draft": "draft",
			"mem.archived": "archived",
			"mem.loading": "Loading…",
			"mem.loadingMore": "Loading…",
			"mem.loadMore": "Load more",
			"mem.progress": "Showing {loaded} of {total}",
			"mem.allLoaded": "All {total} loaded",
			"mem.retry": "Retry",
			"mem.error": "Sync failed",
			"mem.kind.lesson": "lesson",
			"mem.kind.decision": "decision",
			"mem.kind.procedure": "procedure",
			"mem.kind.experience": "experience",
			"mem.needs-bound": "Bind a task to demote",
			"mem.new": "New",
			"mem.save": "Save",
			"mem.cancel": "Cancel",
			"mem.f.title": "Title (pattern / topic / procedure name)",
			"mem.f.kind": "Kind",
			"mem.f.body": "Fix / reason / solution",
			"mem.f.steps": "Steps (one per line)",
			"mem.f.trigger": "As Skill: trigger keywords (comma separated)",
			"mem.saved": "Saved",
			"mem.edit": "Edit",
			"mem.section-label": "Task memory",
			"slash.group": "Workflow",
			"slash.tasks-desc": "Task list: progress, involved files, current session binding",
			"slash.project-desc": "Project memory: this project’s lessons / decisions / procedures",
			"slash.global-desc": "Global memory: experience entries shared across projects",
			"settings.title": "Common settings",
			"settings.subtitle": "Saved changes apply immediately, except the startup full index; the rest stays in the profile’s cordis.patch.yml.",
			"settings.unsaved": "Unsaved",
			"settings.autoIndexOnFirstUse.title": "Full index on startup",
			"settings.autoIndexOnFirstUse.hint": "Scan the current working directory after the plugin loads; takes effect from the next start.",
			"settings.watchInterval.title": "Refresh interval",
			"settings.watchInterval.hint": "How often the index refreshes in the background, in seconds. Slower during a turn, up to two minutes when idle.",
			"settings.llmQueryExpansion.title": "Expand queries",
			"settings.llmQueryExpansion.hint": "Ask the model for a few query variants before search: better recall, spends tokens.",
			"settings.unit.seconds": "s",
			"settings.form.unavailable": "Settings unavailable: the host serves no configuration namespace for this plugin.",
			"settings.form.readOnly": "This deployment is read-only; changes cannot be saved.",
			"settings.form.saveFailed": "The host rejected this save; check the values.",
			"settings.form.save": "Save",
			"settings.form.saving": "Saving…"
		};
		function createTranslate(dict) {
			return (key, params) => {
				let text = dict[key] ?? key;
				if (params) for (const [k, v] of Object.entries(params)) text = text.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
				return text;
			};
		}
		//#endregion
		//#region src/client/services.ts
		/**
		* Client 服务软探测 —— 顶层 `inject` 是「整半边静默消失」的开关，这里把它降级成运行时探测。
		*
		* cordis 的顶层 `inject` 是**装配期门控**：只要声明的一项在当前客户端装配里不可用，
		* 它根本不会调用 `apply()`。这是插件能遇到的最坏失败形态 —— 没有面板、没有 `/` 组、
		* 也没有任何报错（0.1.7 会话格式变更、0.2.0 装配差异都踩过这一条）。
		*
		* 所以本插件的 client 半边把必需服务全部当**软依赖**：
		*   - 顶层 `inject` 留空 → `apply()` 一定被调用，插件一定挂载；
		*   - 每个服务用 `ctx.get(name)` 现场读（cordis 里它**不需要 inject**），读不到就降级；
		*   - 缺什么由 {@link missingServices} 说清楚：面板上显示、日志里告警，而不是静默消失。
		*
		* 另一条与 `inject` 同源的坑：**属性路径（`ctx.remote.commands`）也是 inject 门控的**。
		* 子命名空间在 cordis 里是**独立注册的扁平服务**（名字就叫 `remote.commands`，由 gateway 的
		* `RemoteNamespaceService` 在嵌套 fiber 里 provide），读它只有 `ctx.get('remote.commands')`
		* 这一条路不需要 inject；`ctx.remote.commands` 会走 ctx 代理，报
		* `cannot get property "remote.commands" without inject` —— 于是"宿主明明有，插件却说缺"。
		* 见 {@link service}：整名优先，属性路径只作老宿主回退。
		*/
		/**
		* 必需服务。带 `.` 的名字（`remote.commands`）是 cordis 里**独立注册的扁平服务名**，
		* 不是"父服务上的属性"——只是老宿主可能把它挂在服务对象上，`service()` 才留了属性回退。
		* 顺序即告警文案里的顺序，从"没有它就没有界面"到"没有它只是少个数据通道"。
		*/
		const REQUIRED_SERVICES = [
			"slots",
			"sessions",
			"remote",
			"remote.commands",
			"locale"
		];
		/**
		* 读一个服务（或它的属性路径），**永不抛出**。
		*
		* 读法有两条，顺序不能反：
		*  1. **整名优先**：`ctx.get('remote.commands')`。cordis 里子命名空间就是独立注册的扁平服务，
		*     这条路不经过 inject 门控 —— 它是"没有顶层 inject 的插件"读 `remote.commands` 的**唯一**可行路径。
		*  2. **属性路径回退**：`ctx.get('remote').commands`。老宿主 / 测试替身把子命名空间挂在父服务对象上时走这条。
		*
		* `ctx.get()` 是 cordis 官方的"无 inject 读取"入口；老宿主没有它时回退到 `ctx[name]` —— 但那条路
		* 既会因"没有 inject 又没有实现"**抛错**（而不是返回 undefined），也**读不到扁平子命名空间**，
		* 所以必须整段接住：软依赖的全部意义就是不能让它带崩调用方，读不到就交给调用方按 undefined 处理。
		* @param ctx - client 上下文（宿主没给上下文时返回 undefined）。
		* @param path - 服务名，或 `服务名.属性.属性`。
		* @returns 服务值；缺失/不可读时为 undefined。
		*/
		function service(ctx, path) {
			const whole = readService(ctx, path);
			if (whole !== void 0) return whole;
			const [head, ...rest] = path.split(".");
			if (rest.length === 0) return whole;
			let value = readService(ctx, head);
			for (const key of rest) {
				if (value === null || value === void 0) return void 0;
				try {
					value = value[key];
				} catch {
					return;
				}
			}
			return value;
		}
		/**
		* 读一层服务实现：先 `ctx.get(name)`，再回退到属性访问。
		* @param ctx - client 上下文。
		* @param name - 服务名（不含路径）。
		* @returns 服务值，或 undefined。
		*/
		function readService(ctx, name) {
			if (ctx === null || ctx === void 0) return void 0;
			try {
				const get = ctx.get;
				if (typeof get === "function") {
					const found = get.call(ctx, name);
					if (found !== void 0) return found;
				}
			} catch {}
			try {
				return ctx[name];
			} catch {
				return;
			}
		}
		/**
		* 当前装配里读不到的必需服务。
		* @param ctx - client 上下文。
		* @param names - 待检查的服务路径，默认 {@link REQUIRED_SERVICES}。
		* @returns 缺失的服务路径；全都在时为 `[]`。
		*/
		function missingServices(ctx, names = REQUIRED_SERVICES) {
			return names.filter((name) => service(ctx, name) === void 0);
		}
		/**
		* 降级检查的宽限期（毫秒）。装配是异步的：`apply()` 时某个服务还没到位**不算缺失**
		* （它可能几百毫秒后才 provide），所以只在过了宽限期仍然读不到时才告警。
		*/
		const DEGRADED_GRACE_MS = 3e3;
		/**
		* 延后执行一次（宿主 ctx 有 `setTimeout` 就用它的，能随 fiber 一起回收）。
		* @param ctx - client 上下文。
		* @param delay - 毫秒。
		* @param fn - 回调。
		*/
		function later(ctx, delay, fn) {
			try {
				if (typeof ctx?.setTimeout === "function") {
					ctx.setTimeout(fn, delay);
					return;
				}
				const handle = globalThis.setTimeout(fn, delay);
				if (handle !== null && typeof handle === "object" && typeof handle.unref === "function") handle.unref();
			} catch {}
		}
		//#endregion
		//#region src/client/commands.ts
		/**
		* 客户端命令调用层：所有 `remote.commands.execute` 只走这里。
		*
		* 三件事必须集中在一处，否则每个调用点都会各漏一项：
		*  - 超时/取消（宿主 RPC 不返回时不能把面板永久锁死）；
		*  - 信封解析（宿主 `{ok:false,error}` 与 `{ok:true,value}` 是两种形状）；
		*  - 错误归一（调用点只关心 ok/text/error，不重复猜）。
		*/
		function errorText(value) {
			if (typeof value === "string") return value;
			if (value && typeof value === "object") {
				const record = value;
				if (typeof record.message === "string" && record.message) return record.message;
				if (typeof record.code === "string" && record.code) return record.code;
			}
			return "";
		}
		/**
		* 执行一条 `/tasks` 命令。
		* @param ctx client 上下文（服务一律软探测）
		* @param sessionId 当前会话；为空表示没有可用数据通道
		* @param line 完整命令行（以 `/tasks` 开头）
		* @param timeoutMs 超时；到点 abort，调用方拿到可重试的错误态
		*/
		async function invokeCommand(ctx, sessionId, line, timeoutMs = 15e3) {
			const commands = service(ctx, "remote.commands");
			if (!sessionId || !commands || typeof commands.execute !== "function") return {
				ok: false,
				text: "",
				error: "no-channel"
			};
			const controller = typeof AbortController === "function" ? new AbortController() : null;
			const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
			try {
				const response = await commands.execute(sessionId, line, [], controller?.signal);
				const envelope = response && typeof response === "object" ? response : null;
				if (envelope && envelope.ok === false) return {
					ok: false,
					text: "",
					error: errorText(envelope.error) || "command rejected"
				};
				const execution = envelope && "value" in envelope ? envelope.value : envelope;
				if (execution === void 0 || execution === null) return {
					ok: false,
					text: "",
					error: "unknown or malformed command"
				};
				const result = execution.result ?? execution;
				if (result?.kind === "error") return {
					ok: false,
					text: "",
					error: String(result.text ?? "command error")
				};
				return {
					ok: true,
					text: typeof result?.text === "string" ? result.text : ""
				};
			} catch (err) {
				return {
					ok: false,
					text: "",
					error: controller?.signal.aborted === true ? "command timed out" : String(err?.message ?? err)
				};
			} finally {
				if (timer !== null) clearTimeout(timer);
			}
		}
		//#endregion
		//#region src/client/task-scope.js
		/**
		* 跨标签页任务广播的**项目作用域**判定（纯函数，无 React / 无 BroadcastChannel 依赖）。
		*
		* 为什么需要它：同步频道名是固定的（同一浏览器同源的所有 dsh 页面共用一个
		* `dsh-pm-tasks-data`），而消息体只带任务数组。没有作用域判定时，在 A 项目点一下刷新，
		* B 项目的标签页面板就会被贴上 A 的任务列表——它自己保留着 B 的 `boundTaskId`，
		* 于是表现为"绑定莫名丢了"。频道名不能按项目拆：项目根是数据到达后才知道的，
		* 而 `new BroadcastChannel` 在模块加载期就要定名。
		*
		* 判据刻意**严格**：消息里没有根、或本页还没确定根，都不接受。
		*  - 无根：老宿主/老 bundle 的载荷，宁可不同步也不猜；
		*  - 本页未知根：它自己那一次 `/tasks` 会决定归属，不先借别人的数据（避免短暂显示错项目）。
		* 两侧都已知且相等时才接受——这正是"同一项目的两个标签页"。
		*
		* @param {string|null|undefined} localRoot - 本页当前数据的项目根（未同步过为 null）
		* @param {unknown} incomingRoot - 广播消息里的项目根
		* @returns {boolean} true = 这条广播属于同一个项目，可以套用
		*/
		function broadcastAppliesTo(localRoot, incomingRoot) {
			if (typeof incomingRoot !== "string" || incomingRoot === "") return false;
			if (typeof localRoot !== "string" || localRoot === "") return false;
			return localRoot === incomingRoot;
		}
		/**
		* 从 `/tasks` 载荷里取项目根（旧宿主没有该键）。
		* @param {unknown} value - `payload.root`
		* @returns {string|null} 非空字符串才算根
		*/
		function payloadRoot(value) {
			return typeof value === "string" && value !== "" ? value : null;
		}
		//#endregion
		//#region src/client/task-data-store.ts
		/**
		* Task Data Store — 仅管服务端同步的数据（tasks、boundTaskId、archivedCount）
		* - 单向数据流：命令执行结果 → setTasks → 广播给其他标签页
		* - 无 UI 状态，无 localStorage，纯内存 + BroadcastChannel 同步
		*/
		function parseTaskPayloadText(text) {
			if (!text) return null;
			let jsonBlock = null;
			const fenced = text.match(/```(?:json)?\s*\n([\s\S]*?)\n```/);
			if (fenced) jsonBlock = fenced[1];
			else {
				const lastBrace = text.lastIndexOf("{");
				if (lastBrace !== -1) jsonBlock = text.slice(lastBrace);
			}
			if (!jsonBlock) return null;
			try {
				const data = JSON.parse(jsonBlock);
				if (!Array.isArray(data.tasks)) return null;
				return {
					tasks: data.tasks,
					boundId: data.boundId ?? null,
					archived: data.archived ?? 0,
					root: payloadRoot(data.root)
				};
			} catch {
				return null;
			}
		}
		const SYNC_CHANNEL = typeof window !== "undefined" ? new BroadcastChannel("dsh-pm-tasks-data") : null;
		let dataState = {
			tasks: [],
			boundTaskId: null,
			archivedCount: 0,
			root: null,
			lastUpdate: 0
		};
		const dataListeners = /* @__PURE__ */ new Set();
		function setDataState(next) {
			const patch = typeof next === "function" ? next(dataState) : next;
			dataState = {
				tasks: Array.isArray(patch?.tasks) ? patch.tasks : [],
				boundTaskId: patch?.boundTaskId ?? null,
				archivedCount: typeof patch?.archivedCount === "number" ? patch.archivedCount : 0,
				root: payloadRoot(patch?.root),
				lastUpdate: typeof patch?.lastUpdate === "number" ? patch.lastUpdate : 0
			};
			for (const listener of dataListeners) listener();
		}
		function broadcastDataUpdate(tasks, archivedCount, root) {
			if (!SYNC_CHANNEL) return;
			SYNC_CHANNEL.postMessage({
				type: "PROJECT_TASKS_UPDATED",
				payload: {
					tasks: Array.isArray(tasks) ? tasks : [],
					archivedCount,
					root
				}
			});
		}
		if (SYNC_CHANNEL) SYNC_CHANNEL.onmessage = (event) => {
			const msg = event.data;
			if (msg?.type !== "PROJECT_TASKS_UPDATED" || !msg.payload) return;
			const { tasks, archivedCount, root } = msg.payload;
			if (!broadcastAppliesTo(dataState.root, root)) return;
			setDataState((prev) => ({
				...prev,
				tasks: Array.isArray(tasks) ? tasks : [],
				archivedCount: typeof archivedCount === "number" ? archivedCount : prev.archivedCount,
				lastUpdate: Date.now()
			}));
		};
		const taskDataStore = {
			subscribe(listener) {
				dataListeners.add(listener);
				return () => {
					dataListeners.delete(listener);
				};
			},
			getSnapshot() {
				return dataState;
			},
			actions: {
				setTasks(payload) {
					const nextTasks = payload.tasks || [];
					const nextArchived = payload.archivedCount ?? 0;
					const nextRoot = payloadRoot(payload.root);
					setDataState({
						tasks: nextTasks,
						boundTaskId: payload.boundTaskId ?? null,
						archivedCount: nextArchived,
						root: nextRoot,
						lastUpdate: Date.now()
					});
					broadcastDataUpdate(nextTasks, nextArchived, nextRoot);
				},
				reset() {
					setDataState({
						tasks: [],
						boundTaskId: null,
						archivedCount: 0,
						root: null,
						lastUpdate: 0
					});
				}
			}
		};
		function useTaskData() {
			return (0, react.useSyncExternalStore)(taskDataStore.subscribe, taskDataStore.getSnapshot, taskDataStore.getSnapshot);
		}
		function useTaskDataActions() {
			return taskDataStore.actions;
		}
		//#endregion
		//#region src/client/task-ui-store.ts
		/**
		* Task UI Store — 仅管本地 UI 状态（closed、minimized、position、expandedIds、theme、showHints）
		* - 持久化到 localStorage（key: dsh-pm-task-panel-ui）
		* - 不跨标签页同步（每个标签页独立）
		* - 启动/刷新强制 closed: true，面板默认不显示
		*/
		const STORAGE_KEY = "dsh-pm-task-panel-ui";
		/**
		* 面板的三个视图页。**单一事实来源**：面板的切页按钮与 `/` 菜单的三行都读它。
		* 两边各抄一份必然漂移 —— 实测就是这样：菜单行去执行宿主命令"开记忆页"，而面板的 view
		* 是组件内部 state，谁也够不着它，于是点击没有任何可见效果。
		*/
		const PANEL_VIEWS = [
			"task",
			"project",
			"global"
		];
		/** 把任意值收敛成一个合法视图页（脏 localStorage / 外部传入都要过这一关）。 */
		function normalizeView(value) {
			return PANEL_VIEWS.includes(value) ? value : "task";
		}
		function defaultPosition() {
			if (typeof window !== "undefined") return {
				x: Math.max(16, window.innerWidth - 408),
				y: 72
			};
			return {
				x: 0,
				y: 0
			};
		}
		/** 位置必须留在视口内：换小屏/拔掉外接屏后，持久化的坐标可能已经看不见。 */
		function clampPosition(value) {
			if (typeof window === "undefined") return defaultPosition();
			const pos = value;
			const x = Number(pos?.x);
			const y = Number(pos?.y);
			if (!Number.isFinite(x) || !Number.isFinite(y)) return defaultPosition();
			return {
				x: Math.max(8, Math.min(x, window.innerWidth - 80)),
				y: Math.max(8, Math.min(y, window.innerHeight - 40))
			};
		}
		/**
		* 启动时的初始状态：
		* - closed 恒为 true（不读取 localStorage 的 closed），刷新后面板隐藏；
		* - 其余（展开项/位置/主题）可恢复上次会话偏好，minimized 默认折叠成迷你条。
		*/
		function getDefaultUIState() {
			if (typeof window !== "undefined") try {
				const saved = localStorage.getItem(STORAGE_KEY);
				if (saved) {
					const parsed = JSON.parse(saved);
					return {
						expandedTaskIds: Array.isArray(parsed.expandedTaskIds) ? parsed.expandedTaskIds : [],
						panelPosition: clampPosition(parsed.panelPosition),
						minimized: parsed.minimized !== false,
						closed: true,
						theme: typeof parsed.theme === "string" ? parsed.theme : "native",
						showHints: parsed.showHints !== false,
						view: normalizeView(parsed.view)
					};
				}
			} catch {}
			return {
				expandedTaskIds: [],
				panelPosition: defaultPosition(),
				minimized: true,
				closed: true,
				theme: "native",
				showHints: true,
				view: "task"
			};
		}
		function persistUI(state) {
			if (typeof window === "undefined") return;
			try {
				localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
			} catch {}
		}
		let uiState = getDefaultUIState();
		const uiListeners = /* @__PURE__ */ new Set();
		function setUIState(next) {
			uiState = next;
			persistUI(next);
			for (const listener of uiListeners) listener();
		}
		const taskUIStore = {
			subscribe(listener) {
				uiListeners.add(listener);
				return () => {
					uiListeners.delete(listener);
				};
			},
			getSnapshot() {
				return uiState;
			},
			actions: {
				toggleTaskExpanded(taskId) {
					const prev = uiState;
					const ids = prev.expandedTaskIds.includes(taskId) ? prev.expandedTaskIds.filter((id) => id !== taskId) : [...prev.expandedTaskIds, taskId];
					setUIState({
						...prev,
						expandedTaskIds: ids
					});
				},
				expandAll(taskIds) {
					setUIState({
						...uiState,
						expandedTaskIds: taskIds
					});
				},
				setPanelPosition(pos) {
					setUIState({
						...uiState,
						panelPosition: clampPosition(pos)
					});
				},
				open() {
					setUIState({
						...uiState,
						minimized: false,
						closed: false
					});
				},
				/**
				* 切页但不动开合状态（面板里那个循环按钮用）。
				* 非法值一律忽略 —— 这个入口会被菜单行与脏 localStorage 碰到，静默归一比抛错合适。
				*/
				setView(view) {
					if (!PANEL_VIEWS.includes(view)) return;
					if (uiState.view === view) return;
					setUIState({
						...uiState,
						view
					});
				},
				/**
				* 打开面板并切到指定页 —— `/` 菜单那三行的**全部**动作。
				*
				* 纯客户端：不再绕 `remote.commands.execute('/tasks insight list …')` 一圈。那条路
				* 只在对话里留下一个命令节点，而客户端渲染命令节点的是按**命令名**分发的
				* `TaskCommandNode`（`name === 'tasks'`），它拿任务解析器去解记忆载荷，解析必然失败
				* —— 于是点菜单"开记忆页"什么都不会发生。
				* @param view - 目标视图页；非法值直接忽略（不打开面板，避免"点了没反应还弹窗"）。
				*/
				openView(view) {
					if (!PANEL_VIEWS.includes(view)) return;
					setUIState({
						...uiState,
						view,
						minimized: false,
						closed: false
					});
				},
				minimize() {
					setUIState({
						...uiState,
						minimized: true,
						closed: false
					});
				},
				close() {
					setUIState({
						...uiState,
						minimized: true,
						closed: true
					});
				},
				setTheme(theme) {
					setUIState({
						...uiState,
						theme
					});
				},
				toggleHints() {
					setUIState({
						...uiState,
						showHints: !uiState.showHints
					});
				},
				setShowHints(showHints) {
					setUIState({
						...uiState,
						showHints
					});
				},
				reset() {
					setUIState(getDefaultUIState());
				}
			}
		};
		function useTaskUI() {
			return (0, react.useSyncExternalStore)(taskUIStore.subscribe, taskUIStore.getSnapshot, taskUIStore.getSnapshot);
		}
		function useTaskUIActions() {
			return taskUIStore.actions;
		}
		//#endregion
		//#region src/client/task-hooks.ts
		/**
		* Task Panel Hooks — 步骤拖拽交互逻辑（useTaskDrag）。
		* 只依赖 react + task-data-store 类型，不碰数据/UI store。
		*/
		/**
		* useTaskDrag — 步骤拖拽重排（绑定任务内，同一任务卡的步骤行间移动）。
		*
		* 交互模型（拖动全程按住鼠标）：
		*  - 步骤行上按下（左键、非按钮/输入区域）→ 进入预览；
		*  - 按住 350ms 不松，或按住后移动超过 6px → 唤起跟随鼠标的浮动幽灵卡片；
		*  - 幽灵悬停到本任务卡内的步骤行时显示蓝色插入线（上半=插到该行前，下半=插到该行后）；
		*  - 松手（mouseup）：落在有效位置 → onReorder 落子；落在卡外/别的任务卡/原行
		*    （插入自身前后）/按钮输入等控件上 → 取消；
		*  - 350ms 内原地松手 = 普通点击，不产生幽灵；Esc → 取消。
		*/
		function useTaskDrag(taskId, steps, isBound, onReorder) {
			const [dragState, setDragState] = (0, react.useState)(null);
			const [dropTargetIndex, setDropTargetIndex] = (0, react.useState)(null);
			const dragRef = (0, react.useRef)(dragState);
			dragRef.current = dragState;
			const longPressTimer = (0, react.useRef)(void 0);
			const dragOrigin = (0, react.useRef)(null);
			const clearTimer = (0, react.useCallback)(() => {
				if (longPressTimer.current !== void 0) {
					window.clearTimeout(longPressTimer.current);
					longPressTimer.current = void 0;
				}
			}, []);
			const cancelDrag = (0, react.useCallback)(() => {
				clearTimer();
				dragOrigin.current = null;
				document.body.style.userSelect = "";
				setDropTargetIndex(null);
				setDragState(null);
			}, [clearTimer]);
			const startDrag = (0, react.useCallback)((fromIndex, stepContent, e) => {
				if (!isBound || e.button !== 0) return;
				if (dragRef.current) return;
				e.preventDefault();
				e.stopPropagation();
				document.body.style.userSelect = "none";
				dragOrigin.current = {
					x: e.clientX,
					y: e.clientY
				};
				setDropTargetIndex(null);
				setDragState({
					fromIndex,
					stepContent,
					clientX: e.clientX,
					clientY: e.clientY,
					dragging: false
				});
				clearTimer();
				longPressTimer.current = window.setTimeout(() => {
					longPressTimer.current = void 0;
					setDragState((prev) => prev ? {
						...prev,
						dragging: true
					} : null);
				}, 350);
			}, [isBound, clearTimer]);
			/** 计算某行上 y 坐标对应的插入位（行数下标：上半=该行前，下半=该行后）；非本任务卡返回 null */
			const dropIndexAt = (0, react.useCallback)((row, clientY) => {
				const parentOl = row.closest("ol");
				if (!parentOl || !parentOl.closest(`article[data-task-id="${taskId}"]`)) return null;
				const index = Array.from(parentOl.children).indexOf(row);
				const rect = row.getBoundingClientRect();
				return clientY < rect.top + rect.height / 2 ? index : index + 1;
			}, [taskId]);
			/** 在 (x,y) 处结算：命中有效落点则重排，否则取消；并结束本次拖拽 */
			const commitDrop = (0, react.useCallback)((x, y) => {
				const cur = dragRef.current;
				if (!cur || !cur.dragging) return;
				const el = document.elementFromPoint(x, y);
				if (el && !el.closest("button, input, textarea, a")) {
					const row = el.closest("[data-step-row]");
					if (row) {
						const drop = dropIndexAt(row, y);
						if (drop !== null) {
							if ((drop > cur.fromIndex ? drop - 1 : drop) !== cur.fromIndex) onReorder(cur.fromIndex, drop);
						}
					}
				}
				cancelDrag();
			}, [
				dropIndexAt,
				onReorder,
				cancelDrag
			]);
			const active = dragState !== null;
			(0, react.useEffect)(() => {
				if (!active) return;
				const onMouseMove = (e) => {
					const cur = dragRef.current;
					if (!cur) return;
					if (!cur.dragging) {
						const origin = dragOrigin.current;
						if (!origin) return;
						if (Math.hypot(e.clientX - origin.x, e.clientY - origin.y) < 6) return;
						clearTimer();
						setDragState((prev) => prev ? {
							...prev,
							dragging: true,
							clientX: e.clientX,
							clientY: e.clientY
						} : null);
					} else setDragState((prev) => prev ? {
						...prev,
						clientX: e.clientX,
						clientY: e.clientY
					} : null);
					const row = document.elementFromPoint(e.clientX, e.clientY)?.closest("[data-step-row]");
					setDropTargetIndex(row ? dropIndexAt(row, e.clientY) : null);
				};
				const onMouseUp = (e) => {
					const cur = dragRef.current;
					if (!cur) return;
					if (cur.dragging) commitDrop(e.clientX, e.clientY);
					else cancelDrag();
				};
				const onClick = (e) => {
					const cur = dragRef.current;
					if (!cur || !cur.dragging) return;
					commitDrop(e.clientX, e.clientY);
				};
				const onKeyDown = (e) => {
					if (e.key === "Escape") cancelDrag();
				};
				window.addEventListener("mousemove", onMouseMove);
				window.addEventListener("mouseup", onMouseUp);
				window.addEventListener("click", onClick, true);
				window.addEventListener("keydown", onKeyDown);
				return () => {
					window.removeEventListener("mousemove", onMouseMove);
					window.removeEventListener("mouseup", onMouseUp);
					window.removeEventListener("click", onClick, true);
					window.removeEventListener("keydown", onKeyDown);
					document.body.style.userSelect = "";
				};
			}, [
				active,
				taskId,
				dropIndexAt,
				onReorder,
				cancelDrag,
				commitDrop
			]);
			(0, react.useEffect)(() => () => clearTimer(), [clearTimer]);
			return {
				dragState,
				dropTargetIndex,
				startDrag,
				cancelDrag
			};
		}
		//#endregion
		//#region \0dsh-css:src/client/TaskPanel.module.css.mjs
		const css$2 = ".i54Wjq_panel{pointer-events:auto;background:var(--dsw-alias-bg-layer-2,var(--dsw-alias-bg-base,#fff));border:1px solid var(--dsw-alias-border-l2,#7f7f7f4d);border-radius:14px;flex-direction:column;width:380px;max-width:calc(100vw - 24px);max-height:min(70vh,640px);font-family:inherit;animation:.18s ease-out i54Wjq_panelIn;display:flex;position:fixed;overflow:hidden;box-shadow:0 12px 32px #00000029,0 2px 8px #00000014}@keyframes i54Wjq_panelIn{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}.i54Wjq_dragHandle{cursor:grab;z-index:1;justify-content:center;align-items:center;height:12px;display:flex;position:absolute;top:0;left:0;right:0}.i54Wjq_dragHandle:active{cursor:grabbing}.i54Wjq_handleGrip{background:var(--dsw-alias-separator-primary,#7f7f7f59);opacity:.8;border-radius:2px;width:32px;height:3px}.i54Wjq_header{border-bottom:1px solid var(--dsw-alias-border-l1,#7f7f7f2e);-webkit-user-select:none;user-select:none;justify-content:space-between;align-items:center;gap:8px;padding:10px 10px 8px 14px;display:flex}.i54Wjq_headerLeft{align-items:center;gap:6px;min-width:0;display:flex}.i54Wjq_headerIcon{color:var(--dsw-alias-label-secondary);flex:none}.i54Wjq_headerTitle{color:var(--dsw-alias-label-primary);white-space:nowrap;margin:0;font-size:13px;font-weight:600;line-height:20px}.i54Wjq_headerRight{align-items:center;gap:2px;margin-left:auto;display:flex}.i54Wjq_hintsOff{opacity:.45}.i54Wjq_hintsOff:hover{opacity:.75}.i54Wjq_counts{color:var(--dsw-alias-label-tertiary);white-space:nowrap;margin-right:4px;font-size:11px;line-height:16px}.i54Wjq_boundBadge{color:var(--dsw-alias-label-primary-foreground,#fff);background:var(--dsw-alias-button-primary-fill,#3a6ef5);white-space:nowrap;border-radius:7px;flex:none;padding:0 6px;font-size:10px;line-height:14px}.i54Wjq_notice{color:var(--dsw-alias-state-warn-label,#b7791f);background:var(--dsw-alias-interactive-bg-hover,#7f7f7f1a);word-break:break-all;border-radius:8px;margin:8px 12px 0;padding:6px 10px;font-size:12px;line-height:18px}.i54Wjq_taskList{scrollbar-width:thin;scrollbar-color:var(--dsw-alias-scrollbar-bg-l2,transparent) transparent;flex-direction:column;gap:6px;padding:8px;display:flex;overflow-y:auto}.i54Wjq_emptyState{text-align:center;color:var(--dsw-alias-label-secondary);padding:36px 24px 30px}.i54Wjq_emptyTitle{color:var(--dsw-alias-label-primary);margin:0 0 6px;font-size:13px;font-weight:600}.i54Wjq_emptyDesc{color:var(--dsw-alias-label-tertiary);margin:0;font-size:12px;line-height:20px}.i54Wjq_syncHint{color:var(--dsw-alias-label-dimmed);justify-content:center;align-items:center;gap:6px;margin:10px 0 0;font-size:11px;display:flex}.i54Wjq_card{border:1px solid var(--dsw-alias-border-l1,#7f7f7f29);background:var(--dsw-alias-bg-base,transparent);content-visibility:auto;contain-intrinsic-size:auto 140px;border-radius:10px;transition:border-color .15s;overflow:hidden}.i54Wjq_cardBound{border-color:var(--dsw-alias-border-l3,#7f7f7f59);box-shadow:inset 0 0 0 .5px var(--dsw-alias-border-l3,transparent)}.i54Wjq_cardHead{cursor:pointer;text-align:left;background:0 0;border:none;justify-content:space-between;align-items:center;gap:8px;width:100%;padding:8px 10px 7px;display:flex}.i54Wjq_cardHead:hover{background:var(--dsw-alias-interactive-bg-hover,#7f7f7f14)}.i54Wjq_cardTitleRow{align-items:center;gap:6px;min-width:0;display:flex}.i54Wjq_cardTitle{color:var(--dsw-alias-label-primary);white-space:nowrap;text-overflow:ellipsis;font-size:13px;font-weight:500;line-height:20px;overflow:hidden}.i54Wjq_cardMeta{color:var(--dsw-alias-label-tertiary);flex:none;align-items:center;gap:8px;display:flex}.i54Wjq_progressText{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-secondary);font-size:11px;line-height:16px}.i54Wjq_updated{color:var(--dsw-alias-label-dimmed);font-size:10px;line-height:14px}.i54Wjq_chevron{color:var(--dsw-alias-label-tertiary);display:inline-flex}.i54Wjq_track{background:var(--dsw-alias-interactive-bg-hover,#7f7f7f1f);border-radius:1px;height:2px;margin:0 10px 6px;overflow:hidden}.i54Wjq_trackFill{background:var(--dsw-alias-label-primary-bluish,var(--dsw-alias-button-primary-fill,#3a6ef5));border-radius:1px;height:100%;transition:width .2s}.i54Wjq_cardBody{border-top:1px solid var(--dsw-alias-border-l1,#7f7f7f24);overscroll-behavior:contain;max-height:300px;padding:8px 10px 10px;overflow-y:auto}.i54Wjq_section{margin-bottom:8px}.i54Wjq_section:last-child{margin-bottom:0}.i54Wjq_sectionLabel{color:var(--dsw-alias-label-secondary);align-items:center;gap:6px;margin-bottom:4px;font-size:11px;line-height:16px;display:flex}.i54Wjq_sectionCount{background:var(--dsw-alias-interactive-bg-hover,#7f7f7f1a);color:var(--dsw-alias-label-tertiary);border-radius:6px;padding:0 5px;font-size:10px;line-height:14px}.i54Wjq_stepsList{flex-direction:column;gap:1px;margin:0;padding:0;list-style:none;display:flex}.i54Wjq_stepRow{align-items:flex-start;gap:7px;padding:3px 2px;display:flex}.i54Wjq_stepRow>svg{flex:none;margin-top:2px}.i54Wjq_stepDone{color:var(--dsw-alias-label-dimmed)}.i54Wjq_stepRun{color:var(--dsw-alias-label-primary-bluish,#3a6ef5)}.i54Wjq_stepPending{background:var(--dsw-alias-border-l3,#7f7f7f80);border-radius:50%;flex:none;width:8px;height:8px;margin:5px 3px}.i54Wjq_stepContent{color:var(--dsw-alias-label-secondary);word-break:break-word;white-space:pre-wrap;font-size:12px;line-height:20px}.i54Wjq_stepContentDone{color:var(--dsw-alias-label-dimmed);text-decoration:line-through}.i54Wjq_stepContentRun{color:var(--dsw-alias-label-primary)}.i54Wjq_muted{color:var(--dsw-alias-label-dimmed);font-size:11px;line-height:18px}.i54Wjq_filesList{flex-direction:column;margin:0;padding:0;list-style:none;display:flex}.i54Wjq_fileRow{cursor:pointer;text-align:left;background:0 0;border:none;border-radius:6px;align-items:center;gap:6px;width:100%;padding:3px 4px;display:flex}.i54Wjq_fileRow:hover{background:var(--dsw-alias-interactive-bg-hover,#7f7f7f14)}.i54Wjq_fileDot{background:var(--dsw-alias-border-l3,#7f7f7f80);border-radius:50%;flex:none;width:5px;height:5px}.i54Wjq_filePath{color:var(--dsw-alias-label-secondary);white-space:nowrap;text-overflow:ellipsis;text-align:left;direction:rtl;font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:11px;line-height:18px;overflow:hidden}.i54Wjq_fileLine{color:var(--dsw-alias-label-dimmed);flex:none;font-size:10px;line-height:18px}.i54Wjq_cardFooter{gap:6px;margin-top:8px;display:flex}@media (prefers-reduced-motion:reduce){.i54Wjq_panel{animation:none}.i54Wjq_trackFill,.i54Wjq_card{transition:none}}.i54Wjq_miniBar{border:1px solid var(--dsw-alias-border-l3,#7f7f7f4d);background:var(--dsw-alias-bg-layer-2,var(--dsw-alias-bg-base,#fff));max-width:min(46vw,340px);height:34px;color:var(--dsw-alias-label-primary);cursor:grab;-webkit-user-select:none;user-select:none;pointer-events:auto;border-radius:999px;align-items:center;gap:7px;padding:0 12px;font-size:12px;line-height:18px;transition:background .15s,border-color .15s;display:inline-flex;position:fixed;box-shadow:0 6px 20px #00000024,0 1px 4px #00000014}.i54Wjq_miniBar:active{cursor:grabbing}.i54Wjq_miniBar:hover{background:var(--dsw-alias-interactive-bg-hover,#7f7f7f14)}.i54Wjq_miniIcon{color:var(--dsw-alias-label-secondary);flex:none}.i54Wjq_miniText{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.i54Wjq_miniChevron{color:var(--dsw-alias-label-tertiary);flex:none}.i54Wjq_taskList{flex:auto;min-height:0}.i54Wjq_card{flex-direction:column;display:flex}.i54Wjq_boundaryFallback{border:1px solid var(--dsw-alias-border-l3,#7f7f7f4d);background:var(--dsw-alias-bg-layer-2,#fff);color:var(--dsw-alias-label-secondary);cursor:pointer;pointer-events:auto;border-radius:999px;padding:4px 10px;font-size:12px;line-height:18px;position:fixed;top:64px;right:16px}.i54Wjq_stepToggle{cursor:pointer;background:0 0;border:none;border-radius:4px;flex:none;align-items:center;margin-top:2px;padding:0;display:inline-flex}.i54Wjq_stepToggle:hover{background:var(--dsw-alias-interactive-bg-hover,#7f7f7f1f)}.i54Wjq_stepToggle:disabled{cursor:default;opacity:.5}.i54Wjq_stepEditable{cursor:text;border-radius:3px}.i54Wjq_stepEditable:hover{outline:1px dashed var(--dsw-alias-border-l3,#7f7f7f66);outline-offset:1px}.i54Wjq_stepInput{box-sizing:border-box;width:auto;min-width:0;font:inherit;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-base,transparent);border:1px solid var(--dsw-alias-border-l3,#7f7f7f73);border-radius:5px;flex:auto;padding:0 5px;font-size:12px;line-height:20px}.i54Wjq_editorArea{box-sizing:border-box;min-width:0;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-base,transparent);border:1px solid var(--dsw-alias-border-l3,#7f7f7f73);resize:none;vertical-align:middle;cursor:text;white-space:pre-wrap;word-break:break-word;border-radius:5px;flex:1;margin:0;padding:2px 5px;font-family:inherit;font-size:12px;line-height:20px;overflow:hidden}.i54Wjq_editorArea:focus{border-color:var(--dsw-alias-border-l3,#7f7f7f99);outline:none}.i54Wjq_stepDragging{opacity:.3;background:var(--dsw-alias-interactive-bg-hover,#7f7f7f14)}.i54Wjq_cardTitleEditable{cursor:text;border-radius:3px}.i54Wjq_cardTitleEditable:hover{outline:1px dashed var(--dsw-alias-border-l3,#7f7f7f66);outline-offset:1px}.i54Wjq_panel[data-theme=glass],.i54Wjq_miniBar[data-theme=glass]{background:color-mix(in srgb, var(--dsw-alias-bg-layer-2,#fff) 90%, transparent);-webkit-backdrop-filter:blur(18px)saturate(1.2);border:1px solid color-mix(in srgb, var(--dsw-alias-border-l2,#7f7f7f4d) 80%, transparent)}.i54Wjq_panel[data-theme=glass] .i54Wjq_card{background:color-mix(in srgb, var(--dsw-alias-bg-base,transparent) 84%, transparent);border-color:color-mix(in srgb, var(--dsw-alias-border-l1,#7f7f7f29) 60%, transparent)}.i54Wjq_panel[data-theme=glass] .i54Wjq_cardBody{border-top-color:color-mix(in srgb, var(--dsw-alias-border-l1,#7f7f7f24) 60%, transparent)}@media (prefers-reduced-transparency:reduce){.i54Wjq_panel[data-theme=glass],.i54Wjq_miniBar[data-theme=glass]{background:var(--dsw-alias-bg-layer-2,#fff);-webkit-backdrop-filter:none;backdrop-filter:none}.i54Wjq_panel[data-theme=glass] .i54Wjq_card{background:var(--dsw-alias-bg-base,transparent)}}@supports not ((-webkit-backdrop-filter:blur(1px)) or (backdrop-filter:blur(1px))){.i54Wjq_panel[data-theme=glass],.i54Wjq_miniBar[data-theme=glass]{background:var(--dsw-alias-bg-layer-2,#fff)}}.i54Wjq_panel[data-theme=brutal]{box-shadow:none;border-width:1px;border-radius:6px}.i54Wjq_panel[data-theme=brutal] .i54Wjq_card{border:1px solid var(--dsw-alias-border-l3,#7f7f7f6b);background:var(--dsw-alias-bg-base,transparent);box-shadow:none;border-radius:3px}.i54Wjq_panel[data-theme=brutal] .i54Wjq_cardHead{padding:7px 10px 6px}.i54Wjq_panel[data-theme=brutal] .i54Wjq_cardTitle{letter-spacing:.01em;font-weight:650}.i54Wjq_panel[data-theme=brutal] .i54Wjq_headerTitle{letter-spacing:.03em}.i54Wjq_panel[data-theme=brutal] .i54Wjq_boundBadge{border-radius:2px}.i54Wjq_panel[data-theme=brutal] .i54Wjq_track{border-radius:0;height:3px}.i54Wjq_panel[data-theme=brutal] .i54Wjq_trackFill{border-radius:0}.i54Wjq_panel[data-theme=brutal] .i54Wjq_cardBody{border-top:1px solid var(--dsw-alias-border-l2,#7f7f7f3d)}.i54Wjq_panel[data-theme=mono] .i54Wjq_headerTitle,.i54Wjq_panel[data-theme=mono] .i54Wjq_counts,.i54Wjq_panel[data-theme=mono] .i54Wjq_cardTitle,.i54Wjq_panel[data-theme=mono] .i54Wjq_progressText,.i54Wjq_panel[data-theme=mono] .i54Wjq_stepContent,.i54Wjq_panel[data-theme=mono] .i54Wjq_filePath{font-family:ui-monospace,SF Mono,Menlo,Consolas,Liberation Mono,monospace}.i54Wjq_panel[data-theme=mono] .i54Wjq_cardTitle{font-size:12px}.i54Wjq_panel[data-theme=mono] .i54Wjq_stepContent{font-size:11.5px}.i54Wjq_panel[data-theme=mono] .i54Wjq_card{border-radius:5px}.i54Wjq_panel[data-theme=mono] .i54Wjq_trackFill{border-radius:0}.i54Wjq_panel[data-theme=mono] .i54Wjq_stepPending{border-radius:1px}.i54Wjq_panel[data-theme=mono] .i54Wjq_updated{letter-spacing:.02em}.i54Wjq_headerIconBtn{color:inherit;cursor:pointer;background:0 0;border:none;border-radius:0;flex:none;justify-content:center;align-items:center;margin:0;padding:0;display:inline-flex}.i54Wjq_headerIcon{color:var(--dsw-alias-label-secondary);flex:none;display:block}.i54Wjq_headerLeft{min-width:0}.i54Wjq_headerTitle{text-overflow:ellipsis;flex:0 auto;min-width:0;overflow:hidden}.i54Wjq_headerRight{min-width:0}.i54Wjq_counts{text-overflow:ellipsis;flex:none;max-width:45%;margin-left:auto;overflow:hidden}.i54Wjq_dragGhost{pointer-events:none;z-index:9999;transition:left 50ms,top 50ms;position:fixed;transform:translate(-50%,-50%)}.i54Wjq_dragGhostCard{background:var(--dsw-alias-bg-layer-2,var(--dsw-alias-bg-base,#fff));border:1px solid var(--dsw-alias-border-l3,#7f7f7f59);color:var(--dsw-alias-label-primary);white-space:nowrap;border-radius:8px;align-items:center;gap:8px;max-width:280px;padding:8px 12px;font-size:12px;line-height:20px;display:inline-flex;transform:scale(.9);box-shadow:0 8px 24px #0000002e,0 2px 8px #0000001a}.i54Wjq_dragGhostContent{text-overflow:ellipsis;word-break:break-word;flex:1;min-width:0;overflow:hidden}.i54Wjq_dragGhostClose{width:20px;height:20px;color:var(--dsw-alias-label-tertiary);cursor:pointer;opacity:.6;background:0 0;border:none;border-radius:4px;flex:none;justify-content:center;align-items:center;margin-left:8px;font-size:16px;line-height:1;transition:opacity .15s,background .15s,color .15s;display:inline-flex}.i54Wjq_dragGhostClose:hover{opacity:1;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-interactive-bg-hover,#7f7f7f1f)}.i54Wjq_dropTargetBefore{position:relative}.i54Wjq_dropTargetBefore:before{content:\"\";background:var(--dsw-alias-button-primary-fill,#3a6ef5);height:2px;box-shadow:0 0 4px var(--dsw-alias-button-primary-fill,#3a6ef5);border-radius:1px;animation:.8s ease-in-out infinite i54Wjq_dropPulse;position:absolute;top:-1px;left:0;right:0}.i54Wjq_dropTargetAfter{position:relative}.i54Wjq_dropTargetAfter:after{content:\"\";background:var(--dsw-alias-button-primary-fill,#3a6ef5);height:2px;box-shadow:0 0 4px var(--dsw-alias-button-primary-fill,#3a6ef5);border-radius:1px;animation:.8s ease-in-out infinite i54Wjq_dropPulse;position:absolute;bottom:-1px;left:0;right:0}@keyframes i54Wjq_dropPulse{0%,to{opacity:.6}50%{opacity:1}}.i54Wjq_memoryPane{flex-direction:column;gap:6px;max-height:480px;padding:8px 10px 10px;display:flex;overflow:auto}.i54Wjq_memToolbar{justify-content:space-between;align-items:center;gap:8px;display:flex}.i54Wjq_memCount{opacity:.75;font-size:12px;font-weight:600}.i54Wjq_memList{flex-direction:column;gap:6px;display:flex}.i54Wjq_memSentinel{flex:none;height:1px}.i54Wjq_memFooter{flex-direction:column;align-items:center;gap:4px;padding:6px 0 2px;font-size:12px;display:flex}.i54Wjq_memRow{border:1px solid var(--dsw-border-weak,#80808040);background:color-mix(in srgb, var(--dsw-bg-secondary,#f5f5f5) 45%, transparent);content-visibility:auto;contain-intrinsic-size:auto 76px;border-radius:6px;flex-direction:column;gap:4px;padding:6px 8px;display:flex}.i54Wjq_memRowArchived{opacity:.55}.i54Wjq_memRowMain{flex-direction:column;gap:2px;display:flex}.i54Wjq_memTitle{word-break:break-word;align-items:flex-start;gap:6px;font-size:13px;line-height:1.35;display:flex}.i54Wjq_kindBadge{background:var(--dsw-accent-soft,#5078ff26);color:var(--dsw-accent,#4d6bfe);border-radius:4px;flex:none;padding:0 5px;font-size:11px;line-height:1.5}.i54Wjq_memMeta{flex-wrap:wrap;align-items:center;gap:4px;display:flex}.i54Wjq_badge{background:color-mix(in srgb, var(--dsw-fg,#222) 8%, transparent);border-radius:4px;padding:0 5px;font-size:11px;line-height:1.5}.i54Wjq_badgeDraft{color:#b26a00;background:#ffb40029}.i54Wjq_badgeArchived{opacity:.8}.i54Wjq_memBody{opacity:.8;word-break:break-word;font-size:12px}.i54Wjq_memActs{flex-wrap:wrap;gap:4px;display:flex}.i54Wjq_memToolbarActs{align-items:center;gap:6px;display:flex}.i54Wjq_memNew{border:1px solid var(--dsw-border-weak,#80808040);border-radius:6px;flex-direction:column;gap:6px;padding:8px;display:flex}.i54Wjq_memNewRow{align-items:center;gap:8px;display:flex}.i54Wjq_memLabel{opacity:.8;align-items:center;gap:6px;font-size:12px;display:inline-flex}.i54Wjq_memNew select,.i54Wjq_memNew textarea{box-sizing:border-box;width:100%}";
		const tagId$2 = "@yolk_vat-y/dsh-project-memory/TaskPanel.module.css";
		if (typeof document !== "undefined") {
			const selector = "style[data-plugin-css=" + JSON.stringify(tagId$2) + "]";
			const existing = document.querySelector(selector);
			if (existing) existing.textContent = css$2;
			else {
				const tag = document.createElement("style");
				tag.dataset.plugin = "@yolk_vat-y/dsh-project-memory";
				tag.dataset.pluginCss = tagId$2;
				tag.textContent = css$2;
				document.head.appendChild(tag);
			}
		}
		var TaskPanel_module_css_default = {
			"badge": "i54Wjq_badge",
			"badgeArchived": "i54Wjq_badgeArchived",
			"badgeDraft": "i54Wjq_badgeDraft",
			"boundBadge": "i54Wjq_boundBadge",
			"boundaryFallback": "i54Wjq_boundaryFallback",
			"card": "i54Wjq_card",
			"cardBody": "i54Wjq_cardBody",
			"cardBound": "i54Wjq_cardBound",
			"cardFooter": "i54Wjq_cardFooter",
			"cardHead": "i54Wjq_cardHead",
			"cardMeta": "i54Wjq_cardMeta",
			"cardTitle": "i54Wjq_cardTitle",
			"cardTitleEditable": "i54Wjq_cardTitleEditable",
			"cardTitleRow": "i54Wjq_cardTitleRow",
			"chevron": "i54Wjq_chevron",
			"counts": "i54Wjq_counts",
			"dragGhost": "i54Wjq_dragGhost",
			"dragGhostCard": "i54Wjq_dragGhostCard",
			"dragGhostClose": "i54Wjq_dragGhostClose",
			"dragGhostContent": "i54Wjq_dragGhostContent",
			"dragHandle": "i54Wjq_dragHandle",
			"dropPulse": "i54Wjq_dropPulse",
			"dropTargetAfter": "i54Wjq_dropTargetAfter",
			"dropTargetBefore": "i54Wjq_dropTargetBefore",
			"editorArea": "i54Wjq_editorArea",
			"emptyDesc": "i54Wjq_emptyDesc",
			"emptyState": "i54Wjq_emptyState",
			"emptyTitle": "i54Wjq_emptyTitle",
			"fileDot": "i54Wjq_fileDot",
			"fileLine": "i54Wjq_fileLine",
			"filePath": "i54Wjq_filePath",
			"fileRow": "i54Wjq_fileRow",
			"filesList": "i54Wjq_filesList",
			"handleGrip": "i54Wjq_handleGrip",
			"header": "i54Wjq_header",
			"headerIcon": "i54Wjq_headerIcon",
			"headerIconBtn": "i54Wjq_headerIconBtn",
			"headerLeft": "i54Wjq_headerLeft",
			"headerRight": "i54Wjq_headerRight",
			"headerTitle": "i54Wjq_headerTitle",
			"hintsOff": "i54Wjq_hintsOff",
			"kindBadge": "i54Wjq_kindBadge",
			"memActs": "i54Wjq_memActs",
			"memBody": "i54Wjq_memBody",
			"memCount": "i54Wjq_memCount",
			"memFooter": "i54Wjq_memFooter",
			"memLabel": "i54Wjq_memLabel",
			"memList": "i54Wjq_memList",
			"memMeta": "i54Wjq_memMeta",
			"memNew": "i54Wjq_memNew",
			"memNewRow": "i54Wjq_memNewRow",
			"memRow": "i54Wjq_memRow",
			"memRowArchived": "i54Wjq_memRowArchived",
			"memRowMain": "i54Wjq_memRowMain",
			"memSentinel": "i54Wjq_memSentinel",
			"memTitle": "i54Wjq_memTitle",
			"memToolbar": "i54Wjq_memToolbar",
			"memToolbarActs": "i54Wjq_memToolbarActs",
			"memoryPane": "i54Wjq_memoryPane",
			"miniBar": "i54Wjq_miniBar",
			"miniChevron": "i54Wjq_miniChevron",
			"miniIcon": "i54Wjq_miniIcon",
			"miniText": "i54Wjq_miniText",
			"muted": "i54Wjq_muted",
			"notice": "i54Wjq_notice",
			"panel": "i54Wjq_panel",
			"panelIn": "i54Wjq_panelIn",
			"progressText": "i54Wjq_progressText",
			"section": "i54Wjq_section",
			"sectionCount": "i54Wjq_sectionCount",
			"sectionLabel": "i54Wjq_sectionLabel",
			"stepContent": "i54Wjq_stepContent",
			"stepContentDone": "i54Wjq_stepContentDone",
			"stepContentRun": "i54Wjq_stepContentRun",
			"stepDone": "i54Wjq_stepDone",
			"stepDragging": "i54Wjq_stepDragging",
			"stepEditable": "i54Wjq_stepEditable",
			"stepInput": "i54Wjq_stepInput",
			"stepPending": "i54Wjq_stepPending",
			"stepRow": "i54Wjq_stepRow",
			"stepRun": "i54Wjq_stepRun",
			"stepToggle": "i54Wjq_stepToggle",
			"stepsList": "i54Wjq_stepsList",
			"syncHint": "i54Wjq_syncHint",
			"taskList": "i54Wjq_taskList",
			"track": "i54Wjq_track",
			"trackFill": "i54Wjq_trackFill",
			"updated": "i54Wjq_updated"
		};
		//#endregion
		//#region src/client/TaskComponents.tsx
		/**
		* Task Panel Presentational 组件 — MiniBar（折叠迷你条）与 TaskCard（任务卡）。
		* 纯渲染 + 卡片局部行内编辑/拖拽状态，动作经 props 回调交给容器（TaskPanel.tsx）。
		*/
		function insightKindLabel(kind, t) {
			return {
				lesson: t("mem.kind.lesson"),
				decision: t("mem.kind.decision"),
				procedure: t("mem.kind.procedure"),
				experience: t("mem.kind.experience")
			}[kind] ?? kind;
		}
		function timeAgo(iso) {
			if (!iso) return "";
			const diff = Date.now() - new Date(iso).getTime();
			const m = Math.floor(diff / 6e4);
			if (m < 1) return "刚刚";
			if (m < 60) return `${m}分钟前`;
			const h = Math.floor(m / 60);
			if (h < 24) return `${h}小时前`;
			return `${Math.floor(h / 24)}天前`;
		}
		function StepIcon({ status }) {
			if (status === "completed") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCheckOutline16, { className: TaskPanel_module_css_default.stepDone });
			if (status === "in_progress") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconPlayOutline16, { className: TaskPanel_module_css_default.stepRun });
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: TaskPanel_module_css_default.stepPending });
		}
		/**
		* 双击判定窗口（ms）。
		* 单击（如卡片展开/收起）会延迟该时长执行：若期间收到第二次点击则按“双击”处理并取消单击，
		* 从而避免“第一下先展开/收起、布局位移后第二下点不到目标”的问题。
		* 数值是可感知与可靠性的折中：太小慢速双击会失效，太大单击会显“肉”。
		*/
		const CLICK_SINGLE_DELAY_MS = 250;
		function InlineEditor({ value, className, maxRows = 8, onValueChange, onCommit, onCancel }) {
			const ref = (0, react.useRef)(null);
			(0, react.useLayoutEffect)(() => {
				const el = ref.current;
				if (!el) return;
				el.style.height = "auto";
				const cs = getComputedStyle(el);
				const lineHeight = parseFloat(cs.lineHeight) || 20;
				const padV = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
				const borderV = (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
				const cap = maxRows * lineHeight + padV + borderV;
				const height = Math.min(el.scrollHeight, cap);
				el.style.height = `${height}px`;
				el.style.overflowY = el.scrollHeight > cap ? "auto" : "hidden";
			}, [value, maxRows]);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
				ref,
				className,
				rows: 1,
				value,
				autoFocus: true,
				spellCheck: false,
				onChange: (e) => onValueChange(e.target.value),
				onFocus: (e) => {
					const len = e.target.value.length;
					e.target.setSelectionRange(len, len);
				},
				onBlur: onCommit,
				onKeyDown: (e) => {
					if (e.key === "Enter" && !e.shiftKey) {
						e.preventDefault();
						onCommit();
					} else if (e.key === "Escape") {
						e.preventDefault();
						onCancel();
					}
				}
			});
		}
		function MiniBar({ label, hint, showHints, position, theme, onMove, open }) {
			const barRef = (0, react.useRef)(null);
			const down = (0, react.useRef)(null);
			const onMouseDown = (e) => {
				if (e.button !== 0) return;
				const rect = barRef.current?.getBoundingClientRect();
				if (!rect) return;
				down.current = {
					dx: e.clientX - rect.left,
					dy: e.clientY - rect.top,
					sx: e.clientX,
					sy: e.clientY,
					moved: false
				};
				const onMoveEv = (ev) => {
					const d = down.current;
					if (!d) return;
					if (!d.moved && Math.abs(ev.clientX - d.sx) + Math.abs(ev.clientY - d.sy) > 4) d.moved = true;
					if (d.moved) {
						const w = barRef.current?.offsetWidth ?? 260;
						const h = barRef.current?.offsetHeight ?? 34;
						onMove({
							x: Math.max(8, Math.min(window.innerWidth - w - 8, ev.clientX - d.dx)),
							y: Math.max(8, Math.min(window.innerHeight - h - 8, ev.clientY - d.dy))
						});
					}
				};
				const onUpEv = () => {
					const d = down.current;
					down.current = null;
					window.removeEventListener("mousemove", onMoveEv);
					window.removeEventListener("mouseup", onUpEv);
					if (d && !d.moved) open();
				};
				window.addEventListener("mousemove", onMoveEv);
				window.addEventListener("mouseup", onUpEv);
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				ref: barRef,
				className: TaskPanel_module_css_default.miniBar,
				style: {
					left: position.x,
					top: position.y
				},
				"data-theme": theme === "native" ? void 0 : theme,
				onMouseDown,
				onKeyDown: (e) => {
					if (e.key === "Enter" || e.key === " ") {
						e.preventDefault();
						open();
					}
				},
				role: "button",
				tabIndex: 0,
				title: showHints ? hint : void 0,
				"aria-label": hint,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconFolderOpenOutline16, { className: TaskPanel_module_css_default.miniIcon }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: TaskPanel_module_css_default.miniText,
						children: label
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { className: TaskPanel_module_css_default.miniChevron })
				]
			});
		}
		function TaskCard({ task, isBound, expanded, onToggleExpand, onSwitch, onUnbind, onArchive, onRename, onEditStep, onCycleStatus, onReorderSteps, onInsightAction, showHints, syncing, t }) {
			const steps = task.steps || [];
			const { dragState, dropTargetIndex, startDrag, cancelDrag } = useTaskDrag(task.id, steps, isBound, onReorderSteps);
			const [stepEdit, setStepEdit] = (0, react.useState)(null);
			const [titleEdit, setTitleEdit] = (0, react.useState)(null);
			const done = steps.filter((s) => s.status === "completed").length;
			const pct = steps.length > 0 ? Math.round(done / steps.length * 100) : 0;
			const commitStepEdit = (index) => {
				if (!stepEdit || stepEdit.index !== index) return;
				const value = stepEdit.value;
				setStepEdit(null);
				onEditStep(index, value);
			};
			const commitTitleEdit = () => {
				if (titleEdit === null) return;
				const value = titleEdit.value;
				setTitleEdit(null);
				onRename(value);
			};
			const headClickTimer = (0, react.useRef)(null);
			const suppressHeadClick = (0, react.useRef)(false);
			(0, react.useEffect)(() => () => {
				if (headClickTimer.current !== null) window.clearTimeout(headClickTimer.current);
			}, []);
			const handleHeadClick = (e) => {
				if (suppressHeadClick.current) {
					suppressHeadClick.current = false;
					return;
				}
				if (titleEdit !== null) return;
				const target = e.target;
				const onTitle = isBound && target.closest("[data-card-title]") !== null;
				if (headClickTimer.current !== null) {
					window.clearTimeout(headClickTimer.current);
					headClickTimer.current = null;
					if (onTitle) setTitleEdit({ value: String(task.title ?? "") });
					else onToggleExpand();
					return;
				}
				headClickTimer.current = window.setTimeout(() => {
					headClickTimer.current = null;
					onToggleExpand();
				}, CLICK_SINGLE_DELAY_MS);
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
				"data-task-id": task.id,
				className: `${TaskPanel_module_css_default.card}${isBound ? ` ${TaskPanel_module_css_default.cardBound}` : ""}`,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.cardHead,
						role: "button",
						tabIndex: 0,
						onClick: handleHeadClick,
						onKeyDown: (e) => {
							if (e.key === "Enter" || e.key === " ") {
								e.preventDefault();
								handleHeadClick(e);
							}
						},
						onMouseDownCapture: () => {
							if (titleEdit !== null) suppressHeadClick.current = true;
						},
						onDoubleClick: (e) => e.preventDefault(),
						"aria-expanded": expanded,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: TaskPanel_module_css_default.cardTitleRow,
							children: [isBound && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: TaskPanel_module_css_default.boundBadge,
								children: t("task.current")
							}), isBound && titleEdit !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(InlineEditor, {
								className: TaskPanel_module_css_default.editorArea,
								value: titleEdit.value,
								maxRows: 4,
								onValueChange: (value) => setTitleEdit({ value }),
								onCommit: commitTitleEdit,
								onCancel: () => setTitleEdit(null)
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								"data-card-title": true,
								className: `${TaskPanel_module_css_default.cardTitle}${isBound ? ` ${TaskPanel_module_css_default.cardTitleEditable}` : ""}`,
								title: isBound && showHints ? t("task.title-edit") : void 0,
								onDoubleClick: (e) => {
									e.preventDefault();
									e.stopPropagation();
									if (isBound) setTitleEdit({ value: String(task.title ?? "") });
								},
								children: task.title
							})]
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: TaskPanel_module_css_default.cardMeta,
							children: [
								steps.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									className: TaskPanel_module_css_default.progressText,
									children: [
										done,
										"/",
										steps.length
									]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: TaskPanel_module_css_default.updated,
									children: timeAgo(task.updatedAt || task.lastActiveAt)
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: TaskPanel_module_css_default.chevron,
									children: expanded ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, {}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, {})
								})
							]
						})]
					}),
					steps.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: TaskPanel_module_css_default.track,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: TaskPanel_module_css_default.trackFill,
							style: { width: `${pct}%` }
						})
					}),
					expanded && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.cardBody,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: TaskPanel_module_css_default.section,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: TaskPanel_module_css_default.sectionLabel,
									children: [t("task.steps"), steps.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: TaskPanel_module_css_default.sectionCount,
										children: steps.length
									})]
								}), steps.length > 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("ol", {
									className: TaskPanel_module_css_default.stepsList,
									children: steps.map((step, i) => {
										const stepIsEditing = stepEdit !== null && stepEdit.index === i;
										const stepIsDragging = dragState?.dragging && dragState.fromIndex === i;
										const isDropTarget = dropTargetIndex === i;
										const isDropTargetAfter = dropTargetIndex === i + 1;
										return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
											"data-step-row": true,
											className: `${TaskPanel_module_css_default.stepRow}${stepIsDragging ? ` ${TaskPanel_module_css_default.stepDragging}` : ""}${isDropTarget ? ` ${TaskPanel_module_css_default.dropTargetBefore}` : ""}${isDropTargetAfter ? ` ${TaskPanel_module_css_default.dropTargetAfter}` : ""}`,
											onMouseDown: (e) => {
												if (e.button !== 0) return;
												if (!isBound || syncing) return;
												if (e.target.closest("button, input, textarea, a")) return;
												startDrag(i, step.content, e);
											},
											children: [isBound ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: TaskPanel_module_css_default.stepToggle,
												disabled: syncing,
												onClick: (e) => {
													e.stopPropagation();
													onCycleStatus(i);
												},
												title: showHints ? `${t("step.completed")}/${t("step.in-progress")}/${t("step.pending")}` : void 0,
												children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(StepIcon, { status: step.status })
											}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(StepIcon, { status: step.status }), stepIsEditing ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(InlineEditor, {
												className: TaskPanel_module_css_default.editorArea,
												value: stepEdit.value,
												maxRows: 10,
												onValueChange: (value) => setStepEdit({
													index: i,
													value
												}),
												onCommit: () => commitStepEdit(i),
												onCancel: () => setStepEdit(null)
											}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: `${TaskPanel_module_css_default.stepContent}${step.status === "completed" ? ` ${TaskPanel_module_css_default.stepContentDone}` : ""}${step.status === "in_progress" ? ` ${TaskPanel_module_css_default.stepContentRun}` : ""}${isBound ? ` ${TaskPanel_module_css_default.stepEditable}` : ""}`,
												title: isBound && showHints ? t("step.edit-hint") : void 0,
												onDoubleClick: (e) => {
													e.stopPropagation();
													if (isBound) setStepEdit({
														index: i,
														value: String(step.content ?? "")
													});
												},
												children: step.content
											})]
										}, i);
									})
								}), dragState && dragState.dragging && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: TaskPanel_module_css_default.dragGhost,
									style: {
										left: dragState.clientX + 12,
										top: dragState.clientY - 20
									},
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: TaskPanel_module_css_default.dragGhostCard,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: TaskPanel_module_css_default.dragGhostContent,
											children: dragState.stepContent
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
											type: "button",
											className: TaskPanel_module_css_default.dragGhostClose,
											style: { pointerEvents: "auto" },
											onClick: (e) => {
												e.stopPropagation();
												cancelDrag();
											},
											title: showHints ? t("drag.cancel") : void 0,
											"aria-label": t("drag.cancel"),
											children: "×"
										})]
									})
								})] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: TaskPanel_module_css_default.muted,
									children: t("panel.empty-desc")
								})]
							}),
							(task.files?.length ?? 0) > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: TaskPanel_module_css_default.section,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: TaskPanel_module_css_default.sectionLabel,
									children: [t("task.files"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: TaskPanel_module_css_default.sectionCount,
										children: task.files.length
									})]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("ul", {
									className: TaskPanel_module_css_default.filesList,
									children: [task.files.slice(0, 12).map((file, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
										className: TaskPanel_module_css_default.fileRow,
										onClick: () => navigator.clipboard?.writeText(file.path),
										title: showHints ? `${t("file.copy")}: ${file.path}${file.line ? `:${file.line}` : ""}` : void 0,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: TaskPanel_module_css_default.fileDot }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: TaskPanel_module_css_default.filePath,
												children: file.path
											}),
											file.line && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
												className: TaskPanel_module_css_default.fileLine,
												children: [":", file.line]
											})
										]
									}) }, i)), (task.files?.length ?? 0) > 12 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
										className: TaskPanel_module_css_default.muted,
										children: [
											"… 共 ",
											task.files.length,
											" 个"
										]
									})]
								})]
							}),
							onInsightAction && Array.isArray(task.insights) && task.insights.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: TaskPanel_module_css_default.section,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: TaskPanel_module_css_default.sectionLabel,
									children: [t("mem.section-label"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: TaskPanel_module_css_default.sectionCount,
										children: task.insights.length
									})]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
									className: TaskPanel_module_css_default.memList,
									children: task.insights.map((ins) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
										className: TaskPanel_module_css_default.memRow,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: TaskPanel_module_css_default.memTitle,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: TaskPanel_module_css_default.kindBadge,
													children: insightKindLabel(ins.kind, t)
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: ins.title || ins.id }),
												ins.draft && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: `${TaskPanel_module_css_default.badge} ${TaskPanel_module_css_default.badgeDraft}`,
													children: t("mem.draft")
												})
											]
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: TaskPanel_module_css_default.memActs,
											children: [
												ins.draft && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "outline",
													size: "sm",
													disabled: syncing,
													onClick: () => onInsightAction("confirm", ins.id),
													children: t("mem.confirm")
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "outline",
													size: "sm",
													disabled: syncing,
													onClick: () => onInsightAction("promote", ins.id),
													children: t("mem.promote")
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "outline",
													size: "sm",
													disabled: syncing,
													onClick: () => onInsightAction("delete", ins.id),
													children: t("mem.delete")
												})
											]
										})]
									}, ins.id))
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: TaskPanel_module_css_default.cardFooter,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "outline",
										size: "sm",
										disabled: isBound || syncing,
										onClick: onSwitch,
										children: t("task.switch")
									}),
									isBound && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "outline",
										size: "sm",
										disabled: syncing,
										onClick: onUnbind,
										title: showHints ? t("task.unbind") : void 0,
										children: t("task.unbind")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "outline",
										size: "sm",
										disabled: syncing,
										onClick: onArchive,
										children: t("task.archive")
									})
								]
							})
						]
					})
				]
			});
		}
		/** 预取提前量：哨兵进入视口**下方 600px** 就开始取下一页，数据在滚到底之前到位。 */
		const PREFETCH_MARGIN = "600px 0px";
		/**
		* 拼一页的请求命令行：数据通道是命令文本，协议只在这里拼一次。
		* @param {string} scope - `task` | `project` | `global`。
		* @param {number} offset - 起始下标。
		* @param {number} limit - 本页条数。
		* @returns {string} 可直接交给 remote.commands.execute 的命令行。
		*/
		function insightListLine(scope, offset, limit) {
			return `/tasks insight list ${scope} ${offset} ${limit}`;
		}
		/**
		* 追加一页并**按 id 去重**。去重是必需的：前缀重放（见 {@link reloadWindowRequest}）与并发
		* 刷新都可能让同一 id 出现两次，重复行带重复按钮，点错一个就是误删。
		* @param {ReadonlyArray<{id?: string}>} prev - 已渲染条目。
		* @param {ReadonlyArray<{id?: string}>} page - 新到的一页。
		* @returns {Array} 追加后的数组；无新增时**原样返回** prev（避免无意义的重渲染）。
		*/
		function appendUnique(prev, page) {
			if (!Array.isArray(page) || page.length === 0) return prev;
			const seen = new Set(prev.map((row) => row && row.id));
			const fresh = page.filter((row) => row && !seen.has(row.id));
			if (fresh.length === 0) return prev;
			return [...prev, ...fresh];
		}
		/**
		* 动作（archive/delete/promote…）之后的重载窗口：刷新**已加载的整个前缀**而非重置成第一页（否则
		* 会把正在看第 5 页的用户弹回顶部）；用 offset 分页而非 keyset 游标正是为了让"把 0..N 重取一遍"
		* 可行。**上限**：宿主单页最多 {@link HOST_PAGE_MAX} 条且静默截断，`limit` 在这里夹住，余下的由 `nextOffset` 追加。
		* @param {number} loadedCount - 当前已渲染条数。
		* @param {number} [pageSize] - 每页条数下界，保证至少取一页。
		* @returns {{offset: number, limit: number}} 重放请求窗口（limit ≤ HOST_PAGE_MAX）。
		*/
		function reloadWindowRequest(loadedCount, pageSize = 30) {
			return {
				offset: 0,
				limit: Math.min(200, Math.max(pageSize, Number.isFinite(loadedCount) && loadedCount > 0 ? Math.floor(loadedCount) : 0))
			};
		}
		/**
		* 把宿主载荷归一成窗口状态，兼容三种形态：新宿主分页（有 `total` + `nextOffset`）、新宿主不
		* 分页（省略 limit，`nextOffset === null`）、老宿主/老 bundle（两个字段都没有 → 视为一次给全）。
		* @param {any} data - 已解析的 JSON 载荷。
		* @param {number} fallbackOffset - 请求时的 offset（载荷没给 offset 时用它）。
		* @returns {{items: any[], total: number, offset: number, nextOffset: number|null}} 归一化窗口。
		*/
		function normalizeWindow(data, fallbackOffset = 0) {
			const items = Array.isArray(data && data.items) ? data.items : [];
			const rawTotal = data && typeof data.total === "number" ? data.total : data && typeof data.count === "number" ? data.count : items.length;
			const total = Number.isFinite(rawTotal) && rawTotal >= 0 ? rawTotal : items.length;
			const offset = data && Number.isFinite(data.offset) ? data.offset : fallbackOffset;
			const next = data && data.nextOffset;
			return {
				items,
				total,
				offset,
				nextOffset: typeof next === "number" && Number.isFinite(next) && next >= 0 ? next : null
			};
		}
		/**
		* 页脚文案用的"已显示 N / 总数"。
		* @param {number} loaded - 已渲染条数。
		* @param {number} total - 服务端总数。
		* @returns {{loaded: number, total: number}} 归一化后的计数（total 不会小于 loaded）。
		*/
		function progressCounts(loaded, total) {
			const l = Number.isFinite(loaded) && loaded > 0 ? Math.floor(loaded) : 0;
			return {
				loaded: l,
				total: Math.max(l, Number.isFinite(total) && total > 0 ? Math.floor(total) : 0)
			};
		}
		/**
		* 请求闸门：协调首屏 / 追加 / 动作后重放这几类**会重叠**的请求。两件事必须分开：
		*   - **过期响应丢弃**（靠序号 + 作用域判定）；
		*   - **新请求照发**（只有同一个 key 正在飞时才去重，避免哨兵连续触发重复取同一页）。
		* 用"有在途请求就直接 return"的布尔守卫会让切 scope 时新请求被丢掉、过期响应又被作用域检查
		* 丢掉 → 新列表永远空白。
		* @returns {{begin: Function, end: Function, isStale: Function}} 闸门。
		*/
		function createRequestGate() {
			let seq = 0;
			let inflightKey = null;
			return {
				/**
				* 申请发起一次请求。
				* @param {string} key - 请求身份（scope|offset|limit|append）。
				* @returns {number|false} 该请求的序号；同一 key 已在飞时返回 false（去重）。
				*/
				begin(key) {
					if (inflightKey === key) return false;
					inflightKey = key;
					seq += 1;
					return seq;
				},
				/**
				* 请求结束。
				* @param {string} key - 请求身份。
				* @param {number} ticket - begin 返回的序号。
				* @returns {boolean} 它是否仍是最后一次请求（决定加载标志该不该回落）。
				*/
				end(key, ticket) {
					if (inflightKey === key) inflightKey = null;
					return ticket === seq;
				},
				/**
				* 该响应是否已过期。
				* @param {number} ticket - 发出时的序号。
				* @param {string} requestedScope - 发出时的作用域。
				* @param {string} currentScope - 当前作用域。
				* @returns {boolean} true=必须整份丢弃。
				*/
				isStale(ticket, requestedScope, currentScope) {
					return ticket !== seq || requestedScope !== currentScope;
				}
			};
		}
		//#endregion
		//#region src/client/MemoryView.tsx
		/**
		* Memory View — 记忆三作用域列表（Task 草稿 / Project / Global）
		* 数据通道与任务面板一致：remote.commands.execute 执行 /insight 命令，取 JSON 载荷。
		* 动作：confirm(草稿审核) / promote(向上提升) / demote(向下降级，需绑定任务) / archive / restore / delete
		*
		* 列表是**增量加载**的：首屏只取 PAGE_SIZE 条，滚到底前 600px 预取下一页追加。
		* 分页的决策逻辑在 ./paging.js（纯函数，可单测），本组件只把它接到渲染上。
		*/
		/**
		* 切页缓存：任务/项目/全局三页在同一个面板里来回切时，30 秒内直接复用上一份列表，
		* 不再发 /tasks insight list。宿主每次命令都会在会话里留一个 command 节点，
		* 而"切回刚才那页"并不需要重新证明数据没变；动作之后的 reloadWindow 会更新缓存。
		*/
		const INSIGHT_CACHE_TTL_MS = 3e4;
		const INSIGHT_CACHE_MAX = 12;
		const insightCache = /* @__PURE__ */ new Map();
		function insightCacheKey(sessionId, scope, root, boundTaskId) {
			return `${sessionId || ""}|${root || ""}|${scope}|${boundTaskId || ""}`;
		}
		function readInsightCache(sessionId, scope, root, boundTaskId) {
			const key = insightCacheKey(sessionId, scope, root, boundTaskId);
			const hit = insightCache.get(key);
			if (!hit) return null;
			if (Date.now() - hit.at > INSIGHT_CACHE_TTL_MS) {
				insightCache.delete(key);
				return null;
			}
			return hit;
		}
		function writeInsightCache(sessionId, scope, root, boundTaskId, rows, total, nextOffset) {
			const key = insightCacheKey(sessionId, scope, root, boundTaskId);
			insightCache.delete(key);
			insightCache.set(key, {
				rows,
				total,
				nextOffset,
				at: Date.now()
			});
			while (insightCache.size > INSIGHT_CACHE_MAX) {
				const oldest = insightCache.keys().next().value;
				if (oldest === void 0) break;
				insightCache.delete(oldest);
			}
		}
		function parseInsightPayloadText(text) {
			if (!text) return null;
			let jsonBlock = null;
			const fenced = text.match(/```(?:json)?\s*\n([\s\S]*?)\n```/);
			if (fenced) jsonBlock = fenced[1];
			else {
				const lastBrace = text.lastIndexOf("{");
				if (lastBrace !== -1) jsonBlock = text.slice(lastBrace);
			}
			if (!jsonBlock) return null;
			try {
				const data = JSON.parse(jsonBlock);
				if (!Array.isArray(data.items)) return null;
				const w = normalizeWindow(data, 0);
				return {
					scope: data.scope ?? "project",
					count: w.total,
					total: w.total,
					offset: w.offset,
					nextOffset: w.nextOffset,
					items: w.items
				};
			} catch {
				return null;
			}
		}
		function kindText(kind, t) {
			return {
				lesson: t("mem.kind.lesson"),
				decision: t("mem.kind.decision"),
				procedure: t("mem.kind.procedure"),
				experience: t("mem.kind.experience")
			}[kind] ?? kind;
		}
		function MemoryView({ ctx, sessionId, scope, root, boundTaskId, showHints, t }) {
			const [rows, setRows] = (0, react.useState)([]);
			const [total, setTotal] = (0, react.useState)(0);
			const [nextOffset, setNextOffset] = (0, react.useState)(null);
			const [error, setError] = (0, react.useState)(null);
			const [loading, setLoading] = (0, react.useState)(false);
			const [loadingMore, setLoadingMore] = (0, react.useState)(false);
			const [showSpinner, setShowSpinner] = (0, react.useState)(false);
			const [busy, setBusy] = (0, react.useState)(false);
			const [showNew, setShowNew] = (0, react.useState)(false);
			const [editingId, setEditingId] = (0, react.useState)(null);
			const [form, setForm] = (0, react.useState)({
				title: "",
				kind: "lesson",
				body: "",
				steps: "",
				trigger: ""
			});
			const [savedTip, setSavedTip] = (0, react.useState)(null);
			const scrollRef = (0, react.useRef)(null);
			const sentinelRef = (0, react.useRef)(null);
			const runLine = (0, react.useCallback)(async (line) => {
				const commands = service(ctx, "remote.commands");
				if (!sessionId || !commands || typeof commands.execute !== "function") return {
					ok: false,
					text: "data channel unavailable (missing client service)"
				};
				try {
					const envelope = await commands.execute(sessionId, line, []);
					const execution = envelope && typeof envelope === "object" && "value" in envelope ? envelope.value : envelope;
					const result = execution?.result ?? execution;
					if (result?.kind === "error") return {
						ok: false,
						text: result.text ?? "command error"
					};
					return {
						ok: true,
						text: result?.text ?? ""
					};
				} catch (err) {
					return {
						ok: false,
						text: String(err?.message ?? err)
					};
				}
			}, [ctx, sessionId]);
			const gateRef = (0, react.useRef)(null);
			if (gateRef.current === null) gateRef.current = createRequestGate();
			const scopeRef = (0, react.useRef)(scope);
			(0, react.useEffect)(() => {
				scopeRef.current = scope;
			}, [scope]);
			/**
			* 取一页并落到状态里。
			* @param offset 起始下标。
			* @param limit 本页条数。
			* @param append true=追加到已渲染列表；false=替换成这一页（首屏或前缀重放）。
			*/
			const load = (0, react.useCallback)(async (offset, limit, append) => {
				if (!sessionId) {
					setRows([]);
					setTotal(0);
					setNextOffset(null);
					setError(null);
					setLoading(false);
					return;
				}
				const requestedScope = scopeRef.current;
				const key = `${requestedScope}|${offset}|${limit}|${append}`;
				const ticket = gateRef.current.begin(key);
				if (ticket === false) return;
				if (!append) setLoading(true);
				setLoadingMore(append);
				setError(null);
				const spinner = window.setTimeout(() => setShowSpinner(true), 150);
				try {
					const res = await runLine(insightListLine(requestedScope, offset, limit));
					if (gateRef.current.isStale(ticket, requestedScope, scopeRef.current)) return;
					if (!res.ok) {
						setError(res.text);
						return;
					}
					const parsed = parseInsightPayloadText(res.text);
					if (!parsed) {
						setError("unparsable payload");
						return;
					}
					setRows((prev) => {
						const next = append ? appendUnique(prev, parsed.items) : parsed.items;
						writeInsightCache(sessionId, requestedScope, root, boundTaskId, next, parsed.total, parsed.nextOffset);
						return next;
					});
					setTotal(parsed.total);
					setNextOffset(parsed.nextOffset);
				} finally {
					window.clearTimeout(spinner);
					if (gateRef.current.end(key, ticket)) {
						setShowSpinner(false);
						setLoading(false);
						setLoadingMore(false);
					}
				}
			}, [
				runLine,
				sessionId,
				root,
				boundTaskId
			]);
			const loadRef = (0, react.useRef)(load);
			(0, react.useEffect)(() => {
				loadRef.current = load;
			}, [load]);
			(0, react.useEffect)(() => {
				setRows([]);
				setTotal(0);
				setNextOffset(null);
				setError(null);
				if (!sessionId) return;
				const cached = readInsightCache(sessionId, scope, root, boundTaskId);
				if (cached) {
					setRows(cached.rows);
					setTotal(cached.total);
					setNextOffset(cached.nextOffset);
					setLoading(false);
					setLoadingMore(false);
					setShowSpinner(false);
					return;
				}
				loadRef.current(0, 30, false);
			}, [scope, sessionId]);
			(0, react.useEffect)(() => {
				if (nextOffset === null || typeof IntersectionObserver === "undefined") return;
				const sentinel = sentinelRef.current;
				if (!sentinel) return;
				const observer = new IntersectionObserver((entries) => {
					if (entries.some((e) => e.isIntersecting)) loadRef.current(nextOffset, 30, true);
				}, {
					root: scrollRef.current ?? null,
					rootMargin: PREFETCH_MARGIN
				});
				observer.observe(sentinel);
				return () => observer.disconnect();
			}, [nextOffset, rows.length]);
			/**
			* 重载**已加载的整个前缀**（不是重置成第一页）：动作之后用户的位置不该跳回顶部。
			*/
			const reloadWindow = (0, react.useCallback)(async () => {
				const { offset, limit } = reloadWindowRequest(rows.length);
				await loadRef.current(offset, limit, false);
			}, [rows.length]);
			const act = async (action, id) => {
				if (busy) return;
				setBusy(true);
				setError(null);
				try {
					const line = `/tasks insight ${action} ${scope} ${id}${action === "demote" && scope === "project" && boundTaskId ? ` ${boundTaskId}` : ""}`;
					const res = await runLine(line);
					if (!res.ok) setError(res.text);
					else await reloadWindow();
				} finally {
					setBusy(false);
				}
			};
			const rowToForm = (row) => {
				const main = row.kind === "lesson" ? row.fix : row.kind === "experience" ? row.solution : row.kind === "decision" ? row.reason : row.body;
				const body = main && main !== row.title ? main : "";
				return {
					title: row.title || "",
					kind: row.kind || "lesson",
					body,
					steps: Array.isArray(row.steps) ? row.steps.join("\n") : "",
					trigger: (row.trigger?.keywords || []).join(",")
				};
			};
			const startEdit = (row) => {
				setEditingId(row.id);
				setForm(rowToForm(row));
				setShowNew(true);
				setError(null);
			};
			const closeForm = () => {
				setShowNew(false);
				setEditingId(null);
				setForm({
					title: "",
					kind: "lesson",
					body: "",
					steps: "",
					trigger: ""
				});
			};
			const changeKind = (next) => {
				setForm((prev) => {
					if (prev.kind === next) return prev;
					const fromProc = prev.kind === "procedure";
					const toProc = next === "procedure";
					let body = prev.body;
					let steps = prev.steps;
					if (fromProc && !toProc && !body && steps.trim()) body = steps.trim();
					if (toProc && !fromProc && !steps.trim() && body.trim()) steps = body.trim();
					return {
						...prev,
						kind: next,
						body,
						steps
					};
				});
			};
			const submitNew = async () => {
				if (scope === "task" && !editingId) return;
				if (busy) return;
				const title = form.title.trim();
				if (!title) return;
				setBusy(true);
				setError(null);
				try {
					const fields = {
						title,
						kind: form.kind
					};
					if (form.kind === "lesson") fields.pattern = title;
					if (form.kind === "decision") fields.choice = title;
					if (form.kind === "experience") fields.problem = title;
					if (form.body.trim()) {
						if (form.kind === "lesson") fields.fix = form.body.trim();
						else if (form.kind === "decision") fields.reason = form.body.trim();
						else if (form.kind === "experience") fields.solution = form.body.trim();
						else fields.body = form.body.trim();
					}
					if (form.kind === "procedure" && form.steps.trim()) fields.steps = form.steps.split("\n").map((s) => s.trim()).filter(Boolean);
					if (form.kind === "procedure" && form.trigger.trim()) fields.trigger = { keywords: form.trigger.split(/[,，]/).map((s) => s.trim()).filter(Boolean) };
					const line = editingId ? `/tasks insight edit ${scope} ${editingId} ${JSON.stringify(fields)}` : `/tasks insight save ${scope} ${JSON.stringify(fields)}`;
					const res = await runLine(line);
					if (!res.ok) setError(res.text);
					else {
						setSavedTip(t("mem.saved"));
						closeForm();
						window.setTimeout(() => setSavedTip(null), 2500);
						await reloadWindow();
					}
				} finally {
					setBusy(false);
				}
			};
			const items = rows;
			const progress = progressCounts(items.length, total);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: TaskPanel_module_css_default.memoryPane,
				ref: scrollRef,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.memToolbar,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
							className: TaskPanel_module_css_default.memCount,
							children: [scope === "task" ? t("mem.scope.task") : scope === "global" ? t("mem.scope.global") : t("mem.scope.project"), total > 0 ? ` · ${total}` : ""]
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
							className: TaskPanel_module_css_default.memToolbarActs,
							children: [
								savedTip && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: TaskPanel_module_css_default.badge,
									children: savedTip
								}),
								scope !== "task" && !showNew && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									disabled: busy,
									onClick: () => {
										setShowNew(true);
										setEditingId(null);
										setError(null);
									},
									children: t("mem.new")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									onClick: () => void reloadWindow(),
									disabled: loading,
									title: showHints ? t("panel.refresh") : void 0,
									"aria-label": t("panel.refresh"),
									children: "↻"
								})
							]
						})]
					}),
					showNew && scope !== "task" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.memNew,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								className: TaskPanel_module_css_default.stepInput,
								placeholder: t("mem.f.title"),
								value: form.title,
								onChange: (e) => setForm({
									...form,
									title: e.target.value
								}),
								autoFocus: true
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: TaskPanel_module_css_default.memNewRow,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
									className: TaskPanel_module_css_default.memLabel,
									children: [t("mem.f.kind"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
										className: TaskPanel_module_css_default.stepInput,
										value: form.kind,
										onChange: (e) => changeKind(e.target.value),
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "lesson",
												children: "lesson"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "decision",
												children: "decision"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "procedure",
												children: "procedure"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
												value: "experience",
												children: "experience"
											})
										]
									})]
								})
							}),
							form.kind !== "procedure" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
								className: TaskPanel_module_css_default.stepInput,
								placeholder: t("mem.f.body"),
								rows: 2,
								value: form.body,
								onChange: (e) => setForm({
									...form,
									body: e.target.value
								})
							}),
							form.kind === "procedure" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
								className: TaskPanel_module_css_default.stepInput,
								placeholder: t("mem.f.steps"),
								rows: 3,
								value: form.steps,
								onChange: (e) => setForm({
									...form,
									steps: e.target.value
								})
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								className: TaskPanel_module_css_default.stepInput,
								placeholder: t("mem.f.trigger"),
								value: form.trigger,
								onChange: (e) => setForm({
									...form,
									trigger: e.target.value
								})
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: TaskPanel_module_css_default.memActs,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									disabled: busy || !form.title.trim(),
									onClick: () => void submitNew(),
									children: t("mem.save")
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									onClick: closeForm,
									children: t("mem.cancel")
								})]
							})
						]
					}),
					error && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.notice,
						children: [
							t("mem.error"),
							": ",
							error,
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								size: "sm",
								disabled: loading || loadingMore,
								onClick: () => void reloadWindow(),
								children: t("mem.retry")
							})
						]
					}),
					loading && !items.length && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: TaskPanel_module_css_default.muted,
						children: t("mem.loading")
					}),
					!loading && !error && items.length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: TaskPanel_module_css_default.muted,
						children: t("mem.empty")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.memList,
						children: [items.map((row) => {
							const canDemoteToTask = scope === "project" && !!boundTaskId;
							return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: `${TaskPanel_module_css_default.memRow}${row.archived ? ` ${TaskPanel_module_css_default.memRowArchived}` : ""}`,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: TaskPanel_module_css_default.memRowMain,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
											className: TaskPanel_module_css_default.memTitle,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: TaskPanel_module_css_default.kindBadge,
												children: kindText(row.kind, t)
											}), row.title || row.body]
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
											className: TaskPanel_module_css_default.memMeta,
											children: [
												row.draft && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: `${TaskPanel_module_css_default.badge} ${TaskPanel_module_css_default.badgeDraft}`,
													children: t("mem.draft")
												}),
												row.archived && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: `${TaskPanel_module_css_default.badge} ${TaskPanel_module_css_default.badgeArchived}`,
													children: t("mem.archived")
												}),
												row.taskTitle && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
													className: TaskPanel_module_css_default.badge,
													children: ["@", row.taskTitle]
												}),
												row.members !== void 0 && row.members > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
													className: TaskPanel_module_css_default.badge,
													children: ["×", row.members]
												}),
												row.confidence != null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
													className: TaskPanel_module_css_default.badge,
													children: [Math.round(row.confidence * 100), "%"]
												}),
												row.trigger && row.trigger.keywords.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
													className: TaskPanel_module_css_default.badge,
													children: ["⚡", row.trigger.keywords.slice(0, 2).join(",")]
												})
											]
										})]
									}),
									row.body && row.body !== row.title && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: TaskPanel_module_css_default.memBody,
										children: String(row.body).slice(0, 160)
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: TaskPanel_module_css_default.memActs,
										children: [
											scope !== "task" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => startEdit(row),
												children: t("mem.edit")
											}),
											scope === "task" && !row.archived && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [row.draft && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("confirm", row.id),
												children: t("mem.confirm")
											}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("promote", row.id),
												children: t("mem.promote")
											})] }),
											scope === "project" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("promote", row.id),
												children: t("mem.promote")
											}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy || !canDemoteToTask,
												title: showHints && !canDemoteToTask ? t("mem.needs-bound") : void 0,
												onClick: () => void act("demote", row.id),
												children: t("mem.demote")
											})] }),
											scope === "global" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("demote", row.id),
												children: t("mem.demote")
											}),
											row.archived ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("restore", row.id),
												children: t("mem.restore")
											}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("archive", row.id),
												children: t("mem.archive")
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy,
												onClick: () => void act("delete", row.id),
												children: t("mem.delete")
											})
										]
									})
								]
							}, row.id);
						}), items.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: TaskPanel_module_css_default.memFooter,
							children: [
								nextOffset !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									ref: sentinelRef,
									className: TaskPanel_module_css_default.memSentinel,
									"aria-hidden": "true"
								}),
								nextOffset !== null && typeof IntersectionObserver === "undefined" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									disabled: loadingMore,
									onClick: () => void loadRef.current(nextOffset, 30, true),
									children: t("mem.loadMore")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									className: TaskPanel_module_css_default.muted,
									children: [progress.loaded < progress.total ? t("mem.progress", {
										loaded: progress.loaded,
										total: progress.total
									}) : t("mem.allLoaded", { total: progress.total }), showSpinner && loadingMore ? ` · ${t("mem.loadingMore")}` : ""]
								})
							]
						})]
					})
				]
			});
		}
		//#endregion
		//#region src/client/session-id.js
		/**
		* 会话列表快照 → 当前会话 id（宿主版本兼容层）。
		*
		* 快照结构被宿主改过一次，旧写法只认第一种：
		*   - dsh ≤0.1.6：`{ current?: id, items: [{ sessionId, blank }] }`
		*   - dsh 0.1.7+：`{ ids: id[], byId: Record<id, SessionSummary>, phase, projectionsBySession }`
		*     —— `current` 与 `items` **都不存在了**。
		*
		* 后果一（永远 null）：0.1.7 上 `snap.current` 和 `snap.items` 都是 undefined → 旧代码永远
		* 返回 null → 面板显示「还没有会话」、记忆视图报 `同步失败: no session / commands service`。
		* 而**任务视图渲染的是 task-data-store 里的缓存快照**，看起来还正常，所以这个故障很容易被
		* 误读成"数据格式/旧版本兼容"问题。
		*
		* 后果二（不跟随切换）：光"取一个非 null 的 id"不够 —— 兜底取的是宿主列表里第一个非 blank 的
		* 会话，它**不随用户切换对话而变化**，面板会一直停在同一个会话（从而显示错项目的任务）。
		* 0.1.7 判断"当前会话"的正式依据是 `SessionSummary.retainedBy.mainView > 0`：
		* 主视图正在 retain 的那个就是用户正在看的那个（第一方同款判据，见 ui-layout/DocumentTitle.tsx
		* 与 ui-session）。它就在**列表快照的 byId 行上**，而 retain 计数变化会 `list.set(...)` 重新发布
		* 快照（session-controller/.../sessions/service.ts 的 publishRetention），所以订阅
		* `ctx.sessions.list` 的组件会在切换会话时自动重渲染 —— 这条必须走快照内字段，不能另开
		* `retainInfo()` 订阅，否则切换不会触发重渲染。
		*
		* 实测形状见 `packages/api/session-controller/src/client/sessions/service.ts` 的
		* `SessionListState` / `SessionSummary`。
		*/
		/** 正数才算持有（retain 计数缺失/0/负数一律当没有）。 */
		function heldCount(value) {
			return typeof value === "number" && value > 0 ? value : 0;
		}
		/** 从一行 summary 抽出本模块关心的三个事实。 */
		function rowFacts(row) {
			return {
				blank: row?.blank === true,
				/** 主视图对这条会话的 retain 计数；> 0 即"用户正在看它"。 */
				mainView: heldCount(row?.retainedBy?.mainView)
			};
		}
		/**
		* 把两种快照形状统一成 `{ id, blank, mainView }` 列表，顺序保持宿主给的顺序。
		* @param {object|undefined|null} snap - `ctx.sessions.list.getSnapshot()`
		* @returns {Array<{id: string, blank: boolean, mainView: number}>} 认不出的形状返回空数组
		*/
		function sessionRows(snap) {
			if (!snap || typeof snap !== "object") return [];
			if (Array.isArray(snap.items)) return snap.items.map((row) => ({
				id: row?.sessionId,
				...rowFacts(row)
			})).filter((row) => typeof row.id === "string" && row.id !== "");
			const byId = snap.byId && typeof snap.byId === "object" ? snap.byId : null;
			if (Array.isArray(snap.ids)) return snap.ids.map((id) => ({
				id,
				...rowFacts(byId?.[id])
			})).filter((row) => typeof row.id === "string" && row.id !== "");
			if (byId) return Object.keys(byId).map((id) => ({
				id,
				...rowFacts(byId[id])
			})).filter((row) => typeof row.id === "string" && row.id !== "");
			return [];
		}
		/**
		* 选出一个可用于执行命令的会话 id（即"用户正在看的那个"）。
		*
		* 优先级：
		*  1. 旧形状的显式 `current`（≤0.1.6 的权威字段，保持原语义）；
		*  2. `retainedBy.mainView > 0` 的会话（0.1.7 的权威判据，**跟随会话切换**）；
		*  3. 第一个非 blank → 第一个（对两种形状都适用的兜底）。
		* @param {object|undefined|null} snap - `ctx.sessions.list.getSnapshot()`
		* @returns {string|null} 会话 id；拿不到返回 null（调用方据此显示「还没有会话」）
		*/
		function pickSessionId(snap) {
			if (!snap || typeof snap !== "object") return null;
			if (typeof snap.current === "string" && snap.current !== "") return snap.current;
			const rows = sessionRows(snap);
			const live = rows.find((row) => row.mainView > 0);
			if (live) return live.id;
			const chosen = rows.find((row) => !row.blank) ?? rows[0];
			return chosen ? chosen.id : null;
		}
		//#endregion
		//#region src/client/TaskPanel.tsx
		/**
		* Task Panel — dsh web `shell.overlay` 浮动任务面板。
		* Container 组件：负责数据获取、命令桥接、状态协调
		* Presentational 组件在 TaskComponents.tsx
		*/
		const STATUS_CYCLE = [
			"pending",
			"in_progress",
			"completed"
		];
		const VIEW_CYCLE = PANEL_VIEWS;
		function getT(ctx) {
			return createTranslate(service(ctx, "locale")?.getSnapshot?.()?.active === "zh" ? zh : en);
		}
		function useSessionId(ctx) {
			const [, force] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				const list = service(ctx, "sessions")?.list;
				if (!list || typeof list.subscribe !== "function") return;
				return list.subscribe(() => force((n) => n + 1));
			}, [ctx]);
			return pickSessionId(service(ctx, "sessions")?.list?.getSnapshot?.());
		}
		var PanelErrorBoundary = class extends react.Component {
			state = { failed: false };
			static getDerivedStateFromError() {
				return { failed: true };
			}
			componentDidCatch(error) {
				console.warn("[dsh-project-memory] task panel render crashed:", error);
			}
			render() {
				if (!this.state.failed) return this.props.children;
				return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					className: TaskPanel_module_css_default.boundaryFallback,
					onClick: () => this.setState({ failed: false }),
					title: "重新渲染任务面板",
					children: "任务面板（点击重试）"
				});
			}
		};
		function TaskPanelEntry({ ctx }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(PanelErrorBoundary, { children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TaskPanelView, { ctx }) });
		}
		function TaskPanelView({ ctx }) {
			const t = getT(ctx);
			const data = useTaskData();
			const ui = useTaskUI();
			const degraded = missingServices(ctx);
			const sessionId = useSessionId(ctx);
			const [syncing, setSyncing] = (0, react.useState)(false);
			const syncingRef = (0, react.useRef)(false);
			const [syncedAt, setSyncedAt] = (0, react.useState)(0);
			const [syncError, setSyncError] = (0, react.useState)(null);
			const showHints = ui.showHints;
			const dataActions = useTaskDataActions();
			const uiActions = useTaskUIActions();
			const view = ui.view;
			const cycleView = () => {
				const i = VIEW_CYCLE.indexOf(view);
				uiActions.setView(VIEW_CYCLE[(i + 1) % VIEW_CYCLE.length]);
			};
			const viewTitle = view === "task" ? t("panel.title") : view === "global" ? t("view.global") : t("view.project");
			const tasks = Array.isArray(data.tasks) ? data.tasks : [];
			const activeTasks = tasks.filter((task) => !task.archived);
			const boundTask = data.boundTaskId ? tasks.find((task) => task.id === data.boundTaskId) ?? null : null;
			const applyPayload = (text) => {
				const parsed = parseTaskPayloadText(text);
				if (!parsed) return false;
				dataActions.setTasks({
					tasks: parsed.tasks,
					boundTaskId: parsed.boundId,
					archivedCount: parsed.archived,
					root: parsed.root
				});
				setSyncedAt(Date.now());
				setSyncError(null);
				return true;
			};
			const runLine = async (line) => {
				const result = await invokeCommand(ctx, sessionId, line);
				if (!result.ok) {
					setSyncError(result.error === "no-channel" ? t("panel.no-channel") : result.error || t("panel.sync-failed"));
					return false;
				}
				return applyPayload(result.text);
			};
			const withLock = async (fn) => {
				if (syncingRef.current) return;
				syncingRef.current = true;
				setSyncing(true);
				try {
					await fn();
				} finally {
					syncingRef.current = false;
					setSyncing(false);
				}
			};
			/**
			* 只取数据，**不**顺手 switch。
			*
			* 旧实现在这里补一次 `/tasks switch <boundId>`（条件是"新 boundId 与内存里的不同"），
			* 意图是刷新后让宿主 todo 跟随绑定任务。但那是多余的：宿主的 todo 清单是
			* `sessionProjections` 里的 `todos` 单元（由 `todo/write` 事件折叠而来），重启/换标签页
			* 都会从会话日志重建，不需要谁再推一次；而 switch 会 `session.append('todo/write')`，
			* 于是"打开面板/切一次会话"就写一次会话历史（还顺手刷新任务的 lastActiveAt）。
			* 真正的绑定动作都有明确入口：`select_task`、`/tasks switch`、面板卡片的切换按钮，
			* 它们各自会推宿主清单（adoptStepsToSession），不需要巡检式补写。
			*/
			const refresh = async () => {
				await withLock(() => runLine("/tasks"));
			};
			const handleAction = async (verb, taskId) => {
				await withLock(() => runLine(`/tasks ${verb} ${taskId}`));
			};
			const handleInsightTask = async (action, id) => {
				await withLock(async () => {
					await runLine(`/tasks insight ${action} task ${id}`);
					await runLine("/tasks");
				});
			};
			const cycleStatus = (taskId, index) => {
				const task = data.tasks.find((tt) => tt.id === taskId);
				if (!task) return;
				const cur = STATUS_CYCLE.indexOf((task.steps || [])[index]?.status);
				const next = STATUS_CYCLE[(cur + 1) % STATUS_CYCLE.length];
				withLock(() => runLine(`/tasks step ${taskId} ${index} ${next}`));
			};
			const commitStepText = (taskId, index, value) => {
				const task = data.tasks.find((tt) => tt.id === taskId);
				const trimmed = value.trim();
				if (!task) return;
				if ((task.steps || [])[index]?.content === trimmed || !trimmed) return;
				withLock(() => runLine(`/tasks step-text ${taskId} ${index} ${JSON.stringify(trimmed)}`));
			};
			const reorderSteps = (taskId, fromIndex, toIndex) => {
				if (fromIndex === toIndex) return;
				if (!data.tasks.find((tt) => tt.id === taskId)) return;
				withLock(() => runLine(`/tasks step-move ${taskId} ${fromIndex} ${toIndex}`));
			};
			const commitTitle = (taskId, value) => {
				const task = data.tasks.find((tt) => tt.id === taskId);
				const trimmed = value.trim();
				if (!task) return;
				if (task.title === trimmed || !trimmed) return;
				withLock(() => runLine(`/tasks rename ${taskId} ${JSON.stringify(trimmed)}`));
			};
			const expand = () => {
				uiActions.open();
				if (Date.now() - Math.max(data.lastUpdate, syncedAt) > 5e3) refresh();
			};
			const THEMES = [
				"native",
				"glass",
				"brutal",
				"mono"
			];
			const style = THEMES.includes(ui.theme) ? ui.theme : "native";
			const styleLabel = t(`style.${style}`);
			const cycleTheme = () => {
				const i = THEMES.indexOf(style);
				uiActions.setTheme(THEMES[(i + 1) % THEMES.length]);
			};
			const panelRef = (0, react.useRef)(null);
			const drag = (0, react.useRef)(null);
			const [dragPos, setDragPos] = (0, react.useState)(null);
			const dragPosRef = (0, react.useRef)(null);
			const handleDragStart = (e) => {
				if (e.target !== e.currentTarget) return;
				const rect = panelRef.current?.getBoundingClientRect();
				if (!rect) return;
				drag.current = {
					dx: e.clientX - rect.left,
					dy: e.clientY - rect.top
				};
				const onMove = (ev) => {
					if (!drag.current) return;
					const width = panelRef.current?.offsetWidth ?? 380;
					panelRef.current?.offsetHeight;
					const x = Math.max(8, Math.min(window.innerWidth - width - 8, ev.clientX - drag.current.dx));
					const y = Math.max(8, Math.min(window.innerHeight - 64, ev.clientY - drag.current.dy));
					dragPosRef.current = {
						x,
						y
					};
					setDragPos({
						x,
						y
					});
				};
				const onUp = () => {
					drag.current = null;
					window.removeEventListener("mousemove", onMove);
					window.removeEventListener("mouseup", onUp);
					if (dragPosRef.current) uiActions.setPanelPosition(dragPosRef.current);
					dragPosRef.current = null;
					setDragPos(null);
				};
				window.addEventListener("mousemove", onMove);
				window.addEventListener("mouseup", onUp);
			};
			const refreshRef = (0, react.useRef)(() => {});
			refreshRef.current = () => {
				refresh();
			};
			(0, react.useEffect)(() => {
				if (ui.closed || !sessionId || ui.view !== "task") return;
				if (Date.now() - Math.max(data.lastUpdate, syncedAt) < 5e3) return;
				refreshRef.current();
			}, [
				ui.closed,
				ui.view,
				sessionId
			]);
			if (ui.closed) return null;
			if (ui.minimized) {
				const label = boundTask ? `${t("minibar.current")}: ${boundTask.title}` : activeTasks.length > 0 ? `${t("minibar.current")}: ${activeTasks.length} ${t("minibar.tasks")}` : t("minibar.no-task");
				return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MiniBar, {
					label,
					hint: t("minibar.click-expand"),
					showHints,
					position: ui.panelPosition,
					theme: style,
					onMove: uiActions.setPanelPosition,
					open: expand
				});
			}
			const doneCount = activeTasks.filter((task) => {
				const steps = task.steps || [];
				return steps.length > 0 && steps.every((s) => s.status === "completed");
			}).length;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: TaskPanel_module_css_default.panel,
				ref: panelRef,
				style: {
					left: (dragPos ?? ui.panelPosition).x,
					top: (dragPos ?? ui.panelPosition).y
				},
				"data-theme": style === "native" ? void 0 : style,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: TaskPanel_module_css_default.dragHandle,
						onMouseDown: handleDragStart,
						title: showHints ? t("task.drag") : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { className: TaskPanel_module_css_default.handleGrip })
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
						className: TaskPanel_module_css_default.header,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: TaskPanel_module_css_default.headerLeft,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								type: "button",
								className: TaskPanel_module_css_default.headerIconBtn,
								onClick: cycleTheme,
								title: showHints ? styleLabel : void 0,
								"aria-label": styleLabel,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconFolderOpenOutline16, { className: TaskPanel_module_css_default.headerIcon })
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("h2", {
								className: TaskPanel_module_css_default.headerTitle,
								children: viewTitle
							})]
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: TaskPanel_module_css_default.headerRight,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									onClick: cycleView,
									"aria-label": t("view.cycle"),
									title: showHints ? `${t("view.cycle")}（${view} → ${VIEW_CYCLE[(VIEW_CYCLE.indexOf(view) + 1) % VIEW_CYCLE.length]}）` : void 0,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
										width: "16",
										height: "16",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										"aria-hidden": "true",
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M2 6h4" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M2 10h4" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M2 14h4" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M2 18h4" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
												width: "16",
												height: "20",
												x: "4",
												y: "2",
												rx: "2"
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M15 2v20" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M15 7h5" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M15 12h5" }),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M15 17h5" })
										]
									})
								}),
								view === "task" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: TaskPanel_module_css_default.counts,
									children: activeTasks.length > 0 ? `${t("panel.active")} ${activeTasks.length} · ${doneCount}/${activeTasks.length}` : ""
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									className: showHints ? void 0 : TaskPanel_module_css_default.hintsOff,
									onClick: () => uiActions.toggleHints(),
									"aria-pressed": !showHints,
									"aria-label": showHints ? t("panel.hints-off") : t("panel.hints-on"),
									title: showHints ? t("panel.hints-off") : t("panel.hints-on"),
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconQuestionOutline14, { size: 16 })
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => uiActions.minimize(),
									"aria-label": t("panel.minimize"),
									title: showHints ? t("panel.minimize") : void 0,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, {})
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => uiActions.close(),
									"aria-label": t("panel.close"),
									title: showHints ? t("panel.close") : void 0,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCloseOutline16, {})
								})
							]
						})]
					}),
					degraded.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: TaskPanel_module_css_default.notice,
						children: t("panel.degraded", { names: degraded.join(", ") })
					}),
					!sessionId && service(ctx, "sessions") !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: TaskPanel_module_css_default.notice,
						children: t("panel.no-session")
					}),
					syncError && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.notice,
						children: [
							t("panel.sync-failed"),
							": ",
							syncError
						]
					}),
					view !== "task" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MemoryView, {
						ctx,
						sessionId,
						scope: view,
						root: data.root ?? null,
						boundTaskId: data.boundTaskId,
						showHints,
						t
					}) : activeTasks.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.emptyState,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: TaskPanel_module_css_default.emptyTitle,
								children: t("panel.empty")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: TaskPanel_module_css_default.emptyDesc,
								children: t("panel.empty-desc")
							}),
							syncing && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: TaskPanel_module_css_default.syncHint,
								children: t("panel.syncing")
							})
						]
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: TaskPanel_module_css_default.taskList,
						children: [activeTasks.map((task) => {
							task.steps;
							const expanded = ui.expandedTaskIds.includes(task.id);
							const isBound = data.boundTaskId === task.id;
							return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(TaskCard, {
								task,
								isBound,
								expanded,
								onToggleExpand: () => uiActions.toggleTaskExpanded(task.id),
								onSwitch: () => handleAction("switch", task.id),
								onUnbind: () => runLine("/tasks unbind"),
								onArchive: () => handleAction("archive", task.id),
								onRename: (value) => commitTitle(task.id, value),
								onEditStep: (index, value) => commitStepText(task.id, index, value),
								onCycleStatus: (index) => cycleStatus(task.id, index),
								onReorderSteps: (from, to) => reorderSteps(task.id, from, to),
								onInsightAction: (action, id) => void handleInsightTask(action, id),
								showHints,
								syncing,
								t
							}, task.id);
						}), syncing && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: TaskPanel_module_css_default.syncHint,
							children: t("panel.syncing")
						})]
					})
				]
			});
		}
		//#endregion
		//#region \0dsh-css:src/client/TaskCommandNode.module.css.mjs
		const css$1 = "._9r5h7a_row{max-width:100%;color:var(--dsw-alias-label-tertiary);white-space:nowrap;text-overflow:ellipsis;align-items:center;gap:6px;padding:2px 0;font-size:12px;line-height:20px;display:inline-flex;overflow:hidden}._9r5h7a_row[data-variant=ok]{color:var(--dsw-alias-label-secondary)}._9r5h7a_row[data-variant=error]{color:var(--dsw-alias-state-warn-label,#b7791f)}._9r5h7a_row[data-variant=running]{color:var(--dsw-alias-label-dimmed)}._9r5h7a_icon{color:var(--dsw-alias-label-tertiary);flex:none}";
		const tagId$1 = "@yolk_vat-y/dsh-project-memory/TaskCommandNode.module.css";
		if (typeof document !== "undefined") {
			const selector = "style[data-plugin-css=" + JSON.stringify(tagId$1) + "]";
			const existing = document.querySelector(selector);
			if (existing) existing.textContent = css$1;
			else {
				const tag = document.createElement("style");
				tag.dataset.plugin = "@yolk_vat-y/dsh-project-memory";
				tag.dataset.pluginCss = tagId$1;
				tag.textContent = css$1;
				document.head.appendChild(tag);
			}
		}
		var TaskCommandNode_module_css_default = {
			"icon": "_9r5h7a_icon",
			"row": "_9r5h7a_row"
		};
		//#endregion
		//#region src/client/TaskCommandNode.tsx
		/**
		* /tasks、/task、/insight 命令在会话中的节点渲染器（conversation.chat.commandview，按命令名 key）。
		* 列表型命令（/tasks、无动词 /task、/insight list）只显示一行摘要；/insight 的动作类只显示一句结果——
		* 目的：大 JSON 载荷绝不整段渲染进对话（否则切视图会刷屏）。
		*/
		function TaskCommandNode({ node }) {
			const name = node?.name ?? "task";
			const outcome = node?.outcome ?? null;
			const tokens = (typeof node?.args === "string" ? node.args : "").trim().split(/\s+/).filter(Boolean);
			const verb = tokens[0] ?? "";
			const sub = tokens[1] ?? "";
			const isTasks = name === "tasks";
			const isInsight = name === "insight" || isTasks && verb === "insight";
			const insightVerb = name === "insight" ? verb : sub;
			const isList = isInsight ? name === "insight" ? !verb || verb === "list" : sub === "list" : isTasks && !verb;
			const text = outcome?.text ?? "";
			const parsedTasks = isInsight ? null : parseTaskPayloadText(text);
			const parsedInsights = isInsight ? parseInsightPayloadText(text) : null;
			const live = (0, react.useRef)(outcome === null);
			(0, react.useEffect)(() => {
				if (!parsedTasks || !live.current) return;
				taskDataStore.actions.setTasks({
					tasks: parsedTasks.tasks,
					boundTaskId: parsedTasks.boundId,
					archivedCount: parsedTasks.archived,
					root: parsedTasks.root
				});
				if (isList) taskUIStore.actions.open();
			}, [text]);
			if (outcome === null) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: TaskCommandNode_module_css_default.row,
				"data-variant": "running",
				children: [
					"/",
					name,
					" 执行中…"
				]
			});
			if (outcome.kind === "error") {
				const brief = String(text ?? "").split("\n")[0].slice(0, 120);
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: TaskCommandNode_module_css_default.row,
					"data-variant": "error",
					children: [
						"/",
						name,
						" 失败",
						brief ? `：${brief}` : ""
					]
				});
			}
			if (isList && (isInsight ? parsedInsights : parsedTasks)) return null;
			if (isInsight) {
				const note = String(text ?? "").split("\n")[0].slice(0, 120);
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: TaskCommandNode_module_css_default.row,
					"data-variant": "ok",
					children: [
						"/insight ",
						insightVerb,
						" ",
						note || "已完成"
					]
				});
			}
			if (!isList) {
				const note = String(text ?? "").split(/\n{2,}/)[0].replace(/```.*$/s, "").trim().slice(0, 200);
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: TaskCommandNode_module_css_default.row,
					"data-variant": "ok",
					children: [
						"/",
						name,
						" ",
						note || "已完成"
					]
				});
			}
			const count = parsedTasks ? parsedTasks.tasks.length : 0;
			const archived = parsedTasks ? parsedTasks.archived : 0;
			const label = parsedTasks ? `任务 ${count} 套${archived ? `（归档 ${archived}）` : ""} · 已同步到任务面板` : `/${name} 已执行`;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: TaskCommandNode_module_css_default.row,
				"data-variant": "ok",
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconFolderOpenOutline16, { className: TaskCommandNode_module_css_default.icon }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: label })]
			});
		}
		//#endregion
		//#region src/client/ShowTaskPanelNode.tsx
		/**
		* `show_task_panel` 工具调用的会话内视图 —— 它的作用就是**把面板打开**。
		*
		* 为什么这件事必须在这里做：面板的显示状态（closed / minimized）是**浏览器侧**的
		* （`task-ui-store.ts`），宿主进程碰不到它。宿主侧原本写的是
		* `exec.ctx.events.emit('dsh:task-panel:show')`，而宿主契约里根本没有 `ctx`：
		*
		*   packages/core/tools/src/index.ts:418
		*   export interface ToolRunContext extends ToolExecution {
		*     deferContext(context: UserMessage): void
		*     concludeTurn(): void
		*   }
		*
		* 于是那个工具每次都只返回「无法获取上下文」，面板从来不会打开 —— 插件里唯一的
		* 宿主命令之外，这是第二个"写了但没生效"的面（详见 CHANGELOG 0.5.14）。
		*
		* 正确的位置是宿主给出的扩展点：`ui-tool` 注册了 `conversation.chat.node`（key `tool-call`），
		* 其下有个按**工具名**分发的子槽 `tool.call.toolview`（契约原文：*Any name is allowed,
		* including tools registered by your package. Register with `key: '<tool name>'`*）。
		* 在这里认领 `show_task_panel` 这个 key，工具结果一渲染就把面板打开。
		*/
		/**
		* 只在**现场执行**时打开面板。
		*
		* 历史节点在刷新 / 切换会话后挂载时会**直接**处于 `result` 阶段；现场调用则会先经过
		* `preparing` / `start`。这与 `/tasks` 命令节点用的判据同款（见 `TaskCommandNode.tsx`
		* 的 `live` ref）：刷新后只展示、不再开面板，否则每次打开会话都会弹一次面板。
		*/
		function ShowTaskPanelNode(props) {
			const phase = props?.phase;
			const live = (0, react.useRef)(phase !== "result");
			(0, react.useEffect)(() => {
				if (phase !== "result" || !live.current) return;
				live.current = false;
				taskUIStore.actions.open();
			}, [phase]);
			return null;
		}
		/** 把 `show_task_panel` 的视图注册进宿主的 `tool.call.toolview` 槽。 */
		function registerShowTaskPanelView(slots, keep) {
			slots.inject("tool.call.toolview", () => {
				const off = slots.register({
					name: "tool.call.toolview",
					key: "show_task_panel"
				}, ShowTaskPanelNode);
				if (typeof keep === "function") keep(off);
			});
		}
		//#endregion
		//#region src/client/slash.ts
		/** 源的稳定标识：同一 trigger 内唯一，重复注册会抛错。 */
		const SLASH_SOURCE_NAME = "project-memory";
		/** 菜单三行。顺序即渲染顺序；标题复用面板已有的 view.* 文案，保证与面板视图名一致。 */
		const ROWS = [
			{
				labelKey: "view.task",
				descriptionKey: "slash.tasks-desc",
				icon: IconChecklistOutline16,
				match: ["tasks", "task"],
				view: "task"
			},
			{
				labelKey: "view.project",
				descriptionKey: "slash.project-desc",
				icon: IconLightOutline16,
				match: [
					"memory",
					"project",
					"insight"
				],
				view: "project"
			},
			{
				labelKey: "view.global",
				descriptionKey: "slash.global-desc",
				icon: IconGlobeOutline16,
				match: [
					"memory",
					"global",
					"insight"
				],
				view: "global"
			}
		];
		/** 按当前语言取翻译函数。 */
		function translator(ctx) {
			return createTranslate(service(ctx, "locale")?.getSnapshot?.()?.active === "zh" ? zh : en);
		}
		/**
		* 一轮候选：把三行装配成菜单行，再按查询与位置过滤。
		* 三行都不接参数（动作全在面板卡片里），所以位置过滤只做一件事：非 leading 位置不弹这一整组
		* （行内出现的 `/` 多半是路径）。
		* @param t - 翻译函数。
		* @param req - 宿主给的候选请求（query / position）。
		* @returns 菜单行；永不抛出。
		*/
		function buildSlashCandidates(t, req) {
			if (req?.position !== void 0 && req.position !== "leading") return [];
			const query = typeof req?.query === "string" ? req.query.trim().toLowerCase() : "";
			return ROWS.map((row) => {
				const title = t(row.labelKey);
				return {
					name: title,
					label: title,
					description: t(row.descriptionKey),
					icon: row.icon,
					section: t("slash.group"),
					terms: [title, ...row.match].map((term) => term.toLowerCase())
				};
			}).filter((row) => query === "" || row.terms.some((term) => term.startsWith(query))).map(({ terms: _terms, ...candidate }) => candidate);
		}
		/**
		* 把触发 token 从草稿里删掉（span 做 CAS：草稿被改过就拒绝，什么都不动）。
		* 与宿主 command 源消费菜单点击是同一条契约事件。
		* @returns true 表示确实消费掉了。
		*/
		function consumeSpan(deps, pick) {
			try {
				const scope = deps.sessions?.scope?.(pick?.session?.sessionId);
				if (!scope || typeof scope.bail !== "function") return false;
				return scope.bail(scope, "slash/input-consume-token", { guard: {
					kind: "span",
					span: pick.span
				} }) === true;
			} catch (err) {
				console.warn("[dsh-project-memory] slash token consume failed:", err);
				return false;
			}
		}
		/**
		* 一次菜单点击：消费掉触发 token 后**直接打开面板的对应页** —— 这三行是「打开某个视图」不是
		* 「执行命令」，`closed`/`view` 是浏览器侧状态；不返回 claim 是因为没有参数要填，消费失败仍切页。
		* @param t - 翻译函数（按当前语言把候选 name 映射回 ROWS）。
		* @param deps - 会话服务与 UI store 动作。
		* @param pick - 宿主给的点击载荷。
		* @returns PickOutcome；拿不到可用形状时返回 undefined（菜单照常关闭，草稿不动）。
		*/
		function dispatchSlashPick(t, deps, pick) {
			const title = pick?.candidate?.name;
			if (typeof title !== "string" || title === "") return void 0;
			const row = ROWS.find((candidate) => t(candidate.labelKey) === title);
			if (row === void 0) return void 0;
			consumeSpan(deps, pick);
			try {
				deps.openView(row.view);
			} catch (err) {
				console.warn(`[dsh-project-memory] open view ${row.view} failed:`, err);
			}
			return "handled";
		}
		/**
		* 造出注册给 `ctx.inputTriggers.registerSource` 的源对象。
		* @param ctx - client 根上下文（只读 locale）。
		* @param deps - 会话服务与命令执行通道。
		* @returns 触发器源；只依赖宿主的公开契约字段。
		*/
		function createSlashSource(ctx, deps) {
			const t = translator(ctx);
			return {
				trigger: "/",
				name: SLASH_SOURCE_NAME,
				order: 1,
				showGroupTitle: false,
				candidates: async (_session, req) => buildSlashCandidates(t, req),
				onPick: (pick) => dispatchSlashPick(t, deps, pick)
			};
		}
		//#endregion
		//#region \0dsh-css:src/client/SettingsCard.module.css.mjs
		const css = ".CSjuLW_card{box-sizing:border-box;border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-lg,16px);background:var(--dsw-alias-bg-layer-3,#fff);transition:border-color .16s,background .16s}.CSjuLW_card:hover{border-color:var(--dsw-alias-label-dimmed,#c8ccd4)}.CSjuLW_cardOpen{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-color:var(--dsw-alias-label-dimmed,#c8ccd4)}.CSjuLW_header{-webkit-appearance:none;appearance:none;border-radius:inherit;width:100%;font:inherit;color:inherit;text-align:left;cursor:pointer;background:0 0;border:0;align-items:center;gap:12px;padding:14px 16px;display:flex}.CSjuLW_header:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4f6ef7);outline-offset:-2px}.CSjuLW_headText{flex-direction:column;flex:1;gap:4px;min-width:0;display:flex}.CSjuLW_name{color:var(--dsw-alias-label-primary,#1f2328);font-size:15px;font-weight:600;line-height:1.4}.CSjuLW_desc{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:13px;line-height:1.5}.CSjuLW_unsaved{color:var(--dsw-alias-label-secondary,#6b7280);background:var(--dsw-alias-bg-module-platform,#eef0f4);border-radius:9px;flex:none;padding:0 6px;font-size:11px;font-weight:600;line-height:17px}.CSjuLW_chevron{color:var(--dsw-alias-label-tertiary,#8b93a1);flex:none;transition:transform .16s;display:inline-flex}.CSjuLW_chevronOpen{transform:rotate(180deg)}.CSjuLW_body{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);margin:0 16px;padding-bottom:8px}.CSjuLW_row{align-items:center;gap:12px;padding:12px 0;display:flex}.CSjuLW_row+.CSjuLW_row{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb)}.CSjuLW_labelBox{flex-direction:column;flex:1;gap:3px;min-width:0;display:flex}.CSjuLW_label{color:var(--dsw-alias-label-primary,#1f2328);font-size:13px;line-height:20px}.CSjuLW_hint{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:12px;line-height:18px}.CSjuLW_control{flex:none;align-items:center;gap:6px;display:flex}.CSjuLW_number{box-sizing:border-box;border:1px solid var(--dsw-alias-border-l2,#d1d5db);background:var(--dsw-alias-bg-layer-3,#fff);width:84px;font:inherit;color:var(--dsw-alias-label-primary,#1f2328);text-align:right;border-radius:7px;padding:6px 8px;font-size:12px;line-height:18px}.CSjuLW_number:disabled{opacity:.5;cursor:default}.CSjuLW_number:focus{border-color:var(--dsw-alias-brand-primary,#4f6ef7);outline:2px solid color-mix(in srgb, var(--dsw-alias-brand-primary,#4f6ef7) 18%, transparent)}.CSjuLW_number[aria-invalid=true]{border-color:var(--dsw-alias-state-error-primary,#dc2626)}.CSjuLW_unit{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:12px;line-height:18px}.CSjuLW_actions{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);justify-content:flex-end;align-items:center;gap:8px;padding:12px 0 4px;display:flex}.CSjuLW_failed{min-width:0;color:var(--dsw-alias-label-error,#dc2626);flex:1;margin:0;font-size:12px;line-height:18px}.CSjuLW_notice{color:var(--dsw-alias-label-tertiary,#8b93a1);margin:0;padding:12px 0;font-size:12px;line-height:18px}";
		const tagId = "@yolk_vat-y/dsh-project-memory/SettingsCard.module.css";
		if (typeof document !== "undefined") {
			const selector = "style[data-plugin-css=" + JSON.stringify(tagId) + "]";
			const existing = document.querySelector(selector);
			if (existing) existing.textContent = css;
			else {
				const tag = document.createElement("style");
				tag.dataset.plugin = "@yolk_vat-y/dsh-project-memory";
				tag.dataset.pluginCss = tagId;
				tag.textContent = css;
				document.head.appendChild(tag);
			}
		}
		var SettingsCard_module_css_default = {
			"actions": "CSjuLW_actions",
			"body": "CSjuLW_body",
			"card": "CSjuLW_card",
			"cardOpen": "CSjuLW_cardOpen",
			"chevron": "CSjuLW_chevron",
			"chevronOpen": "CSjuLW_chevronOpen",
			"control": "CSjuLW_control",
			"desc": "CSjuLW_desc",
			"failed": "CSjuLW_failed",
			"headText": "CSjuLW_headText",
			"header": "CSjuLW_header",
			"hint": "CSjuLW_hint",
			"label": "CSjuLW_label",
			"labelBox": "CSjuLW_labelBox",
			"name": "CSjuLW_name",
			"notice": "CSjuLW_notice",
			"number": "CSjuLW_number",
			"row": "CSjuLW_row",
			"unit": "CSjuLW_unit",
			"unsaved": "CSjuLW_unsaved"
		};
		//#endregion
		//#region src/client/settings-card.tsx
		/**
		* 插件详情页上的「常用设置」卡片。
		*
		* 座位是 `plugins.bundle.config`（key = 包名），外形照宿主自己的插件卡片长：
		* 一行标题 + 说明 + 折叠箭头，**默认收起**；展开后是一列开关，底部右对齐一个保存。
		*
		* 数据面**完全走宿主设置**，不自建第二份配置：
		*   Config 里标了 `.volatile()` 的字段 → 宿主 settings 文档的一个命名空间（ns = 条目 id
		*   `project-memory`）→ 客户端 `ctx.configForms.get('project-memory')` 读写 → 宿主校验 +
		*   revision fence + volatile 原地更新（不重启插件）。这里既不写 profile 的 yml，也不缓存
		*   值：卡片永远是宿主那份配置的投影，命令行改配置和这里改配置是同一条链路。
		*
		* 只放**用户真的会想调、且调了不会让记忆失真**的旋钮（见 SETTINGS_FIELDS 的注释）。
		* memoryDir / roots / insight.* 这类一改就换数据位置或需要理解上下文的，仍留在 profile。
		*/
		/** bundle 包名：`plugins.bundle.config` 的 key 必须与 profile 里安装的包名一致。 */
		const SETTINGS_PACKAGE_NAME = "@yolk_vat-y/dsh-project-memory";
		/** 本插件在 profile 的 loader 条目 id（bundle 的 cordis.patch.yml 定死的那个），也是 settings 命名空间。 */
		const SETTINGS_ENTRY_ID = "project-memory";
		/** 卡片文案的 locale 命名空间。与面板共用一份词典，但独立注册，互不影响。 */
		const SETTINGS_NS = "dsh-project-memory.settings";
		/**
		* 卡片编辑的字段；顺序即渲染顺序。
		*
		* 入选标准只有两条：**用户会主动想调**，且**调坏了不会让记忆失真**。
		*   - `autoIndexOnFirstUse`：换项目时最常见的诉求（"启动就把这里索引好"），默认关。
		*   - `watchInterval`：后台刷新唯一值得调的成本旋钮（频率）。监视本身**不提供关闭**——
		*     关掉之后记忆只会越来越旧，那不是一个选项，是一个坑。
		*   - `llmQueryExpansion`：唯一直接花 token 的开关，该由用户自己决定。
		* 刻意**没有**的：lazyIndexing（默认开，关掉只会让断言变旧）、enableTypeScript（内部实现
		* 细节，用户无从判断）、watch（见上）、memoryDir / roots / 扫描上限（改的是数据落在哪）。
		*/
		const SETTINGS_FIELDS = [
			"autoIndexOnFirstUse",
			"watchInterval",
			"llmQueryExpansion"
		];
		/** 布尔字段：草稿是 `'true'` / `'false'`，其它文本判为非法（挡住保存，而不是吞掉）。 */
		function settingsBooleanField(field) {
			return {
				field,
				format: (value) => typeof value === "boolean" ? String(value) : "",
				parse: (text) => text === "true" ? {
					kind: "set",
					value: true
				} : text === "false" ? {
					kind: "set",
					value: false
				} : void 0
			};
		}
		/** 把 `project-memory` 命名空间桥到卡片的状态上。 */
		var SettingsCardController = class {
			form;
			store;
			expanded = false;
			/**
			* @param scope - 宿主共享配置表单（`ctx.configForms.get('project-memory')`）
			*/
			constructor(scope) {
				this.form = new _deepseek_ai_dsh_client_ui_primitives.SettingsFormModel(scope, [
					settingsBooleanField("autoIndexOnFirstUse"),
					(0, _deepseek_ai_dsh_client_ui_primitives.settingsNumberField)("watchInterval"),
					settingsBooleanField("llmQueryExpansion")
				]);
				this.store = this.form.bind(() => this.projection());
			}
			/**
			* 构造槽位注入面。
			* @returns 快照钩子、展开动作与表单动作
			*/
			inject() {
				return {
					hooks: { settingsCard: this.store },
					toggleExpanded: () => {
						this.expanded = !this.expanded;
						this.store.set(this.projection());
					},
					...this.form.actions()
				};
			}
			/** 释放对宿主命名空间的订阅。 */
			dispose() {
				this.form.dispose();
			}
			projection() {
				const fields = {};
				for (const field of SETTINGS_FIELDS) fields[field] = this.form.field(field);
				return {
					...this.form.shell(),
					expanded: this.expanded,
					fields
				};
			}
		};
		/** 一行：左侧标题 + 说明，右侧控件（与宿主插件卡片的行同构）。 */
		function SettingRow(props) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: SettingsCard_module_css_default.row,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: SettingsCard_module_css_default.labelBox,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: SettingsCard_module_css_default.label,
						children: props.title
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: SettingsCard_module_css_default.hint,
						children: props.hint
					})]
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: SettingsCard_module_css_default.control,
					children: props.children
				})]
			});
		}
		/** 宿主导出的"可渲染组件"：普通函数组件，或 `forwardRef` / `memo` 返回的对象。 */
		function isComponent(value) {
			return typeof value === "function" || typeof value === "object" && value !== null;
		}
		/** 渲染器缺钩子时的占位状态：卡片只显示标题，不读任何宿主值。 */
		const UNAVAILABLE_STATE = {
			available: false,
			writable: false,
			dirty: false,
			invalid: false,
			saving: false,
			failed: false,
			expanded: false,
			fields: Object.fromEntries(SETTINGS_FIELDS.map((field) => [field, {
				text: "",
				overridden: false,
				invalid: false
			}]))
		};
		/** 非 Hook 的稳定回退：hook 数量在两次渲染之间不变，避免条件调用 Hooks。 */
		const fallbackHook = (selector) => selector(UNAVAILABLE_STATE);
		/**
		* 渲染本插件的常用设置。
		* @param props - 表单快照与动作（由槽位注入）
		* @returns 折叠卡片；`summary` 视图不渲染
		*/
		function SettingsCard(props) {
			const t = props.t ?? createTranslate(zh);
			const state = (props.useSettingsCard ?? fallbackHook)((snapshot) => snapshot);
			const discard = props.discard;
			(0, react.useEffect)(() => () => {
				discard?.();
			}, [discard]);
			if (props.view === "summary") return null;
			const edit = props.edit;
			const save = props.save;
			if (edit === void 0 || save === void 0) return null;
			const disabled = !state.writable || state.saving;
			const on = (field) => state.fields[field]?.text === "true";
			const toggle = (field, next) => {
				edit(field, next ? "true" : "false");
			};
			const expanded = state.expanded === true;
			const saveBlocked = !state.dirty || state.invalid || state.saving || !state.writable;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: expanded ? `${SettingsCard_module_css_default.card} ${SettingsCard_module_css_default.cardOpen}` : SettingsCard_module_css_default.card,
				"data-project-memory-settings": true,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					className: SettingsCard_module_css_default.header,
					"aria-expanded": expanded,
					onClick: props.toggleExpanded,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
							className: SettingsCard_module_css_default.headText,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: SettingsCard_module_css_default.name,
								children: t("settings.title")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: SettingsCard_module_css_default.desc,
								children: t("settings.subtitle")
							})]
						}),
						state.dirty ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: SettingsCard_module_css_default.unsaved,
							children: t("settings.unsaved")
						}) : null,
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: expanded ? `${SettingsCard_module_css_default.chevron} ${SettingsCard_module_css_default.chevronOpen}` : SettingsCard_module_css_default.chevron,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, {})
						})
					]
				}), expanded ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: SettingsCard_module_css_default.body,
					children: state.available ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
						!state.writable ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: SettingsCard_module_css_default.notice,
							children: t("settings.form.readOnly")
						}) : null,
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SettingRow, {
							title: t("settings.autoIndexOnFirstUse.title"),
							hint: t("settings.autoIndexOnFirstUse.hint"),
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Switch, {
								checked: on("autoIndexOnFirstUse"),
								disabled,
								label: t("settings.autoIndexOnFirstUse.title"),
								onChange: (next) => {
									toggle("autoIndexOnFirstUse", next);
								}
							})
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(SettingRow, {
							title: t("settings.watchInterval.title"),
							hint: t("settings.watchInterval.hint"),
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								className: SettingsCard_module_css_default.number,
								type: "number",
								min: 5,
								max: 600,
								step: 1,
								inputMode: "numeric",
								"aria-label": t("settings.watchInterval.title"),
								value: state.fields.watchInterval.text,
								disabled,
								"aria-invalid": state.fields.watchInterval.invalid || void 0,
								onChange: (event) => {
									edit("watchInterval", event.target.value);
								}
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: SettingsCard_module_css_default.unit,
								children: t("settings.unit.seconds")
							})]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SettingRow, {
							title: t("settings.llmQueryExpansion.title"),
							hint: t("settings.llmQueryExpansion.hint"),
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Switch, {
								checked: on("llmQueryExpansion"),
								disabled,
								label: t("settings.llmQueryExpansion.title"),
								onChange: (next) => {
									toggle("llmQueryExpansion", next);
								}
							})
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: SettingsCard_module_css_default.actions,
							children: [state.failed ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: SettingsCard_module_css_default.failed,
								role: "status",
								children: t("settings.form.saveFailed")
							}) : null, /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "primary",
								size: "sm",
								disabled: saveBlocked,
								onClick: save,
								children: state.saving ? t("settings.form.saving") : t("settings.form.save")
							})]
						})
					] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: SettingsCard_module_css_default.notice,
						children: t("settings.form.unavailable")
					})
				}) : null]
			});
		}
		/**
		* 注册卡片（软依赖，永不抛出）。
		*
		* 两层门控：
		*   1. 嵌套 `inject(['slots','configForms','locale'])` —— 宿主没有设置服务时这里根本不跑；
		*   2. `configForms.whileServed(['project-memory'])` + `slots.inject('plugins.bundle.config')`
		*      —— 命名空间没被宿主提供、或该版本没有这个槽时，不留下任何注册痕迹。
		* @param ctx - client 根上下文
		*/
		function registerSettingsCard(ctx) {
			if (typeof ctx?.inject !== "function") return;
			try {
				ctx.inject([
					"slots",
					"configForms",
					"locale"
				], (scope) => {
					try {
						mountSettingsCard(scope);
					} catch (err) {
						console.warn(`[${SETTINGS_NS}] settings card registration failed:`, err);
					}
				});
			} catch (err) {
				console.warn(`[${SETTINGS_NS}] settings card injection failed:`, err);
			}
		}
		/**
		* 在已就绪的 scope 上挂载卡片。
		* @param scope - 三个服务齐备的嵌套上下文
		*/
		function mountSettingsCard(scope) {
			const slots = scope?.slots;
			const configForms = scope?.configForms;
			const locale = scope?.locale;
			if (typeof slots?.inject !== "function" || typeof configForms?.get !== "function" || typeof configForms?.whileServed !== "function" || typeof locale?.register !== "function") return;
			if (typeof _deepseek_ai_dsh_client_ui_primitives.SettingsFormModel !== "function" || !isComponent(_deepseek_ai_dsh_client_ui_primitives.Switch) || !isComponent(_deepseek_ai_dsh_client_ui_primitives.Button)) {
				console.warn(`[${SETTINGS_NS}] host ui-primitives has no settings controls — visual settings disabled`);
				return;
			}
			const effect = typeof scope.effect === "function" ? scope.effect.bind(scope) : null;
			const keep = (dispose) => {
				if (typeof dispose !== "function" || effect === null) return;
				effect(() => () => {
					try {
						dispose();
					} catch {}
				});
			};
			try {
				keep(locale.register(SETTINGS_NS, {
					zh,
					en
				}));
			} catch (err) {
				console.warn(`[${SETTINGS_NS}] locale dictionary already registered:`, err);
			}
			const controller = new SettingsCardController(configForms.get(SETTINGS_ENTRY_ID));
			keep(() => controller.dispose());
			keep(configForms.whileServed([SETTINGS_ENTRY_ID], () => slots.inject("plugins.bundle.config", () => slots.register({
				name: "plugins.bundle.config",
				key: SETTINGS_PACKAGE_NAME,
				locale: SETTINGS_NS,
				inject: () => controller.inject()
			}, SettingsCard))));
		}
		//#endregion
		//#region src/client/client.ts
		/**
		* dsh-project-memory Client Entry
		*
		* dsh web (rc.1) 的 client 插件契约为 cordis client plugin：
		*   export const inject = [<client 服务名>...]
		*   export function apply(ctx) { ... }
		*
		* 本插件**不用顶层 `inject` 声明必需服务**（见 services.ts）：它是装配期门控，缺一项宿主
		* 就根本不调用 apply()，表现是"插件出问题、界面上却静默消失"。服务改由 `service()` 现场探测，
		* 缺了照常挂载、面板上显示原因、日志里打一条点名缺失项的告警。
		*
		* 面板注册进 `shell.overlay`（Frame 级浮动层，additive 列表槽）：
		* 该槽由 ui-layout 的 AppFrame 声明渲染（scope root，独立于滚动容器），
		* 默认 click-through，条目自身需开启 pointer-events。
		*
		* 只依赖宿主 seed 提供的模块（react / dsh-client-ui-primitives），
		* 数据经 remote.commands.execute 执行 /tasks 命令获取 JSON 快照。
		*
		* 另有一个可选增强：自建的 `/` 菜单源（slash.ts），把三条命令收进一个带图标和
		* 小节标题的「工作流」组。它**整体是可选的**——宿主没有 slash 触发器服务时静默跳过。
		*/
		const NS = "dsh-project-memory";
		const name = NS;
		/**
		* 顶层 `inject` **留空**（必需服务的软依赖清单在 services.ts 的 `REQUIRED_SERVICES`）。
		*
		* 这不是省略，而是契约选择：cordis 的顶层 inject 是装配期门控，缺一项就根本不调用
		* `apply()` —— 整个 client 半边静默消失。留空后 apply() 一定会被调用，服务缺失由
		* `missingServices()` 在运行时说清楚（面板上显示 + 日志告警）。
		*/
		const inject = [];
		/**
		* 注册自建的 `/` 菜单源（见 slash.ts）。
		*
		* 整段都是**可选增强**：宿主没有 `inputTriggers` 服务、或该服务换了契约时，绝不能因此
		* 让整个 client 插件挂掉——那会连任务面板一起消失。`inputTriggers` 因此不进任何 `inject`
		* 声明，而是走嵌套 `ctx.inject` + 两层 try/catch（顶层 inject 未满足时 cordis 根本不会
		* 调用 apply，见 services.ts）。
		* @param ctx - client 根上下文
		*/
		function registerSlashSource(ctx) {
			if (typeof ctx?.inject !== "function") {
				console.warn(`[${NS}] host has no ctx.inject — slash menu group disabled`);
				return;
			}
			try {
				ctx.inject(["inputTriggers", "sessions"], (scope) => {
					try {
						const inputTriggers = scope?.inputTriggers;
						if (!inputTriggers || typeof inputTriggers.registerSource !== "function") {
							console.warn(`[${NS}] host has no inputTriggers.registerSource — slash menu group disabled`);
							return;
						}
						const source = createSlashSource(scope, {
							sessions: scope.sessions,
							openView: (view) => taskUIStore.actions.openView(view)
						});
						scope.effect(() => inputTriggers.registerSource(source), "dsh-project-memory: slash source");
					} catch (err) {
						console.warn(`[${NS}] slash source registration failed:`, err);
					}
				});
			} catch (err) {
				console.warn(`[${NS}] slash source injection failed:`, err);
			}
		}
		/**
		* 挂载任务面板（`shell.overlay` 浮层 + 会话内命令节点 + `show_task_panel` 工具视图）。
		*
		* `slots` 同样是软依赖：现成的就用；没有就**等它**（cordis 的 `ctx.inject` 是嵌套注入，
		* 只门控这一段回调，插件本身照样挂载）。等不到时由 {@link reportDegradedLater} 说明原因。
		* @param ctx - client 根上下文
		*/
		function registerTaskPanel(ctx) {
			const mount = (slots, effect) => {
				if (!slots || typeof slots.inject !== "function") {
					console.warn(`[${NS}] host has no slots service — task panel disabled`);
					return;
				}
				const keep = (off) => {
					if (typeof off !== "function") return;
					const dispose = () => {
						try {
							off();
						} catch {}
					};
					if (typeof effect === "function") effect(() => dispose);
				};
				const register = (spec, component) => {
					try {
						keep(slots.register(spec, component));
					} catch (err) {
						console.warn(`[${NS}] slot registration failed:`, err);
					}
				};
				try {
					slots.inject("shell.overlay", () => register({
						name: "shell.overlay",
						id: "dsh-project-memory-task-panel",
						order: 100
					}, () => (0, react.createElement)(TaskPanelEntry, { ctx })));
					for (const key of ["tasks"]) slots.inject("conversation.chat.commandview", () => register({
						name: "conversation.chat.commandview",
						key
					}, TaskCommandNode));
					registerShowTaskPanelView(slots, keep);
				} catch (err) {
					console.warn(`[${NS}] task panel registration failed:`, err);
				}
			};
			if (typeof ctx?.inject === "function") try {
				ctx.inject(["slots"], (scope) => mount(scope?.slots ?? service(ctx, "slots"), scope?.effect));
				return;
			} catch (err) {
				console.warn(`[${NS}] slots injection failed:`, err);
			}
			mount(service(ctx, "slots"), typeof ctx?.effect === "function" ? ctx.effect.bind(ctx) : void 0);
		}
		/**
		* 过了宽限期仍然读不到必需服务时，打**一条**点名缺失项的告警。
		*
		* 为什么不在 `apply()` 里立刻报：装配是异步的，apply 时某个服务还没 provide 是正常的
		* （那样每次启动都会误报）。宽限期后还缺，就是真的缺 —— 这条日志是"静默消失"的反面。
		* @param ctx - client 根上下文
		*/
		function reportDegradedLater(ctx) {
			later(ctx, DEGRADED_GRACE_MS, () => {
				const missing = missingServices(ctx);
				if (missing.length === 0) return;
				console.warn(`[${NS}] degraded: client service(s) unavailable in this assembly: ${missing.join(", ")} — the client half is mounted anyway; the task panel shows the same reason.`);
			});
		}
		function apply(ctx) {
			registerTaskPanel(ctx);
			registerSlashSource(ctx);
			registerSettingsCard(ctx);
			reportDegradedLater(ctx);
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		exports.name = name;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map