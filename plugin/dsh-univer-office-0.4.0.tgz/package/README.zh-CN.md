![Univer × DeepSeek](docs/assets/readme/univer-deepseek-banner.png)

# DSH × Univer Office

> 为 DeepSeek Harness 打造一个真正的办公环境。
>
> Univer Office 插件将电子表格、文档、幻灯片、画布、多维表格等汇聚到同一个运行时——数据互联、修改经过校验、变更按版本管理，并以隔离工作树支持多 Agent 协作。

[English](README.md) · 简体中文

[![npm](https://img.shields.io/npm/v/dsh-univer-office)](https://www.npmjs.com/package/dsh-univer-office)
[![Node.js](https://img.shields.io/badge/Node.js-%3E%3D22.19-339933?logo=node.js&logoColor=white)](package.json)
[![License](https://img.shields.io/badge/license-Apache--2.0-blue)](LICENSE)

`dsh-univer-office` 是 DeepSeek Harness（DSH）的 Univer 办公插件。告诉 Agent 你想要什么，它可以创建和编辑电子表格、文档、演示文稿、多维表格与画布，也可以处理现有的 Excel、Word 和 PowerPoint 文件。所有修改都会经过校验，并留在会话中供你预览、确认或放弃。

安装后直接用自然语言描述目标即可。Agent 会完成创建、编辑和校验，你可以在会话中实时查看过程、审阅结果，并把电子表格导出为 Excel（`.xlsx`），或按需交付 Word（`.docx`）和 PowerPoint（`.pptx`）文件。

## 看看实际效果

[![播放 DSH × Univer Office 演示视频](docs/assets/readme/nike-presentation-demo.png)](https://www.youtube.com/watch?v=k-2zW_CMiew)


下面的电子表格由 Agent 根据自然语言要求创建，并在同一个会话中继续添加条件格式和图表。完成后可以直接预览、继续修改、合入当前版本或丢弃。

![在 DSH 会话中审阅带条件格式和图表的电子表格](docs/assets/readme/chart-and-formatting.png)

> **可以直接交付 Excel 文件：** 审阅完成后，让 Agent 将电子表格导出为 `.xlsx`，即可使用 Excel、WPS Office 等常见办公软件继续打开和编辑。

<details>
<summary>查看从提出需求到审阅结果的完整过程</summary>

### 1. 用自然语言描述任务

![要求 Agent 创建班级成绩表](docs/assets/readme/spreadsheet-request.png)

### 2. 修改过程中实时查看结果

![Agent 工作时显示实时电子表格浮窗](docs/assets/readme/live-worktree.png)

### 3. 在会话中确认或放弃修改

![任务完成后的电子表格审阅卡片](docs/assets/readme/review-result.png)

</details>

### 从一句话生成可交付的演示文稿

Agent 可以根据主题、受众、页数、内容结构和视觉要求生成完整演示文稿，在制作过程中逐页检查内容与布局，并把结果留在会话中审阅。

![在 DSH 会话中审阅冒泡排序教学演示文稿](docs/assets/readme/presentation-review.png)

> **可以直接交付 PowerPoint 文件：** 审阅完成后，让 Agent 将演示文稿导出为 `.pptx`，即可使用 PowerPoint、WPS Office 等常见办公软件继续播放和编辑。

<details>
<summary>查看演示文稿从需求到成品的制作过程</summary>

#### 1. 说明主题、受众和页面要求

![要求 Agent 创建冒泡排序教学演示文稿](docs/assets/readme/presentation-request.png)

#### 2. 制作过程中实时查看和校验页面

![Agent 制作演示文稿时显示实时预览窗口](docs/assets/readme/presentation-live.png)

</details>

## 你可以让它做什么

- **分析和制作表格**：读取或创建 Excel 数据，清洗字段，编写公式，设置格式、数据验证和条件格式，创建表格、图表、透视表、筛选器、迷你图与图片，最后导出为 `.xlsx`、`.csv` 或 `.tsv`。
- **撰写和排版文档**：创建段落、富文本、列表、任务、表格、图片、图表、页眉页脚、分页与页面布局。
- **创建和修改演示文稿**：从大纲生成整套幻灯片，重设计指定页面，编辑文字、形状、图片、表格、图表与转场，并检查越界、溢出和文本重叠。
- **搭建多维表格**：创建表、字段、记录和视图，使用公式字段、筛选、排序、分组及 Sheet 数据引用。
- **绘制可编辑画布**：创建形状、文本、连接线、图片、原生图表和流程图，并检查连接关系与布局。
- **组合多种内容**：一个 `.univer` 文件可以同时包含 Sheet、Doc、Slide、多维表格（Base）和 Board；公式或嵌入内容可以引用同一文件中的其他内容。
- **处理 Office 文件**：导入 `.xlsx`、`.csv`、`.tsv`、`.docx`、`.pptx`，修改后按对应格式导出。
- **安全审阅 Agent 修改**：所有写入先进入隔离草稿。你可以实时预览差异，再选择确认或放弃，不会让 Agent 直接覆盖当前版本。
- **按语义比较 worktree 修改**：把草稿或已提交 worktree 从“查看”切换到“比较”，即可将 Sheet、Doc、Slide、Base 或 Board 与固定的主线版本或另一个活跃 worktree 并排审阅。

### 试试这些任务

```text
帮我做一个简单的工资计算表，包含员工、基本工资、奖金、扣款、应发工资和实发工资，自动计算汇总结果。

帮我做一个冒泡排序的幻灯片课件，用 6 页讲清楚原理、逐轮比较过程、伪代码和复杂度，每页完成布局检查。

帮我创建一份正式的项目周报文档，包含执行摘要、本周进展、风险表、下周计划和页眉页脚，最后导出 docx。

创建一个客户跟进多维表格，包含公司、联系人、阶段、预计金额和下次行动，并提供按阶段分组的视图。

在同一个 .univer 文件里创建销售数据 Sheet 和汇报 Slide，让 Slide 图表引用 Sheet 数据。
```

## 能力一览

| 内容类型 | 创建与编辑 | 校验与审阅 | 导入 | 导出 |
| --- | --- | --- | --- | --- |
| Sheet | 单元格、公式、样式、表格、图表、透视表、筛选、验证、图片等 | 结构化范围检查、公式重算、截图、PDF 打印、实时预览 | `.xlsx` `.csv` `.tsv` | `.xlsx` `.csv` `.tsv` |
| Doc | 段落、富文本、列表、任务、表格、图片、图表、页眉页脚、分页 | 文档结构回读、逐页截图、PDF 打印、实时预览 | `.docx` | `.docx` |
| Slide | 页面、文字、形状、图片、表格、图表、SVG 布局、转场 | 结构检查、布局检查、截图、PDF 打印、实时预览 | `.pptx` | `.pptx` |
| 多维表格（Base） | 表、字段、记录、视图、公式字段、筛选、排序、分组 | 结构化数据检查、工作台截图、实时预览 | — | `.xlsx` `.csv` `.tsv` |
| Board | 形状、文字、连接线、图片、原生图表、自动布线 | 元素分析、截图、PDF 打印、实时预览 | — | — |

所有类型都支持隔离草稿、并排语义比较、审阅、继续修改、确认或放弃。多维表格和 Board 支持结构校验；Board 暂不支持文件导出。

## 3 分钟上手

### 1. 安装插件

支持的 DSH 版本为 `0.1.5-rc.3`、`0.1.7-rc.1`、`0.2.0-rc.1` 和 `0.2.1-rc.3`。

如果 DSH 正在运行，先在启动它的终端按 **Ctrl+C** 停止进程。运行中可以执行安装命令，但当前 DSH 进程不会自动加载新插件。

从 npm 安装插件：

```sh
dsh plugin --profile web add dsh-univer-office
```

安装完成后重新启动 DSH：

```sh
dsh web
```

DSH 启动成功后，在已有的 DeepSeek Harness 浏览器页面按 **Cmd+R / Ctrl+R** 刷新。

### 2. 直接描述需求

```text
帮我生成一个月度支出表格，包含日期、分类、金额和合计，并填入几条示例数据。
```

### 3. 在会话中审阅

- Agent 工作时，修改会显示在可移动的实时预览窗口中。浮窗和全屏审阅卡片会避开桌面标题栏。
- 审阅卡片会保留在会话里，之后仍可折叠或全屏打开。全屏不受对话容器的布局限制，原位置保留卡片占位，切换时不重新加载 Viewer，按 Esc 可退出。
- 继续修改、确认或放弃都可直接在卡片内的 Univer 页面完成。

## 工作方式

1. 描述目标，并提供需要处理的源文件。
2. Agent 创建隔离草稿，在其中编辑 Univer 内容。
3. 通过实时预览查看结果，并继续提出修改要求。
4. 确认结果后更新当前版本，或放弃草稿而不影响当前版本。

确认和放弃都必须由用户明确提出。

## 内置工具

DSH 会自动选择这些工具，日常使用不需要手动调用。

| 工具 | 作用 |
| --- | --- |
| `univer_new` | 创建空 `.univer` 文件，不覆盖已有文件 |
| `univer_status` | 查看文件内容与草稿状态 |
| `univer_worktree` | 创建、提交、继续修改、确认或放弃隔离草稿 |
| `univer_unit` | 添加或删除 Sheet、Doc、Slide、多维表格或 Board 内容 |
| `univer_import` | 把 Office 文件导入 `.univer` 文件；docx 默认保留页面设置，`docType` 可选 traditional（默认）或 modern |
| `univer_inspect` | 读取文档结构或指定 Sheet 范围 |
| `univer_execute` | 通过 Univer API 读取或编辑内容 |
| `univer_export` | 导出 Sheet、Doc、Slide 或多维表格内容 |
| `univer_lint` | 检查 Slide 文字越界、溢出和重叠 |
| `univer_compile_svg` | 将 SVG 布局按文字度量添加到 Slide |
| `univer_screenshot` | 把支持的内容渲染为 PNG 图片供审阅 |
| `univer_print_pdf` | 把 Sheet、Doc、Slide 或 Board 打印为 workspace 中的 PDF 文件 |
| `univer_api` | 按关键词查找插件内置的 Univer API 符号并查看精确引用 |
| `univer_resources` | 查找和使用内置图标、Logo、Emoji 与插画 |

## 预览与审阅体验

- **文件树按需预览**：在 DSH 文件树中点击 `.univer` 文件即可在右侧栏打开预览，与 `.docx`、`.xlsx`、`.pptx` 的内置预览一致。整个过程不需要 Agent 执行任何操作，因此在关闭自动实时预览后依然可用。版本切换与 worktree 审阅统一在 Viewer 内完成。打开文件时若未指定目标，且主线没有文档，则默认进入第一个活跃 worktree。该入口直接注册在 DSH 自带的右侧栏上；若安装了 `dsh-better-sidebar`，由于该插件会接管文件地址，预览会改为注册成它的文件预览器。
- **实时 Univer 窗口**：修改默认自动显示在可拖动、缩放、折叠和全屏的窗口中；可在插件设置中关闭自动打开（侧边栏“插件”页面中的 **dsh-univer-office** 详情页；0.1.6-alpha.2 之前的 DSH 版本在“设置 → 插件 → 插件配置”），不影响会话审阅卡片和上面的文件树预览。
- **会话审阅卡片**：每个修改过的 `.univer` 文件都有独立的完整预览卡片；已删除的临时文件不会留下无效卡片。可在插件设置中关闭「在会话中显示审阅卡片」让会话更紧凑——文件树预览与实时窗口由各自的开关独立控制。
- **固定版本的 worktree 比较**：在草稿或已提交 worktree 中选择“比较”，可与主线或另一个活跃 worktree 对照。打开比较时会固定两侧版本，可逐项定位变更；任一侧继续更新后会显示刷新入口。
- **响应式审阅 Header**：空间充足时“查看 / 对比”居中，窗口变窄后控件紧凑排列并按顺序换行；标题显示当前文档名，超长名称截断，合并状态提示保持可见。
- **历史审阅**：草稿、已提交修改、确认和放弃结果都会保留在会话中。只有最近一次操作文件的回合卡片默认展开，更早的卡片默认折叠，展开时才加载预览。
- **多会话隔离**：每个 DSH 会话只展示属于自己的窗口、卡片和审阅状态。
- **中英文界面**：插件外壳和已打开的 Viewer 跟随 DSH 的界面语言。
- **导入、导出与打印**：当前版本可通过 Univer Ribbon 导入 Office 文件、导出受支持的内容并打印。草稿和审阅预览不开放导入导出；Board 仅提供打印。
- **五类 Unit 版本历史**：当前版本的 Sheet、Doc、Slide、Base 和 Board 均可查看按时间聚合的历史。只读视图可以查看版本，可编辑视图可以显式恢复。

## 要求与限制

- DeepSeek Harness，以及 Node.js `>=22.19.0`。
- 文件树预览不需要额外插件：它在 DSH 自带右侧栏注册一个 tab 类型，认领以 `.univer` 结尾的 `dsh-resource://file/**` 地址。安装 `dsh-better-sidebar`（`^0.19.0`）期间，该插件会以同档位、更宽的模式接管文件地址，因此预览改为注册成它的文件预览器——两种宿主形态都覆盖，且任一时刻只有一条生效。
- 打开旧版 `.univer` 文件时会自动升级到 v3 格式：先在原文件旁保存备份，在临时副本中完成迁移和验证，成功后才替换原文件；升级失败时原文件保持不变。再次打开同一份未变化的文件时复用这份备份，不会再复制一份。
- 截图、PDF 打印、Slide 布局检查和 SVG 文字度量需要本机 Chromium 系浏览器。Chrome/Chromium 与 Microsoft Edge 会被自动探测；也可以通过 `browserExecutablePath` 配置项或 `UNIVER_RENDER_BROWSER` 环境变量指定浏览器可执行文件路径（例如 Windows 上的 Edge）。
- Slide 的母版、版式页和演讲者备注不在当前编辑范围内。
- Board 的思维导图、表格、墨迹和高级编辑，以及 Board 文件导出尚未开放。
- 启用内置任务指引时，插件会替换 DSH 自带的 `office`、`office-docx`、`office-xlsx` 和 `office-pptx` 技能，使 Word、Excel 和 PowerPoint 任务走 Univer，而不是 python-docx、openpyxl 或 python-pptx。DSH 的 LibreOffice Kit 技能（`office-render`、`office-recalculate` 和 `office-export-pdf`）保持可用。如需保留 DSH 原有技能，设置 `skills: false`。

## 配置

默认配置适合本地使用：服务从端口 `9080` 启动；若该端口被占用，则依次尝试 `9081`、`9082`。如需定制，可设置以下插件选项：

| 字段 | 默认值 | 说明 |
| --- | --- | --- |
| `gatewayPort` | `9080` | 本地服务起始端口；被占用时逐次加一 |
| `autoStartGateway` | `true` | 首次访问时自动启动服务 |
| `gatewayStartupTimeoutMs` | `10000` | 服务启动超时 |
| `gatewayRequestTimeoutMs` | `3000` | 状态读取超时 |
| `gatewayMutationTimeoutMs` | `60000` | 写操作超时 |
| `unitContentOperationTimeoutMs` | `120000` | 导入、导出、检查和执行超时 |
| `unitContentRuntimeMaxEntries` | `20` | 为检查、执行和渲染保持预热的 Unit runtime 数；全部忙碌时后续操作返回 `COLLABORATION_POOL_CAPACITY_EXCEEDED`；`0` 表示每次操作都启动新进程 |
| `unitContentRuntimeIdleTtlMs` | `300000` | 预热的 Unit runtime 空闲多久后退出 |
| `screenshotOperationTimeoutMs` | `120000` | 一次浏览器截图操作的总超时 |
| `printPdfOperationTimeoutMs` | `120000` | 一次浏览器 PDF 打印操作的总超时 |
| `screenshotMaxPages` | `30` | 一次 Doc 或 Slide 截图最多渲染的页数 |
| `screenshotMaxPixels` | `16777216` | 每张截图允许的最大像素数 |
| `browserExecutablePath` | 自动探测 | 截图、PDF 打印和 Slide 检查使用的浏览器可执行文件；设置后优先于 `UNIVER_RENDER_BROWSER` |
| `resourceCacheRoot` | `$DSH_HOME/cache/dsh-univer-office/resources` | 下载 SVG 资源的持久缓存目录；未设置 `DSH_HOME` 时使用 `~/.dsh` |
| `resourceDownloadTimeoutMs` | `15000` | 单个 SVG 资源下载超时 |
| `resourceOperationTimeoutMs` | `120000` | 一次资源库工具操作的总超时 |
| `tools` | `true` | 启用 Agent 编辑能力 |
| `skills` | `true` | 启用内置任务指引 |
| `telemetry` | `true` | 发送匿名产品遥测 |

Viewer 页面、HTTP API 与 WebSocket 协作流量由插件直接挂载在 DSH WebServer origin 上（`/univer-viewer/...` 与 `/uf/...`），远程部署沿用现有 DSH 访问入口即可，无需额外反向代理配置。每个浏览器请求均通过 `connection` 服务完成 DSH 浏览器鉴权。Viewer 文档打开与 `/univer-api` 请求还会校验指定会话的 workspace；后续 `/uf` API 与 WebSocket 请求不依赖插件会话 cookie，也不重复 workspace 校验。已通过鉴权的浏览器可以寻址 Host 进程有权访问的任意 `.univer` 文件，远程部署也采用相同规则。在 DSH 桌面端，Viewer 通过受鉴权保护的运行时接口获取当前 Host loopback 地址，用于 WebSocket 连接；HTTP 请求仍由桌面壳转发。Gateway 始终只监听 loopback，不对外暴露。（原 `viewerBaseUrl` 配置已随本次变更移除，保留时会被忽略。）

## 遥测

插件激活后默认发送匿名使用统计（不含文件内容与路径），发布包不声明 `postinstall` 脚本。设 `DO_NOT_TRACK=1` 或配置 `telemetry: false` 关闭遥测。

## 卸载

```sh
dsh plugin --profile web remove dsh-univer-office
```

## 开发

本项目是一个标准 [DSH bundle](https://github.com/deepseek-ai/deepseek-harness/blob/main/docs/user/develop/basic/publish.md)。Host 组合 Univer Service Provider、Tools Consumer、webServer Consumer 和 Skill Provider；插件自带 Gateway、Viewer、池化 Collaboration Runtime Worker、无头 Unit Content Worker 与 Slide render machine。依赖方向和运行时边界见[架构文档](docs/architecture.md)。

项目要求 Node.js `>=22.19.0` 和 `pnpm@11.23.0`。

```sh
pnpm install
pnpm run lint
pnpm run typecheck
pnpm run build
pnpm run test
```

`.npmrc` 让 `@univer-cli`、`@univerjs`、`@univerjs-pro` 三个 scope 从 Univer 的 insider registry（`https://insider-npm-registry.univer.work/`）解析。该源对外公开，不需要账号或 token，主要用于访问 Univer 的 insider 版本；正式版本推荐从 npm 下载安装。

## 官方包名

请只安装 `dsh-univer-office`。以下相似名称是本项目为防止仿冒而保留的 deprecated npm 占位包，不包含插件代码：

- `dsh-univer-plugin`
- `dsh-univer-office-suite`
- `dsh-univer-suite`
- `univer-office-suite`
- `univer-office`

## 许可

[Apache-2.0](LICENSE)
