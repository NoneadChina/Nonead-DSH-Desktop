import {
  ErrorCode,
  UniverType,
  ap,
  cp,
  dp,
  executeUnitContent,
  inspectUnitContent,
  invalidRequest,
  ip,
  isRecord,
  loadUnitContentRuntime,
  lp,
  op,
  parseUnitContentRuntimeInit,
  pullUnitContent,
  requiredString,
  sp,
  unitContentError,
  unitContentKind,
  up
} from "./worker-chunks/chunk-PWYAH7S6.mjs";
import "./worker-chunks/chunk-D3GMOPM4.mjs";

// src/workers/unit-content/entry.ts
import { extname as extname2, isAbsolute } from "node:path";

// node_modules/.pnpm/@univerjs-pro+exchange-node@1.2.0_react@18.3.1_rxjs@7.8.2/node_modules/@univerjs-pro/exchange-node/lib/es/index.js
import { basename, extname } from "node:path";
import { readFile, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import process2 from "node:process";
import { Buffer as NodeBuffer } from "node:buffer";
var ExchangeFormat = /* @__PURE__ */ ((ExchangeFormat2) => (ExchangeFormat2.XLS = "xls", ExchangeFormat2.XLSX = "xlsx", ExchangeFormat2.CSV = "csv", ExchangeFormat2.TSV = "tsv", ExchangeFormat2.DOC = "doc", ExchangeFormat2.DOCX = "docx", ExchangeFormat2.PPT = "ppt", ExchangeFormat2.PPTX = "pptx", ExchangeFormat2))(ExchangeFormat || {});
var FormulaCalculationMode = /* @__PURE__ */ ((FormulaCalculationMode2) => (FormulaCalculationMode2.FORCED = "forced", FormulaCalculationMode2.WHEN_EMPTY = "when_empty", FormulaCalculationMode2.NO = "no", FormulaCalculationMode2))(FormulaCalculationMode || {});
var DocxCompatibilityMode = /* @__PURE__ */ ((DocxCompatibilityMode2) => (DocxCompatibilityMode2.TRADITIONAL = "traditional", DocxCompatibilityMode2.MODERN = "modern", DocxCompatibilityMode2))(DocxCompatibilityMode || {});
var ExchangeErrorCode = /* @__PURE__ */ ((ExchangeErrorCode2) => (ExchangeErrorCode2.INVALID_ARGUMENT = "INVALID_ARGUMENT", ExchangeErrorCode2.UNSUPPORTED_FORMAT = "UNSUPPORTED_FORMAT", ExchangeErrorCode2.INVALID_FILE = "INVALID_FILE", ExchangeErrorCode2.INCOMPLETE_SNAPSHOT = "INCOMPLETE_SNAPSHOT", ExchangeErrorCode2.IO_ERROR = "IO_ERROR", ExchangeErrorCode2.NATIVE_LOAD_FAILED = "NATIVE_LOAD_FAILED", ExchangeErrorCode2.CONVERSION_FAILED = "CONVERSION_FAILED", ExchangeErrorCode2))(ExchangeErrorCode || {});
var ExchangeError = class extends Error {
  constructor(code, message, options) {
    super(message, options);
    this.code = code;
  }
  code;
  name = "ExchangeError";
};
var nativeBinding = null;
var nativeBindingSource = null;
var nodeRequire = createRequire(import.meta.url);
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}
async function loadNativeBinding() {
  if (nativeBinding)
    return nativeBinding;
  let errors = [];
  try {
    return nativeBinding = nodeRequire("@univerjs-pro/exchange-node-binding"), nativeBindingSource = "@univerjs-pro/exchange-node-binding", nativeBinding;
  } catch (error) {
    errors.push(`@univerjs-pro/exchange-node-binding: ${errorMessage(error)}`);
  }
  throw new ExchangeError(
    "NATIVE_LOAD_FAILED",
    [
      "Failed to load native exchange binding.",
      `platform=${process2.platform}`,
      `arch=${process2.arch}`,
      "expected npm package=@univerjs-pro/exchange-node-binding",
      "attempted paths:",
      ...errors.map((item) => `- ${item}`)
    ].join(`
`)
  );
}
function createSnapshotCollector() {
  let sheetBlocks = /* @__PURE__ */ new Map();
  return {
    // The public Pro conversion functions accept the host-wide service
    // contract even though these conversion paths use its two write methods.
    service: {
      async saveSheetBlock(_context, { block }) {
        return block ? (sheetBlocks.set(block.id, block), {
          blockID: block.id,
          error: { code: ErrorCode.OK, message: "" }
        }) : {
          blockID: "",
          error: { code: ErrorCode.UNDEFINED, message: "block is required" }
        };
      },
      async saveSnapshot() {
        return { error: { code: ErrorCode.OK, message: "" } };
      }
    },
    get sheetBlocks() {
      return [...sheetBlocks.values()];
    }
  };
}
function bufferView(bytes) {
  return NodeBuffer.isBuffer(bytes) ? bytes : NodeBuffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}
function takeMetadata(owner, kind, metadata, ownerId) {
  if (!owner)
    return owner;
  let { originalMeta, ...rest } = owner;
  if (originalMeta instanceof Uint8Array)
    metadata.push({ kind, ownerId, data: bufferView(originalMeta) });
  else if (originalMeta != null)
    throw new TypeError(`${kind} originalMeta must be a Uint8Array`);
  return rest;
}
function toNativeSnapshot(value) {
  let metadata = [], source = value.snapshot, snapshot = { ...source }, sourceWorkbook = source.workbook;
  if (sourceWorkbook) {
    let workbook = takeMetadata(sourceWorkbook, "workbook", metadata), sourceSheets = sourceWorkbook.sheets;
    sourceSheets && (workbook.sheets = Object.fromEntries(
      Object.entries(sourceSheets).map(([sheetId, sheet]) => [
        sheetId,
        takeMetadata(sheet, "worksheet", metadata, sheetId)
      ])
    )), snapshot.workbook = workbook;
  }
  for (let kind of ["doc", "slide"]) {
    let owner = source[kind];
    owner && (snapshot[kind] = takeMetadata(owner, kind, metadata));
  }
  return {
    snapshotJson: NodeBuffer.from(JSON.stringify(snapshot)),
    metadata,
    sheetBlocks: value.sheetBlocks.map((block) => ({
      id: block.id,
      startRow: block.startRow,
      endRow: block.endRow,
      data: bufferView(block.data)
    }))
  };
}
function restoreMetadata(snapshot, metadata) {
  for (let entry of metadata) {
    let owner;
    if (entry.kind === "worksheet") {
      let sheets = snapshot.workbook?.sheets;
      owner = entry.ownerId ? sheets?.[entry.ownerId] : void 0;
    } else {
      if (entry.kind !== "workbook" && entry.kind !== "doc" && entry.kind !== "slide")
        throw new TypeError(`unsupported native snapshot metadata kind ${entry.kind}`);
      owner = snapshot[entry.kind];
    }
    if (!owner)
      throw new TypeError(`native snapshot metadata owner ${entry.kind}/${entry.ownerId ?? ""} is missing`);
    owner.originalMeta = entry.data;
  }
}
function fromNativeSnapshot(value) {
  let snapshot = JSON.parse(value.snapshotJson.toString("utf8"));
  return restoreMetadata(snapshot, value.metadata), {
    snapshot,
    sheetBlocks: value.sheetBlocks.map((block) => ({
      id: block.id,
      startRow: block.startRow,
      endRow: block.endRow,
      data: block.data
    }))
  };
}
var FORMAT_BY_EXTENSION = {
  ".xls": "xls",
  ".xlsx": "xlsx",
  ".csv": "csv",
  ".tsv": "tsv",
  ".doc": "doc",
  ".docx": "docx",
  ".ppt": "ppt",
  ".pptx": "pptx"
  /* PPTX */
};
function normalizeWorkbookSheetOrder(data) {
  let existingOrder = Array.isArray(data.sheetOrder) ? data.sheetOrder.filter((sheetId) => typeof sheetId == "string") : [], ordered = new Set(existingOrder), missingSheetIds = Object.keys(data.sheets).filter((sheetId) => !ordered.has(sheetId));
  return missingSheetIds.length === 0 ? data : { ...data, sheetOrder: [...existingOrder, ...missingSheetIds] };
}
function exchangeError(error, fallback) {
  if (error instanceof ExchangeError)
    return error;
  let message = error instanceof Error ? error.message : String(error), nativeCode = /^\[([A-Z_]+)]\s*/.exec(message)?.[1];
  return nativeCode && Object.values(ExchangeErrorCode).includes(nativeCode) ? new ExchangeError(nativeCode, message.replace(/^\[[A-Z_]+]\s*/, ""), {
    cause: error
  }) : error instanceof TypeError ? new ExchangeError("INVALID_ARGUMENT", message, { cause: error }) : new ExchangeError(fallback, message, { cause: error });
}
function resolveFormat(fileName, format) {
  if (format)
    return format;
  let inferred = FORMAT_BY_EXTENSION[extname(fileName).toLowerCase()];
  if (!inferred)
    throw new ExchangeError(
      "UNSUPPORTED_FORMAT",
      `Cannot infer an exchange format from fileName: ${fileName}`
    );
  return inferred;
}
function nativeUnitType(type) {
  switch (type) {
    case UniverType.UNIVER_SHEET:
      return "sheet";
    case UniverType.UNIVER_BASE:
      return "base";
    case UniverType.UNIVER_DOC:
      return "doc";
    case UniverType.UNIVER_SLIDE:
      return "slide";
    default:
      throw new ExchangeError("INVALID_ARGUMENT", `Unsupported Univer unit type: ${type}`);
  }
}
function nativeImportOptions(options, fileName) {
  return {
    format: resolveFormat(fileName, options.format),
    unitType: nativeUnitType(options.type),
    fileName,
    unitId: options.unitId,
    minSheetRowCount: "minSheetRowCount" in options ? options.minSheetRowCount : void 0,
    minSheetColumnCount: "minSheetColumnCount" in options ? options.minSheetColumnCount : void 0,
    compatibilityMode: "compatibilityMode" in options ? options.compatibilityMode : void 0,
    csv: "csv" in options ? options.csv : void 0,
    base: options.type === UniverType.UNIVER_BASE ? {
      mode: options.mode,
      typeInference: options.typeInference,
      formulaPolicy: options.formulaPolicy,
      imagePolicy: options.imagePolicy,
      maxCells: options.maxCells,
      mapping: options.mapping
    } : void 0,
    formulaCalculation: "formulaCalculation" in options ? options.formulaCalculation : void 0
  };
}
function nativeExportOptions(options) {
  return {
    format: options.format,
    unitType: nativeUnitType(options.type),
    csv: "csv" in options ? options.csv : void 0,
    base: options.type === UniverType.UNIVER_BASE && options.format === "xlsx" ? {
      mode: options.mode,
      formulaPolicy: options.formulaPolicy,
      attachmentPolicy: options.attachmentPolicy,
      mapping: options.mapping
    } : void 0,
    formulaCalculation: "formulaCalculation" in options ? options.formulaCalculation : void 0
  };
}
async function importSnapshot(input, options, fileName) {
  try {
    let result = await (await loadNativeBinding()).exchangeImportToSnapshot(
      input,
      JSON.stringify(nativeImportOptions(options, fileName))
    );
    return fromNativeSnapshot(result);
  } catch (error) {
    throw exchangeError(
      error,
      "CONVERSION_FAILED"
      /* CONVERSION_FAILED */
    );
  }
}
async function snapshotToMemory(snapshot, type) {
  try {
    switch (type) {
      case UniverType.UNIVER_SHEET:
        return await op(snapshot.snapshot, snapshot.sheetBlocks);
      case UniverType.UNIVER_BASE:
        return await sp(snapshot.snapshot, snapshot.sheetBlocks);
      case UniverType.UNIVER_DOC:
        return cp(snapshot.snapshot);
      case UniverType.UNIVER_SLIDE:
        return dp(snapshot.snapshot);
      default:
        throw new TypeError(`Unsupported Univer unit type: ${type}`);
    }
  } catch (error) {
    throw exchangeError(
      error,
      "CONVERSION_FAILED"
      /* CONVERSION_FAILED */
    );
  }
}
async function memoryToSnapshot(data, options) {
  try {
    let unitId = data.id;
    if (!unitId)
      throw new ExchangeError("INVALID_ARGUMENT", "Export data must have a non-empty id");
    let rev = data.rev ?? 0, collector = createSnapshotCollector();
    switch (options.type) {
      case UniverType.UNIVER_SHEET: {
        let workbook = normalizeWorkbookSheetOrder(data), { snapshot } = await ip(
          { metadata: void 0 },
          workbook,
          unitId,
          rev,
          collector.service
        );
        return { snapshot, sheetBlocks: collector.sheetBlocks };
      }
      case UniverType.UNIVER_BASE: {
        let { snapshot } = await ap(
          { metadata: void 0 },
          data,
          unitId,
          rev,
          collector.service
        );
        return { snapshot, sheetBlocks: collector.sheetBlocks };
      }
      case UniverType.UNIVER_DOC: {
        let { snapshot } = await lp(
          { metadata: void 0 },
          data,
          unitId,
          rev,
          collector.service
        );
        return { snapshot, sheetBlocks: [] };
      }
      case UniverType.UNIVER_SLIDE: {
        let slide = data, { snapshot } = await up(
          slide.resources,
          slide,
          unitId,
          rev,
          collector.service
        );
        return { snapshot, sheetBlocks: [] };
      }
      default:
        throw new TypeError("Unsupported Univer unit type");
    }
  } catch (error) {
    throw exchangeError(
      error,
      "CONVERSION_FAILED"
      /* CONVERSION_FAILED */
    );
  }
}
async function importFile(path, options) {
  let snapshot = await importFileToSnapshot(path, options);
  return snapshotToMemory(snapshot, options.type);
}
async function importFileToSnapshot(path, options) {
  let fileName = options.fileName ?? basename(path), input;
  try {
    input = await readFile(path);
  } catch (error) {
    throw exchangeError(
      error,
      "IO_ERROR"
      /* IO_ERROR */
    );
  }
  return importSnapshot(input, options, fileName);
}
async function exportToFile(data, path, options) {
  await exportSnapshotToFile(await memoryToSnapshot(data, options), path, options);
}
async function exportSnapshotToBuffer(snapshot, options) {
  try {
    return await (await loadNativeBinding()).exchangeExportSnapshot(
      toNativeSnapshot(snapshot),
      JSON.stringify(nativeExportOptions(options))
    );
  } catch (error) {
    throw exchangeError(
      error,
      "CONVERSION_FAILED"
      /* CONVERSION_FAILED */
    );
  }
}
async function exportSnapshotToFile(snapshot, path, options) {
  let output = await exportSnapshotToBuffer(snapshot, options);
  try {
    await writeFile(path, output);
  } catch (error) {
    throw exchangeError(
      error,
      "IO_ERROR"
      /* IO_ERROR */
    );
  }
}

// src/workers/unit-content/entry.ts
var importOfficeFile = importFile;
var exportOfficeFile = exportToFile;
var envelope = await main().then(
  (result) => ({ ok: true, result }),
  (error) => ({
    ok: false,
    error: {
      code: errorCode(error),
      message: error instanceof Error ? error.message : String(error)
    }
  })
);
process.stdout.write(`${JSON.stringify(envelope)}
`);
if (!envelope.ok) process.exitCode = 1;
async function main() {
  const request = parseRequest(JSON.parse(await readStdin()));
  if (request.operation === "import") {
    return await importOfficeFile(
      request.sourcePath,
      importOptions(request.sourcePath, request.unitType, request.docType)
    );
  }
  const collaboration = await loadUnitContentRuntime(request);
  try {
    await pullUnitContent(collaboration);
    switch (request.operation) {
      case "inspect":
        return await inspectUnitContent(collaboration, request.query);
      case "execute": {
        const execution = await executeUnitContent(collaboration, request.code);
        return {
          committed: execution.committed,
          filePath: request.filePath,
          ...execution.revision === void 0 ? {} : { revision: execution.revision },
          unitId: request.unitId,
          value: execution.value,
          worktreeId: request.worktreeId
        };
      }
      case "export": {
        const unitData = await collaboration.exportUnitData();
        await exportUnit(request, unitData);
        return {
          filePath: request.filePath,
          kind: unitContentKind(request.unitType),
          outputPath: request.outputPath,
          scope: request.worktreeId === void 0 ? "trunk" : "worktree",
          type: request.unitType,
          unitId: request.unitId,
          ...request.worktreeId === void 0 ? {} : { worktreeId: request.worktreeId }
        };
      }
      case "render-source":
        return {
          unitType: unitContentKind(request.unitType),
          unitData: await collaboration.exportUnitData()
        };
    }
  } finally {
    await collaboration.close();
  }
}
async function exportUnit(request, unitData) {
  const extension = extname2(request.outputPath).toLowerCase();
  switch (request.unitType) {
    case UniverType.UNIVER_SHEET:
      await exportOfficeFile(unitData, request.outputPath, {
        format: sheetLikeFormat(extension, "Sheet"),
        formulaCalculation: FormulaCalculationMode.FORCED,
        type: UniverType.UNIVER_SHEET
      });
      return;
    case UniverType.UNIVER_BASE:
      await exportOfficeFile(unitData, request.outputPath, {
        format: sheetLikeFormat(extension, "Base"),
        type: UniverType.UNIVER_BASE
      });
      return;
    case UniverType.UNIVER_DOC:
      requireExtension(extension, ".docx", "Doc");
      await exportOfficeFile(unitData, request.outputPath, {
        format: ExchangeFormat.DOCX,
        type: UniverType.UNIVER_DOC
      });
      return;
    case UniverType.UNIVER_SLIDE:
      requireExtension(extension, ".pptx", "Slide");
      await exportOfficeFile(unitData, request.outputPath, {
        format: ExchangeFormat.PPTX,
        type: UniverType.UNIVER_SLIDE
      });
      return;
    default:
      throw unitContentError(
        "EXPORT_UNIT_TYPE_UNSUPPORTED",
        `Unit type ${String(request.unitType)} cannot be exported`
      );
  }
}
function sheetLikeFormat(extension, kind) {
  if (extension === ".xlsx") return ExchangeFormat.XLSX;
  if (extension === ".csv") return ExchangeFormat.CSV;
  if (extension === ".tsv") return ExchangeFormat.TSV;
  throw unitContentError(
    "EXPORT_FORMAT_MISMATCH",
    `${kind} Units must be exported to .xlsx, .csv, or .tsv files`
  );
}
function importOptions(sourcePath, type, docType) {
  return {
    type,
    // Traditional mode keeps the source section geometry; modern mode rewrites
    // page setup to a canned pageless layout and loses it.
    ...type === UniverType.UNIVER_DOC ? {
      compatibilityMode: docType === "modern" ? DocxCompatibilityMode.MODERN : DocxCompatibilityMode.TRADITIONAL
    } : {},
    ...type === UniverType.UNIVER_SHEET && extname2(sourcePath).toLowerCase() === ".xlsx" ? { formulaCalculation: FormulaCalculationMode.FORCED } : {}
  };
}
function requireExtension(actual, expected, kind) {
  if (actual === expected) return;
  throw unitContentError("EXPORT_FORMAT_MISMATCH", `${kind} Units must be exported to ${expected}`);
}
function parseRequest(value) {
  if (!isRecord(value)) {
    throw unitContentError(
      "UNIT_CONTENT_WORKER_REQUEST_INVALID",
      "Unit content worker request must be an object"
    );
  }
  const request = value;
  if (request.operation === "import") {
    const sourcePath = requiredString(request.sourcePath, "sourcePath");
    if (!isAbsolute(sourcePath)) invalidRequest("sourcePath must be absolute");
    const unitType = requiredImportUnitType(request.unitType);
    const docType = optionalImportDocType(request.docType);
    return {
      operation: "import",
      sourcePath,
      unitType,
      ...docType === void 0 ? {} : { docType }
    };
  }
  const base = {
    ...parseUnitContentRuntimeInit(request),
    filePath: requiredString(request.filePath, "filePath")
  };
  if (request.operation === "inspect") {
    return { ...base, operation: "inspect", query: requiredInspectionQuery(request.query) };
  }
  if (request.operation === "execute") {
    return {
      ...base,
      operation: "execute",
      code: requiredString(request.code, "code", true),
      worktreeId: requiredString(request.worktreeId, "worktreeId")
    };
  }
  if (request.operation === "export") {
    const outputPath = requiredString(request.outputPath, "outputPath");
    if (!isAbsolute(outputPath)) invalidRequest("outputPath must be absolute");
    return { ...base, operation: "export", outputPath };
  }
  if (request.operation === "render-source") {
    return { ...base, operation: "render-source" };
  }
  throw unitContentError("UNIT_CONTENT_WORKER_REQUEST_INVALID", "Unknown Unit content worker operation");
}
function requiredImportUnitType(value) {
  if (value !== UniverType.UNIVER_SHEET && value !== UniverType.UNIVER_DOC && value !== UniverType.UNIVER_SLIDE) {
    invalidRequest("import unitType must be Sheet, Doc, or Slide");
  }
  return value;
}
function optionalImportDocType(value) {
  if (value === void 0 || value === null) return void 0;
  if (value === "traditional" || value === "modern") return value;
  invalidRequest("import docType must be traditional or modern");
}
function requiredInspectionQuery(value) {
  if (!isRecord(value)) invalidRequest("query must be an object");
  if (value.kind === "workbook" || value.kind === "presentation" || value.kind === "document" || value.kind === "base" || value.kind === "board") {
    return { kind: value.kind };
  }
  if (value.kind === "board-element") {
    if (!Array.isArray(value.elements) || value.elements.length === 0) {
      invalidRequest("board-element query must contain at least one element");
    }
    const elements = value.elements.map((element, index) => {
      if (!isRecord(element)) invalidRequest(`query.elements[${index}] must be an object`);
      return { id: requiredString(element.id, `query.elements[${index}].id`) };
    });
    return { kind: "board-element", elements: [elements[0], ...elements.slice(1)] };
  }
  if (value.kind !== "worksheet-range" || !Array.isArray(value.ranges) || value.ranges.length !== 1) {
    invalidRequest("worksheet-range query must contain exactly one range");
  }
  const entry = value.ranges[0];
  if (!isRecord(entry) || !isRecord(entry.worksheet)) invalidRequest("worksheet range is invalid");
  const range = requiredString(entry.range, "query.ranges[0].range");
  if (typeof entry.worksheet.name === "string" && entry.worksheet.name.length > 0) {
    return {
      kind: "worksheet-range",
      ranges: [{ range, worksheet: { name: entry.worksheet.name } }]
    };
  }
  if (Number.isSafeInteger(entry.worksheet.index) && Number(entry.worksheet.index) >= 0) {
    return {
      kind: "worksheet-range",
      ranges: [{ range, worksheet: { index: Number(entry.worksheet.index) } }]
    };
  }
  return invalidRequest("worksheet selector must have a non-empty name or non-negative index");
}
async function readStdin() {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
  const value = Buffer.concat(chunks).toString("utf8");
  if (value.trim().length === 0) {
    throw unitContentError("UNIT_CONTENT_WORKER_REQUEST_INVALID", "Unit content worker request is empty");
  }
  return value;
}
function errorCode(error) {
  return typeof error === "object" && error !== null && "code" in error && typeof error.code === "string" ? error.code : "UNIT_CONTENT_WORKER_FAILED";
}
