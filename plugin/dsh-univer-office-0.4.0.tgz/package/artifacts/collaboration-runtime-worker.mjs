import {
  loadUnitContentRuntime,
  parseUnitContentRuntimeInit
} from "./worker-chunks/chunk-PWYAH7S6.mjs";
import "./worker-chunks/chunk-D3GMOPM4.mjs";

// src/workers/collaboration-runtime/entry.ts
var worker = {
  createRuntime: (init) => loadUnitContentRuntime(parseUnitContentRuntimeInit(init))
};
var entry_default = worker;
export {
  entry_default as default
};
