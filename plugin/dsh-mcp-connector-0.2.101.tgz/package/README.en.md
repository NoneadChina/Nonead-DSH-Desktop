# MCP Connector: a Specialist Data Marketplace for DeepSeek Harness

<!-- npm-download-trend:start -->
[![npm download trend](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/metrics/npm-downloads.png)](https://github.com/duhu2000/dsh-mcp-connector/blob/main/docs/metrics/npm-downloads.json)
npm downloads include upgrades, repeat installs and automation; they are not unique users or successful installs. The chart shows its UTC cutoff. [Install](#get-started) · [First successful connection](https://github.com/duhu2000/dsh-mcp-connector/blob/main/docs/tutorials/FIRST-SUCCESS-SCENARIOS.md)
<!-- npm-download-trend:end -->

> MCP Connector for DeepSeek Harness: a data marketplace connecting specialist providers and open data sources. Browse 100+ connectors, manage authorization, search tools and troubleshoot MCP connections.

Connect MCP servers from a continuously updated catalog. Search tools across enabled connections in the current scope, inspect readable parameters, source metadata, and the last successful cache time, then check a connection or rediscover its tools when discovery fails. Supports OAuth 2.0 PKCE, API keys, Streamable HTTP/stdio, and `mcpServers` JSON import.

OAuth availability depends on each provider's client-registration policy and account permissions. Verify a saved connection, discovered/registered tools, and a successful business call as separate outcomes.

> Here, “skill extension” means extending an agent through MCP tools and prompts; this package does not present itself as a standalone DSH Skill.

[简体中文](README.md)

**Bilingual interface:** Compact **中文 / EN** buttons share the top toolbar; full language names remain in tooltips and accessible labels. Your explicit choice is remembered in this browser. Host messages follow the explicit DSH language preference, defaulting to Chinese when unavailable; configure `locale: en` or `locale: zh-CN` to override. Switching reloads only the panel. Provider descriptions and user content retain their original language. See [language configuration](docs/I18N.md).

### Homepage recommendations

The homepage shows ten data-source recommendations in a fixed order: Qichacha company data, Wind stock data, Amap, PatSnap, Qichacha legal data, PKULaw, TuShare, OpenAlex, PubMed, and IMF. All available recommended cards are expanded by default. This is a curated selection, not a usage ranking. Community adapters are not official institutional MCP products. Verify authorization, entitlements and actual calls separately. Office and developer connectors remain accessible through categories and search.

![Homepage recommendations — English UI](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/08-ten-recommendations.jpg)

### Tool discovery and troubleshooting

Search cached tools across enabled connections visible to the current workspace in the Tools tab. Filter by connection, service and latest discovery status, then open parameter details for types, required fields and nested structures. Without a selected workspace, only global connections appear.

Results identify their source and last successful cache time. A cached tool is not a guarantee that the service is currently callable. Expand connection diagnostics to check the connection or rediscover tools. Healthy discovery becomes due after five minutes; while the page remains connected, background scheduling checks due tasks. Failures back off, and authentication failures pause automatic retries.

Tool browsing does not execute target tools. Parameter summaries may omit complex rules; the original-schema view contains the sanitized, size-limited cached schema, not an untouched server response. See the [Chinese tool-workspace guide](docs/USER-GUIDE.md#51-工具工作台统一查找工具).

[Chinese user guide](docs/USER-GUIDE.md) · [Connector onboarding](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md) · [First contribution](docs/FIRST-CONTRIBUTION.md) · [Contributing](CONTRIBUTING.md) · [Issues](https://github.com/duhu2000/dsh-mcp-connector/issues)

[![CI](https://github.com/duhu2000/dsh-mcp-connector/actions/workflows/ci.yml/badge.svg)](https://github.com/duhu2000/dsh-mcp-connector/actions/workflows/ci.yml)
[![npm](https://img.shields.io/npm/v/dsh-mcp-connector.svg)](https://www.npmjs.com/package/dsh-mcp-connector)
[![npm downloads](https://img.shields.io/npm/dm/dsh-mcp-connector.svg)](https://www.npmjs.com/package/dsh-mcp-connector)
[![GitHub stars](https://img.shields.io/github/stars/duhu2000/dsh-mcp-connector?style=flat)](https://github.com/duhu2000/dsh-mcp-connector/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/duhu2000/dsh-mcp-connector?style=flat)](https://github.com/duhu2000/dsh-mcp-connector/forks)
[![GitHub Release](https://img.shields.io/github/v/release/duhu2000/dsh-mcp-connector)](https://github.com/duhu2000/dsh-mcp-connector/releases/latest)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Registry connectors](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2Fduhu2000%2Fdsh-mcp-connector-registry%2Fmain%2Fcatalog-stats.json&query=%24.registryCount&label=Registry%20connectors&color=5865f2)](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/catalog-stats.json)
[![Marketplace cards](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2Fduhu2000%2Fdsh-mcp-connector-registry%2Fmain%2Fcatalog-stats.json&query=%24.marketCount&label=Marketplace%20cards&color=16a34a)](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/catalog-stats.json)

## Get started

Search for **`dsh-mcp-connector`** in your plugin marketplace, or run the command below. Default Desktop and Web installations both use the `web` profile; custom deployments should use the profile actually loaded by their host.

```bash
dsh plugin --profile web add dsh-mcp-connector
```

Fully restart DeepSeek Harness Desktop or `dsh web` after installation or upgrade, then open **MCP Connector** in the primary sidebar, or open it directly from **Settings → Plugins → Plugin Configuration → MCP Connector**.

For Desktop, fully quit and relaunch the application. For Web, stop the existing `dsh web` process and start it again; refreshing the browser does not reload backend plugins.

**Complete one task first:** [look up one company's profile](docs/tutorials/ONE-SUCCESS-CASE.md) (Chinese), checking authorization, tool source, and the actual result. For an independent review, use the [community sharing kit](docs/tutorials/SHARING-KIT.md) (Chinese): demo assets, an article outline, and a redacted evidence template.

For a first successful use, confirm the connection and scope in Installed, find the expected tool and source in Tools, then complete one provider-permitted read-only call through the normal DSH Host approval flow. Cached visibility alone does not prove that a service is currently callable.

First-success guide (Chinese): [install → connect → find a tool → make the first read-only call](docs/tutorials/README.md). Task details: [three acceptance-ready scenarios](docs/tutorials/FIRST-SUCCESS-SCENARIOS.md) · [migrate `mcpServers` JSON](docs/tutorials/JSON-MIGRATION.md) · [diagnose OAuth](docs/tutorials/OAUTH-DIAGNOSTICS.md) · [find and recover tools](docs/tutorials/TOOL-SEARCH-RECOVERY.md) · [trusted status copy](docs/tutorials/TRUSTED-STATUS-COPY.md).

![MCP Connector walkthrough — English UI](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/demo.gif)

If the plugin helps you connect an MCP server faster, consider [starring the repository](https://github.com/duhu2000/dsh-mcp-connector/stargazers), [submitting a connector](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md), or [contributing a fix](CONTRIBUTING.md).

## What MCP Connector provides

| Capability | What it gives you |
|---|---|
| Continuously updated catalog | Browse featured connectors and nine business categories; refresh after a Registry update to fetch new cards |
| Multiple connection paths | Connect with OAuth 2.0 PKCE, API keys, Streamable HTTP/stdio, or `mcpServers` JSON |
| Cross-connection tool search | Search the last-success cache of enabled connections in the current scope, then filter by connection, service, or state |
| Readable parameters and sources | Inspect types, required fields, enums, nested summaries, sources, cache time, and a sanitized schema |
| Connection troubleshooting | Use observed stages and stable error codes to check a connection or rediscover tools while retaining an available last-success cache |
| Scope and governance | Manage project/global visibility plus Connection, Server, and Tool rules |
| Per-session tool injection | Keep a connection online while hiding its schemas by default, then activate exact tools only for the current Agent |
| Safer lifecycle management | Keep credentials local, refresh grants, export redacted backups, restore snapshots, and preserve the previous connection on failure |
| Plugin updates | Detect newer versions and, when the host exposes a compatible Update Provider, show progress, failures, and rollback results |

## Features

- A native `sidebar.panellist` row and keyed main panel on DSH `>=0.2.0-rc.2`, inheriting host selection, collapsed tooltip, and accessibility behavior; DSH `0.1.x` automatically uses the compatibility entry.
- A profile-wide sidebar visibility preference; even when the shortcut is hidden, the existing connector dialog remains available from **Settings → Plugins → Plugin Configuration → MCP Connector**.
- Searchable Marketplace and Installed views; the default Marketplace groups cards into Featured plus nine business-category sections, previews four cards per section, keeps the category bar visible while scrolling, and shows every card when a single category is selected.
- OAuth 2.0 Authorization Code with PKCE, including DCR public clients and `client_secret_post` / `client_secret_basic`; API key/Bearer/unauthenticated HTTP configuration, stdio local-process configuration, and `mcpServers` JSON import.
- Installation from a credential-free connector descriptor URL.
- Credential and MCP initialize validation before HTTP API-key connectors are saved as installed, plus declarative multi-field credential-to-env bindings for marketplace stdio connectors.
- Dynamic tool discovery grouped by MCP server, including descriptions, search, parameter details, batched rendering, and an independent scroll region. When live discovery fails, the UI shows the last successful tool cache with observation-time and stale markers.
- Same-origin SSE updates the UI after connection, catalog, health, tool, governance, or scope changes. Event payloads contain no connection identifiers, endpoints, errors, or credentials.
- Progressive `mcp_connector_tool_search` and `mcp_connector_tool_detail` tools search last-success metadata and reveal a bounded, sanitized input schema on demand without executing the target MCP tool.
- Curated prompt templates that can open a DSH conversation and prefill its draft; missing variables are requested before the prompt is sent.
- Persistent connection lifecycle management: restore on restart, enable/disable, disconnect, retry transient OAuth refresh failures with bounded backoff, and revoke authorization. Cards declaring issuer-level sharing reuse one grant; a cross-process lock and per-grant atomic journal prevent Desktop and Web hosts from consuming or overwriting the same rotating refresh token.
- In-place configuration editing for custom and JSON-imported connections: edit normalized JSON from Installed and reconnect without deleting the connection. Existing sensitive values use local keep markers, and validation, startup, or persistence failures leave the previous connection usable.
- Portable redacted configuration export plus up to 20 local pre-change snapshots, with preview and atomic restore. Credentials, local paths, and OAuth grants never enter the export.
- Project/global connection scopes: choose the current DSH Workspace or profile-global visibility when connecting, preview affected servers/tools, then copy, move, or roll back by revision. Credentials remain single-copy and project-only tools are enforced by the DSH Host.
- Three-layer Connection, Server, and Tool governance with Tool > Server > Connection > default-allow precedence, preview, revision-checked commits, and rollback. DSH Host restrictions narrow schemas/lookups/dispatch while a final execution guard prevents UI-only enforcement.
- Per-session tool injection: choose **Always inject** or **Enable per session** for an installed connection. Session mode keeps the server online but hides its business-tool schemas until exact public tool names are previewed and explicitly confirmed for the current Agent, for at most 30 minutes. Session state is memory-only and cannot override scope, governance, or Host approval.
- Explainable diagnostics report only observed evidence. Unchecked or Host-unobservable connections remain `unknown`, with a failure stage, stable code, suggested action, check time, and process-local last-success time.
- Built-in, remote, and local catalogs with `published` and `featured` controls.
- A standalone remote Registry, allowing new marketplace cards to appear after refresh without publishing a new npm version.
- Plugin version and one-click updates: version discovery is independent of the installation source, while an Update Provider adapter layer negotiates safe mutation capabilities. DSH Market API v1 is the first adapter and supports progress, normalized failures, rollback, and capability-gated restart/refresh actions. Without a compatible provider the UI offers update instructions; if Desktop has no plugin-market section, it opens the npm package page instead of leaving the user on generic Settings.
- The two legacy Qichacha OAuth plugins support explicit authorization migration. For an affected connection, select **Connection error** in the marketplace or **View recovery steps** under Installed to see which DSH plugin or remaining service entry to disable. After a full DSH restart, MCP Connector takes over the authorization, or prompts for authorization again if it has expired.

<!-- catalog-stats:start -->
As of 2026-10-24, the public Registry publishes 112 connector descriptors. After merging and deduplicating them with the 4 bundled Qichacha cards, the Marketplace exposes 116 cards across 9 business categories. Recommendations remain limited to the four Qichacha cards, PKULaw, and Wind, for 6 featured cards in total. The Registry evolves independently; the badge shown after a client refresh and the live badges above are the authoritative current counts.
<!-- catalog-stats:end -->

## Interface and demo

| Marketplace overview | Connector details and curated prompts |
|---|---|
| ![Marketplace overview](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/01-market-overview.jpg) | ![Connector details](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/02-connector-detail.jpg) |
| Tool discovery, descriptions, and scrolling | JSON import |
| ![Tool discovery](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/03-tool-discovery.jpg) | ![JSON import](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/04-json-import.jpg) |
| Unified tool search and sources | Parameter details and safe schema |
| ![Unified tool search](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/05-unified-tool-search.png) | ![Tool parameter details](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/06-tool-parameters.png) |
| Connection diagnostics and last-success cache |  |
| ![Connection diagnostics](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/07-connection-diagnostics.png) |  |

<!-- generated:media -->English UI screenshots and GIF were captured from v0.2.101 (2026-11-11), using the credential-free Mock harness. Provider content retains its original language. They demonstrate UI, not real business acceptance; counts are fixtures. See [asset provenance](docs/screenshots/README.md).<!-- /generated:media -->

## Installation

Requirements: DeepSeek Harness Desktop or web profile, and Node.js 20 or later.

```bash
dsh plugin --profile web add dsh-mcp-connector
```

Or use the installer:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/install.sh)
```

Run the same command again to upgrade. Fully quit and restart DeepSeek Harness Desktop after installation or upgrade. For `dsh web`, stop the original process before starting it again; `EADDRINUSE 127.0.0.1:3080` means another instance is already listening.

## Usage

1. Select **MCP Connector** in the primary sidebar, or choose **Open MCP Connector** from **Settings → Plugins → Plugin Configuration → MCP Connector**.
2. Choose a connector, confirm **Current project** or **All projects (global)**, and complete authorization or configuration.
3. Open its details to inspect tools or send an example prompt to a new conversation draft.
4. Use Installed or the conversation tools to enable, disable, inspect, or disconnect a connection.
5. After connecting, open **Tools** to search by tool name or description and filter by connection or service. Provider authorization, fees, and actual execution remain under the provider and DSH Host.

Connected tools are exposed to the model with the `mcp__<serverName>__*` prefix.

The detailed [Chinese user guide](docs/USER-GUIDE.md) covers category browsing, authentication and connection states, HTTP/stdio configuration, JSON import, explainable diagnostics, compatibility, responsibility boundaries, and troubleshooting.

## Guides and ecosystem

- [User guide: installation, authorization, diagnostics, compatibility, and troubleshooting](docs/USER-GUIDE.md)
- [First-success guide: install, connect, find a tool, and make a read-only call (Chinese)](docs/tutorials/README.md)
- [Task guides: JSON migration, OAuth diagnostics, and cross-connection tool recovery](docs/USER-GUIDE.md#按任务开始)
- [Connection scopes: project/global inheritance, copy, move, and rollback](docs/CONNECTION-SCOPES.md)
- [Connection, Server, and Tool governance](docs/TOOL-GOVERNANCE.md)
- [Per-session tool activation, TTL, and Host safety boundary](docs/SESSION-TOOL-INJECTION.md)
- [Tool trial: official API evidence and safety design](docs/TOOL-TRIAL-DESIGN.md)
- [Plugin updates: version discovery, providers, and rollback](docs/PLUGIN-UPDATE.md)
- [Localization: `locale`, dictionary conventions, and the translation completeness gate](docs/I18N.md)
- [Marketplace registration: local cards, the public Registry, and OAuth requirements](docs/MARKET-REGISTRATION.md)
- [Third-party connector onboarding](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md)
- [First contribution: from a good first issue to your first PR](docs/FIRST-CONTRIBUTION.md)
- [Development, forks, and contributions](CONTRIBUTING.md)
- [Growth baseline and monthly review template](docs/GROWTH-BASELINE.md)

## Connector catalog

The package contains a bundled fallback catalog. By default, it refreshes the public [dsh-mcp-connector-registry](https://github.com/duhu2000/dsh-mcp-connector-registry) through jsDelivr, then tries GitHub raw if the primary source fails; cached or bundled data remains available if neither remote source can be reached. jsDelivr branch URLs can lag behind a newly merged registry commit, so new cards may not appear immediately.

The public connector registration process and descriptor requirements are documented in [docs/MARKET-REGISTRATION.md](docs/MARKET-REGISTRATION.md).
The stdio architecture, passthrough boundary, and security constraints are documented in [docs/STDIO-SUPPORT.md](docs/STDIO-SUPPORT.md).

## Configuration

The default bundle configuration is in `cordis.patch.yml`:

```yaml
- id: mcp-connector
  name: dsh-mcp-connector
  config:
    catalogUrl: 'https://cdn.jsdelivr.net/gh/duhu2000/dsh-mcp-connector-registry@main/catalog.json'
    persistSecrets: true
    entryPrefix: mcp
    refreshSkewMs: 300000
    openBrowser: true
    showSidebarEntry: true
    compactManagementTools: false
    locale: 'auto'
    frameAncestors: ['self']
```

Set `catalogUrl` to an empty string for an explicitly offline/private setup. A custom non-default URL is used as-is and does not fall back to the public registry.

Remote catalog requests (including the fallback source) honor `HTTP_PROXY`, `HTTPS_PROXY`, and `NO_PROXY`, as well as their lowercase forms. A lowercase variable takes precedence when both forms are present; HTTPS uses `HTTP_PROXY` when `HTTPS_PROXY` is absent. Use an HTTP(S) proxy URL and configure `NO_PROXY` for destinations that should connect directly (for example, `localhost,127.0.0.1`). This works on Node.js 20+ without `--use-env-proxy` and does not change the Host's global fetch dispatcher or MCP transport settings.

The proxy variables must be present in the running DSH process. After changing them, fully exit and restart DSH Desktop or launch `dsh web` from a shell with those variables set; changing Windows user environment variables does not update an already-running process. The connector does not read OS proxy settings or infer a local proxy address.

`showSidebarEntry` defaults to `true`. Users can override it from the DSH plugin configuration page; turning it off hides only the shortcut and does not disable the connector, connected MCP servers, or tools.

`compactManagementTools` defaults to `false` for backward compatibility. Set it to `true` in the plugin configuration and reload the plugin (or restart DSH) to expose only two management tools at the next inference boundary:

- `mcp_connector_discover`: fixed read-only actions `catalog`, `status`, `search` (requires `query`), and `detail` (requires `toolName`). Example: `{"action":"search","query":"weather","limit":5}`.
- `mcp_connector_session_tools`: unchanged session activation, confirmation and TTL behavior.

Use the connector UI for connection setup, authorization, import, editing, snapshots and migration. There is no arbitrary execution proxy or automatic management-tool loading. Keep this option `false` for conversation-only deployments or workflows that depend on legacy tool names. Set it back to `false` and reload to restore those names; do not run duplicate plugin instances.

This setting does not hide downstream business tools, disable connections, migrate credentials, change workspace/governance rules or bypass Host approval. Use the existing session injection mode for downstream tool visibility. Reduced tool count/schema size is not a measured token or cost saving.

`locale` selects the language of the panel and of the text returned by the conversation tools. It defaults to `'auto'`, which follows the language you picked in DSH under Settings → Language (the `preference` of `@deepseek-ai/dsh-client-locale`), then `LC_ALL` / `LC_MESSAGES` / `LANG`, and falls back to Chinese when nothing matches. The interface language is the user's own preference, so the plugin does not override it: a Chinese user who changes nothing still gets Chinese (the DSH default), and a user who selected English in DSH gets English. Set it to `'zh-CN'` or `'en'` to force one language. Reload the plugin after changing it.

Connector names, vendors, categories, URLs and error codes are never translated, so the same catalog renders in both languages. See [docs/I18N.md](docs/I18N.md).

`frameAncestors` defaults to `['self']`: the CSP of the panel page (`/mcp-connector/ui/`) only allows same-origin embedding, which is the existing behaviour and is not relaxed by default. When a desktop shell (Tauri/Electron) embeds the panel, the ancestor origin differs from the panel origin, so the browser blocks it with `Framing '...' violates the following Content Security Policy directive: "frame-ancestors 'self'"` and the panel renders blank. Deployers must opt in explicitly:

```yaml
frameAncestors: ['self', 'http://tauri.localhost', 'tauri://localhost']
```

This is a deliberate security trade-off, not an oversight: `frame-ancestors` cannot verify who owns the embedding origin, so the plugin never hardcodes a shell origin such as Tauri — listing one lets any page served from that origin frame the local panel. Accepted values are CSP keywords (`self` / `none` / `*`) and host-sources (`https://*.example.com`, `127.0.0.1:3080`, `tauri://localhost`, `http://tauri.localhost:1420`, optionally with scheme, port, and path). Values containing `;`, commas, spaces, or non-host-source keywords such as `'unsafe-inline'` are dropped entirely to prevent CSP header injection; if nothing valid remains the list falls back to `['self']` rather than allowing every origin. Only add origins you trust.

## Compatibility and responsibility boundary

| Area | Current boundary |
|---|---|
| Host and runtime | DSH Desktop / `web` profile; Node.js 20+ |
| MCP client | Official `@deepseek-ai/dsh-mcp-client` `^0.1.1-rc.2` |
| Transports | Streamable HTTP and stdio; legacy `sse` normalizes to Streamable HTTP |
| Configuration scope | Workspace project / profile global, with Host enforcement, impact preview, copy/move, and revision rollback |
| Configuration exchange | JSON import, redacted export, up to 20 local snapshots, preview, and atomic restore |
| Governance and execution | Connection / Server / Tool allow/deny with preview, revision commits, and rollback; no tool trial yet |
| Session injection | Existing connections default to always; an explicit session mode uses per-Agent Host restriction + guard with a memory-only TTL of at most 30 minutes |

The plugin owns the catalog, authorization, connection records, governance rules, official-client provisioning, read-only health checks, tool discovery, and diagnostics. DSH Host and the official MCP client own transport, stdio subprocesses, tool registration, real tool execution, and permission/approval flows. Governance uses the Host's official restriction/guard boundary; the plugin never invokes MCP tools from the browser. See the [user guide](docs/USER-GUIDE.md#75-如何理解连接诊断) for status semantics, limitations, and troubleshooting.

## Development and release checks

```bash
npm run check
npm run marketing:check:live
npm run registry:build
npm run registry:validate
npm run market:check
npm run dev:ui
```

`marketing/metadata.json` is the source of truth for the npm description/keywords, GitHub About/Topics, bilingual first-screen CTAs, and external listing copy. `npm run check` blocks repository drift offline; `npm run marketing:check:live` also compares the public GitHub and npm metadata for metadata changes and monthly reviews. `npm run market:check` tracks the external DSH marketplace PR and live directory. Tags matching `v*` trigger GitHub Actions; the tag must match `package.json`. npm releases use Trusted Publishing through GitHub OIDC and do not require a long-lived `NPM_TOKEN`.

Every Registry merge regenerates `catalog-stats.json`; an hourly workflow in this repository synchronizes the Chinese and English product copy plus a local stats snapshot. The static npm README updates with package releases, while the live badges above read the Registry directly and therefore stay current without another npm release.

<!-- generated:version -->The current public version is [`dsh-mcp-connector@0.2.101`](https://www.npmjs.com/package/dsh-mcp-connector), with [GitHub Release v0.2.101](https://github.com/duhu2000/dsh-mcp-connector/releases/tag/v0.2.101).<!-- /generated:version -->

See [CHANGELOG.md](CHANGELOG.md) for version history and [docs/DESKTOP-E2E.md](docs/DESKTOP-E2E.md) for the Desktop release checklist.

## Security and limitations

- Credentials stay inside the local DSH storage boundary: connection records use the storage domain, while rotating OAuth credentials are also saved in `$DSH_HOME/storages/mcp_connector_grants_v1` so stale host snapshots cannot overwrite them. The directory is mode 0700 and records are mode 0600; credentials are never written to the catalog, Git repository, page, logs, or conversation history.
- Failed API key/token validation is not persisted; authentication, timeout, DNS, and TLS/network errors are reported separately.
- Unchecked or Host-unobservable connections are reported as `unknown`, never as healthy. Health history and last-success timestamps are currently process-local.
- External URLs use HTTPS by default, and HTTP is allowed for loopback development. A user-created connection may explicitly opt in to plaintext HTTP for literal RFC1918 IPv4 or RFC4193 IPv6 ULA addresses; hostnames, public HTTP, link-local addresses, and cloud metadata addresses remain blocked.
- Remote descriptors and catalogs are limited to 2 MiB, Web API requests to 1 MiB, and imported JSON is scanned for credential fields before normalization.
- Streamable HTTP and stdio are supported end to end. Legacy `sse` entries are normalized to Streamable HTTP. Restored stdio connections run their original command through a transparent startup guard; persisted records, environment and working directory remain unchanged. Tool registration and execution still belong to `@deepseek-ai/dsh-mcp-client`.
- On restoration, `server/discover`, `initialize` and initial `tools/list` requests (including pagination) use `requestTimeoutMs`, capped at 15 seconds per request. A timeout closes that connection and its child processes rather than blocking Host startup. Connections stay enabled; requests after initial discovery keep the Host deadline.
- Official CLIs that are not MCP servers can be exposed through a separate [controlled CLI Provider](docs/CLI-PROVIDERS.md). Only code-reviewed commands and arguments are available; the initial DingTalk `dws` provider is read-only.
- stdio starts a local process. Import or connect only trusted commands and packages. Catalog descriptors may declare `credentialFields` and `credentialBindings`, but may never contain actual token/secret values; user input is injected only into the local Host process environment.
- OAuth DCR client secrets share the same local-only boundary as access and refresh tokens and are omitted from catalog/status responses and logs.
- OAuth failures identify resource discovery, server discovery, client registration, browser callback, or token exchange. A DCR HTTP 403 is reported as provider-side client admission rejection rather than a missing user authorization.
- Redacted exports replace tokens, API keys, static header/env values, stdio arguments, local directories, and URLs containing query/user information with explicit placeholders. OAuth entries contain only a reconnect reference; full snapshots remain inside the current profile's storage domain.
- The primary sidebar placement uses the stable DSH `data-slot` marker and falls back to the footer if that marker is removed.
- Project/global scopes apply only inside the current DSH profile and do not synchronize across profiles. If a Workspace is deleted, its project-only bindings remain fail-closed until moved to another project or global.
- Tool trials are not implemented. Governance and scopes are enforced in the DSH Host execution path. The tool-trial design records the official API evidence, but remains blocked until DSH exposes safe out-of-turn approval orchestration and the MCP bridge preserves side-effect metadata. A local snapshot cannot recreate a server-side OAuth grant after revocation.

## License

MIT
