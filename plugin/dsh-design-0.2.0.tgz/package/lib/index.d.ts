/**
 * dsh-design — design taste an agent can be held to. Ships a design-system
 * skill that constrains the choices generated UI is built from, and a
 * `design_audit` tool that renders the page and measures whether those
 * constraints actually survived: type scale, WCAG contrast, spacing grid,
 * palette size, tap targets, line length, and the specific tells of a
 * generated-looking page. Named exports preserve loader injection metadata.
 * @module dsh-design
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "design";
export declare const inject: string[];
/** Deployment configuration; every tunable is a cordis.yml field. */
export interface Config {
    /** Run the browser without a visible window. */
    headless: boolean;
    /** Browser channels tried in order until one launches. */
    browserChannels: string[];
    /** Viewport width used for measurement. */
    viewportWidth: number;
    /** Viewport height used for measurement. */
    viewportHeight: number;
    /** Navigation timeout, in milliseconds. */
    navigationTimeoutMs: number;
    /** Spacing values must be multiples of this many px. */
    spacingBasePx: number;
    /** More distinct text sizes than this fails the type-scale rule. */
    maxTypeSizes: number;
    /** More distinct non-neutral colors than this fails the palette rule. */
    maxPaletteColors: number;
    /** HSL saturation below which a color counts as neutral. */
    neutralSaturation: number;
    /**
     * Interactive elements smaller than this in either axis are flagged. The
     * default is WCAG 2.2 AA (24px); raise it to 44 for a touch-first product.
     */
    minTapTargetPx: number;
    /** Running text wider than this many characters per line is flagged. */
    maxCharsPerLine: number;
    /** Extra hostnames the audit may load; local hosts are always allowed. */
    allowedHosts: string[];
    /** Register the bundled `design-system` skill when the skill seam is composed. */
    registerSkill: boolean;
}
/** Schemastery schema for {@link Config}. */
export declare const Config: z<Config>;
/**
 * Whether the policy admits this host.
 * @param hostname - the URL's hostname.
 * @param allowedHosts - extra hostnames permitted beyond local hosts.
 * @returns true when the audit may load it.
 */
export declare function hostAllowed(hostname: string, allowedHosts: readonly string[]): boolean;
/**
 * Resolve a model-supplied target to a loadable URL.
 *
 * A remote URL passes the host policy. A local path is canonicalized and must
 * stay inside the workspace and be an HTML file: the renderer executes what it
 * loads, so an unconstrained path would both run arbitrary local scripts and
 * report whether a given file exists.
 * @param target - http(s) URL, or a path to an HTML file in the workspace.
 * @param allowedHosts - extra hostnames permitted beyond local hosts.
 * @returns the URL to load.
 */
export declare function resolveTarget(target: string, allowedHosts: readonly string[]): Promise<string>;
/**
 * Register the `design_audit` tool and (optionally) the bundled skill.
 * @param ctx - registrant context carrying the tool registry.
 * @param config - deployment configuration.
 */
export declare function apply(ctx: Context, config: Config): void;
