/**
 * The audit rules. Each one turns measurements taken from a rendered page into
 * violations that name an element and a number, so a report says "seven type
 * sizes, here they are" rather than "the hierarchy feels off".
 *
 * Every rule here is a pure function of the collected snapshot: the browser
 * measures, this decides.
 * @module dsh-design/audit
 */
import { type Rgba } from './color.js';
/** One element as measured in the page. */
export interface ElementSample {
    /** A short human-locatable description, e.g. `button.primary`. */
    selector: string;
    /** Trimmed text content, when the element renders text directly. */
    text?: string;
    /** Computed font size in px. */
    fontSizePx: number;
    /** Computed numeric font weight. */
    fontWeight: number;
    /** Computed font-family list, verbatim. */
    fontFamily: string;
    /** Computed text color, verbatim. */
    color: string;
    /** Effective background behind the element, resolved by walking ancestors. */
    backgroundColor: string;
    /** Computed background-image, verbatim (`none` when absent). */
    backgroundImage: string;
    /** Border-box width in px. */
    widthPx: number;
    /** Border-box height in px. */
    heightPx: number;
    /** Non-zero spacing values in px: paddings, margins, gaps. */
    spacingPx: number[];
    /** Whether the element is a control a person is expected to hit. */
    interactive: boolean;
    /** Rendered characters per line, for running text only. */
    charsPerLine?: number;
}
/** What the page as a whole looked like. */
export interface PageSample {
    /** Page URL. */
    url: string;
    /** Document title. */
    title: string;
    /** Viewport width the measurements were taken at. */
    viewportWidthPx: number;
    /** Every visible element the collector sampled. */
    elements: ElementSample[];
}
/** How strict the audit is. */
export interface AuditOptions {
    /** Spacing values must be multiples of this many px. */
    spacingBasePx: number;
    /** More distinct text sizes than this means the hierarchy is unplanned. */
    maxTypeSizes: number;
    /** More distinct non-neutral colors than this means palette drift. */
    maxPaletteColors: number;
    /** HSL saturation below which a color counts as neutral. */
    neutralSaturation: number;
    /**
     * Interactive elements smaller than this in either axis are flagged.
     * The default is WCAG 2.2 AA (2.5.8 Target Size Minimum, 24px); raise it to
     * 44 for a touch-first product, which is the AAA / platform touch guidance.
     */
    minTapTargetPx: number;
    /** Running text wider than this many characters per line is tiring to read. */
    maxCharsPerLine: number;
}
/** Sensible defaults; every one is a deployment config field. */
export declare const DEFAULT_OPTIONS: AuditOptions;
/** How much a violation matters. */
export type Severity = 'high' | 'medium' | 'low';
/** One thing the page got wrong. */
export interface Violation {
    /** Stable rule id, e.g. `contrast`. */
    rule: string;
    /** How much it matters. */
    severity: Severity;
    /** What is wrong, including the measured value. */
    message: string;
    /** Elements it applies to, at most a handful. */
    elements: string[];
}
/** The finished audit. */
export interface AuditResult {
    /** Violations, most severe first. */
    violations: Violation[];
    /** Measurements worth reporting even when nothing is wrong. */
    summary: {
        elementsSampled: number;
        typeSizes: number[];
        paletteColors: string[];
        contrastFailures: number;
        offGridSpacings: number[];
    };
}
/**
 * Run every rule over a page sample.
 * @param page - the measurements taken from the rendered page.
 * @param options - strictness settings.
 * @returns violations plus the measurements behind them.
 */
export declare function auditPage(page: PageSample, options: AuditOptions): AuditResult;
/**
 * Render an audit as the text the model reads.
 * @param result - the finished audit.
 * @returns the model-facing report.
 */
export declare function renderAudit(result: AuditResult): string;
/**
 * Colors are compared as opaque values; exported for the collector's tests.
 * @param color - any parsed color.
 * @returns the same color at full alpha.
 */
export declare function opaque(color: Rgba): Rgba;
