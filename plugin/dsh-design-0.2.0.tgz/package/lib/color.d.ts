/**
 * Color math for the audit: parse what `getComputedStyle` returns, composite
 * translucent layers, and compute WCAG contrast. Kept pure so the rules that
 * decide whether text is readable are testable without a browser.
 * @module dsh-design/color
 */
/** A parsed color with straight (non-premultiplied) alpha. */
export interface Rgba {
    r: number;
    g: number;
    b: number;
    /** 0-1. */
    a: number;
}
/**
 * Parse a computed-style color string.
 * @param value - `rgb()`, `rgba()`, `#rgb`, `#rrggbb(aa)`, or `transparent`.
 * @returns the parsed color, or undefined when the syntax is not recognized
 *   (a modern color function this audit does not model, for instance).
 */
export declare function parseColor(value: string): Rgba | undefined;
/**
 * Composite a translucent color over an opaque one.
 * @param over - the upper layer.
 * @param under - the lower layer, treated as opaque.
 * @returns the resulting opaque color.
 */
export declare function composite(over: Rgba, under: Rgba): Rgba;
/**
 * WCAG relative luminance.
 * @param color - an opaque color.
 * @returns luminance in 0-1.
 */
export declare function luminance(color: Rgba): number;
/**
 * WCAG contrast ratio between two opaque colors.
 * @param a - one color.
 * @param b - the other.
 * @returns the ratio, from 1 (identical) to 21 (black on white).
 */
export declare function contrastRatio(a: Rgba, b: Rgba): number;
/**
 * The contrast WCAG AA requires for this text.
 *
 * Large text is 18pt (24px) or 14pt (18.66px) bold and above, and is allowed
 * 3:1 because size compensates for lower contrast.
 * @param fontSizePx - computed font size in px.
 * @param fontWeight - computed numeric weight.
 * @returns the required ratio.
 */
export declare function requiredContrast(fontSizePx: number, fontWeight: number): number;
/**
 * Whether a color reads as a neutral (grey, black, white) rather than part of
 * the palette. Neutrals are excluded from palette-size accounting because a
 * grey scale is structure, not a color choice.
 * @param color - the color to classify.
 * @param saturationThreshold - HSL saturation below which a color is neutral.
 * @returns true for neutrals.
 */
export declare function isNeutral(color: Rgba, saturationThreshold: number): boolean;
/**
 * The hue angle of a color, for detecting a specific hue family.
 * @param color - the color to measure.
 * @returns hue in degrees, 0-360.
 */
export declare function hue(color: Rgba): number;
/**
 * Format a color for a report.
 * @param color - the color to render.
 * @returns a short `rgb()`/`rgba()` string.
 */
export declare function formatColor(color: Rgba): string;
