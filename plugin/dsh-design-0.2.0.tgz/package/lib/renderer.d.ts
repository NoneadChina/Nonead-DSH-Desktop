/**
 * Minimal headless renderer: launch once, open a page per measurement, run the
 * collector, close the page. Smaller than a general browser plugin's engine
 * because an audit needs exactly one round trip and keeps no page state.
 * @module dsh-design/renderer
 */
/** Launch settings fixed per renderer by plugin config. */
export interface RendererOptions {
    /** Preferred browser channels in order; each is tried until one launches. */
    channels: string[];
    /** Run without a visible window. */
    headless: boolean;
    /** Default viewport width in px. */
    viewportWidth: number;
    /** Default viewport height in px. */
    viewportHeight: number;
}
/** What one measurement produced. */
export interface MeasureResult {
    /** The URL that actually answered, after any redirects. */
    finalUrl: string;
    /** Whatever the collector script returned. */
    value: unknown;
}
/** One measurement request. */
export interface MeasureRequest {
    /** Absolute URL to load (http(s) or file). */
    url: string;
    /** Script evaluated in the page; its return value is the measurement. */
    script: string;
    /** Navigation timeout in milliseconds. */
    timeoutMs: number;
    /** Override the configured viewport width for this measurement. */
    viewportWidth?: number;
    /** Cooperative cancellation from the tool execution. */
    signal: AbortSignal;
}
/**
 * Owns the browser process. Disposal is registered as a Cordis effect by the
 * plugin, so unload never leaks a browser.
 */
export declare class Renderer {
    private options;
    private browser;
    private launching;
    private disposed;
    constructor(options: RendererOptions);
    /**
     * Load a page, run the collector, and return its value.
     * @param request - what to load and evaluate.
     * @returns whatever the script returned.
     */
    measure(request: MeasureRequest): Promise<MeasureResult>;
    /**
     * Load and measure one page under an installed cancellation scope.
     * @param request - what to load and evaluate.
     * @param scope - cancellation scope registering the context to close.
     * @returns the final URL and the collector's value.
     */
    private load;
    /**
     * Throw when the caller cancelled during one of the awaits above.
     * @param signal - the tool execution's cancellation signal.
     */
    private throwIfCancelled;
    /** Close the browser. Safe to call twice and safe to race a launch. */
    dispose(): Promise<void>;
    private ensureBrowser;
    private launch;
}
