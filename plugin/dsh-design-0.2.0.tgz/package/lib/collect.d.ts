/**
 * The measurement pass. `COLLECT_SCRIPT` runs inside the page and returns a
 * {@link PageSample}; it is a string rather than a function so it can be
 * evaluated verbatim in the browser realm without a bundler step, and so the
 * audit rules stay in Node where they are testable.
 * @module dsh-design/collect
 */
/**
 * Sentinel returned as an element's background when the real backdrop cannot
 * be modelled — a gradient, an image, or a color syntax this audit does not
 * parse. Node treats it as unparseable and skips the element rather than
 * inventing a ratio, because guessing white behind a dark hero reports a
 * contrast failure that does not exist.
 */
export declare const UNKNOWN_BACKDROP = "dsh-design-unknown";
/**
 * Script evaluated in the page. Returns a JSON-serializable PageSample.
 *
 * Editing rules: it must not import anything, must not throw on exotic
 * documents, and must never report a backdrop it did not actually find. An
 * element whose backdrop is a gradient or an unparsed color reports
 * {@link UNKNOWN_BACKDROP}; only a genuinely transparent layer is walked past.
 */
export declare const COLLECT_SCRIPT: string;
