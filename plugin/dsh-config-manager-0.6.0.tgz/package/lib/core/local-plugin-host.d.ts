import { parsePackOutput } from './local-plugin-pack.ts';
import type { PackExec, PackLocalPluginsResult } from './local-plugin-pack.ts';
import type { HostContext } from './types.ts';
/**
 * 本地源插件打包钩子签名。
 *
 * 刻意在 core 内**重新声明**该签名（而非从 adapters 反向 import）：架构边界测试
 * （tests/architecture-boundaries.test.ts F7）规定 core 层只允许依赖
 * node 内置 / core 内部 / schema / utils / security —— core → adapters 是违规方向。
 * adapters 侧的 `LocalPluginPackHook` 与这是**结构等价**的，故可直接互赋（TS 结构化类型）。
 * 注意：这里 host ctx 参数只需 HostContext，无需 adapters 的任何类型。
 */
export type LocalPluginPackHook = (plugins: readonly {
    name: string;
    version: string;
    spec?: string;
}[], ctx: Pick<HostContext, 'profile' | 'profileDir'>) => Promise<PackLocalPluginsResult>;
export interface LocalPluginPackHookOptions {
    /** $DSH_HOME 绝对路径 */
    homeDir: string;
    /** 插件数据目录（临时打包目录建在其下，保证与既有目录生命周期一致） */
    dataDir: string;
    /** 覆盖 exec（测试注入） */
    exec?: PackExec;
    /**
     * 超限负缓存 TTL（缺省 OVERSIZE_NEGATIVE_TTL_MS；**0 = 关闭缓存**，测试用）。
     * 命中条件 = 源指纹未变 且 距上次实测超限不足 TTL。
     */
    oversizeTtlMs?: number;
    /** 源指纹（测试注入；缺省见 defaultSourceFingerprint） */
    sourceFingerprint?: (absPath: string) => Promise<string | null>;
    /** tarball 体积上限（缺省 MAX_LOCAL_TARBALL_BYTES；测试用小值验证超限负缓存） */
    maxTarballBytes?: number;
}
export declare function createLocalPluginPackHook(opts: LocalPluginPackHookOptions): LocalPluginPackHook;
/** 供其他模块复用（避免重复实现 npm 输出解析） */
export { parsePackOutput };
