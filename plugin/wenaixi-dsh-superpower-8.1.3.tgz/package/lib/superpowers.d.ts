/**
 * @wenaixi/dsh-superpower — DSH 移植版 Superpowers
 *
 * 将 obra/superpowers 的 15 个 skill 以 DSH 原生 SkillProvider 形式暴露，
 * 通过 ctx.skills.registerProvider 注入全局层，rank 10 使本插件技能优先级最高：
 * 小于 dsh-skill-filesystem 的项目/用户根（100–500）与官方 bundled（600）。
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { SkillCatalog } from './catalog.js';
import { SkillDocument } from './document.js';
export { SkillCatalog, EXPECTED_SKILL_COUNT, type SpecificationReport } from './catalog.js';
export { SkillDocument, type SpecificationTestResult } from './document.js';
export { SkillSwitches, applySwitches, extractCleanDisabled, extractCleanLanguage, extractCleanSwitches, isConfigCorrupted, readSwitches, type CleanSwitchesExtraction, } from './switches.js';
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * volatile 配置值已在不重挂载的情况下提交给运行中的 fiber；派发给所属 fiber。
         * @param paths - 变更的配置路径数组
         * @mode emit
         */
        'loader/volatile-update'(paths: readonly (readonly string[])[]): void;
        /**
         * 宿主配置重载通知（在 profile 补丁应用后广播），宿主界面语言变更经此收敛。
         * @mode emit
         */
        'app-boot/config-reload'(): void;
    }
}
export declare const Config: Schema<Config>;
export interface Config {
    providerName: string;
    skillDir?: string;
    /** 技能描述显示语言偏好：'zh'/'en' 显式固定；缺失（undefined）时跟随宿主界面语言。 */
    language: Volatile<'zh' | 'en' | undefined>;
    /** 唯一的开关写入目标：键为技能名，值为 true 时模型与用户两侧同时关闭 */
    disabled: Volatile<Record<string, boolean>>;
}
export declare const name = "superpowers";
export declare const inject: readonly ["skills"];
/**
 * 从宿主 settings 服务读出界面语言偏好。
 *
 * settings 服务不在本插件 inject 列表：headless/CLI 组合里它永不存在，
 * 若写进 inject 会让插件永远 PENDING、连技能都不再提供。改用 ctx.get()
 * 的可选读取（cordis 的 get 对缺失服务返回 undefined，不抛错）。
 *
 * 返回 undefined 的三种情形都与「有服务但崩了」不同，因此不在这里吞日志：
 * 服务缺失、preference 未设置、preference 值非法。
 */
export declare function hostLanguageFrom(ctx: {
    get?: (name: string) => unknown;
}): 'zh' | 'en' | undefined;
export declare function apply(ctx: Context, config: Config): void;
declare const _default: {
    name: string;
    inject: readonly ["skills"];
    Config: Schema<Config>;
    apply: typeof apply;
    SkillDocument: typeof SkillDocument;
    SkillCatalog: typeof SkillCatalog;
};
export default _default;
//# sourceMappingURL=superpowers.d.ts.map