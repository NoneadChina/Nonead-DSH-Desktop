/**
 * Export 编排（规范 §1/§18/§21，设计 §4.4）：
 *   adapter 收集各分区 → Secret 过滤 → manifest → checksum → ZIP。
 *
 * 安全不变量：
 *  - Secret 值默认永不进入导出数据（结构化分区逐一过 SecretScanner）；
 *  - includeSecrets=true 必须注入 EncryptionProvider（m4 实现），否则拒绝导出；
 *  - 注入 EncryptionProvider 时备份标记为加密（encrypted=true）：includeSecrets=false
 *    时 secrets.enc 加密空内容占位，备份仍需要密码导入，但不含任何凭据值；
 *  - 加密密码/秘密值绝不写入 manifest 与日志。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { buildChecksums } from '../utils/hashing.ts';
import { stringifyJsonSafe } from '../utils/json.ts';
import { buildManifest, CHECKSUMS_FILE, MANIFEST_FILE, EXPORTER_NAME } from '../schema/manifest.ts';
import { SECTION_JSON_PATHS, SECTION_FILE_PREFIXES, isFileSection } from '../schema/config.ts';
import { DEFAULT_SENSITIVE_RELS, refreshVault } from '../security/vault.ts';
import { isSensitiveHomeRel } from '../utils/paths.ts';
import { writeZip } from '../utils/zip.ts';
import { formatDateOnly } from '../utils/time.ts';
import { msgOf } from './messages.ts';
import { sanitizeSectionData } from './section-sanitize.ts';
import { engineMsg } from './messages-core.ts';
import { declareBundledSessionsInWorkspaces, normalizeSessionLimit, sessionIdKey } from './session-select.ts';
// issue #45 连带匹配的第二判据：工作区 path 的 cwd 目录键（DSH 的 sessionIds 覆盖率很低，见 coupleSessionWorkspaces）
import { projectKeyOf } from './session-meta.ts';
import type { MsgFunc } from './messages.ts';

/** 会话单元 id（`sessions:<项目键>/<目录名>`）→ cwd 目录键（项目键）；形状不符 → undefined。 */
function projectKeyOfUnitId(unitId: string): string | undefined {
  const rest = unitId.startsWith('sessions:') ? unitId.slice('sessions:'.length) : unitId
  const slash = rest.lastIndexOf('/')
  return slash <= 0 ? undefined : rest.slice(0, slash)
}
import type { Manifest, SectionId } from '../schema/types.ts';
import type {
  ConfigAdapter, EncryptionProvider, ExportOptions, ExportReport,
  ExportSection, HostContext, SecretScanner, SensitiveHit,
} from './types.ts';

/** m1：每导出一个分区前的进度回调信息（Host 侧 run 状态更新用；section = adapter id） */
export interface SectionProgress {
  section: string;
  /** 当前分区序号（1 起） */
  index: number;
  /** 选中分区总数 */
  total: number;
}

export interface ExporterOptions {
  ctx: HostContext;
  adapters: ConfigAdapter[];
  /** Secret 扫描器；缺省用字段名黑名单剥离（m4 可注入强化版） */
  scanner?: SecretScanner;
  /** 加密提供者（m4 用 node:crypto 实现）；includeSecrets 时必填；提供时备份标记 encrypted=true */
  encryption?: EncryptionProvider | null;
  /** 插件自身版本（manifest.exporter.version） */
  exporterVersion?: string;
  now?: () => Date;
  /** 消息翻译器（缺省 ctx.msg ?? zh） */
  msg?: MsgFunc;
  /** m1：每导出一个分区前调用（真实进度埋点；不传则无埋点） */
  onSection?: (info: SectionProgress) => void;
  /**
   * 插件数据目录（文件级 vault 位于 <vaultDataDir>/vault，缺省 <homeDir>/dsh-config-manager）。
   * includeSecrets=false 时导出会自动刷新 vault；宿主自定义 dataDir 时应注入实际值
   * （HostContext 不携带 dataDir，故经选项注入）。
   */
  vaultDataDir?: string;
}

/** 缺省 SecretScanner：递归黑名单字段剥离（字段名大小写不敏感；二进制/Uint8Array 原样跳过） */
export function defaultSecretScanner(): SecretScanner {
  const SENSITIVE_FIELDS = [
    'password', 'passwd', 'token', 'accesstoken', 'refreshtoken', 'apikey',
    'secret', 'credential', 'authorization', 'cookie', 'privatekey', 'clientsecret',
  ];
  /** 仅存「引用名」而非值的字段（如 apiKeyEnv=DEEPSEEK_API_KEY 是环境变量名，不是秘密） */
  const REFERENCE_FIELDS = new Set([
    'apikeyenv', 'api_key_env', 'apikeyname', 'tokenenv', 'accesstokenenv',
    'refreshtokenenv', 'clientsecretenv', 'passwordenv',
  ]);
  return {
    scanAndRedact(data: unknown): { sanitized: unknown; hits: SensitiveHit[] } {
      const hits: SensitiveHit[] = [];
      const walk = (v: unknown, p: string): unknown => {
        if (v === null || typeof v !== 'object') return v;
        if (v instanceof Uint8Array) return v; // 二进制内容不按字段展开
        if (Array.isArray(v)) return v.map((item, i) => walk(item, `${p}[${i}]`));
        const out: Record<string, unknown> = {};
        for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
          const lower = k.toLowerCase().replace(/[^a-z0-9]/g, '');
          const isRefName = REFERENCE_FIELDS.has(lower);
          const sensitive = !isRefName && SENSITIVE_FIELDS.some((f) => lower.includes(f));
          if (sensitive && typeof val === 'string' && val !== '') {
            hits.push({ path: p === '' ? k : `${p}.${k}`, field: k });
            out[k] = ''; // 值剥离为空串（保留字段名与位置，供「需补录」提示）
            continue;
          }
          out[k] = walk(val, p === '' ? k : `${p}.${k}`);
        }
        return out;
      };
      return { sanitized: walk(data, ''), hits };
    },
  };
}

/* ---------------- G-09：文件类分区文本级扫描（只报告，绝不改写） ---------------- */

/**
 * 单文件扫描字节上限（1 MiB）。超大文件只扫描前 1 MiB：
 * 凭据通常出现在配置/脚本的头部；超过上限的剩余部分放弃扫描，避免单个巨型文件拖垮导出。
 */
export const FILE_SECTION_SCAN_MAX_BYTES = 1024 * 1024;

/** 一次导出中所有文件类分区的累计扫描字节上限（16 MiB），防「成千上万小文件」拖慢导出 */
export const FILE_SECTION_SCAN_TOTAL_BUDGET_BYTES = 16 * 1024 * 1024;

/** 每个分区最多告警的**不同文件**数（不是 hit 条数）；命中仍全量计入 redactedHits（报告统计通道），超出部分由一条汇总告警兜底，避免「真有凭据的文件被静默淹没」或「截断即静默丢失」 */
export const MAX_FILE_SECTION_WARNINGS_PER_SECTION = 5;

/** 二进制探测窗口（前 4 KiB 出现 NUL 即视为二进制，不按文本扫描） */
const BINARY_SNIFF_BYTES = 4096;

/** 是否为二进制内容（含 NUL 字节 → 不是 UTF-8 文本；避免对二进制做无意义的文本扫描/误报） */
function looksBinary(bytes: Uint8Array): boolean {
  const n = Math.min(bytes.length, BINARY_SNIFF_BYTES);
  for (let i = 0; i < n; i++) {
    if (bytes[i] === 0) return true;
  }
  return false;
}

/**
 * 文件类分区内容扫描（G-09）：
 *  - 走注入 scanner 的 `scanText`（只报告不改写；`scanAndRedact` 会剥离值，**不得**用于用户文件）；
 *  - 扫描档位与 `src/market/prepare.ts` 的导出侧扫描保持一致：默认保守档 +
 *    值形状启发式（`valuePatterns` 默认开），**不启用** `highEntropy`（默认关，误报率高）；
 *  - 二进制文件（含 NUL）跳过：文本扫描对它无意义且必然误报；
 *  - 单文件上限 `FILE_SECTION_SCAN_MAX_BYTES`、累计上限 `FILE_SECTION_SCAN_TOTAL_BUDGET_BYTES`：
 *    超限即停止扫描（不是停止导出），被跳过的部分不产生命中也不产生告警；
 *  - scanner 未实现 `scanText`（如 core 内置的字段名黑名单 defaultSecretScanner）→ 返回空，
 *    行为与修复前一致（生产路径注入的是含 scanText 的强化扫描器）。
 *
 * 返回命中清单，`path` 为「分区内文件相对路径」，`field` 为 `line:N`（值永不外泄）。
 */
function scanFileSectionText(scanner: SecretScanner, data: unknown): SensitiveHit[] {
  const scanText = scanner.scanText;
  if (typeof scanText !== 'function') return [];
  const files = extractFileEntries(data);
  if (files === null) return [];

  const hits: SensitiveHit[] = [];
  let budget = FILE_SECTION_SCAN_TOTAL_BUDGET_BYTES;
  for (const file of files) {
    if (budget <= 0) break;
    const bytes = file.data;
    if (!(bytes instanceof Uint8Array) || bytes.length === 0) continue;
    const window = bytes.subarray(0, Math.min(bytes.length, FILE_SECTION_SCAN_MAX_BYTES, budget));
    budget -= window.length;
    if (looksBinary(window)) continue;
    let text: string;
    try {
      text = new TextDecoder('utf-8').decode(window);
    } catch {
      continue;
    }
    for (const hit of scanText(text)) {
      hits.push({ path: file.relativePath, field: hit.path });
    }
  }
  return hits;
}

/** 从分区数据里取出文件条目（非文件类/结构异常 → null；只看 files 数组，不展开其他字段） */
function extractFileEntries(data: unknown): { relativePath: string; data: Uint8Array }[] | null {
  if (data === null || typeof data !== 'object') return null;
  const files = (data as { files?: unknown }).files;
  if (!Array.isArray(files)) return null;
  return files.filter((f): f is { relativePath: string; data: Uint8Array } => (
    f !== null && typeof f === 'object'
    && typeof (f as { relativePath?: unknown }).relativePath === 'string'
    && (f as { data?: unknown }).data instanceof Uint8Array
  ));
}

export class Exporter {
  private readonly ctx: HostContext;
  private readonly adapters: ConfigAdapter[];
  private readonly scanner: SecretScanner;
  private readonly encryption: EncryptionProvider | null;
  private readonly exporterVersion: string;
  private readonly now: () => Date;
  private readonly msg: MsgFunc;
  private readonly onSection: ((info: SectionProgress) => void) | undefined;
  private readonly vaultDataDir: string;

  constructor(opts: ExporterOptions) {
    this.ctx = opts.ctx;
    this.adapters = opts.adapters;
    this.scanner = opts.scanner ?? defaultSecretScanner();
    this.encryption = opts.encryption ?? null;
    this.exporterVersion = opts.exporterVersion ?? '0.1.0';
    this.now = opts.now ?? (() => new Date());
    this.msg = opts.msg ?? msgOf(opts.ctx);
    this.onSection = opts.onSection;
    this.vaultDataDir = opts.vaultDataDir ?? path.join(opts.ctx.homeDir, 'dsh-config-manager');
  }

  /**
   * 勾选/导出 sessions 时，自动把这些会话所属的工作区记录纳入导出范围（issue #45）。
   *
   * 为什么必须自动：DSH 里会话能不能显示出来取决于「有没有一条工作区记录指向它的 cwd 且 id 在
   * sessionIds 里」—— 只带会话文件不带工作区，目标机必然「数据恢复了却显示不出来」。这条依赖不该
   * 由用户来记。
   *
   * 「所属」判定（宽进严出）：用户做了条目级选择时精确匹配 sessionIds；只给了 sessions.limit
   * （选中的是「最新 N 个」，此刻还不知道是哪几个）或整分区选择时，凡声明了 sessionIds 的工作区都算。
   *
   * **一条都没匹配上时不再放弃**（真机事故加固）：只要本机存在工作区记录，就整分区带上 —— 会话能否显示
   * 完全取决于「有没有工作区指向它的 cwd」，多带几条纯元数据（path/title/sessionIds）没有副作用，而漏带
   * 的代价是用户以为对话丢了。读不到注册表、或本机一条记录都没有时如实返回，交由报告层显式告警。
   *
   * @returns 连带结果：ids = 要带的工作区单元 id；total = 本机记录总数；matched = 是否按会话归属匹配出来；
   *   unreadable = 注册表读不到（此时 ids 恒为空、不做任何白名单限制，绝不因为这里失败而让导出整体失败）
   */
  private async coupleSessionWorkspaces(options: ExportOptions): Promise<{ ids: string[]; total: number; matched: boolean; unreadable: boolean }> {
    const selectedSessions = options.includeItems?.['sessions'];
    let records: { id: string; path: string; sessionIds: string[] }[];
    try {
      records = await this.ctx.workspace.listRecords();
    } catch {
      return { ids: [], total: 0, matched: false, unreadable: true };
    }
    const sessionIds = selectedSessions === undefined
      ? undefined
      // 单元末段是**目录名**（`session-<uuid>` / 裸 `<uuid>` 两种形态并存），注册表一律 `session-<uuid>`：
      // 必须归一化后比较，否则「所属」判定对绝大多数会话失配（真机实测 546/570 失配）。
      : new Set(selectedSessions.map((unit) => sessionIdKey(unit.split('/').pop() ?? '')).filter((value) => value !== ''));
    // 第二判据：会话 cwd 的目录键 == 工作区 path 的目录键（与 DSH 把会话显示在工作区下的口径一致）。
    // 为什么必须有：注册表 sessionIds 覆盖率很低（真机实测：一次可选择的 570 条会话里只有 23 条在里面），
    // 只按 sessionIds 匹配会让绝大多数会话「认不出所属工作区」，连带就退化成「整分区带上」。
    const projectKeys = selectedSessions === undefined
      ? undefined
      : new Set(selectedSessions.map(projectKeyOfUnitId).filter((value): value is string => value !== undefined));
    const owned = records
      .filter((rec) => {
        // 数量筛选（limit）：此刻还不知道是哪几条 → 保持既有宽进口径：只连带「声明过会话」的工作区
        if (sessionIds === undefined || projectKeys === undefined) return rec.sessionIds.length > 0;
        if (rec.sessionIds.some((id) => sessionIds.has(sessionIdKey(id)))) return true;
        return rec.path !== '' && projectKeys.has(projectKeyOf(rec.path));
      })
      .map((rec) => 'workspace:' + rec.id);
    const picked = options.includeItems?.['workspaces'] ?? [];
    // 匹配上 → 只带「所属」的（用户自己勾选的照旧并集）；一条都没匹配上 → 整分区带上（广撒网比漏带安全）。
    const target = owned.length > 0 ? owned : records.map((rec) => 'workspace:' + rec.id);
    return { ids: [...new Set([...picked, ...target])], total: records.length, matched: owned.length > 0, unreadable: false };
  }

  /**
   * 导出：收集 → 过滤 → checksum → manifest → ZIP。
   * 返回 zipPath（含文件名）、manifest、报告。
   */
  async export(options: ExportOptions): Promise<{ zipPath: string; manifest: Manifest; report: ExportReport }> {
    const { includeSecrets, only } = options;
    if (includeSecrets && !this.encryption) {
      throw new Error(this.msg('export.encryptionRequired'));
    }

    // 1. 选定分区（only 过滤 + 默认包含）
    //    条目级选择（Phase 1）：includeItems[s] === [] 表示用户把该分区整个取消了 ——
    //    与「未勾选该分区」等价，在选定阶段即剔除，不产出空载荷分区，
    //    manifest.sections / report.excluded 如实反映（绝不静默变成「导出成功但内容为空」）。
    //    纵深防御：宿主已保证不下发空白名单，此处覆盖 CLI / 第三方直接调用 core 的情况。
    // issue #39 Feature 1：`sessions: { limit }` 是**显式分区选择 + 数量筛选**。
    // sessions 的 defaultIncluded=false（Quick Export 不带会话），所以键存在必须自己把该分区
    // 选上；limit=0 反之把该分区整体剔除（等价于未勾选，不产出空载荷分区）。
    const sessionsLimit = options.sessions === undefined
      ? undefined
      : normalizeSessionLimit(options.sessions.limit);
    const sessionsRequested = options.sessions !== undefined && sessionsLimit !== 0;
    // issue #45：导出会话必须连带其所属工作区（否则目标机上会话显示不出来）。
    // 「导出了会话」有三种表达方式：sessions 键（数量筛选）、only 列表、条目级 includeItems.sessions。
    const sessionsSelected = sessionsRequested
      || (options.only?.includes('sessions') ?? false)
      || (options.includeItems?.['sessions']?.length ?? 0) > 0;
    // 加固（真机事故复现）：只要导出会话，工作区**一定**跟着走 —— 归属判定不出来就整分区带上，
    // 连一条工作区记录都没有也必须显式告警。绝不产出「有会话、没工作区」的包：那在目标机上就是
    // 「数据恢复了却看不见」，用户会直接理解成「对话丢了」。
    const coupling = sessionsSelected ? await this.coupleSessionWorkspaces(options) : undefined;
    const carryWorkspaces = coupling !== undefined && coupling.ids.length > 0;
    // 连带白名单必须与分区选定共用**同一份** includeItems：否则用户「把工作区全部取消勾选」
    // （includeItems.workspaces = []）会在第二个 filter 里把刚被强制选中的分区再挡掉。
    const effectiveIncludeItems: Partial<Record<SectionId, string[]>> | undefined = carryWorkspaces
      ? { ...options.includeItems, workspaces: coupling.ids }
      : options.includeItems;
    const selected = this.adapters
      .filter((a) => {
        if (a.id === 'sessions') {
          if (sessionsLimit === 0) return false;
          if (sessionsRequested) return true;
        }
        // issue #45：勾选/导出 sessions 时，工作区分区**强制**跟着走（用户没勾也要带 —— 不带就必然显示不出来）
        if (a.id === 'workspaces' && carryWorkspaces) return true;
        return only === undefined ? a.defaultIncluded : only.includes(a.id);
      })
      .filter((a) => (effectiveIncludeItems?.[a.id]?.length ?? 1) > 0)
      .map((a) => a.id);

    // 2. 逐 adapter 收集（导出数据）
    const sections: ExportSection[] = [];
    const effectiveOptions: ExportOptions = effectiveIncludeItems === options.includeItems
      ? options
      : { ...options, includeItems: effectiveIncludeItems };
    const warnings: string[] = [];
    // 连带行为必须**永远**在报告里可见：带了几条 / 一条都没匹配上（整分区带上）/ 本机根本没有记录。
    if (coupling !== undefined) {
      if (coupling.unreadable) warnings.push(this.msg('export.sessionsWorkspacesUnreadable'));
      else if (coupling.total === 0) warnings.push(this.msg('export.sessionsWithoutWorkspaces'));
      else if (coupling.matched) warnings.push(this.msg('export.sessionsWorkspacesCoupled', { count: String(coupling.ids.length) }));
      else warnings.push(this.msg('export.sessionsWorkspacesCarriedAll', { count: String(coupling.ids.length) }));
    }
    const redactedHits: SensitiveHit[] = [];
    const included: ExportReport['included'] = [];
    const excluded: SectionId[] = this.adapters.filter((a) => !selected.includes(a.id)).map((a) => a.id);

    // m1 埋点：每导出一个分区前上报真实进度（onSection 抛错不得中断导出）
    let sectionIndex = 0;
    for (const adapter of this.adapters) {
      if (!selected.includes(adapter.id)) continue;
      sectionIndex += 1;
      try {
        this.onSection?.({ section: adapter.id, index: sectionIndex, total: selected.length });
      } catch {
        // 埋点回调失败不影响导出本身（进度是尽力而为）
      }
      let section: ExportSection;
      try {
        section = await adapter.export(this.ctx, effectiveOptions);
      } catch (err) {
        // 单个分区失败不拖垮整体（§34.17）；如实告警并跳过
        warnings.push(this.msg('export.sectionFailed', { adapter: adapter.id, reason: err instanceof Error ? err.message : String(err) }));
        excluded.push(adapter.id);
        continue;
      }
      // 3. Secret 过滤：结构化数据逐一过 scanner（剥离值）；
      //    文件类分区（skills/agentPresets/agentInstructions/pluginFiles/sessions/self）是用户的真实文件，
      //    只做**文本级扫描 + 告警**，绝不改写/剥离内容（见 scanFileSectionText）。
      let sanitized = section.data;
      if (!isFileSection(adapter.id)) {
        // issue #136 C：脱敏 + 归属标注走唯一入口（与同步侧五个出口同一份字节）。
        // 归属信息随载荷走（plugins 的 patch 行 `redactedPaths`），报告统计仍用全量命中。
        const scanned = sanitizeSectionData(adapter, this.scanner, section.data);
        redactedHits.push(...scanned.hits);
        sanitized = scanned.sanitized;
      } else {
        const fileHits = scanFileSectionText(this.scanner, section.data);
        if (fileHits.length > 0) {
          // redactedHits 是**报告统计**通道（非告警通道）：仍计入全量命中（含同一文件的多行/多形态命中）。
          redactedHits.push(...fileHits);
          // 告警按**文件**去重（G-09/H1）：同一路径只告警一次。
          // 修复前按 hit 计数，同一行同时命中「字段名」与「值形状」会产出两条同路径告警，
          // 使少数文件就吃满上限，导致含真实明文凭据的其它文件被静默淹没（实测 redactedHits=8 而 5 条告警全属一个文件）。
          const hitPaths: string[] = [];
          const seenPaths = new Set<string>();
          for (const hit of fileHits) {
            if (seenPaths.has(hit.path)) continue;
            seenPaths.add(hit.path);
            hitPaths.push(hit.path);
          }
          // 上限语义 = 不同**文件**数 ≤ MAX_FILE_SECTION_WARNINGS_PER_SECTION（避免大分区刷屏）
          const warnedPaths = hitPaths.slice(0, MAX_FILE_SECTION_WARNINGS_PER_SECTION);
          for (const hitPath of warnedPaths) {
            warnings.push(this.msg('export.fileSectionSecrets', { section: adapter.id, path: hitPath }));
          }
          // 被截断的文件数必须**显式**汇总告警，否则截断本身又变成静默丢失。
          // 文案在 t4 域目录（src/core/messages-core.ts）：不再借用 export.fileSectionSecrets 传中文 path 值。
          const truncatedCount = hitPaths.length - warnedPaths.length;
          if (truncatedCount > 0) {
            warnings.push(engineMsg('core.exporter.fileSectionSecretsTruncated', { section: adapter.id, count: truncatedCount }));
          }
        }
      }
      sections.push({ ...section, data: sanitized });
      included.push({ section: adapter.id, counts: section.counts });
      warnings.push(...section.warnings);
    }

    // issue #45 ③（真机事故加固）：导出会话时让包**自洽** —— 把本次真正带走的会话 id 声明进所属工作区记录。
    // 为什么必须：DSH 注册表的 sessionIds 覆盖率极低（真机实测 570 条里只有 23 条在里面），用户勾选的
    // 对话往往**不在**里面 —— 于是目标机上「工作区记录里没有它 → 没有任何人把它登记进工作区 → 对话
    // 看不见」（真机复现：导出 3 次对话 + 7 条工作区，导入后 3 次对话全部不可见，反倒刷出 156 条
    // 「未能登记」的误报）。**只增不减**：注册表原有的 id 保留，它们对「目标机本来就有这些会话」的
    // 场景仍然有用；包内没带数据的 id 由导入侧按「不在此包内」如实分类，不再当成路径映射错误。
    if (sessionsSelected) {
      const sessionsSection = sections.find((s) => s.sectionId === 'sessions');
      const workspacesSection = sections.find((s) => s.sectionId === 'workspaces');
      if (sessionsSection !== undefined && workspacesSection !== undefined) {
        const linked = declareBundledSessionsInWorkspaces(sessionsSection.data, workspacesSection.data);
        if (linked.declared > 0) {
          warnings.push(this.msg('export.sessionsDeclaredInWorkspaces', {
            count: String(linked.declared), workspaces: String(linked.workspaces),
          }));
        }
      }
    }

    // 4. 组装 ZIP 条目（JSON 分区 + 文件类分区 + secrets.enc + checksums + manifest）
    const entries: { name: string; data: Uint8Array }[] = [];
    const sectionFlags = buildSectionFlags(sections);
    let containsSecrets = false;
    let encrypted = false;
    let encryption: Manifest['security']['encryption'] = null;

    for (const section of sections) {
      if (isFileSection(section.sectionId)) {
        const prefix = SECTION_FILE_PREFIXES[section.sectionId]!;
        const files = (section.data as { files?: { relativePath: string; data: Uint8Array }[] }).files ?? [];
        // 打包侧兜底（审计 P2-1 P0）：第三方插件数据分区的根是**系统主目录**，收集侧已按同一判据
        // 剔除凭据文件；这里再判一次，防止「收集侧漏判 / 消费者手工构造 section」把整文件秘密写进 ZIP。
        // 判据唯一来源 = utils/paths.ts 的 isSensitiveHomeRel。
        const guardCredentials = section.sectionId === 'pluginData' || section.sectionId === 'pluginAssets';
        let droppedSensitive = 0;
        let droppedSample = '';
        for (const file of files) {
          if (guardCredentials && isSensitiveHomeRel(file.relativePath)) {
            droppedSensitive += 1;
            if (droppedSample === '') droppedSample = file.relativePath;
            continue;
          }
          entries.push({ name: `${prefix}${file.relativePath}`, data: file.data });
        }
        if (droppedSensitive > 0) {
          warnings.push(this.msg('export.pluginDataSensitiveSkipped', {
            count: String(droppedSensitive), sample: droppedSample,
          }));
        }
        continue;
      }
      const jsonPath = SECTION_JSON_PATHS[section.sectionId];
      if (jsonPath === undefined) continue;
      entries.push({
        name: jsonPath,
        data: Buffer.from(stringifyJsonSafe(section.data, { space: 2 }), 'utf8'),
      });
    }

    // secrets.enc：有加密提供者即生成。includeSecrets=true 时加密真实的凭据原文；
    // 只勾选加密（不导出密钥）时加密空内容占位，备份仍标记 encrypted（导入需密码），
    // 但绝不把凭据值放进去（containsSecrets 保持 false；安全不变量不破）。
    if (this.encryption) {
      const credentialsFile = path.join(this.ctx.homeDir, '.credentials.yaml');
      let plaintext: string;
      if (includeSecrets) {
        try {
          const raw = await this.ctx.fs.readFile(credentialsFile);
          plaintext = Buffer.from(raw).toString('utf8');
        } catch (err) {
          warnings.push(this.msg('export.credentialsReadFailed', { reason: err instanceof Error ? err.message : String(err) }));
          plaintext = '';
        }
      } else {
        plaintext = '';
      }
      const result = await this.encryption.encrypt(plaintext);
      entries.push({ name: 'security/secrets.enc', data: result.blob });
      encryption = result.info;
      containsSecrets = includeSecrets && plaintext !== '';
      encrypted = true;
    }

    // 4b. 文件级 vault（includeSecrets=false：敏感文件明文不进归档 → 镜像到本机 vault）。
    //     尽力而为：任何失败仅记警告，不中断导出。includeSecrets=true 时秘密已加密进归档，
    //     无需镜像（vault 只服务于「明文不进备份」的本机留存场景）。
    let vaultRefreshed = 0;
    if (!includeSecrets) {
      try {
        const vault = await refreshVault(this.ctx.fs, this.vaultDataDir, this.ctx.homeDir, DEFAULT_SENSITIVE_RELS);
        vaultRefreshed = vault.mirrored.length;
        if (vault.mirrored.length > 0) {
          warnings.push(this.msg('export.vaultRefreshed', { count: vault.mirrored.length }));
        }
        for (const s of vault.skipped) {
          warnings.push(this.msg('export.vaultRefreshSkipped', { rel: s.rel, reason: s.reason }));
        }
      } catch (err) {
        warnings.push(this.msg('export.vaultRefreshFailed', { reason: err instanceof Error ? err.message : String(err) }));
      }
    }

    // 5. checksums（覆盖除 manifest/checksums 外的全部条目）
    const checksums = buildChecksums(entries);
    entries.push({ name: CHECKSUMS_FILE, data: Buffer.from(stringifyJsonSafe(checksums, { space: 2 }), 'utf8') });

    // 6. manifest（最后写：需要完整分区与安全信息）
    const manifest = buildManifest({
      // 跨机基础路径重定基的依据（issue #45）：本机 DSH home 随包走
      sourceHome: this.ctx.homeDir,
      exporterVersion: this.exporterVersion,
      dshVersion: this.ctx.dshVersion,
      platform: this.ctx.platform as Manifest['source']['platform'],
      arch: this.ctx.arch,
      sections: sectionFlags,
      containsSecrets,
      encrypted,
      encryption,
      exportedAt: this.now().toISOString(),
    });
    entries.push({ name: MANIFEST_FILE, data: Buffer.from(stringifyJsonSafe(manifest, { space: 2 }), 'utf8') });

    // 7. 落盘
    const outPath = options.outPath ?? defaultOutPath(this.now());
    await writeZip(outPath, entries);
    const stat = await fs.stat(outPath);

    // 日志不泄值：只记分区与命中数量
    this.ctx.log.info('导出完成', {
      file: path.basename(outPath),
      sizeBytes: stat.size,
      sections: Object.keys(sectionFlags).filter((k) => sectionFlags[k as SectionId]),
      redactedFields: redactedHits.length,
      containsSecrets,
      encrypted,
      vaultRefreshed,
    });

    const report: ExportReport = {
      included,
      excluded,
      security: {
        secretsExcluded: !includeSecrets,
        containsSecrets,
        encrypted,
        redactedHits: redactedHits.length,
        vaultRefreshed,
      },
      file: { name: path.basename(outPath), sizeBytes: stat.size },
      warnings,
    };
    return { zipPath: outPath, manifest, report };
  }
}

/** 构建 manifest.sections 布尔表（只含实际导出分区） */
function buildSectionFlags(sections: ExportSection[]): Manifest['sections'] {
  const flags = {} as Manifest['sections'];
  for (const id of Object.keys(SECTION_JSON_PATHS) as SectionId[]) flags[id] = false;
  for (const id of Object.keys(SECTION_FILE_PREFIXES) as SectionId[]) flags[id] = false;
  flags['secrets'] = false;
  for (const section of sections) flags[section.sectionId] = true;
  return flags;
}

function defaultOutPath(now: Date): string {
  return `dsh-config-${formatDateOnly(now)}.zip`;
}

/** 供报告使用：导出器身份（避免与 manifest 常量重复维护） */
export const EXPORTER_INFO = { name: EXPORTER_NAME };
