/**
 * Host-side extension registry: the one place that admits external providers,
 * negotiates the contract version, gates them on the board's own enable state,
 * fans board events out to them, and routes dispatched provider actions back.
 *
 * Failure policy (mirrors the board's plugin philosophy): a provider that
 * throws, mis-declares its version, or disables itself degrades only its own
 * surface. The board keeps serving; the registry records what it refused.
 *
 * @module dsh-task-board/host/extension-registry
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { HostTaskLedger } from '../host-ledger.ts';
import type { TaskBoardAction, TaskBoardSnapshot } from '../protocol.ts';
import { type TaskBoardExecutionSettledEvent, type TaskBoardExtension, type TaskBoardExtensionActionRequest, type TaskBoardExtensionPayload, type TaskBoardLaunchContext, type TaskBoardLaunchDecision, type TaskBoardStatusChangedEvent, type TaskBoardTaskDeletedEvent } from '../core/extension.ts';
import { type TaskRecord } from '../core/tasks.ts';
/** Diagnosable refusal raised by the registry and the capability face. */
export declare class TaskBoardExtensionError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Logging seat the registry uses; a deployment may supply its own. */
export interface TaskBoardExtensionLogger {
    warn(message: string, ...rest: unknown[]): void;
    error(message: string, ...rest: unknown[]): void;
}
/** The deployment's model-visible tool registry, resolved lazily. */
export interface TaskBoardExtensionToolRegistry {
    register(definition: ToolDefinition): () => void;
}
/** Applies one board action with every board gate intact (never an extension action). */
export type TaskBoardActionApplier = (action: Exclude<TaskBoardAction, {
    kind: 'extension-action';
}>, initiator?: string) => TaskBoardSnapshot;
/** Delivers one follow-up message into an existing execution session. */
export type TaskBoardFollowUpDelivery = (sessionId: string, text: string) => Promise<void>;
/** Applies one rework request through the board's own run path. */
export type TaskBoardReworkApplier = (taskId: string, instructions: string, initiator?: string) => void;
/** Registry dependencies. */
export interface TaskBoardExtensionRegistryOptions {
    ledger: HostTaskLedger;
    /** Apply an action through the board service (gates, run dispatch, schedule). */
    apply?: TaskBoardActionApplier;
    /**
     * Queue one follow-up message into a session. Absent means this deployment
     * serves no session delivery, which the capability face refuses visibly.
     */
    followUp?: TaskBoardFollowUpDelivery;
    /**
     * Apply one rework run request (through the same gates a run takes). Absent
     * means this deployment serves no rework, which the face refuses visibly.
     */
    rework?: TaskBoardReworkApplier;
    /** Resolve the deployment's tool registry; absent loses the tool surface only. */
    toolRegistry?: () => TaskBoardExtensionToolRegistry | undefined;
    /** Notified whenever a provider publishes, changes, or withdraws its summary. */
    onPublished?: () => void;
    now?: () => number;
    uuid?: () => string;
    logger?: TaskBoardExtensionLogger;
}
export declare class TaskBoardExtensionRegistry {
    private readonly entries;
    private readonly ledger;
    private readonly applyAction;
    private readonly followUpDelivery;
    private readonly reworkApply;
    private readonly now;
    private readonly uuid;
    private readonly logger;
    private toolResolver;
    private readonly onPublished;
    private publishedVersionCounter;
    /** Board master switch (enabled config); providers start only while it is on. */
    private boardEnabled;
    private disposed;
    constructor(options: TaskBoardExtensionRegistryOptions);
    /** Monotonic revision of the published extension summaries map. */
    get publishedRevision(): number;
    /**
     * Pin (or replace) the deployment's tool registry. A registry that appears
     * after a provider started is picked up here, which is what keeps the tool
     * surface alive across the board's own late service resolution.
     */
    setToolRegistry(resolver: (() => TaskBoardExtensionToolRegistry | undefined) | undefined): void;
    /** Apply the board's master switch; providers start and stop with it. */
    setEnabled(enabled: boolean): void;
    /** Whether the board currently runs a given extension (board x extension). */
    isActive(extensionId: string): boolean;
    /**
     * Admit one provider. Idempotent by id: a second registration of the same id
     * is a no-op that returns the same release handle. A contract-version
     * mismatch is refused visibly (logged and thrown) without disturbing the
     * board or any other provider.
     * @param extension - the provider to admit.
     * @returns a disposer releasing the registration (idempotent).
     */
    registerExtension(extension: TaskBoardExtension): () => void;
    /** Remove one provider; its provider-side work stops and its payload stays stored. */
    unregister(extensionId: string): void;
    /**
     * Route one dispatched provider action. Refuses visibly when the extension is
     * unknown, currently gated off, or does not implement the action.
     */
    handleAction(request: TaskBoardExtensionActionRequest): Promise<unknown>;
    /**
     * The board's single launch gate: ask every running provider whether this run
     * is theirs.
     *
     * Consulted by the ledger at the one point every trigger passes — before a
     * session exists and before an execution record is written — so the order
     * here is the only ordering a provider can observe: registration order, first
     * decision wins. A handler that throws is isolated and treated as "not mine",
     * exactly as if it had answered undefined, because a provider's bug must cost
     * its own interception and never the launch. Without a registered handler
     * this answers nothing at all and the launch path is untouched.
     * @param task - the card about to run.
     * @param context - which entry asked for this run.
     * @returns the first decision a running provider made, or undefined.
     */
    interceptLaunch(task: TaskRecord, context: TaskBoardLaunchContext): TaskBoardLaunchDecision | undefined;
    /**
     * What the running providers say about one card, keyed by extension id.
     * Isolated per provider: a throw drops that provider's entry only.
     */
    describeTask(task: TaskRecord): Record<string, Record<string, unknown>> | undefined;
    /** The run handle a running provider holds for one card, keyed by extension id. */
    describeRun(taskId: string): Record<string, Record<string, unknown>> | undefined;
    private describe;
    /** Published summaries of currently running providers, keyed by extension id. */
    published(): Record<string, TaskBoardExtensionPayload>;
    /** Fan a status change out to every running provider, isolated per callback. */
    emitStatusChanged(event: TaskBoardStatusChangedEvent): void;
    /** Fan an execution settlement out to every running provider. */
    emitExecutionSettled(event: TaskBoardExecutionSettledEvent): void;
    /** Fan a task deletion out to every running provider. */
    emitTaskDeleted(event: TaskBoardTaskDeletedEvent): void;
    /** Stop every provider and release the registry (idempotent). */
    dispose(): void;
    private emit;
    /** Start or stop one entry against the current board + extension gate. */
    private reconcile;
    private startEntry;
    private stopEntry;
    /** (Re)register every buffered tool against the current tool registry. */
    private syncTools;
    private disposeTools;
    private assertActive;
    /** Build the per-extension capability face. */
    private capabilities;
    private createTask;
    private patchContent;
    private setStatus;
    /**
     * Queue one follow-up message into the session of a card's current or most
     * recent execution.
     *
     * A running card is the point of the capability, so an open execution is not
     * a refusal: the message is queued behind the turn that is already going. What
     * IS refused is a card with no conversation to deliver into, and a session
     * this Host no longer reaches — the delivery refuses, and that refusal must
     * reach the provider as such instead of looking like a silent success.
     */
    private followUp;
    /**
     * Re-run an executed card in its own session with rework instructions.
     *
     * The registry decides only what it can read from the ledger — the card
     * exists, is not archived, is not running, and has a conversation to continue
     * — and then hands the request to the board's own run path, so the running
     * lock, the permission confirmation, the acceptance contract and the spend cap
     * keep judging it. A board refusal surfaces unchanged, exactly as it does for
     * {@link setStatus}, because those are the board's own words.
     */
    private rework;
    /** One task by id, or the refusal that names the unknown id. */
    private requireTask;
    private linkedTasks;
    private writeIntegration;
    private publish;
    /**
     * Hold one launch handler for a running provider. The handler is dropped when
     * the provider stops or is unregistered, so the disposer only has to cover the
     * provider's own early withdrawal.
     */
    private addLaunchHandler;
    private registerTool;
}
