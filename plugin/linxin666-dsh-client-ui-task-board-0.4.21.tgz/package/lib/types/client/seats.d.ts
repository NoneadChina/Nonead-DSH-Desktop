/**
 * The board's child seats, threaded from the slot registration that declares
 * them down to the components that consume them.
 *
 * The framework hands the declaring component a `renderSlot` binding; the board
 * wraps that binding in a React context so a provider's contribution can render
 * deep inside TaskDetail, the card, the settings card, or the create dialog
 * without those components knowing which providers exist.
 *
 * @module dsh-task-board/client/seats
 */
import { Component } from 'react';
import type { ReactNode } from 'react';
import { type TaskBoardCardDecorationProps, type TaskBoardComposeSectionProps, type TaskBoardDetailSectionProps, type TaskBoardSettingsSectionProps } from '../core/extension.ts';
/** The four provider seats, adapted to plain render functions. */
export interface TaskBoardSeats {
    detailSection: (props: TaskBoardDetailSectionProps) => ReactNode;
    settingsSection: (props: TaskBoardSettingsSectionProps) => ReactNode;
    cardDecoration: (props: TaskBoardCardDecorationProps) => ReactNode;
    composeSection: (props: TaskBoardComposeSectionProps) => ReactNode;
}
/** Nothing registered: every seat renders empty. */
export declare const EMPTY_TASK_BOARD_SEATS: TaskBoardSeats;
/** The framework `renderSlot` binding shape (key + owner props share). */
export type SlotRenderBinding = (key: string, owner: Record<string, unknown>) => ReactNode;
/** Adapt one framework renderSlot binding to the board's seat interface. */
export declare function seatsFromRenderSlot(renderSlot: SlotRenderBinding | undefined): TaskBoardSeats;
/**
 * Isolation for one seat whose providers render outside the framework's own
 * per-entry boundary: a provider that throws while rendering contributes
 * nothing here instead of taking the surface around the seat down with it.
 * Nothing is rendered in that case — the seat is optional, so its absence is
 * the honest state — and the failure is logged once for the provider's author.
 */
export declare class TaskBoardSeatBoundary extends Component<{
    children: ReactNode;
}, {
    failed: boolean;
}> {
    state: {
        failed: boolean;
    };
    static getDerivedStateFromError(): {
        failed: boolean;
    };
    componentDidCatch(error: unknown): void;
    render(): ReactNode;
}
/** Provider the board's registered components wrap their subtree in. */
export declare const TaskBoardSeatsProvider: import("react").Provider<TaskBoardSeats>;
/** Read the current seat set (empty when no board registration is above). */
export declare function useTaskBoardSeats(): TaskBoardSeats;
