/**
 * What belongs in a before-image backup.
 *
 * The checkpoint store used to copy every regular file a write-class tool
 * touched (and every workspace file the first-sighting scan found). That is
 * correct for source text and wrong for the bulk of a working tree: rendered
 * PNG frames, browser profiles under `.dsh-tmp`, model weights and build
 * artefacts are either reproducible or never restorable in a useful way, and
 * one PNG sequence can dwarf every source file in the workspace. This module is
 * the single policy that both capture paths consult, so "excluded" means the
 * same thing at the tool boundary, the shell scan and the message-boundary
 * re-check.
 *
 * The policy is deliberately conservative and explainable:
 * - a directory name anywhere in the path (relative to the workspace when the
 *   caller knows it) marks the whole subtree as disposable;
 * - a known binary/media extension is skipped without reading the file;
 * - unknown extensions get a cheap content sniff: a NUL byte in the first
 *   {@link BINARY_SNIFF_BYTES} means binary. UTF-16 BOMs stay text.
 *
 * `includeGlobs` is the escape hatch and wins over every exclusion, including
 * the binary sniff; `excludeGlobs` adds user-defined paths. Glob matching is
 * case-insensitive, `/`-normalized and supports `*`, `**` and `?`.
 *
 * @module dsh-rewind/snapshot-policy
 */
/** Bytes read from the head of an unknown file to decide text vs binary. */
export declare const BINARY_SNIFF_BYTES: number;
/** Per-file ceiling for the automatic first-sighting scan (1 MiB). */
export declare const DEFAULT_SCAN_MAX_FILE_BYTES: number;
/** Per-session snapshot budget (256 MiB), evicted oldest-anchor-first. */
export declare const DEFAULT_MAX_SESSION_BYTES: number;
/** Whole-store snapshot budget (2 GiB), evicted least-recently-used first. */
export declare const DEFAULT_MAX_TOTAL_BYTES: number;
/**
 * Directory names that never carry user source worth restoring. Matched
 * case-insensitively as a whole path segment. `.dsh-tmp` is the harness's own
 * scratch area (browser profiles, downloads); `renders` is Blender's default
 * output directory, which is where the multi-gigabyte PNG sequences live.
 */
export declare const DEFAULT_EXCLUDED_DIRS: readonly string[];
/**
 * Path segments that hold the agent's own bookkeeping rather than user files.
 * They are excluded from capture, and undo also refuses to roll them back: a
 * journal written before this rule existed may still name them, and restoring
 * an audit log or task database would destroy the newer records that made the
 * file look "changed" in the first place.
 */
export declare const MANAGED_STATE_DIRS: readonly string[];
/** True when any path segment is managed agent state (case-insensitive). */
export declare function isManagedStatePath(file: string): boolean;
/**
 * Extensions that are binary or media by definition: never worth a byte-level
 * before-image for a text rewind, and usually the largest files in the tree.
 */
export declare const DEFAULT_EXCLUDED_EXTENSIONS: readonly string[];
export interface SnapshotPolicyOptions {
    /** Extra globs to exclude; matched against the absolute and relative path. */
    readonly excludeGlobs?: readonly string[];
    /** Globs that force inclusion, overriding every exclusion and the sniff. */
    readonly includeGlobs?: readonly string[];
}
/** Why a path was left out of the backup set. */
export type SnapshotSkipReason = 'excluded-dir' | 'excluded-extension' | 'excluded-glob' | 'binary';
/** The policy's answer for one path. */
export type SnapshotPathDecision = {
    readonly ok: true;
    readonly included?: true;
} | {
    readonly ok: false;
    readonly reason: SnapshotSkipReason;
};
/**
 * Compile one glob into an anchored, case-insensitive regexp.
 *
 * `**` crosses separators (and `**\/` also matches zero directories), `*` stays
 * within one segment and `?` matches one non-separator character. Everything
 * else is literal.
 */
export declare function globToRegExp(pattern: string): RegExp;
/**
 * Decide whether one path may be backed up, without reading it.
 * @param path - absolute path being considered.
 * @param policy - user globs.
 * @param workspaceRoot - optional root used to make directory matching relative
 * (so a workspace living under a directory named `tmp` is not excluded wholesale).
 */
export declare function decideSnapshotPath(path: string, policy?: SnapshotPolicyOptions, workspaceRoot?: string): SnapshotPathDecision;
/**
 * Content sniff for an unknown extension: NUL in the head means binary, with a
 * UTF-16 BOM treated as text (those files legitimately contain NUL bytes).
 * A read failure answers `false` so the decision stays with the copy, which
 * will fail loudly on its own.
 */
export declare function looksBinary(head: Uint8Array): boolean;
/** Read the first {@link BINARY_SNIFF_BYTES} of `path` and decide text vs binary. */
export declare function isBinaryFile(path: string): Promise<boolean>;
