/**
 * Host loader entry for the task-board plugin.
 *
 * The Host owns the v2 ledger, action API, cron scheduler, session runner,
 * execution reconciliation, and optional idle-sleep inhibitor. The browser is
 * a same-origin asynchronous view over that service.
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { LlmRuntime } from '@deepseek-ai/dsh-llm';
import { type HostTimerFace } from './host-service.ts';
import { type TaskPermission } from './core/tasks.ts';
import { type TaskBoardConnectionTrust } from './host-routes.ts';
import type { ModelInfoResolver, TaskBoardAttachmentStore } from './host/attachments.ts';
/** Default environment variable holding the authenticated proxy token. */
export declare const DEFAULT_PROXY_TOKEN_ENV = "DSH_TASK_BOARD_PROXY_TOKEN";
export declare const inject: string[];
/** Model-facing announcement: plugin presence, capabilities, and limits. */
export declare const TASK_BOARD_GUIDANCE = "\u672C\u673A\u5DF2\u5B89\u88C5 dsh-task-board \u63D2\u4EF6\uFF08DSH Web GUI \u7684\u4EFB\u52A1\u770B\u677F\uFF09\uFF1A\u4FA7\u8FB9\u680F\u300C\u4EFB\u52A1\u770B\u677F\u300D\u5165\u53E3\uFF1B\u5728 dsh-web \u63D2\u4EF6\u5168\u5BB6\u6876\u4ED3\u5E93\uFF08packages/dsh-task-board\uFF09\u7EDF\u4E00\u7EF4\u62A4\uFF0C\u7ECF\u805A\u5408\u5305 web-ui-all \u4E00\u952E\u5B89\u88C5\u3002\u80FD\u529B\uFF1A\u591A\u5217\u770B\u677F\u7BA1\u7406\u4EFB\u52A1\uFF1BHost \u6743\u5A01\u8D26\u672C\uFF1B\u5173\u95ED\u6D4F\u89C8\u5668\u540E\u4ECD\u7531 Host \u6267\u884C\u548C\u7ED3\u7B97\uFF1B\u4EFB\u52A1\u53EF\u9489\u4F4F\u5DE5\u4F5C\u533A\u3001agent \u9884\u8BBE\u548C\u6743\u9650\uFF1B\u4EFB\u52A1\u53EF\u5EFA\u5B50\u4EFB\u52A1\uFF08\u6DF1\u5EA6\u4E0A\u9650\u53EF\u914D 1..3\uFF0C\u9ED8\u8BA4 1 \u5C42\uFF0C\u5B50\u4EFB\u52A1\u4E0D\u80FD\u518D\u5E26\u5B50\u4EFB\u52A1\uFF09\uFF0C\u6267\u884C\u7236\u4EFB\u52A1\u4F1A\u5E76\u53D1\u6267\u884C\u5176\u5B50\u4EFB\u52A1\u6811\uFF0C\u5B50\u4EFB\u52A1\u53EF\u5355\u72EC\u8986\u76D6\u6743\u9650\u4E0E\u6A21\u578B\uFF1B\u53E6\u6CE8\u518C task_board_* agent \u5DE5\u5177\uFF08list/get/create/update/set_parent/run/manage/schedule\uFF09\uFF0C\u4EFB\u4F55\u4F1A\u8BDD\u90FD\u53EF\u76F4\u63A5\u8BFB\u5199\u770B\u677F\u3001\u5B50\u4EFB\u52A1\u4E0E\u5B9A\u65F6\u8BA1\u5212\uFF0C\u4F46\u8FD0\u884C\u4EFB\u52A1\u4F1A\u771F\u5B9E\u6267\u884C\u5E76\u6D88\u8017\u989D\u5EA6\uFF0C\u9AD8\u4E8E\u4F1A\u8BDD\u9ED8\u8BA4\u6743\u9650\u7684\u7ED1\u5B9A\u4ECD\u5FC5\u987B\u7531\u7528\u6237\u5728 GUI \u4EBA\u5DE5\u786E\u8BA4\uFF08\u5DE5\u5177\u523B\u610F\u4E0D\u63D0\u4F9B\u786E\u8BA4\u80FD\u529B\uFF09\uFF1B\u652F\u6301 Host \u672C\u5730\u65F6\u533A\u7684 5 \u6BB5 cron\uFF0C\u9519\u8FC7\u7684\u89E6\u53D1\u70B9\u4E0D\u8865\u8DD1\uFF1B\u53EF\u9009\u4E14\u9ED8\u8BA4\u5173\u95ED\u7684\u7A7A\u95F2\u7CFB\u7EDF\u7761\u7720\u4FDD\u62A4\u5141\u8BB8\u5C4F\u5E55\u7184\u706D\uFF0C\u4F46\u4E0D\u627F\u8BFA\u62E6\u622A\u5408\u76D6\u3001\u624B\u52A8\u7761\u7720\u3001\u4F11\u7720\u3001\u5173\u673A\u6216\u5524\u9192\u5DF2\u7761\u7720\u673A\u5668\u3002\u6267\u884C\u6D88\u8017 API \u989D\u5EA6\u3002\u7528\u6237\u63D0\u5230\u300C\u4EFB\u52A1\u770B\u677F / \u770B\u677F / \u5B9A\u65F6\u4EFB\u52A1\u300D\u65F6\u5373\u6307\u672C\u63D2\u4EF6\uFF0C\u8BF7\u636E\u6B64\u534F\u4F5C\u3002\u82E5\u4F60\u540C\u65F6\u7528 todo_write \u7EF4\u62A4\u4F1A\u8BDD\u9876\u90E8\u7684\u53EF\u89C1\u8BA1\u5212\u5217\u8868\uFF0C\u6700\u7EC8\u56DE\u590D\u524D\u5FC5\u987B\u518D\u6B21\u8C03\u7528 todo_write \u6536\u5C3E\uFF1A\u6CA1\u6709\u5269\u4F59\u5DE5\u4F5C\u65F6\u4E0D\u8981\u4FDD\u7559 in_progress\uFF0C\u5DF2\u5B8C\u6210\u7684\u6700\u540E\u4E00\u6B65\u8981\u6807\u4E3A completed\u3002";
/**
 * Plugin config, validated by the same-named schemastery schema.
 *
 * This schema IS the board's settings page: the 0.1.7 Host serves one
 * configuration form per profile entry from the entry's own Config, so the
 * fields the browser card edits are marked volatile — the Loader commits
 * an edit into the running fiber's references without remounting the row (no
 * settings document of the plugin's own exists any more). A field without the
 * marker is refused by the settings write path, which fences writes on
 * volatility.
 */
export interface Config {
    /**
     * When true (default), a system-prompt section announces the board to every
     * agent. Set false to keep the board silent in prompts; agents then learn
     * about it only when the user mentions it.
     */
    announceToAgent?: Volatile<boolean>;
    /** Master switch for the plugin (browser half + host announcement). */
    enabled?: Volatile<boolean>;
    /** Prevent idle system sleep while sessions run or schedules are armed. */
    preventIdleSleep?: Volatile<boolean>;
    /**
     * Canonical reverse-proxy Host authorities admitted with a server-side
     * token. Deployment-level, so it stays an ordinary field: editing it reloads
     * the row, which re-registers the routes with the new proxy access.
     */
    trustedProxyHosts?: string[];
    /** Environment variable whose value the authenticated proxy injects upstream. */
    proxyTokenEnv?: string;
    /**
     * Whether the operator's OWN reverse proxy or tunnel may speak for the
     * browser (default OFF). Off keeps the pre-existing fence exactly: a request
     * that carries a forwarding header is never local, so only a direct loopback
     * client or an allowlisted token-injecting proxy reaches the board (issue
     * #1906). On admits one narrower case — a forwarded request whose socket and
     * Host are both this machine's loopback upstream, i.e. the proxy dials the
     * board itself (issue #1918) — and still requires the browser same-origin
     * marker, so a third party's tunnel is only trusted while the operator says
     * it is. Volatile: the fence reads it at each request, so an edit binds the
     * next request without re-registering the routes.
     */
    trustForwardedProxy?: Volatile<boolean>;
    /**
     * An explicit baseline for the permission confirmation gate. Left unset, the
     * board follows the Host's own default permission preset — the value new DSH
     * sessions start at — and falls back to `read-only` when the deployment
     * serves no permission catalog. A card whose effective permission (handover
     * bundle or pin) is above the baseline requires a human confirmation before
     * it may run; cron refuses unconfirmed cards.
     */
    sessionDefaultPermission?: TaskPermission;
    /**
     * Subtask depth limit, 1..3 (default 1). At 1 a task may carry one level of
     * subtasks and a subtask cannot be given subtasks of its own; raising it
     * allows deeper trees. Every extra level is another tree the card's own
     * session may have to dispatch, so the ceiling is deliberately small.
     */
    maxSubtaskDepth?: Volatile<number>;
    /**
     * How often, in seconds, the Host re-reads the DSH session roster while the
     * board has something to reconcile: a running card, an open execution, or an
     * active provider extension. An idle board with none of those does not poll
     * at all, so this cadence only bounds how quickly a running card settles.
     */
    sessionPollSeconds?: Volatile<number>;
    /**
     * How many run launches this board may have in flight at once (1..16,
     * default 3). A run opens one session, so a burst is several cards run at
     * once (several tabs, or a due schedule firing while a manual run starts);
     * without a bound the Host would ask DSH for all of them in the same tick.
     * This is the mechanism that enforces the repository's measured guidance for
     * heavy implementation subagents. Runs wait their turn instead of being
     * dropped, and every one of them still starts. Read at each admission, so an
     * edit bounds the next launch of a run that is still queueing.
     */
    runLaunchWidth?: Volatile<number>;
    /**
     * Daily token ceiling for the work this board dispatches (default 0 = no
     * gate). Tokens, not money: the ledger the board measures against prices
     * DeepSeek's own routes only, so a cost cap would read 0 elsewhere. Read at
     * each gate, so an edit binds the next run without a remount; a manual
     * run/rerun whose day already spent the cap is refused, and a due occurrence
     * is skipped onto the scheduler with its run budget untouched.
     */
    spendBudgetTokens?: Volatile<number>;
    /**
     * Agent preset a NEW card starts from (volatile, default blank = not set).
     * A prefill, never a pin: the create dialog opens with it selected, the
     * caller may override it, and the card stores what it was created with. It
     * reaches the create path only when that caller opts in with
     * `applyCardDefaults`, so the extension provider's own create and the legacy
     * import are untouched.
     */
    cardDefaultMode?: Volatile<string>;
    /**
     * Permission a NEW card starts from (volatile, default blank = not set), one
     * of the three presets. A prefill like the rest: a value above
     * `sessionDefaultPermission` still has to be confirmed by a human before the
     * card may run, because the pre-execution gate is what decides that.
     */
    cardDefaultPermission?: Volatile<TaskPermission | ''>;
    /**
     * Model a NEW card starts from (volatile, default blank = not set).
     */
    cardDefaultModel?: Volatile<string>;
    /**
     * Reasoning level a NEW card starts from (volatile, default blank = not set).
     * Bound to `cardDefaultModel` exactly as a card's own level is bound to its
     * own model: it applies only while the card's final model IS that default
     * model, and a blank `cardDefaultModel` makes it inert.
     */
    cardDefaultReasoningEffort?: Volatile<string>;
}
/**
 * Profile-patch shape of {@link Config}: what the Host validates the row's
 * config against, before the schema turns volatile fields into live references
 * and applies defaults. Declared separately because the two sides no longer
 * share one shape, so the schema is annotated `z<ConfigInput, Config>` — the
 * same split the git-family packages use. The annotation is also what keeps the
 * emitted declaration portable: an unannotated schema holding a nested object
 * array infers a type that cannot be named without reaching into a transitive
 * dependency's own types.
 */
export interface ConfigInput {
    /** Announce the board in the system prompt. */
    announceToAgent?: boolean;
    /** Master switch for the plugin. */
    enabled?: boolean;
    /** Prevent idle system sleep while sessions run or schedules are armed. */
    preventIdleSleep?: boolean;
    /** Canonical reverse-proxy Host authorities. */
    trustedProxyHosts?: string[];
    /** Environment variable whose value the authenticated proxy injects. */
    proxyTokenEnv?: string;
    /** Trust a forwarded request that landed on this machine's loopback upstream; default off. */
    trustForwardedProxy?: boolean;
    /** Explicit baseline for the permission confirmation gate; unset follows the Host default. */
    sessionDefaultPermission?: TaskPermission;
    /** Subtask depth limit, 1..3. */
    maxSubtaskDepth?: number;
    /** Roster-poll cadence in seconds while the board has work to reconcile. */
    sessionPollSeconds?: number;
    /** Concurrent run launches allowed at once, 1..16. */
    runLaunchWidth?: number;
    /** Daily token ceiling for board runs; 0 disables the gate. */
    spendBudgetTokens?: number;
    /** Agent preset a new card starts from; blank = not set. */
    cardDefaultMode?: string;
    /** Permission a new card starts from; blank = not set. */
    cardDefaultPermission?: TaskPermission | '';
    /** Model a new card starts from; blank = not set. */
    cardDefaultModel?: string;
    /** Reasoning level a new card starts from; blank = not set. */
    cardDefaultReasoningEffort?: string;
}
export declare const Config: z<ConfigInput, Config>;
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * Volatile config values were committed into the running fiber without a
         * remount; dispatched to the owning fiber only. Spelled here because the
         * Loader package is not a dependency of this plugin, with the Loader's own
         * shape so the two declarations merge when a Host program carries both.
         * @param paths - changed config paths as key arrays; every value is committed before dispatch.
         * @mode emit
         */
        'loader/volatile-update'(paths: readonly (readonly string[])[]): void;
    }
}
/**
 * Read one config field's current value.
 *
 * The Loader hands schema-volatile fields as stable references it commits in
 * place, so a live value must be read at use time rather than captured when
 * the plugin activates; a plain value (a programmatic mount, or a field the
 * schema does not mark volatile) is returned as it stands.
 * @param field - the config field as the Loader handed it.
 * @param fallback - value to use when the field is absent.
 * @returns the effective field value.
 */
export declare function readConfigField<T>(field: Volatile<T> | T | undefined, fallback: T): T;
/**
 * Resolve proxy access without ever placing the token value in plugin config.
 *
 * The forwarded-proxy switch travels as a reader rather than a value: it is
 * schema-volatile, so the fence must read it when a request arrives instead of
 * when the routes are registered.
 * @param config - the resolved plugin config.
 * @param env - environment holding the proxy token value.
 * @returns the route access handed to {@link makeTaskBoardRoutes}.
 */
export declare function resolveProxyAccess(config: Config | undefined, env?: NodeJS.ProcessEnv): {
    trustedProxyHosts: string[];
    proxyToken?: string;
    trustForwardedProxy: () => boolean;
};
/**
/**
 * Schema default for the forwarded-proxy switch, re-read for hand-built
 * contexts. Deliberately false: a deployment that never configured it keeps
 * refusing every forwarded request, which is the #1906 fence.
 */
export declare const DEFAULT_TRUST_FORWARDED_PROXY = false;
/**
 * Resolve the composition's optional `connection` service.
 *
 * The service is the Host's own browser-session authority: it fronts every
 * `/api` request with the Host/Origin fence and the signed `dsh-auth-*` cookie,
 * which is what a deployment behind a reverse proxy or ingress validates on the
 * same authority the GUI is served from. The board bridges it instead of
 * repeating that check, so a proxy request the Host already authenticated is
 * admitted without a board-specific host allowlist (issue #1930). It is
 * deliberately resolved like the agent-tool registry rather than injected:
 * a composition that serves no connection keeps mounting the board on the
 * pre-existing loopback fence, and one that mounts the service later is picked
 * up on the next request because the fence asks this resolver each time.
 * @param ctx - the plugin context.
 * @returns the trust face, or undefined when this deployment serves none.
 */
export declare function resolveConnectionTrust(ctx: Context): TaskBoardConnectionTrust | undefined;
/** The registry face the agent tools register into. */
interface AgentToolRegistry {
    register(definition: ToolDefinition): () => void;
    /** Scoped lookup; present on the real registry, absent on a stub that only registers. */
    get?(name: string, scope?: unknown): unknown;
}
/**
 * Resolve the optional agent-tool registry. The board deliberately does not
 * inject it: a deployment whose runtime serves no registry must still mount the
 * whole board and lose only the agent-tool surface, the same tolerance the
 * optional llm service gets.
 * @param ctx - the plugin context.
 * @returns the registry, or undefined when this deployment serves none.
 */
export declare function resolveToolRegistry(ctx: Context): AgentToolRegistry | undefined;
/**
 * Resolve the native cordis timer service (dsh-base's own `cordis-plugin-timer`
 * row). The board arms its schedule through it so unloading the row clears
 * every pending timer with the owning fiber, instead of the row tracking raw
 * process handles by hand. A composition that serves no timer service keeps
 * working on the process globals.
 * @param ctx - the plugin context.
 * @returns the timer face, or undefined when this deployment serves none.
 */
export declare function resolveHostTimers(ctx: Context): HostTimerFace | undefined;
/**
 * The Host's own default permission preset, mapped into the board's vocabulary.
 *
 * This is the value new DSH sessions start at (the deployment's `permission`
 * settings row), so a board that follows it treats an ordinary card exactly as
 * the Host would. Absent when the deployment serves no permission catalog, or
 * its default is a current-session identity (`auto`) that names no fixed
 * sandbox mode; the caller then keeps the fail-safe baseline.
 * @param ctx - the plugin context.
 * @returns the Host default as a board permission, or undefined when unreadable.
 */
export declare function resolveHostDefaultPermission(ctx: Context): TaskPermission | undefined;
/**
 * Read the optional `llm` service. The board deliberately does not inject it:
 * a deployment without a model must still mount the board, and the parse route
 * answers a typed failure instead of the plugin failing to load (issue #1540).
 * @param ctx - the plugin context.
 * @returns the llm service, or undefined when this deployment serves none.
 */
export declare function resolveLlmRuntime(ctx: Context): LlmRuntime | undefined;
/**
 * Resolve the optional attachment storage.
 *
 * The board does not inject the service: a deployment without one must still
 * mount the board, and every attachment surface then answers with a typed
 * "storage unavailable" failure instead of the plugin failing to load.
 * @param ctx - the plugin context.
 * @returns the attachment storage, or undefined when this deployment serves none.
 */
export declare function resolveAttachmentStore(ctx: Context): TaskBoardAttachmentStore | undefined;
/**
 * The model-info reader the image preflight uses.
 *
 * It asks the OFFICIAL model service about one exact route. The model catalog
 * the board already publishes carries no modality information and must not be
 * used to answer that question: only the model's own declared input
 * modalities can refuse an image route, and a route whose modalities cannot be
 * read is UNKNOWN and therefore allowed.
 * @param ctx - the plugin context.
 * @returns the reader, or undefined when the deployment serves no model service.
 */
export declare function resolveModelInfoReader(ctx: Context): ModelInfoResolver | undefined;
/**
 * The subset of `sessionController` the board uses to wake a cold persisted
 * session before running a slash command on it (issue #1861).
 */
interface SessionControllerFace {
    resolveAgent(sessionId: Parameters<Context['agents']['get']>[0]): Promise<{
        readonly agent: Parameters<Context['commands']['execute']>[0];
    } | {
        readonly error: {
            readonly message?: string;
        };
    }>;
}
/**
 * Resolve the optional `sessionController` service. Like the tool registry and
 * the llm runtime, it is read dynamically so capture-only test contexts that do
 * not mount the full session controller still activate the board.
 * @param ctx - the plugin context.
 * @returns the session controller face, or undefined when unavailable.
 */
export declare function resolveSessionController(ctx: Context): SessionControllerFace | undefined;
/**
 * Resolve the live Agent for an execution session, resuming a cold persisted
 * session through `sessionController.resolveAgent` when it is not yet in
 * `ctx.agents` (issue #1861).
 *
 * A fresh run (`session/create`) or a session the browser is currently
 * following is already in `ctx.agents`, so the fast path returns immediately.
 * A scheduled or manual reuse of a cold session — one that `session/list`
 * reports as idle from disk without activating its Agent — is not in
 * `ctx.agents` when `pinAndPrompt` runs `/permission` ahead of
 * `session/selectModel` and `session/prompt`; delegating to
 * `sessionController.resolveAgent` resumes it with its recorded preset and
 * model-selection state, matching what those gateway endpoints do next.
 * @param ctx - the plugin context.
 * @param sessionId - the target execution session id.
 * @returns the live Agent for `sessionId`.
 */
export declare function resolveExecutionAgent(ctx: Context, sessionId: Parameters<Context['agents']['get']>[0]): Promise<Parameters<Context['commands']['execute']>[0]>;
/**
 * Activate the board's host half: ledger, routes, cron scheduler, power
 * inhibitor, and the model-facing announcement.
 *
 * The effective settings are the config the Host hands this row. The fields
 * the browser card edits are schema-volatile, so the Loader commits an
 * edit into the running fiber's references instead of remounting the row —
 * `sync` therefore reads them at use time and follows
 * `loader/volatile-update`, the event the Loader emits once it has committed
 * them. Every other field reloads the row, which re-runs this activation.
 * @param ctx - the plugin context (systemPrompt injected).
 * @param config - resolved plugin config (schema defaults applied by the loader).
 */
export declare const apply: typeof applyImpl;
declare function applyImpl(ctx: Context, config?: Config): void;
export {};
