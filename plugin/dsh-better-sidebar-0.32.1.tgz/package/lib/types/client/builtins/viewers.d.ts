import type { FileViewerDescriptor } from '../service.ts';
/** The 5 built-in file viewer descriptors. */
export declare function builtinViewers(): readonly FileViewerDescriptor[];
