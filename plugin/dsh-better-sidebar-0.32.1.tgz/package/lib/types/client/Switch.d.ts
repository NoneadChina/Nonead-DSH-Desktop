/** One labelled switch. */
export declare function Switch(props: {
    checked: boolean;
    onChange: (next: boolean) => void;
    label: string;
}): import("react").JSX.Element;
