/**
 * Path projection helpers shared by the explorer rows: workspace-relative
 * mentions and session-cwd-relative "copy relative path".
 * The fs-tree joins with '/' even on Windows, so both separators normalize
 * to '/' before comparison.
 *
 * This module is dependency-free (no node:path in the client bundle): the
 * host is the authority for path semantics, so this mirror deliberately
 * accepts a SUPERSET of absolute forms — anything a Windows host would emit
 * (drive letters, UNC) plus POSIX roots. A form the host would reject
 * (e.g. a backslash UNC path on a POSIX host) passes through here and then
 * fails loudly in the host's requireAbsolute instead of being silently
 * joined onto the cwd.
 */
/**
 * Mirror of the host's absolute-path notion (see fs-tree.requireAbsolute):
 * POSIX roots, Windows drive letters, and Windows UNC network shares in
 * both backslash (`\\server\share\...`) and forward-slash
 * (`//server/share/...`) form. Deliberately a superset — see the module
 * comment — so a produced UNC path is never joined onto the cwd.
 */
export declare function isAbsolutePath(path: string): boolean;
/**
 * The path relative to the session's working directory.
 * @param cwd - the explorer root (absolute).
 * @param path - an absolute entry path from the fs-tree.
 * @returns the relative path with '/' separators ('.' for the cwd itself),
 * or `path` unchanged when it lies outside the cwd.
 *
 * The prefix test is case-insensitive: Windows paths (and macOS's
 * case-insensitive volumes) may arrive with different casing than the cwd
 * row, and the containment decision must not depend on it. The returned
 * relative text keeps the caller's own casing.
 */
export declare function relativeTo(cwd: string, path: string): string;
/**
 * Project an absolute explorer entry against the host-confirmed workspace
 * root. Unlike copy-relative-path's `relativeTo`, mention insertion must
 * never fall back to an absolute token. Unknown roots, traversal components
 * and paths outside the workspace are refused. Windows drive/UNC paths are
 * case-insensitive; POSIX paths retain their case-sensitive distinction.
 */
export declare function workspaceRelativePath(root: string | undefined, path: string): string | undefined;
/**
 * Whether `target` lies under `base` (or equals it), tolerant of separator
 * style and of letter case. Case-insensitive on every platform by design:
 * the volume may report different casing than the cwd row, and this decision
 * must not depend on it. Used by tab retargeting after rename/delete and by
 * tree search expansion to decide whether an absolute row still belongs
 * under the session root.
 */
export declare function isWithinWorkspace(base: string, target: string): boolean;
/**
 * The last path segment of a '/'- or '\'-separated path (a diff tab title,
 * a worktree label). Returns the whole string when no separator is present.
 */
export declare function baseName(path: string): string;
/**
 * The lowercased file extension of a path ('' when none). The dot must sit
 * inside the last segment — a dot in a directory name is not an extension.
 * Shared by the editor language mapping (lang.ts) and the viewer registry's
 * extension matching (service.ts), which both live in the core bundle.
 */
export declare function extOf(path: string): string;
/**
 * Resolve a (possibly relative) path against the session cwd for the sidebar.
 * Absolute detection mirrors the host (see {@link isAbsolutePath}): POSIX
 * roots, drive letters and UNC shares must not be joined onto the cwd.
 */
export declare function resolveSidebarPath(cwd: string | undefined, path: string): string;
/**
 * Resolve one client path and normalize it to the base's separator dialect.
 *
 * A folder window roots the shared FileTree at this value. The tree keys each
 * level by the root it REQUESTED, while every listing answer is keyed by the
 * host's `path.resolve`'d absolute path — on Windows a chat file address
 * ("research/workspace-sections-campaign/x", session-relative and
 * `/`-separated) joined onto a `C:\…` cwd used to leave MIXED separators: two
 * different strings for one directory, so the root level waited on its
 * loading placeholder forever (#1029 follow-up). Normalizing to the base's
 * dialect also drops a trailing separator, exactly as `path.resolve` does
 * (a drive root keeps it). A non-Windows base returns the plain join: on
 * POSIX a backslash is a legal filename character.
 */
export declare function resolveNativeSidebarPath(cwd: string | undefined, path: string): string;
