/**
 * Pure start-page layout math: ordering, visibility, the two-column threshold,
 * and the overflow that collapses into the "More" card.
 */
/** The wide layout starts at two columns from this pane width on. */
export declare const GUIDE_TWO_COLUMN_MIN_WIDTH = 520;
/** Rows a document without a stored value gets. */
export declare const GUIDE_DEFAULT_ROWS = 6;
/** One card the layout reasons about. */
export interface GuideLayoutEntry {
    readonly key: string;
}
/** Inputs of computeGuideLayout. */
export interface GuideLayoutOptions {
    /** Explicit start-page order, by card key. */
    readonly order: readonly string[];
    /** Visibility overrides; an absent key is visible. */
    readonly hidden: Readonly<Record<string, boolean>>;
    /** Maximum rows; normalized to at least one. */
    readonly rows: number;
    /** Pane width in CSS pixels. */
    readonly width: number;
    /**
     * Keep one cell for the "More" card even when every entry fits. The start
     * page always offers host actions (browse/create plugins, reorder), so the
     * card is a persistent affordance rather than overflow-only.
     */
    readonly reserveMore?: boolean;
}
/** The settled layout one guide render uses. */
export interface GuideLayout<T extends GuideLayoutEntry> {
    readonly columns: number;
    readonly rows: number;
    readonly capacity: number;
    readonly visible: readonly T[];
    readonly overflow: readonly T[];
    readonly showMore: boolean;
}
/** One or two columns for a pane width. */
export declare function columnsForWidth(width: number): number;
/** Normalize a stored row count; anything below one falls back to the default. */
export declare function normalizeGuideRows(rows: number): number;
/**
 * Sort entries by the stored order. Keys absent from the order follow in their
 * registration order; keys in the order that no longer exist do not matter.
 */
export declare function orderGuideEntries<T extends GuideLayoutEntry>(entries: readonly T[], order: readonly string[]): T[];
/**
 * Resolve the cards one start page draws.
 *
 * Hidden cards are removed before the capacity check, so hiding a card never
 * creates an artificial overflow. Once the remaining list exceeds the row
 * budget, ONE slot goes to the "More" card: visible cards are
 * "capacity - 1", and the rest live in its menu. At the minimum capacity of
 * one, the page therefore shows the More card alone.
 */
export declare function computeGuideLayout<T extends GuideLayoutEntry>(entries: readonly T[], options: GuideLayoutOptions): GuideLayout<T>;
