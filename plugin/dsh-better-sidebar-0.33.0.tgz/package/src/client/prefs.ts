/**
 * Client-side read of the user-facing "Side card" preferences. The host owns
 * the namespace through the settings seam (in-process); the DSH settings RPC
 * domain only serves allowlisted namespaces to configuration clients, so the
 * client reads and writes THIS namespace through the plugin's own fenced
 * /sidebar routes instead (api.settingsGet/settingsUpdate). Any failure
 * (route rejected, namespace absent, a field of the wrong type, a value out
 * of the contract range) falls back to the schema defaults — the side card
 * must keep working exactly as composed when the settings surface is missing.
 */
import type { api } from './api.ts'
import {
  EXPLORER_EXCLUDE_DEFAULTS,
  SIDEBAR_PREFS_DEFAULTS,
  SIDECHAT_PREFS_ID,
  SIDECHAT_SUBMIT_KEY_SETTING,
  SIDECHAT_TABS_SETTING,
  parseSidechatSubmitKey,
  parseSidechatTabsMode,
  type SidebarPrefs,
  type SidechatSubmitKey,
  type SidechatTabsMode,
} from '../prefs-shared.ts'

export {
  EXPLORER_EXCLUDE_DEFAULTS,
  SIDEBAR_PREFS_DEFAULTS,
}
export type { SidebarPrefs }

/** The settings wire face the preferences need (a subset of the plugin api). */
export type SidebarSettingsClient = Pick<typeof api, 'settingsGet' | 'settingsUpdate'>

/** Validate one raw resolved value into {@link SidebarPrefs}. Used for the
 * settings.get payload AND the settings.update response (both carry the
 * layered resolved value); any malformed field falls back to its default.
 * @param value - the raw resolved section from the settings wire.
 * @returns validated prefs (always well-formed).
 */
export function parsePrefs(value: unknown): SidebarPrefs {
  if (value === null || typeof value !== 'object') return { ...SIDEBAR_PREFS_DEFAULTS }
  const record = value as Record<string, unknown>
  // The result is built from DECLARED fields only, so a key this release no
  // longer has — the retired title-bar compatibility set (`titleBarScheme` /
  // `titleBarPresetId` / `titleBarCompat` / `titleBarStripPx`), a legacy
  // `workspaceFence` — is dropped here instead of reaching the UI. The host
  // schema passes unknown keys through untouched (config.ts); this is the
  // typed face that makes them inert.
  return {
    autoOpenSubagent: typeof record.autoOpenSubagent === 'boolean'
      ? record.autoOpenSubagent
      : SIDEBAR_PREFS_DEFAULTS.autoOpenSubagent,
    autoOpenJobs: typeof record.autoOpenJobs === 'boolean'
      ? record.autoOpenJobs
      : SIDEBAR_PREFS_DEFAULTS.autoOpenJobs,
    tasksViewMode: record.tasksViewMode === 'tree' || record.tasksViewMode === 'graph'
      ? record.tasksViewMode
      : SIDEBAR_PREFS_DEFAULTS.tasksViewMode,
    tasksAutoFoldSettled: typeof record.tasksAutoFoldSettled === 'boolean'
      ? record.tasksAutoFoldSettled
      : SIDEBAR_PREFS_DEFAULTS.tasksAutoFoldSettled,
    tasksAutoFoldBranches: typeof record.tasksAutoFoldBranches === 'boolean'
      ? record.tasksAutoFoldBranches
      : SIDEBAR_PREFS_DEFAULTS.tasksAutoFoldBranches,
    tasksAutoFoldIdle: typeof record.tasksAutoFoldIdle === 'boolean'
      ? record.tasksAutoFoldIdle
      : SIDEBAR_PREFS_DEFAULTS.tasksAutoFoldIdle,
    jobsAutoCollapse: typeof record.jobsAutoCollapse === 'boolean'
      ? record.jobsAutoCollapse
      : SIDEBAR_PREFS_DEFAULTS.jobsAutoCollapse,
    mobileNoAutoOpen: typeof record.mobileNoAutoOpen === 'boolean'
      ? record.mobileNoAutoOpen
      : SIDEBAR_PREFS_DEFAULTS.mobileNoAutoOpen,
    mobileDefaultTree: typeof record.mobileDefaultTree === 'boolean'
      ? record.mobileDefaultTree
      : SIDEBAR_PREFS_DEFAULTS.mobileDefaultTree,
    agentOpenTools: typeof record.agentOpenTools === 'boolean'
      ? record.agentOpenTools
      : SIDEBAR_PREFS_DEFAULTS.agentOpenTools,
    editorExplorer: typeof record.editorExplorer === 'boolean'
      ? record.editorExplorer
      : SIDEBAR_PREFS_DEFAULTS.editorExplorer,
    editorGitGutter: typeof record.editorGitGutter === 'boolean'
      ? record.editorGitGutter
      : SIDEBAR_PREFS_DEFAULTS.editorGitGutter,
    explorerExclude: stringArrayOf(record.explorerExclude),
    customCss: typeof record.customCss === 'string'
      ? record.customCss
      : SIDEBAR_PREFS_DEFAULTS.customCss,
    htmlViewerNoSandbox: typeof record.htmlViewerNoSandbox === 'boolean'
      ? record.htmlViewerNoSandbox
      : SIDEBAR_PREFS_DEFAULTS.htmlViewerNoSandbox,
    htmlViewerDefaultUnsafe: typeof record.htmlViewerDefaultUnsafe === 'boolean'
      ? record.htmlViewerDefaultUnsafe
      : SIDEBAR_PREFS_DEFAULTS.htmlViewerDefaultUnsafe,
    tabsEnabled: booleanMapOf(record.tabsEnabled),
    viewersEnabled: booleanMapOf(record.viewersEnabled),
    pluginSettings: pluginSettingsMapOf(record.pluginSettings),
    guideRows: positiveIntegerOf(record.guideRows, SIDEBAR_PREFS_DEFAULTS.guideRows),
    guideOrder: uniqueStringListOf(record.guideOrder),
    guideHidden: booleanMapOf(record.guideHidden),
    guideAlign: record.guideAlign === 'top' || record.guideAlign === 'center'
      ? record.guideAlign
      : SIDEBAR_PREFS_DEFAULTS.guideAlign,
    guideTakeover: typeof record.guideTakeover === 'boolean'
      ? record.guideTakeover
      : SIDEBAR_PREFS_DEFAULTS.guideTakeover,
  }
}

/** One positive safe integer, or the fallback (row counts are 1-based). */
function positiveIntegerOf(value: unknown, fallback: number): number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 1 ? value : fallback
}

/** A trimmed, de-duplicated string list preserving first-seen order. */
function uniqueStringListOf(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  const out: string[] = []
  const seen = new Set<string>()
  for (const item of value) {
    if (typeof item !== 'string') continue
    const trimmed = item.trim()
    if (trimmed === '' || seen.has(trimmed)) continue
    seen.add(trimmed)
    out.push(trimmed)
  }
  return out
}

/**
 * Validate the plugin-owned settings map (v0.12.0+): `{ descriptorId: { key:
 * value } }`, nested open maps. Any non-object value (or a malformed whole)
 * falls back to the empty map — the schema defaults already guard the wire
 * shape, this is the client's second line. The one CONTRACTED value inside the
 * open map is the side-chat composer's submit key (a mode, not free-form data):
 * it is normalized to a known mode here, so an absent / legacy / hand-edited
 * value reaches the view as the default instead of as an unknown gesture.
 */
function pluginSettingsMapOf(value: unknown): Record<string, Record<string, unknown>> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return {}
  const out: Record<string, Record<string, unknown>> = {}
  for (const [id, blob] of Object.entries(value as Record<string, unknown>)) {
    if (blob !== null && typeof blob === 'object' && !Array.isArray(blob)) {
      out[id] = blob as Record<string, unknown>
    }
  }
  const sidechat = out[SIDECHAT_PREFS_ID]
  if (sidechat !== undefined) {
    // Copy, never mutate the wire payload: the resolved document is shared
    // with the settings page's revision bookkeeping.
    out[SIDECHAT_PREFS_ID] = {
      ...sidechat,
      [SIDECHAT_SUBMIT_KEY_SETTING]: parseSidechatSubmitKey(sidechat[SIDECHAT_SUBMIT_KEY_SETTING]),
    }
  }
  return out
}

/**
 * The side-chat composer's submission mode from the parsed preferences. The
 * value is the side-chat feature's own plugin-owned setting (see
 * `prefs-shared.ts`), so a document that never chose one reads the default.
 * @param prefs - the parsed side card preferences.
 * @returns the configured submit-key mode.
 */
export function sidechatSubmitKeyOf(prefs: SidebarPrefs): SidechatSubmitKey {
  return parseSidechatSubmitKey(prefs.pluginSettings[SIDECHAT_PREFS_ID]?.[SIDECHAT_SUBMIT_KEY_SETTING])
}

/**
 * The side-chat page mode: one shared native page (the default) or one page
 * per thread. The value is the feature's own plugin-owned setting, so a
 * document that never chose one reads the default.
 * @param prefs - the parsed side card preferences.
 * @returns the configured page mode.
 */
export function sidechatTabsModeOf(prefs: SidebarPrefs): SidechatTabsMode {
  return parseSidechatTabsMode(prefs.pluginSettings[SIDECHAT_PREFS_ID]?.[SIDECHAT_TABS_SETTING])
}

/**
 * Validate the exclude-pattern list: a JSON array whose string entries
 * survive (trimmed; blanks dropped). Anything else falls back to the stock
 * list — the schema defaults already guard the wire shape, this is the
 * client's second line.
 */
function stringArrayOf(value: unknown): string[] {
  if (!Array.isArray(value)) return [...EXPLORER_EXCLUDE_DEFAULTS]
  const out: string[] = []
  for (const item of value) {
    if (typeof item !== 'string') continue
    const trimmed = item.trim()
    if (trimmed !== '') out.push(trimmed)
  }
  return out
}

/**
 * Validate one enable-switch map (per-tab / per-viewer). Only boolean values
 * survive; a non-object or a non-boolean entry falls back to the empty map /
 * drops the entry — an absent key means the feature stays enabled.
 */
function booleanMapOf(value: unknown): Record<string, boolean> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return {}
  const out: Record<string, boolean> = {}
  for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
    if (typeof item === 'boolean') out[key] = item
  }
  return out
}

/**
 * Read the resolved side card preferences through the plugin's settings route.
 * @param settings - the settings wire face (the plugin api by default).
 * @returns validated prefs, or the schema defaults when the route rejects,
 * the namespace is absent, or a stored value violates the contract.
 */
export async function loadPrefs(settings: SidebarSettingsClient): Promise<SidebarPrefs> {
  try {
    const view = await settings.settingsGet()
    return parsePrefs(view.value)
  } catch {
    // Transport/fence rejection or a malformed response: keep the defaults.
    return { ...SIDEBAR_PREFS_DEFAULTS }
  }
}

/**
 * Read the external-disable flag from the same settings route: the
 * dsh-web-ui family's aionui-panel provider choice. True only when the host
 * resolved `aionui-panel.rightPanel` to 'aionui-panel' — while true the
 * sidebar must not mount (the two right panels are mutually exclusive). Any
 * failure (route rejected, aionui absent, malformed response) reads false,
 * so a missing family never hides the sidebar.
 * @param settings - the settings wire face (the plugin api by default).
 * @returns the external-disable flag (false on any failure).
 */
export async function loadExternalDisable(settings: SidebarSettingsClient): Promise<boolean> {
  try {
    const view = await settings.settingsGet()
    return view.externalDisable === true
  } catch {
    return false
  }
}

/** The boot decision both the prefs and the external-disable flag need:
 *  ONE settings fetch answers both (the boot path used to await
 *  {@link loadPrefs} and {@link loadExternalDisable} serially — two round
 *  trips of the same document before the first paint, and the second had no
 *  timeout, so a stalled wire could keep the sidebar unmounted forever). */
export interface BootDecision {
  prefs: SidebarPrefs
  suspended: boolean
}

export async function loadBootDecision(settings: SidebarSettingsClient): Promise<BootDecision> {
  try {
    const view = await settings.settingsGet()
    return { prefs: parsePrefs(view.value), suspended: view.externalDisable === true }
  } catch {
    return { prefs: { ...SIDEBAR_PREFS_DEFAULTS }, suspended: false }
  }
}

/** The first-paint budget for the boot settings read. A cold start or a slow
 *  host / LAN can push the route past this; the sidebar still mounts on the
 *  defaults, and {@link awaitBootDecision} adopts the eventual answer. */
const BOOT_DECISION_TIMEOUT_MS = 2000

/**
 * Resolve the boot decision within `timeoutMs`, and when the settings route
 * misses that budget, keep watching the SAME read so its answer is still
 * applied late. A timed-out boot must not strand the store on its defaults
 * forever: the store's own `settings/document-updated` path fires on a
 * DOCUMENT change, not on a late read, so a disabled third-party tab type
 * would otherwise stay registered until the user toggled it (#1159).
 *
 * `loadBootDecision` never rejects (it falls back to the schema defaults), so
 * only the late-resolving case needs a continuation. `onLate` runs at most
 * once, and only when the timeout won the race — never after an in-time
 * answer. The caller still owns its liveness / supersession checks (a
 * disposed fiber, or a newer settings update that already applied).
 * @param settings - the settings wire face (the plugin api by default).
 * @param onLate - receives the answer that landed after the timeout.
 * @param timeoutMs - the first-paint budget in milliseconds.
 * @returns the in-time decision, or null when the timeout won the race.
 */
export async function awaitBootDecision(
  settings: SidebarSettingsClient,
  onLate: (decision: BootDecision) => void,
  timeoutMs: number = BOOT_DECISION_TIMEOUT_MS,
): Promise<BootDecision | null> {
  const read = loadBootDecision(settings)
  let timer: ReturnType<typeof setTimeout> | undefined
  const timeout = new Promise<null>((resolve) => {
    timer = setTimeout(() => resolve(null), timeoutMs)
  })
  const decision = await Promise.race([read, timeout])
  clearTimeout(timer)
  if (decision !== null) return decision
  // The budget expired: the caller mounts on the defaults now, and this
  // continuation adopts the same read's answer when it lands. No catch —
  // loadBootDecision cannot reject.
  void read.then(onLate)
  return null
}
