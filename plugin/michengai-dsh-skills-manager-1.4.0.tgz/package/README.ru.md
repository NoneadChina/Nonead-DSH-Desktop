<p align="center">
  <img src="assets/branding/dsh-banner-en.webp" alt="DSH Skills Manager" width="100%">
</p>

<div align="center">

# DSH Skills Manager

  **Единое управление локальными и проектными навыками, установка из GitHub, предварительный просмотр обновлений и восстановление резервных копий**

  [简体中文](README.zh-CN.md) · [English](README.en.md) · [日本語](README.ja.md) · [Español](README.es.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Русский](README.ru.md) · [Português](README.pt.md)

  [История изменений](CHANGELOG.md) · [Лицензия](LICENSE)

  [![Лицензия: Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](LICENSE)
  [![npm package](https://img.shields.io/npm/v/%40michengai%2Fdsh-skills-manager.svg?label=npm%20package)](https://www.npmjs.com/package/@michengai/dsh-skills-manager)
  [![npm скачивания](https://img.shields.io/npm/dt/%40michengai%2Fdsh-skills-manager.svg?label=npm%20downloads)](https://www.npmjs.com/package/@michengai/dsh-skills-manager)
  [![DSH Web Plugin](https://img.shields.io/badge/DSH%20Web-Plugin-0f766e.svg)](https://github.com/MichengAI/dsh-skills-manager)
  [![Поддерживается до DSH 0.2.2-rc.1](https://img.shields.io/badge/DSH-up%20to%200.2.2--rc.1-2563eb.svg)](#установка)
</div>

> DSH Skills Manager — это плагин для DeepSeek Harness (DSH), поддерживаемый сообществом, и не является официальным продуктом DeepSeek AI.

## Возможности

Объедините локальные и проектные навыки в одном месте в DSH без необходимости переключаться между каталогами различных агентов.

- **Единое мультипанельное управление**: Вкладки «Глобальные навыки», «Навыки проекта», «Обзор» и «Корзина» со мгновенным поиском и фильтрацией.
- **Просмотр по исходным репозиториям**: Переключение между структурой папок и репозиториями с точным определением источника.
- **Широкая совместимость с экосистемой**: Поддержка более 20 инструментов и CLI-сред (DSH, Shared Agent, Codex, Claude Code, Copilot, Cursor, Google Antigravity, Windsurf, Qoder, Trae).
- **Категории и Drag & Drop**: Создание категорий, перемещение карточек навыков перетаскиванием (`⋮⋮`) и включение/отключение целых категорий одним переключателем.
- **Каталоги и репозитории GitHub**: Встроенный центр обзора для поиска навыков в ClawHub и skills.sh, а также синхронизация с GitHub с автоматическим резервным копированием.
- **Создание и удобный импорт**: Создание новых навыков или импорт ZIP-архивов, папок и файлов `SKILL.md`.
- **Широкоформатный просмотр**: Адаптивное модальное окно 760px с подсветкой синтаксиса и копированием Markdown в один клик.
- **Корзина и безопасное восстановление**: Удаленные навыки DSH отправляются в корзину и могут быть полностью восстановлены в любое время.
- **Пользовательские каталоги источников**: Перенаправление внешних путей чтения без перемещения файлов.

## Скриншоты

Панель управления глобальными навыками:

![Панель управления глобальными навыками](assets/screenshots/skills-manager-v2-preview.webp)

Панель управления проектными навыками (по рабочим областям):

![Панель управления проектными навыками](assets/screenshots/skills-manager-project-scope-preview.webp)

## Установка

### Установка через агента

В диалоге с агентом DSH отправьте команду:

```text
Установи плагин @michengai/dsh-skills-manager
```

### Ручная установка

Выполните в терминале:

```bash
dsh plugin add @michengai/dsh-skills-manager
```

В среде Windows PowerShell:

```powershell
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
dsh plugin --profile web add @michengai/dsh-skills-manager@latest --registry=https://registry.npmjs.org/
```

Перезапустите DSH, обновите страницу и перейдите в **Настройки → Навыки**. Для обновления плагина используйте менеджер плагинов хоста или выполните команду установки повторно.

## Настройка плагина

Плагин следует стандартным соглашениям конфигурации DSH:
> **Боковая панель → Плагины → Нажмите `Skills Manager`** (`plugins.bundle.config`).

Доступные параметры:

### 1. Значок на боковой панели (`sidebarEntry`)
- **По умолчанию**: Отключено (`false`)
- **Описание**: Отображает постоянный значок **Навыки** под разделом «Плагины» в основной боковой панели.
- **Результат**: Открывает менеджер навыков в центрированном контейнере шириной 960px в основной рабочей области.

### 2. Корпоративная блокировка обновлений (`updater` / `onlineUpdate`)
- **Конфигурация**: Для корпоративных сред интерфейс обновлений можно полностью отключить в Cordis:
  ```yaml
  updater: false # или onlineUpdate: false
  ```
- **Результат**: Полностью отключает API обновления плагина (возвращает `HTTP 403 Forbidden`).

## Руководство пользователя

| Действие | Инструкция |
| --- | --- |
| **Поиск навыков** | Переключайтесь между вкладками, сворачивайте/разворачивайте источники или используйте поиск и фильтры. |
| **Просмотр деталей** | Нажмите «Подробнее», чтобы открыть `SKILL.md` в модальном окне 760px с кнопкой копирования текста. |
| **Включение / Отключение** | Переключите переключатель в строке; влияет только на вызов в DSH без изменения исходных файлов. |
| **Смена папки источника** | В меню ➕ выберите «Папки источников…» для безопасного перенаправления путей. |
| **Управление категориями** | Создавайте категории и перемещайте навыки перетаскиванием (`⋮⋮`). |
| **Создание и импорт** | Используйте меню ➕ для создания навыков или импорта ZIP/папок. |
| **Каталоги и репозитории** | Вкладка «Обзор» позволяет находить навыки в ClawHub и подключать репозитории GitHub. |
| **Обновление навыков** | Просматривайте различия (diff) перед подтверждением обновления с резервной копией. |
| **Откат версий** | Возвращайтесь к предыдущим версиям благодаря сохраненным копиям. |
| **Корзина** | Безопасное восстановление или окончательное удаление навыков. |

### Границы установки и репозиториев

- **Обновление**: Кнопка «Обновить» проверяет только репозитории навыков. Обновление самого плагина выполняется через хост.
- **Безопасные пути**: Установка может выполняться в каталог DSH пользователя, Shared Agent (`~/.agents/skills`) или `.dsh/skills` проекта.
- **Выборочная загрузка Git**: Загружаются только каталоги, содержащие `SKILL.md`.

## Поддерживаемые каталоги агентов

| Агент | Глобальный путь | Переменная окружения | Путь проекта |
| --- | --- | --- | --- |
| **DeepSeek Harness** | `~/.dsh/skills` | — | `.dsh/skills` |
| **Shared Agent** | `~/.agents/skills` | `DSH_AGENTS_HOME` | `.agents/skills` |
| **Codex** | `~/.codex/skills` | `CODEX_HOME` | `.codex/skills` |
| **Claude Code** | `~/.claude/skills` | `CLAUDE_HOME` | `.claude/skills` |
| **GitHub Copilot** | `~/.copilot/skills` | `COPILOT_HOME` | `.copilot/skills` |
| **Cursor** | `~/.cursor/skills` | `CURSOR_HOME` | `.cursor/skills` |
| **Google Antigravity** | `~/.gemini/skills` | `GEMINI_HOME` | `.gemini/skills` |
| **Windsurf** | `~/.windsurf/skills` | `WINDSURF_HOME` | `.windsurf/skills` |
| **Qoder** | `~/.qoder/skills` | `QODER_HOME` | `.qoder/skills` |
| **Trae** | `~/.trae/skills` | `TRAE_HOME` | `.trae/skills` |

### Пользовательские источники

Для добавления агента, отсутствующего в списке, воспользуйтесь меню ➕ и выберите «Папки источников…».

## Экосистема продуктов DSH

| Плагин | Описание |
| --- | --- |
| **[dsh-skills-manager](https://github.com/MichengAI/dsh-skills-manager)** | Единое управление навыками с поддержкой резервного копирования и GitHub. |
| **[dsh-im-connect](https://github.com/MichengAI/dsh-im-connect)** | Интеграция с мессенджерами (Feishu, DingTalk, WeChat, Telegram, Slack). |
| **[dsh-codex-ui](https://github.com/MichengAI/dsh-codex-ui)** | Элегантная тема интерфейса для DSH Desktop. |

## Обратная связь и участие

- Сообщить об ошибке: [GitHub Issues](https://github.com/MichengAI/dsh-skills-manager/issues)
- Приветствуются пул-реквесты.

## Лицензия

[Apache-2.0](LICENSE) © MichengAI
