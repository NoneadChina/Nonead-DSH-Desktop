/**
 * 附件引用面的**持久化**索引缓存：每条会话日志一条 `mtime + size → 它引用了哪些 attachmentId`。
 *
 * 为什么需要落盘：抽出引用面必须把日志整份解压。本机实测 339 份日志 / 230 MB，
 * 108517 个 zstd 帧逐个解压要 6.96 s（解压 6.96 s、抽正则 0.27 s、切帧 0.01 s —— 成本
 * 全在逐帧调用开销上），且并发无法改善（纯 CPU）。而导出与预览富化都要这份引用面，
 * 每次导出都重扫 7 s 不可接受。按 `mtime + size` 增量命中后，稳态只剩 stat（339 个约 50 ms）。
 *
 * 三条硬口径：
 * 1. 缓存只是**加速**，不是事实来源：条目必须与当前文件的 `mtime + size` 同时相等才采信，
 *    任一读不到就当没有缓存（重扫），绝不拿旧结果冒充当前。
 * 2. 读写失败一律**静默降级**（返回空表 / 放弃写入）：缓存不可用不该让导出失败，
 *    但也不许因此少带附件 —— 失败时调用方照常整份扫描。
 * 3. 文件内容是不可信输入：版本号、形状逐项校验，超量整份丢弃，不做部分采信。
 */
import type { HostContext } from '../core/types.ts';
import type { AttachmentRefMeta } from '../utils/attachment-refs.ts';
/** 缓存文件位置（DSH home 相对）。放在插件自己的数据目录下，不占宿主的 cache/。 */
export declare const ATTACHMENT_CACHE_REL = "dsh-config-manager/cache/attachment-refs.v1.json";
export interface CachedLogRefs {
    mtimeMs: number;
    size: number;
    refs: Record<string, AttachmentRefMeta>;
}
export type AttachmentRefCache = Map<string, CachedLogRefs>;
/** 读缓存（读不到 / 形状不对 / 版本不符 → 空表，让调用方整份重扫）。 */
export declare function loadAttachmentRefCache(ctx: HostContext): Promise<AttachmentRefCache>;
/**
 * 写缓存（best-effort）。只做「合并」不做「裁剪」：
 * 一次导出可能只扫被勾选的那几条会话，此时删掉没扫到的条目会让下次导出重新解压整库。
 * 失效靠 `mtime + size` 比对，过期条目最多占几十 KB。
 */
export declare function saveAttachmentRefCache(ctx: HostContext, merged: ReadonlyMap<string, CachedLogRefs>): Promise<void>;
