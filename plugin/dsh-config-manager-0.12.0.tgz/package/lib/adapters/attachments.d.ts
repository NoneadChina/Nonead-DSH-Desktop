/**
 * attachments 分区 adapter（P1，默认关）：只带走**被对话真正引用过**的附件。
 *
 * 为什么不整目录搬：本机实测 `$DSH_HOME/attachments` 233 MB / 1374 个对象，其中 68 MB 是
 * 没有任何会话引用的**孤儿**（删除会话后留下的对象）。整库备份会把孤儿一起搬去新机，
 * 用户付出体积与拷贝时间却得不到任何可看的东西。
 *
 * 判据来源：会话日志里的 `"attachmentId":"sha256:<64hex>"`（见 `utils/attachment-refs.ts`）。
 * 只看**日志文本**，不看文件时间、不看最近使用 —— 「用过」是唯一可复现的口径。
 *
 * 收窄范围：`options.includeItems.sessions`（与 sessions adapter 同一份单元 id
 * `<projectKey>/<sessionId>`）：
 *  - 空数组（用户把会话分区清空）⇒ 本分区一条都不带并告警（与基类 allow 语义一致）；
 *  - 键缺省（没指定会话范围）⇒ 按**全部会话**算引用面，并如实告警，
 *    既不能静默当成「只用了选中会话」，也不能当成「没有附件」。
 * `export.sessions.limit`（最新 N 个）**不重复实现**：那是按 mtime 排序的选择，本分区
 * 不复刻排序规则，而是如实告警「按全部会话收集，未按最新 N 个收窄」——宁可多带。
 *
 * 失败方向：会话日志读不出来 / zstd 解不开 ⇒ **退回整库 + 明确告警**（keep=null）。
 * 宁可多带 233 MB，也不静默交出一个「备份成功但图片全丢」的包。
 */
import { FileCollectionAdapter } from './file-collection.ts';
import './messages.ts';
import { type AttachmentRefMeta } from '../utils/attachment-refs.ts';
import type { ExportOptions, ExportUnit, HostContext, ImportContext, PlanItem } from '../core/types.ts';
import type { FilesSection } from '../schema/types.ts';
/**
 * 引用面扫描的短 TTL 缓存：导出预览与真实导出对同一批日志各扫一遍（本机实测 336 个日志 / 225 MB）。
 * 键 = 每个日志的「路径:mtime」；任何一条拿不到 mtime（宿主没暴露 mtimeMs / stat 失败）就整批不缓存 ——
 * 缓存必须能被证伪，宁可多读一遍，也不交出过期的引用面。
 */
/**
 * 引用面索引：attachmentId → 谁用过它（以及日志里声明的类型/字节数）。
 *
 * 为什么记「谁」而不只是「有没有」：导出选择器要把附件挂在**使用它的那条会话**下面（G5），
 * 归属关系只有读会话日志才算得出来；而适配器的 `listUnits()` 是零 I/O 纯函数，拿不到这份关系。
 */
export interface AttachmentRefEntry {
    /** 引用它的会话单元裸键（`<projectKey>/<sessionDir>`，与 sessions 单元 id 同构） */
    units: string[];
    mediaType?: string;
    bytes?: number;
    /** 附件真名（日志里声明的原始文件名；取不到就没有，界面退回 MIME/短哈希） */
    name?: string;
}
export type AttachmentRefIndex = Map<string, AttachmentRefEntry>;
/** 测试用：清空引用面缓存。生产失效只靠 mtime 键与 TTL，不靠这里。 */
export declare function resetAttachmentsScanCache(): void;
/**
 * 日志字节 → 该文件引用的附件（损坏 / 解不开返回 null，由调用方降级）。
 *
 * 纯函数是**有意的**：导出侧从本机盘读日志、导入侧从备份包里的同一个文件字节解析 ——
 * 两条路径共用这一份解析口径。写两份，迟早出现「导出时算得出归属、导入时算不出」，
 * 界面与包内容又会分叉。
 */
export declare function refsOfLogBytes(bytes: Uint8Array): Map<string, AttachmentRefMeta> | null;
export declare class AttachmentsAdapter extends FileCollectionAdapter {
    readonly id: 'attachments';
    readonly displayName = "Attachments";
    readonly defaultIncluded = false;
    readonly portability: 'deviceSpecific';
    readonly baseDir = "attachments";
    /** 单元 = 一个附件对象（路径里那段 64 位 hex 反推出的 attachmentId）。 */
    protected unitIdOf(relativePath: string): string;
    /**
     * 导入侧富化（2026-11-21 用户要求「导入功能也适配」）：把包内附件对象挂到**引用它的会话**
     * 下面，并显示会话日志里记下的真实文件名。
     *
     * 为什么必须在这一层做：「谁引用过这个附件」只存在于会话日志里。导出侧由 `enrichUnits()`
     * 读本机盘算归属；导入时目标盘上还没有这些会话，只能读**包内** sessions 分区的日志字节 ——
     * 同一份 `refsOfLogBytes()` 解析口径，不复刻第二套。归属算得出来，「勾会话带附件」
     * （`applySessionAttachmentCoupling`）才会自动生效，全选也不会把被引用的附件落下。
     *
     * 失败方向与导出侧一致：算不出归属就退回扁平（不填 parentUnitIds），孤儿附件照旧以分区行
     * 可见可勾，绝不因为一次坏日志把整批附件藏起来，也不拦下导入。
     */
    analyzeImport(data: FilesSection, ctx: ImportContext): Promise<PlanItem[]>;
    /**
     * 包内引用面：读 `ctx.sections` 里的 sessions 分区（分析阶段已在内存里，不碰盘）。
     *
     * 返回 null = 归属不可知，调用方退回扁平：任一引用了附件的日志解不开（半份引用当不得完整），
     * 或日志条数超出预览上限。降级方向只能往「少嵌套」，绝不能往「少显示」。
     */
    private refsFromPackage;
    protected restrictUnits(ctx: HostContext, rels: readonly string[], options: ExportOptions): Promise<{
        keep: Set<string> | null;
        warnings: string[];
    } | null>;
    /**
     * 预览富化（G5）：给附件单元补「哪些会话用过它」，选择器据此把附件挂到会话行下面。
     *
     * 返回 `null` = 这次算不出归属（日志读不出/解不开、条数超上限）—— 界面按扁平渲染，
     * **绝不猜归属**：把附件挂错会话，用户会以为「这个包里有那张图」而实际没有。
     * 未变化的单元原样返回（缺字段 ≠ 空数组：没有归属就是不知道，不是「属于零条会话」）。
     */
    enrichUnits(ctx: HostContext, units: readonly ExportUnit[]): Promise<ExportUnit[] | null>;
}
