import { type ProcessControlDeps } from './process-control.ts';
import type { DshProfileStopResult } from './dsh-profile-launcher.ts';
/** 心跳目录名（`<dataDir>/running`）。 */
export declare const RUNTIME_DIR_NAME = "running";
/** 心跳文件 schema 版本（改结构时递增；解析端只认自己认识的版本）。 */
export declare const RUNTIME_SCHEMA_VERSION = 1;
/** 心跳刷新间隔（20s；判死阈值是它的 3 倍）。 */
export declare const RUNTIME_REFRESH_MS = 20000;
/** 心跳过期阈值（超时即视为死实例——进程被硬杀时没人来删文件）。 */
export declare const RUNTIME_STALE_MS = 60000;
/**
 * 孤儿原子写 tmp 的年龄阈值：1 小时（与 `src/core/journal.ts` 的 STALE_JOURNAL_TEMP_MS 同口径）。
 * 在写的 tmp 只活「写 + fsync + rename」的毫秒级窗口，达到 1 小时必然是进程被杀留下的。
 */
export declare const RUNTIME_TEMP_STALE_MS: number;
/** `<dataDir>/running/<profile>.json` 的内容。 */
export interface DshProfileRuntimeRecord {
    schemaVersion: number;
    /** profile 名 */
    name: string;
    /** 该实例的进程 pid（判活 + 停止都靠它） */
    pid: number;
    /** 该实例的 web 端口（无 webServer 的部署为 null；**不含 token**） */
    port: number | null;
    /** 启动时刻（ISO，展示用） */
    startedAt: string;
    /** 上次心跳时刻（epoch ms；判死用） */
    updatedAt: number;
}
/**
 * 孤儿原子写半成品判据（issue #149）：必须**同时**满足 `.dshcm.` 前缀与 `.tmp` 后缀。
 * 沿 `src/core/journal.ts` 的 isJournalTempBasename 口径（前缀是插件专属保留名，
 * 后缀保证不会误删 `.dshcm.notes.json` 这类无 .tmp 的文件）。
 */
export declare function isRuntimeTempBasename(name: string): boolean;
/** 容错解析心跳文件（坏 JSON / 版本不符 / 字段缺失 → null，绝不抛）。 */
export declare function parseRuntimeRecord(text: string): DshProfileRuntimeRecord | null;
/** 心跳是否代表一个活着的实例：pid 存活 **且** 未过期（两者缺一不可）。 */
export declare function runtimeRecordLive(record: DshProfileRuntimeRecord, opts: {
    isAlivePid: (pid: number) => boolean;
    now: number;
    staleMs?: number;
}): boolean;
export interface DshProfileRuntimeOptions {
    /** 插件 dataDir（心跳落在 <dataDir>/running/） */
    dataDir: string;
    /** 本实例跑的 profile 名 */
    name: string;
    /** 自己的 web 端口（惰性；webServer 还没就绪时为 undefined → null） */
    port?: () => number | null;
    /** 自己的 pid（缺省 process.pid；测试可注入） */
    pid?: number;
    deps?: ProcessControlDeps;
    staleMs?: number;
    refreshMs?: number;
    /** 定时器注入（测试用；返回取消函数） */
    schedule?: (fn: () => void, ms: number) => () => void;
    /**
     * 心跳写失败回调（宿主接日志）。**绝不抛**：issue #149 的根因就是写失败顺着
     * `setInterval` 回调冒到事件循环，整个 DSH 直接退出。
     */
    onWriteFailure?: (error: unknown) => void;
    /** 原子写实现（测试注入用；缺省 atomicWriteFileSync）。 */
    write?: (target: string, data: string, opts: {
        mode: number;
        retries: number;
        retryDelayMs: number;
    }) => void;
}
/** 心跳注册表：announce（自报）/ withdraw（自撤）/ listActive（看别人）/ stopExternal（停别人）。 */
export declare class DshProfileRuntimeRegistry {
    private readonly dataDir;
    private readonly name;
    private readonly pid;
    private readonly port;
    private readonly staleMs;
    private readonly refreshMs;
    private readonly schedule;
    private readonly proc;
    private readonly startedAt;
    private readonly onWriteFailure?;
    private readonly write;
    /** 孤儿 tmp 每个实例只扫一遍（首次 announce 时）。 */
    private sweptTemps;
    constructor(options: DshProfileRuntimeOptions);
    /** 心跳目录（`<dataDir>/running`） */
    dir(): string;
    /** 某个 profile 的心跳文件绝对路径（名字哈希保证唯一，见 runtimeFileName） */
    fileFor(name: string): string;
    /** 旧版心跳文件（升级清理用：名字清洗多对一，旧文件可能已被别的 profile 覆盖过） */
    private legacyFileFor;
    /** 删掉自己那份旧版心跳（升级后不留双份；不碰别人的文件） */
    private dropLegacyHeartbeat;
    /**
     * 删一个文件（best-effort）：失败只上报，绝不抛。
     * Windows 上 `rmSync({force:true})` 遇到句柄被占用（杀软扫描、索引器、别的实例正在读）
     * 仍然抛 EPERM —— 收尾/清理路径抛出去就等于「卸不干净还崩一次」。
     */
    private removeQuietly;
    /** 上报写失败（回调自身抛错也不许冒泡，否则又变回崩宿主）。 */
    private reportFailure;
    /**
     * 自报/刷新心跳（幂等；apply 时写一次，之后由 startHeartbeat 定期刷）。
     *
     * **写失败绝不抛**（issue #149）：`running/*.json` 是运行态而不是用户配置，Windows 上
     * rename 撞上 Defender 实时扫描/索引器会返回 EPERM。原先异常穿过 `setInterval` 回调
     * ＝ 未捕获异常 ＝ 整个 DSH 退出（用户看到「应用无法启动或已意外停止」）。
     * 现在写不进去只意味着「别的实例暂时看不到我」，20s 后下一次心跳会再试。
     */
    announce(): DshProfileRuntimeRecord;
    /** 撤回自己的心跳（dispose 时；正常退出的实例不留垃圾文件；删不掉只记日志）。 */
    withdraw(): void;
    /**
     * 清掉被杀进程留下的原子写半成品（issue #149 第三条建议）。
     *
     * 判据只有两条：文件名同时命中 `.dshcm.` 前缀与 `.tmp` 后缀，且 mtime 早于 1 小时。
     * 只删 1 小时前的：在写的 tmp 只活「写 → fsync → rename」的毫秒级窗口，能活到 1 小时
     * 必然是上一个实例被硬杀留下的（与 `src/core/journal.ts` 的 sweepStaleTemps 同口径）。
     * 时间基准用真实系统时钟：tmp 的 mtime 来自真实文件系统，注入时钟对不上。
     */
    sweepStaleTemps(nowMs?: number): number;
    /** 每个实例只扫一遍孤儿 tmp（启动后首次 announce 触发）。 */
    private sweepStaleTempsOnce;
    /**
     * 定时刷新（返回停止函数；调用方必须用 ctx.effect 绑定生命周期）。
     * 不刷新也不会「变成别人可启动」——只是过期后会被别的实例当成死实例。
     */
    startHeartbeat(): () => void;
    /** 当前活着的实例（含自己；死实例/坏文件的记录顺手清掉）。 */
    listActive(): DshProfileRuntimeRecord[];
    /**
     * 停掉**别的**实例（按它的心跳 pid）。
     *  - 没有活心跳 → notRunning；
     *  - 心跳就是自己 → currentProfile（停自己会死在响应途中，UI 也不给这个按钮）；
     *  - 强杀后仍活着 → stopFailed。
     * 成功后删掉那个心跳文件（对方已死，不会自己撤）。
     */
    stopExternal(name: string): Promise<DshProfileStopResult>;
}
