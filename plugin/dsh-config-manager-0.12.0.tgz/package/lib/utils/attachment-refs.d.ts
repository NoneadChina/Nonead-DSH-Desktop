/**
 * 附件引用抽取（P1 附件分区）：会话日志文本 → 被对话真正引用过的 attachmentId 集合。
 *
 * 为什么单独一层纯函数：
 *  · 附件库里 233 MB 有 68 MB 是**孤儿**（没有任何会话引用）；「只带对话用到的」这条需求
 *    的判定完全由本模块决定，必须能用固定输入复现，而不是藏在 adapter 的 IO 里；
 *  · 抽取规则要防误命中：日志里粘的源码会包含 `x-oss-content-sha256`、`sha256: ''` 之类
 *    片段，只按 /sha256:[a-f0-9]{64}/ 扫会把它们当附件 id。因此**只认 JSON 字段形态**
 *    `"attachmentId":"sha256:<64hex>"`。
 *
 * 形状依据（宿主）：`@deepseek-ai/dsh-attachment-local` 的 FILE_ID_PATTERN =
 * /^sha256:([a-f0-9]{64})$/ —— 图片与文件附件共用同一个 id 形状，故一个正则覆盖两类。
 */
/** 日志里声明的附件元信息（取不到就是取不到，不猜默认值）。 */
export interface AttachmentRefMeta {
    /** 媒体类型（`image/jpeg` 这类） */
    mediaType?: string;
    /** 字节数 */
    bytes?: number;
    /**
     * 附件真名（用户发出去时的文件名，如 `P-01-after.png`）。
     *
     * 这是选择器里附件的**首选展示名**：64 位哈希没有信息量，`image/png` 又让人分不清
     * 同名类型的两张图。老日志/没有 name 的附件就是取不到 —— 退回 MIME 或短哈希，不编造。
     */
    name?: string;
}
/**
 * 从一段会话日志文本里抽取全部被引用的附件，附带日志声明的类型/字节数/真名。
 *
 * 同一 id 在同一份日志里出现多次时逐字段取**第一条**非空声明（同一条消息的重试会把
 * 同一附件写多遍，先到的那条就是用户真正发出去的那次）。
 */
export declare function extractAttachmentRefs(text: string): Map<string, AttachmentRefMeta>;
/** 从一段会话日志文本里抽取全部被引用的 attachmentId（去重；只要 id 的调用方用这个）。 */
export declare function extractAttachmentIds(text: string): Set<string>;
/** 合法 attachmentId → 64 位十六进制（不合法返回 null，绝不猜）。 */
export declare function hexOfAttachmentId(id: string): string | null;
/** 64 位十六进制 → 规范 attachmentId（不合法返回 null）。 */
export declare function attachmentIdOfHex(hex: string): string | null;
/**
 * 附件库里的相对路径 → attachmentId。
 *
 * 库布局（宿主 `dsh-attachment-local`）：图片 `v1/objects/<2>/<sha>`、
 * 文件对象 `v1/file-objects/<2>/<sha>`、文件本体 `v1/files/<2>/<sha>/<name>`。
 * 三者的共同点是**路径里必有一段完整的 64 位十六进制**（分片目录只有 2 位，不会误命中），
 * 因此按「首个 64 位 hex 段」判定，不硬编码深度 —— 宿主换布局也不会静默失配。
 */
export declare function attachmentIdOfRelPath(relativePath: string): string | null;
