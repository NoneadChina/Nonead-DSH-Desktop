/**
 * DshWorkspaceFacade —— DSH `workspaceRegistry` → 引擎 `WorkspaceFacade` 的适配。
 *
 * 从 src/index.ts 下沉（体量棘轮）：本类只做「服务读取 + 形状转换」，不含任何路由或
 * 生命周期逻辑。边界同上：core 不 import `@deepseek-ai/*`，宿主入口传入真 ctx。
 */
import type { MsgFunc } from './messages.ts';
import { type ServiceGetter } from './host-service.ts';
import type { WorkspaceFacade } from './types.ts';
import type { WorkspaceRecord } from '../schema/types.ts';
export declare class DshWorkspaceFacade implements WorkspaceFacade {
    private readonly ctx;
    private readonly msg;
    constructor(ctx: ServiceGetter, msg?: MsgFunc);
    private registry;
    listRecords(): Promise<WorkspaceRecord[]>;
    writeRecord(record: WorkspaceRecord): Promise<void>;
    removeRecord(id: string): Promise<void>;
    /**
     * 把一个已存储会话登记进工作区（issue #45 会话归位）。
     *
     * 走 DSH `workspaceRegistry` 的实体方法 `attachSession`：
     *  - DSH 自己读会话 header 并用 realpath 校验 cwd 必须等于该工作区 path（不匹配直接拒绝）；
     *  - 写入走 storage domain 的原子 update（内存权威与磁盘同时更新），并按 cwd 剪掉不属于
     *    本工作区的候选 —— 因此**不需要**插件做「注册表合并 / 去重 / 备份回滚」，
     *    更**不得**旁路直写 storages/workspace.json。
     */
    attachSession(workspaceId: string, sessionId: string): Promise<void>;
    /**
     * P2：读注册表级归档集。
     *
     * 「宿主没这个能力」与「归档集为空」必须分开：前者返回空数组但不会让导出侧写
     * `archivedSessionIds: []`（导出侧只看能力是否存在决定带不带这个字段）。
     */
    listArchivedSessionIds(): Promise<string[] | undefined>;
    /** P2：归档一个会话；宿主未暴露该能力时显式报错（由调用方降级为告警，绝不静默当成功）。 */
    archiveSession(sessionId: string): Promise<void>;
    /**
     * P2-pin：读注册表级置顶集（最近置顶在前）。
     *
     * 与归档集同款边界：`undefined` = 宿主没暴露（导出侧不带字段），**不是**空数组
     * —— 返回 [] 会让导出侧写出 `pinnedSessionIds: []`，等于声称「这台机器没有置顶会话」。
     * 能力在 DSH 0.2.2-rc.5 的 `workspaceRegistry` 上（`pinnedSessionIds` / `pinSession`）。
     */
    listPinnedSessionIds(): Promise<string[] | undefined>;
    /** P2-pin：置顶一个会话；宿主未暴露该能力时显式报错（调用方降级为告警，绝不静默当成功）。 */
    pinSession(sessionId: string): Promise<void>;
    /**
     * P2：按目标顺序重排工作区显示顺序。
     *
     * 宿主只给 `insertBefore(id, beforeId)`（DOM 语义），所以「变成目标顺序」由这里推出：
     * 从倒数第二个开始，把每个 id 挪到它后一个 id 前面，逐次收敛即为目标相对顺序。
     * 未知 id 直接过滤（别人删掉的工作区不该让整轮导入报错）；宿主没有该原语时静默跳过 ——
     * 顺序不是数据，丢了不影响可用性。
     */
    reorderWorkspaces(orderedIds: readonly string[]): Promise<void>;
}
