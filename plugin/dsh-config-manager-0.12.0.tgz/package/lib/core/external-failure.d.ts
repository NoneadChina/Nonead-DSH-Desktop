/** 允许不升全局 SAFE MODE 的可重试/外部传输失败判据集合。 */
export declare const NON_BLOCKING_EXTERNAL_REASONS: ReadonlySet<string>;
/**
 * 给一个错误打上「本地可修」标记并原样返回（便于 `throw markLocalOnlyExternalFailure(err, 'git-identity')`）。
 * 同一个错误重复标记不报错（后写覆盖先写）。
 */
export declare function markLocalOnlyExternalFailure<T extends Error>(err: T, reason: string): T;
/** 读取「本地可修」标记（无标记/非对象 → null）。 */
export declare function localOnlyFailureReason(err: unknown): string | null;
/** 该失败是否只由本机可修的配置/凭据引起。 */
export declare function isLocalOnlyExternalFailure(err: unknown): boolean;
/**
 * 给一个错误打上「可重试/非阻断外部失败」标记并原样返回（如 network / timeout / server / auth / circuit-open）。
 * 不符合 NON_BLOCKING_EXTERNAL_REASONS 的 reason 即使调用也不放行（默认 fail-closed）。
 */
export declare function markRetryableExternalFailure<T extends Error>(err: T, reason: string): T;
/** 读取「可重试/非阻断外部失败」标记（仅允许白名单判据，否则 null）。 */
export declare function retryableExternalFailureReason(err: unknown): string | null;
/** 该失败是否为明确标注的可重试/传输层外部失败。 */
export declare function isRetryableExternalFailure(err: unknown): boolean;
/**
 * phase3-host 统一判据：该外部失败是否证明不会破坏本机盘面且无需升全局 durable SAFE MODE。
 * 只有显式打过 localOnly 或白名单 retryableExternal 标记时才放行，其余一律 fail-closed。
 */
export declare function isNonBlockingExternalFailure(err: unknown): boolean;
