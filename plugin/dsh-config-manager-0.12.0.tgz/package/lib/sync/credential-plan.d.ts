import type { MsgFunc } from '../core/messages.ts';
import type { HostContext, ImportPlan } from '../core/types.ts';
export declare function appendCredentialPlanItems(input: {
    ctx: Pick<HostContext, 'homeDir' | 'fs'>;
    msg: MsgFunc;
    plan: ImportPlan;
    credentials: Map<string, string> | undefined;
}): Promise<void>;
