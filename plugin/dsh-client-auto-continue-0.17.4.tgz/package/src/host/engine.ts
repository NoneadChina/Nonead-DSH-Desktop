/**
 * Auto-continue engine — host half core (single instance).
 *
 * Runs inside the dsh host process, so there is exactly ONE engine regardless
 * of how many browser tabs are open — the multi-tab duplicate-send class of
 * bugs (issue #13) cannot exist by construction. Listens to the session event
 * firehose (`session/event`), sends through the agent registry
 * (`agent.followup`), cancels through `agent.cancel`, and reads configuration
 * injected by the entry (`apply`'s config argument, merged with schema
 * defaults by `resolveConfig`).
 *
 * All behavior is driven by the `auto-continue` entry config; every knob below
 * is user-configurable there.
 */

import type { Context } from '@deepseek-ai/cordis';
import { createUserMessage } from '@deepseek-ai/dsh-llm';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session/types';
import { foldRequestHeader, type Session } from '@deepseek-ai/dsh-session';
import {
  DEFAULT_CONFIG,
  RECOVERY_WINDOW_MS,
  effectiveCooldown,
  emptyDayStats,
  fillTemplate,
  forgetPendingEcho,
  freshState,
  isNonHumanReason,
  isOurEcho,
  isTransientAgentError,
  isTransientFailure,
  resolveConfig,
  sessionMode,
  sleep,
  todayKey,
  trackPendingEcho,
  type AutoContinueConfig,
  type AutoContinueLocale,
  type DayStats,
  type RecoveryAttempt,
  type FailureFacts,
  type SessionState,
  type NotifyAction,
  type NotifyOptions,
  type TemplateContext,
  type ToolRepeatSignal,
} from '../shared/core.ts';

const NOTICE_COPY = {
  zh: {
    notContinuedTitle: 'dsh-auto-continue: 未自动继续',
    permanentErrorBody: (sessionId: SessionId, summary: string) =>
      `${sessionId}: 永久性错误 ${summary}，需要人工处理`,
    resumeAction: '立即续跑',
    pauseAction: '暂停该会话 1 小时',
    continuedTitle: 'dsh-auto-continue: 已自动继续',
    continuedBody: (sessionId: SessionId, text: string, count: number) =>
      `${sessionId}: 已发送「${text}」(第 ${count} 次连续)`,
    stoppedTitle: 'dsh-auto-continue: 已停止自动继续',
    stoppedBody: (sessionId: SessionId, count: number) =>
      `${sessionId}: 连续失败 ${count} 次, 需要人工介入`,
  },
  en: {
    notContinuedTitle: 'dsh-auto-continue: Not continued',
    permanentErrorBody: (sessionId: SessionId, summary: string) =>
      `${sessionId}: Permanent error ${summary}; manual intervention required`,
    resumeAction: 'Resume now',
    pauseAction: 'Pause this session for 1 hour',
    continuedTitle: 'dsh-auto-continue: Continued automatically',
    continuedBody: (sessionId: SessionId, text: string, count: number) =>
      `${sessionId}: Sent "${text}" (consecutive attempt ${count})`,
    stoppedTitle: 'dsh-auto-continue: Auto-continue stopped',
    stoppedBody: (sessionId: SessionId, count: number) =>
      `${sessionId}: ${count} consecutive failures; manual intervention required`,
  },
} as const satisfies Record<AutoContinueLocale, Record<string, unknown>>;

/** Durable cancel identity reserved for this plugin's loop guard. */
const LOOP_GUARD_CANCEL_CAUSE = {
  kind: 'hook',
  reason: 'dsh-auto-continue:loop-guard',
} as const;

/**
 * Autonomous-loop resume reasons.
 * - `turn/end:completed` is a *successful* visible completion: the loop hands
 *   the thread back and the send is exempt from the failure budget.
 * - `turn/end:loop-silent` is a loop-covered turn with no visible output. The
 *   loop still continues it, but it is a failure: it must consume the retry
 *   budget and obey backoff, or a stuck model retries forever.
 * The silent reason must not end in `:silent` — `fire()` skips those when
 * silent-turn resume is off, which would stall the loop (27j).
 */
const LOOP_COMPLETED_REASON = 'turn/end:completed';
const LOOP_SILENT_REASON = 'turn/end:loop-silent';
const MANUAL_NOTIFICATION_REASON = 'manual:notification';

/** Yield between storage batches without spending a live-scan polling interval. */
const SWEEP_OBSERVE_BATCH = 16;
const STORED_READ_TIMEOUT_MS = 5000;
/** 单个存储会话连续观察/物化失败达此数后放弃, 避免坏日志反复占满每轮观察配额。 */
const SWEEP_MAX_FAILURES = 3;

/**
 * 存储扫描消费的宿主服务结构类型。这些服务(sessionQuery 等)随 dsh
 * 版本整组演进, 直接引类型包会拖动 devDependency 时代; 按消费面声明,
 * 缺服务的宿主在运行时禁用存储扫描即可。
 */
interface StoredObservation {
  readonly events: readonly SessionEvent[];
  readonly header: { readonly id?: SessionId; readonly origin?: string; readonly agentPreset?: string };
  readonly projections?: { readonly values: { readonly agentPreset?: string } };
  [Symbol.dispose]?: () => void;
}

const isLoopReason = (reason: string): boolean =>
  reason === LOOP_COMPLETED_REASON || reason === LOOP_SILENT_REASON;

/** Keep fuzzy matching off the unbounded host event path; exact repeats remain unlimited. */
const STREAM_NEAR_DUPLICATE_MAX_CHARS = 2_048;
/** Bound unfinished text copied between token chunks when a provider emits no paragraph break. */
const STREAM_TAIL_MAX_CHARS = 4_096;

/** Ignore invisible formatting only for detection, never rewrite the stored message. */
const visibleText = (text: string): string => text.replace(/\p{Cf}/gu, '').trim();

/** 通知桥事件: host 引擎产生, browser 侧订阅展示(Notification / 动作按钮)。 */
export interface HostNotice {
  /** 稳定标识(供 browser 去重)。 */
  id: string;
  title: string;
  body: string;
  /** 会话 id(通知按钮「立即续跑 / 暂停该会话」作用于它)。 */
  sessionId: SessionId;
  actions: NotifyAction[];
  /** 产生时间。 */
  at: number;
}

/** 自动发送后, 在该窗口内出现的回合结束才计入恢复统计。 */

/** SSE 帧外壳: `{ rpcId, payload }`。 */
type FrameEnvelope<T> = { payload: T };

/** Session history APIs across the supported DSH host releases. */
type CompatibleSession = Session & {
  readonly events?: readonly SessionEvent[];
  snapshotEvents?: () => readonly SessionEvent[];
};

/** Read one stable event-log snapshot on both legacy and DSH 0.1.2 hosts. */
function snapshotSessionEvents(session: Session): readonly SessionEvent[] {
  const compatible = session as CompatibleSession;
  const snapshot = compatible.snapshotEvents;
  const events = typeof snapshot === 'function' ? snapshot.call(session) : compatible.events;
  return validateSessionEvents(events);
}

function validateSessionEvents(events: unknown): readonly SessionEvent[] {
  if (!Array.isArray(events)) throw new TypeError('session history is not an event array');
  // Do not filter damaged entries: one could have been a manual stop, newer turn,
  // or tool result. An incomplete history is not safe evidence for a continuation.
  for (let index = 0; index < events.length; index += 1) {
    const event = events[index];
    if (event === null || typeof event !== 'object' || Array.isArray(event) ||
        typeof event.type !== 'string' || event.type === '' ||
        !Number.isSafeInteger(event.seq) || event.seq < 0 ||
        !Number.isFinite(event.time) || event.time < 0) {
      throw new TypeError(`invalid session event envelope at index ${index}`);
    }
  }
  return events;
}

function latestTurnStart(events: readonly SessionEvent[]): SessionEvent<'turn/start'> | undefined {
  for (let i = events.length - 1; i >= 0; i -= 1) {
    const event = events[i];
    if (event?.type === 'turn/start') return event;
  }
  return undefined;
}

function isMaintenanceTurnStart(event: SessionEvent<'turn/start'> | undefined): boolean {
  // shortcut: only message-ops defines this marker; extend when another producer has a verified contract.
  return (event?.data as { reason?: unknown } | undefined)?.reason === 'message-ops';
}

/** Interpret host failure payloads without trusting persisted or plugin-provided event shapes. */
function parseFailureFacts(value: unknown): FailureFacts | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined;
  const failure = value as { code?: unknown; message?: unknown; status?: unknown };
  const code = typeof failure.code === 'string' && failure.code.trim() !== ''
    ? failure.code
    : undefined;
  const message = typeof failure.message === 'string' && failure.message.trim() !== ''
    ? failure.message
    : undefined;
  const status = typeof failure.status === 'number' && Number.isFinite(failure.status)
    ? failure.status
    : undefined;
  if (code === undefined && message === undefined && status === undefined) return undefined;
  return {
    code: code ?? 'UNKNOWN',
    message: message ?? code ?? `HTTP ${status}`,
    ...(status !== undefined ? { status } : {}),
  };
}

/** Read a reason discriminator defensively because session history can outlive its schema. */
function readReasonKind(value: unknown): string | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined;
  const kind = (value as { kind?: unknown }).kind;
  return typeof kind === 'string' && kind.trim() !== '' ? kind : undefined;
}

function isLoopGuardCancelReason(value: unknown): boolean {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const cause = value as { kind?: unknown; reason?: unknown };
  return cause.kind === LOOP_GUARD_CANCEL_CAUSE.kind && cause.reason === LOOP_GUARD_CANCEL_CAUSE.reason;
}

/**
 * 事件流泵: 带指数退避的 SSE 重连循环。
 * - 从未收到任何帧(宿主未就绪): 退避重试, 不触发扫描
 * - 曾连上后断开: 重连, 并通过 onReconnect 通知外层(宿主可能崩溃重启过)
 */
async function pumpStream<T>(
  open: (signal: AbortSignal) => AsyncIterable<FrameEnvelope<T>>,
  onFrame: (payload: T) => void,
  onReconnect: () => void,
  getBackoff: () => number,
  log: (message: string) => void,
  signal: AbortSignal,
): Promise<void> {
  let backoff = getBackoff();
  while (!signal.aborted) {
    let connected = false;
    try {
      for await (const envelope of open(signal)) {
        connected = true;
        onFrame(envelope.payload);
      }
      if (signal.aborted) return;
    } catch (error) {
      if (signal.aborted) return;
      log(`stream error: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!connected) {
      // 从未连上(宿主未就绪): 指数退避重试
      await sleep(backoff);
      backoff = Math.min(backoff * 2, 15000);
      continue;
    }
    // 曾连上后断开 → 重连并触发外层扫描
    backoff = getBackoff();
    onReconnect();
    await sleep(backoff);
  }
}

/** 插件主体: 一条 mux 流 + 一条 host 流 + 启动/重连扫描。 */
export class AutoContinueRunner {
  private readonly states = new Map<SessionId, SessionState>();
  private readonly pauseUntil = new Map<SessionId, number>();
  private dayStats: DayStats = emptyDayStats();
  private readonly recoveryAttempts: RecoveryAttempt[] = [];
  private readonly notices: HostNotice[] = [];
  private readonly noticeListeners = new Set<() => void>();
  private readonly stateListeners = new Set<() => void>();
  private readonly prioritizedFollowups = new Set<string>();
  private readonly disposeSessionEvents: () => void;
  private readonly disposeInboxEvents: () => void;
  private disposed = false;
  private readonly bootScannedSessions = new WeakSet<Session>();
  /** Also bound diagnostics when even an agent's session getter is unavailable. */
  private readonly bootScanErrors = new WeakSet<object>();
  /** 存储扫描已裁决的会话 id, 避免每轮重复冷读大日志。 */
  private readonly storedSwept = new Set<SessionId>();
  /** 存储会话的连续观察/物化失败次数, 触达 SWEEP_MAX_FAILURES 后不再重试。 */
  private readonly storedSweepFailures = new Map<SessionId, number>();
  private storedSweepAnnounced = false;
  private bootScanTimer: ReturnType<typeof setTimeout> | undefined;
  private wakeBootScan: (() => void) | undefined;
  private storedSweep: Promise<void> | undefined;
  private readonly stopStoredSweep = new AbortController();

  /**
   * @param ctx - host plugin context (agents registry, session events).
   * @param getConfig - read the current resolved configuration (entry config).
   */
  constructor(
    private readonly ctx: Context,
    private readonly getConfig: () => AutoContinueConfig,
  ) {
    // 单实例事件源: 宿主进程内的会话事件 firehose, 天然覆盖所有会话。
    this.disposeSessionEvents = ctx.on('session/event', (session, event) => {
      try {
        this.onHostEvent(session, event);
      } catch (error) {
        console.error(
          `[auto-continue] 会话事件处理异常 ${session.id}: ${
            error instanceof Error ? error.message : String(error)
          }`,
        );
      }
    });
    // followup() appends before it wakes the driver. Move only this plugin's marked
    // message during the synchronous insertion event, while the driver still cannot claim it.
    this.disposeInboxEvents = ctx.on('agent/inbox/inserted', ({ agent, message }) => {
      if (!this.prioritizedFollowups.delete(message.id)) return;
      let removed = false;
      try {
        const index = agent.inbox.nextTurn.findIndex(pending => pending.id === message.id);
        if (index <= 0) return;
        removed = agent.inbox.remove(message.id);
        if (!removed) return;
        agent.inbox.prepend('next-turn', message);
      } catch (error) {
        // Preserve the continuation even if a host-side queue mutation rejects the move.
        if (removed) {
          try {
            agent.inbox.append('next-turn', message);
          } catch (rollbackError) {
            console.error(
              `[auto-continue] 恢复续跑消息失败 ${agent.id}: ${
                rollbackError instanceof Error ? rollbackError.message : String(rollbackError)
              }`,
            );
          }
        }
        console.error(
          `[auto-continue] 调整续跑消息顺序失败 ${agent.id}: ${
            error instanceof Error ? error.message : String(error)
          }`,
        );
      }
    });
    const config = this.getConfig();
    if (config.scanOnBoot) {
      void this.bootScanLoop();
    }
    this.log(
      `已启动(host 单实例, 文本="${config.continueText}", 宽限 ${config.graceMs}ms, ` +
        `冷却 ${config.cooldownMs}ms, 最多连续 ${config.maxConsecutive} 次)`,
    );
  }

  private log(message: string): void {
    if (this.getConfig().verbose) console.info(`[auto-continue] ${message}`);
  }

  /** 对外(状态桥): 今日统计快照。 */
  todayStats(): DayStats {
    const today = todayKey();
    if (this.dayStats.date !== today) this.dayStats = emptyDayStats();
    return { ...this.dayStats, byCode: { ...this.dayStats.byCode } };
  }

  recentRecoveryAttempts(): RecoveryAttempt[] {
    return this.recoveryAttempts.map(attempt => ({ ...attempt }));
  }

  /** 对外(状态桥): 当前生效的会话级暂停列表。 */
  activePauses(): { sessionId: SessionId; until: number }[] {
    const now = Date.now();
    const out: { sessionId: SessionId; until: number }[] = [];
    for (const [sessionId, until] of this.pauseUntil) {
      if (until > now) out.push({ sessionId, until });
    }
    return out;
  }

  /** 对外(状态桥): 订阅通知事件(SSE 端点推送)。 */
  subscribeNotices(listener: () => void): () => void {
    this.noticeListeners.add(listener);
    return () => {
      this.noticeListeners.delete(listener);
    };
  }

  /** 对外(状态桥): 订阅运行时状态变化(统计/暂停列表)。 */
  subscribeState(listener: () => void): () => void {
    this.stateListeners.add(listener);
    return () => {
      this.stateListeners.delete(listener);
    };
  }

  private emitState(): void {
    for (const listener of this.stateListeners) listener();
  }

  private sessionConfig(sessionId: SessionId): AutoContinueConfig {
    const config = this.getConfig();
    const mode = sessionMode(config.sessionModes, sessionId);
    return {
      ...config,
      paused: config.paused || mode === 'off',
      resumeCompletedTurns: mode === 'default' ? config.resumeCompletedTurns : mode === 'loop',
      loopGuard: config.loopGuard && mode !== 'off',
    };
  }

  configurationChanged(): void {
    if (this.disposed) return;
    for (const [sessionId, state] of this.states) {
      const config = this.sessionConfig(sessionId);
      if (config.paused || (isLoopReason(state.pendingReason ?? '') && !config.resumeCompletedTurns)) {
        this.cancelPending(sessionId, '会话模式或全局设置已更改');
      }
    }
    this.emitState();
  }

  /** 对外(状态桥): 消费待展示的通知。 */
  drainNotices(): HostNotice[] {
    return this.notices.splice(0, this.notices.length);
  }

  /** 通知动作(browser 通知按钮回传): 立即续跑 / 暂停该会话 / 解除暂停 / 清零统计。 */
  handleNoticeAction(sessionId: SessionId | undefined, action: string): void {
    if (action === 'unpause') {
      if (sessionId !== undefined) this.pauseUntil.delete(sessionId);
      this.log(`解除暂停 ${sessionId ?? '?'}`);
    } else if (action === 'reset-stats') {
      this.dayStats = emptyDayStats();
      this.log('清零今日统计');
    } else if (sessionId !== undefined) {
      this.onNotifyAction(sessionId, action);
    }
    this.emitState();
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.stopStoredSweep.abort();
    if (this.bootScanTimer !== undefined) clearTimeout(this.bootScanTimer);
    this.bootScanTimer = undefined;
    this.wakeBootScan?.();
    this.wakeBootScan = undefined;
    this.disposeSessionEvents();
    this.disposeInboxEvents();
    this.prioritizedFollowups.clear();
    for (const state of this.states.values()) {
      if (state.pendingTimer !== undefined) clearTimeout(state.pendingTimer);
      if (state.loopRetryTimer !== undefined) clearTimeout(state.loopRetryTimer);
      if (state.cooldownRetryTimer !== undefined) clearTimeout(state.cooldownRetryTimer);
    }
    this.states.clear();
  }

  private state(sessionId: SessionId): SessionState {
    let state = this.states.get(sessionId);
    if (state === undefined) {
      state = freshState();
      this.states.set(sessionId, state);
    }
    return state;
  }

  /** Mark a child session and clear queued grace/cooldown sends. */
  private markSubagent(sessionId: SessionId, state: SessionState): void {
    state.subagent = true;
    this.cancelPending(sessionId, '子代理会话');
  }

  /** Read durable origin from the live agent for direct action paths as well. */
  private isSubagent(sessionId: SessionId, state: SessionState): boolean {
    if (state.subagent) return true;
    const agent = this.ctx.agents.get(sessionId);
    if (agent?.session?.header?.origin !== 'subagent') return false;
    this.markSubagent(sessionId, state);
    return true;
  }

  /**
   * 事件入口(host 单实例): 预处理工具调用/结果/模型消息(护栏与循环信号),
   * 然后交给回合状态机。
   */
  private onHostEvent(session: Session, event: SessionEvent): void {
    const sessionId = session.id;
    const sessionState = this.states.get(sessionId);
    if (session.header?.origin === 'subagent') {
      this.markSubagent(sessionId, sessionState ?? this.state(sessionId));
      return;
    }
    if (sessionState?.subagent) return;
    if (sessionState?.maintenanceTurn !== undefined &&
        sessionState.maintenanceTurn === (event.data as { turn?: number }).turn &&
        event.type !== 'turn/start' && event.type !== 'turn/end') return;
    if (
      (event.type === 'user/message' || event.type === 'assistant/message') &&
      typeof event.surfaceOp === 'object' &&
      event.surfaceOp !== null
    ) {
      // Compaction replacement 不是新消息，也可能 shadow 整段工具结果。
      this.state(sessionId).tools.recordSurfaceReplacement(event.seq);
      return;
    }
    if (event.type === 'tool/call') {
      const state = this.state(sessionId);
      // 任何新鲜调用都代表进展（即使缺关联 id）；旧帧重放不能清短句 streak。
      if (state.tools.recordCall(event)) {
        state.shortRun = 0;
        state.sameTextRun = 0;
        state.lastAssistantText = '';
        if (this.tracksOutput(state, event)) state.turnOutput = 'visible';
      }
    } else if (event.type === 'tool/result') {
      const state = this.state(sessionId);
      state.tools.recordResult(event);
    } else if (event.type === 'step/start') {
      const state = this.state(sessionId);
      if (this.tracksOutput(state, event) && state.turnOutput === 'empty') state.turnOutput = 'silent';
      const repeat = state.tools.confirmRepeatAtStep(event.seq);
      if (repeat !== undefined) this.checkLoop(sessionId, state, repeat);
    } else if (event.type === 'assistant/chunk') {
      const state = this.state(sessionId);
      if (this.tracksOutput(state, event)) {
        const chunk = event.data.chunk;
        const visible = (chunk.type === 'text-delta' && visibleText(chunk.text) !== '') ||
          chunk.type === 'tool-call-delta' ||
          (chunk.type === 'block-end' && this.hasVisibleContent([chunk.block])) ||
          (chunk.type === 'block-start' && chunk.blockType !== 'reasoning' && chunk.blockType !== 'text');
        if (visible) state.turnOutput = 'visible';
        else if (state.turnOutput === 'empty' && chunk.type !== 'usage' && chunk.type !== 'finish') state.turnOutput = 'silent';
      }
      this.onAssistantChunk(sessionId, state, event);
    } else if (event.type === 'assistant/message') {
      const state = this.state(sessionId);
      if (this.tracksOutput(state, event)) {
        if (this.hasVisibleContent(event.data.message.content)) state.turnOutput = 'visible';
        else if (state.turnOutput === 'empty') state.turnOutput = 'silent';
      }
      this.onAssistantMessage(sessionId, state, event);
    }
    this.onSessionEvent(sessionId, event);
  }

  private tracksOutput(state: SessionState, event: SessionEvent): boolean {
    return state.running === true && state.outputTurn === (event.data as { turn?: number }).turn &&
      event.seq > state.outputStartSeq;
  }

  /** Treat unknown block kinds conservatively: only reasoning and blank text are silent. */
  private hasVisibleContent(content: unknown): boolean {
    if (!Array.isArray(content)) return false;
    return content.some((part: unknown) => {
      if (part === null || typeof part !== 'object') return true;
      const block = part as { type?: unknown; text?: unknown };
      if (block.type === 'reasoning') return false;
      if (block.type === 'text') return typeof block.text !== 'string' || visibleText(block.text) !== '';
      return true;
    });
  }

  /** 从 assistant/message 事件提取纯文本。 */
  private assistantText(event: SessionEvent<'assistant/message'>): string {
    const content = event.data.message.content;
    if (!Array.isArray(content)) return '';
    return content
      .filter((part): part is { type: 'text'; text: string } => part.type === 'text')
      .map((part) => part.text)
      .join('');
  }

  private assistantChunkText(event: SessionEvent<'assistant/chunk'>): string {
    return event.data.chunk.type === 'text-delta' ? event.data.chunk.text : '';
  }

  private normalizedSegment(text: string): string {
    return visibleText(text).replace(/\s+/g, ' ');
  }

  private isNearDuplicateSegment(left: string, right: string): boolean {
    if (left === right) return true;
    const leftLen = left.length;
    const rightLen = right.length;
    const longer = Math.max(leftLen, rightLen);
    const shorter = Math.min(leftLen, rightLen);
    if (shorter === 0 || shorter / longer < 0.85) return false;
    if (longer > STREAM_NEAR_DUPLICATE_MAX_CHARS) return false;
    const maxDistance = Math.max(6, Math.floor(longer * 0.08));
    if (Math.abs(leftLen - rightLen) > maxDistance) return false;
    return this.withinEditDistance(left, right, maxDistance);
  }

  private withinEditDistance(left: string, right: string, maxDistance: number): boolean {
    if (left === right) return true;
    if (maxDistance < 0) return false;
    const leftLen = left.length;
    const rightLen = right.length;
    if (Math.abs(leftLen - rightLen) > maxDistance) return false;
    if (leftLen === 0 || rightLen === 0) return Math.max(leftLen, rightLen) <= maxDistance;
    const unreachable = maxDistance + 1;
    let previous = new Int32Array(rightLen + 1);
    let current = new Int32Array(rightLen + 1);
    previous.fill(unreachable);
    for (let col = 0; col <= Math.min(rightLen, maxDistance); col += 1) {
      previous[col] = col;
    }
    for (let row = 1; row <= leftLen; row += 1) {
      current.fill(unreachable);
      if (row <= maxDistance) current[0] = row;
      const firstCol = Math.max(1, row - maxDistance);
      const lastCol = Math.min(rightLen, row + maxDistance);
      let minInRow = unreachable;
      for (let col = firstCol; col <= lastCol; col += 1) {
        const insertion = (current[col - 1] ?? unreachable) + 1;
        const deletion = (previous[col] ?? unreachable) + 1;
        const substitution =
          (previous[col - 1] ?? unreachable) +
          (left.charCodeAt(row - 1) === right.charCodeAt(col - 1) ? 0 : 1);
        const score = Math.min(insertion, deletion, substitution, unreachable);
        current[col] = score;
        if (score < minInRow) minInRow = score;
      }
      if (minInRow > maxDistance) return false;
      [previous, current] = [current, previous];
    }
    return (previous[rightLen] ?? unreachable) <= maxDistance;
  }

  private noteStreamSegment(sessionId: SessionId, state: SessionState, segment: string): void {
    const normalized = this.normalizedSegment(segment);
    const config = this.getConfig();
    if (normalized === '') return;
    if (normalized.length < config.loopShortChars) {
      state.streamLastSegment = '';
      state.streamRepeatRun = 0;
      return;
    }
    if (
      state.streamLastSegment !== '' &&
      this.isNearDuplicateSegment(normalized, state.streamLastSegment)
    ) {
      state.streamRepeatRun += 1;
      state.streamLastSegment = normalized;
    } else {
      state.streamLastSegment = normalized;
      state.streamRepeatRun = 1;
    }
    if (state.streamRepeatRun >= config.loopRepeatText) {
      this.log(
        `检测到流式消息内复读 ${sessionId}: 连续 ${state.streamRepeatRun} 段近似重复文本`,
      );
      this.interruptLoop(sessionId, state);
    }
  }

  private onAssistantChunk(
    sessionId: SessionId,
    state: SessionState,
    event: SessionEvent<'assistant/chunk'>,
  ): void {
    if (!this.sessionConfig(sessionId).loopGuard || !state.running || state.loopFired) return;
    const chunk = this.assistantChunkText(event);
    if (chunk === '') return;
    const merged = `${state.streamTail}${chunk}`.replace(/\r/g, '');
    const pieces = merged.split(/\n(?:[ \t]*\n)+/u);
    const tail = pieces.pop() ?? '';
    for (const piece of pieces) this.noteStreamSegment(sessionId, state, piece);
    if (tail.length <= STREAM_TAIL_MAX_CHARS) {
      state.streamTail = tail;
      return;
    }
    state.streamTail = tail.slice(-STREAM_TAIL_MAX_CHARS);
    if (/\S/u.test(tail)) {
      state.streamLastSegment = '';
      state.streamRepeatRun = 0;
    }
  }

  private onAssistantMessage(
    sessionId: SessionId,
    state: SessionState,
    event: SessionEvent<'assistant/message'>,
  ): void {
    if (!this.sessionConfig(sessionId).loopGuard) return;
    const text = this.assistantText(event);
    const trimmed = visibleText(text);
    // 相同文本重复(不限长度): 模型反复输出完全相同的消息是最强的循环信号,
    // 例如 "Let me test variants of the regex..." 连续 7 遍
    if (trimmed !== '' && trimmed === state.lastAssistantText) {
      state.sameTextRun += 1;
    } else {
      state.lastAssistantText = trimmed;
      state.sameTextRun = trimmed === '' ? 0 : 1;
    }
    // 短句计数(长度 < loopShortChars 且落在时间窗内): 空转信号
    if (trimmed.length < this.getConfig().loopShortChars) {
      const now = Date.now();
      if (now - state.lastShortAt > this.getConfig().loopWindowMs) {
        state.shortRun = 0; // 超过时间窗: 上一次短句太久远, 不算连续
      }
      state.shortRun += 1;
      state.lastShortAt = now;
    } else {
      state.shortRun = 0; // 长句 = 有实际输出, 重置
      state.lastShortAt = 0;
    }
    const streamTail = state.streamTail;
    state.streamTail = '';
    if (streamTail !== '') this.noteStreamSegment(sessionId, state, streamTail);
    state.streamLastSegment = '';
    state.streamRepeatRun = 0;
    this.checkLoop(sessionId, state);
  }

  /** 两个循环信号的公共检查; 命中且本回合未打断过则打断。 */
  private checkLoop(
    sessionId: SessionId,
    state: SessionState,
    toolRepeat?: ToolRepeatSignal,
  ): void {
    if (!this.sessionConfig(sessionId).loopGuard) return;
    if (state.loopFired) return;
    if (!state.running) return; // 只干预运行中的回合
    const config = this.getConfig();
    if (state.sameTextRun >= config.loopRepeatText) {
      this.log(`检测到空转循环 ${sessionId}: 连续 ${state.sameTextRun} 条相同消息`);
      this.interruptLoop(sessionId, state);
    } else if (state.shortRun >= config.loopShortCount) {
      this.log(`检测到空转循环 ${sessionId}: 连续 ${state.shortRun} 条短句且无工具调用`);
      this.interruptLoop(sessionId, state);
    } else if (toolRepeat !== undefined && toolRepeat.count >= config.loopToolRepeat) {
      this.log(`检测到工具死循环 ${sessionId}: 「${toolRepeat.tool}」连续 ${toolRepeat.count} 次(同参数同结果)`);
      this.interruptLoop(sessionId, state);
    }
  }

  /**
   * 打断运行中的回合: cancel(带来源标记)+ 进冷却。
   * 只有随后持久化的 turn/end 精确携带专属 hook cause 时,
   * 才会用 loopText 重启回合——DSH 的 first-cause 语义保证用户 Stop 优先。
   */
  private interruptLoop(sessionId: SessionId, state: SessionState): void {
    if (this.isSubagent(sessionId, state)) return;
    if (state.loopFired) return;
    // 打断本身受冷却约束: 距上次打断/发送太近时不再打断, 防止反复打断刷屏
    if (Date.now() - state.lastAttemptAt < this.cooldownFor(state)) {
      this.log(`跳过循环打断 ${sessionId}: 处于冷却期`);
      return;
    }
    state.loopFired = true;
    state.lastAttemptAt = Date.now(); // 打断计入冷却, 防反复打断
    try {
      const agent = this.ctx.agents.get(sessionId);
      if (agent === undefined) {
        this.log(`打断循环失败 ${sessionId}: 无 live agent`);
        state.loopFired = false;
        return;
      }
      agent.cancel(LOOP_GUARD_CANCEL_CAUSE, { keepInbox: true });
      this.log(`已打断循环 ${sessionId}: cancel 已受理`);
    } catch (error) {
      this.log(`打断循环失败 ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
      state.loopFired = false;
    }
  }

  private onSessionEvent(sessionId: SessionId, event: SessionEvent): void {
    const state = this.state(sessionId);
    switch (event.type) {
      case 'turn/start':
        state.running = true;
        state.maintenanceTurn = isMaintenanceTurnStart(event) ? event.data.turn : undefined;
        if (state.maintenanceTurn !== undefined) state.pendingRecoveryAt = 0;
        // 新回合开始: 清空上一步工具调用状态, 避免跨回合误用护栏
        state.tools.startTurn(event.seq);
        // loop guard 状态按回合重置
        state.shortRun = 0;
        state.lastShortAt = 0;
        state.lastAssistantText = '';
        state.sameTextRun = 0;
        state.streamTail = '';
        state.streamLastSegment = '';
        state.streamRepeatRun = 0;
        state.loopFired = false;
        state.turnOutput = 'empty';
        state.outputTurn = event.data.turn;
        state.outputStartSeq = event.seq;
        if (state.loopRetryTimer !== undefined) {
          clearTimeout(state.loopRetryTimer);
          state.loopRetryTimer = undefined;
        }
        this.cancelPending(sessionId, '宿主自行开启新回合');
        break;
      case 'turn/end': {
        state.running = false;
        const loopCancelPending = state.loopFired;
        state.loopFired = false;
        this.cancelPending(sessionId, '收到新的 turn/end');
        const turnOutput = state.outputTurn === event.data.turn ? state.turnOutput : 'unknown';
        state.turnOutput = 'unknown';
        state.outputTurn = undefined;
        const maintenance = state.maintenanceTurn !== undefined && state.maintenanceTurn === event.data.turn;
        state.maintenanceTurn = undefined;
        if (maintenance) {
          this.log(`跳过维护回合 ${sessionId}(message-ops): 不触发自动继续`);
          break;
        }
        const reason = event.data.reason;
        const reasonKind = readReasonKind(reason);
        if (reasonKind === undefined) {
          console.error(`[auto-continue] 忽略畸形 turn/end ${sessionId}: reason 无法解释`);
          break;
        }
        if (reasonKind === 'no-visible-output' || (reasonKind === 'completed' && turnOutput === 'silent')) {
          // 已观察到模型活动但没有可见输出; 没有模型活动的空回合不属于此类。
          // 不清零 consecutive: 每轮都卡住的模型仍受冷却与连续上限约束。
          // `no-visible-output` 是 DSH 为同一种回合提议的结束原因, 按同样方式处理。
          state.lastFailure = undefined;
          state.lastTurn = event.data.turn;
          state.lastFailureAt = Date.now();
          this.noteRecovery(sessionId, 'error');
          if (this.sessionConfig(sessionId).resumeCompletedTurns) {
            // 自主循环覆盖无可见输出的回合, 但这类回合是「失败」而非成功:
            // 不 force, 否则会绕过连续上限与冷却, 让卡住的模型无限重试。
            this.schedule(sessionId, LOOP_SILENT_REASON);
          } else if (this.sessionConfig(sessionId).resumeSilentTurns) {
            this.schedule(sessionId, `turn/end:${reasonKind}:silent`);
          }
          break;
        }
        if (reasonKind === 'completed') {
          // Only observed visible output proves recovery; no-op and unknown
          // turns must not erase the retry budget or count as successful.
          // 自主循环的例外只在于「是否续跑」, 不在于「是否清零预算」: 循环对每个
          // completed 回合都强制续跑, 但失败预算依旧只在可见输出时清零, 否则
          // 空回合/未观察到的回合会不断抹掉连续计数, 令连续上限永远无法生效。
          if (this.sessionConfig(sessionId).resumeCompletedTurns) {
            if (turnOutput === 'visible') {
              state.consecutive = 0;
              state.lastFailure = undefined;
              this.noteRecovery(sessionId, 'completed');
            }
            this.schedule(sessionId, LOOP_COMPLETED_REASON, true);
          } else if (turnOutput === 'visible') {
            state.consecutive = 0;
            state.lastFailure = undefined;
            this.noteRecovery(sessionId, 'completed');
          }
        } else if (reasonKind === 'aborted') {
          if (isLoopGuardCancelReason((reason as { reason?: unknown }).reason)) {
            if (this.sessionConfig(sessionId).paused) break;
            // 我们自己的 loop guard 打断: 视为可恢复中断, 用循环提示文本重启回合。
            // 不清 consecutive / lastAttemptAt: 冷却与连续上限在 loop 路径同样生效,
            // 防止无限打断重发(issue #13); 打断本身受冷却约束, 重启也要等冷却。
            if (loopCancelPending) this.bumpStat({ looped: 1 });
            state.pendingRecoveryAt = 0;
            state.shortRun = 0;
            state.lastShortAt = 0;
            state.lastAssistantText = '';
            state.sameTextRun = 0;
            state.streamTail = '';
            state.streamLastSegment = '';
            state.streamRepeatRun = 0;
            state.tools.resetRepeat();
            // 重启受冷却约束(防紧密打断循环): 等剩余冷却结束后再调度
            const cooldown = this.cooldownFor(state);
            const remaining = cooldown - (Date.now() - state.lastAttemptAt);
            if (remaining > 0) {
              if (state.loopRetryTimer !== undefined) clearTimeout(state.loopRetryTimer);
              state.loopRetryTimer = setTimeout(() => {
                state.loopRetryTimer = undefined;
                try {
                  this.schedule(sessionId, 'loop:aborted');
                } catch (error) {
                  console.error(`[auto-continue] loop 重启异常 ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
                }
              }, remaining + 10); // +10ms: the schedule re-check compares Date.now() against the cooldown; a 1ms wall-clock step can otherwise make it read just under, silently dropping the restart
              this.log(`loop 重启延迟 ${remaining}ms(冷却期) ${sessionId}`);
            } else {
              this.schedule(sessionId, 'loop:aborted');
            }
          } else {
            // 用户主动停止: 不自动继续, 视为用户介入
            state.consecutive = 0;
            state.pendingRecoveryAt = 0;
          }
        } else if (reasonKind === 'blocked') {
          // 策略拒绝: 不自动继续
        } else if (reasonKind === 'interrupted') {
          // 实时路径的 interrupted 仅来自崩溃修复重载(loop 从不实时发出);
          // 用户手动停止在 DSH 中标记为 aborted, 不走到这里。实时流里出现
          // interrupted 视为异常中断, 不自动继续——宿主崩溃孤儿回合由扫描恢复。
          state.consecutive = 0;
          state.pendingRecoveryAt = 0;
        } else if (reasonKind === 'error') {
          // 记录失败事实(分类与模板填充用), 然后按类型处理
          const failure = parseFailureFacts((reason as { error?: unknown }).error);
          if (failure === undefined) {
            console.error(`[auto-continue] 忽略畸形 turn/end ${sessionId}: error details 无法解释`);
            break;
          }
          state.lastFailure = failure;
          state.lastTurn = event.data.turn;
          state.lastFailureAt = Date.now();
          this.noteRecovery(sessionId, 'error');
          this.onTurnFailure(sessionId, 'turn/end:error', state.lastFailure);
        } else if (reasonKind === 'max-tokens') {
          state.lastFailureAt = Date.now();
          this.noteRecovery(sessionId, 'error');
          this.schedule(sessionId, 'turn/end:max-tokens');
        }
        break;
      }
      case 'user/message':
        if (isOurEcho(state, event)) break; // 我们自己的回显(跨标签页识别)
        if (event.data.source.kind === 'user') {
          // 用户手动介入: 清零上限与跨标签页发送计数
          state.consecutive = 0;
          this.cancelPending(sessionId, '用户手动发送消息');
        }
        break;
      default:
        break;
    }
  }

  // ---------- host 帧 ----------

  private onTurnFailure(sessionId: SessionId, reason: string, failure: FailureFacts): void {
    const config = this.getConfig();
    if (sessionMode(config.sessionModes, sessionId) === 'off') return;
    if (config.classify && !isTransientFailure(failure, config.retryableErrorPatterns)) {
      const copy = NOTICE_COPY[config.locale];
      const summary = `${failure.code}${failure.status !== undefined ? ` (HTTP ${failure.status})` : ''}`;
      this.log(`跳过 ${sessionId}(${reason}): 永久性失败 ${summary} — ${failure.message}`);
      this.bumpStat({ skipped: 1, code: failure.code });
      if (config.notify) {
        this.notify(
          sessionId,
          copy.notContinuedTitle,
          copy.permanentErrorBody(sessionId, summary),
          this.notifyOptions(sessionId, config.locale),
        );
      }
      return;
    }
    this.schedule(sessionId, reason);
  }

  /** 通知操作按钮与回调(「立即续跑」/「暂停该会话 1 小时」)。 */
  private notifyOptions(sessionId: SessionId, locale: AutoContinueLocale): NotifyOptions {
    const copy = NOTICE_COPY[locale];
    // 未物化的存储会话没有 live agent, 「立即续跑」只会空转; 只保留暂停。
    const actions: NotifyAction[] = this.ctx.agents.get(sessionId) === undefined
      ? [{ action: 'pause1h', title: copy.pauseAction }]
      : [
        { action: 'resume', title: copy.resumeAction },
        { action: 'pause1h', title: copy.pauseAction },
      ];
    return { actions, onAction: (action) => this.onNotifyAction(sessionId, action) };
  }

  private onNotifyAction(sessionId: SessionId, action: string): void {
    if (action === 'resume') {
      this.log(`通知按钮: 立即续跑 ${sessionId}`);
      void this.resumeNow(sessionId);
    } else if (action === 'pause1h') {
      this.log(`通知按钮: 暂停 ${sessionId} 1 小时`);
      this.pauseUntil.set(sessionId, Date.now() + 60 * 60 * 1000);
      this.cancelPending(sessionId, '通知按钮暂停该会话');
    }
  }


  /** 内存统计(host 单实例): 按今日桶累计。 */
  private bumpStat(delta: {
    sent?: number;
    skipped?: number;
    recovered?: number;
    failed?: number;
    gaveUp?: number;
    looped?: number;
    code?: string;
  }): void {
    const today = todayKey();
    if (this.dayStats.date !== today) this.dayStats = emptyDayStats();
    if (delta.sent !== undefined) this.dayStats.sent += delta.sent;
    if (delta.skipped !== undefined) this.dayStats.skipped += delta.skipped;
    if (delta.recovered !== undefined) this.dayStats.recovered += delta.recovered;
    if (delta.failed !== undefined) this.dayStats.failed += delta.failed;
    if (delta.gaveUp !== undefined) this.dayStats.gaveUp += delta.gaveUp;
    if (delta.looped !== undefined) this.dayStats.looped += delta.looped;
    if (delta.code !== undefined) {
      this.dayStats.byCode[delta.code] = (this.dayStats.byCode[delta.code] ?? 0) + 1;
    }
    // Stats are only observable through the status bridge, so every bump must
    // publish. Previously the panel only moved when a notification happened to
    // fire (notify=false by default), leaving "Auto-continued" frozen at 0.
    this.emitState();
  }

  /** 通知桥: 产生一条通知事件, SSE 端点推给 browser 侧展示。 */
  private notify(
    sessionId: SessionId,
    title: string,
    body: string,
    options?: NotifyOptions,
  ): void {
    const notice: HostNotice = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      title,
      body,
      sessionId,
      ...(options?.actions !== undefined && options.actions.length > 0
        ? { actions: options.actions }
        : { actions: [] }),
      at: Date.now(),
    };
    this.notices.push(notice);
    for (const listener of this.noticeListeners) listener();
    this.emitState();
  }

  /** 恢复结果记账: 自动发送后窗口内的回合结束, 判定恢复成功或失败。 */
  private noteRecovery(sessionId: SessionId, outcome: 'completed' | 'error'): void {
    const state = this.state(sessionId);
    if (state.pendingRecoveryAt === 0) return;
    if (Date.now() - state.pendingRecoveryAt > RECOVERY_WINDOW_MS) {
      state.pendingRecoveryAt = 0; // 窗口过期, 不再归属这次发送
      return;
    }
    state.pendingRecoveryAt = 0;
    this.bumpStat(outcome === 'completed' ? { recovered: 1 } : { failed: 1 });
    this.log(`恢复结果(${sessionId}): ${outcome === 'completed' ? '成功' : '失败'}`);
  }

  /** 立即为该会话发送一次自动继续(无视冷却与连续上限; 由通知按钮触发)。 */
  async resumeNow(sessionId: SessionId): Promise<void> {
    if (this.disposed) return;
    const state = this.state(sessionId);
    if (this.isSubagent(sessionId, state)) return;
    if (state.pendingTimer !== undefined) {
      clearTimeout(state.pendingTimer);
      state.pendingTimer = undefined;
    }
    try {
      await this.fire(sessionId, MANUAL_NOTIFICATION_REASON, true);
    } catch (error) {
      console.error(`[auto-continue] 手动续跑异常 ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /** 本会话当前生效的冷却间隔(自适应退避)。 */
  private cooldownFor(state: SessionState): number {
    const config = this.getConfig();
    return effectiveCooldown(
      state.consecutive,
      config.cooldownMs,
      config.backoffFactor,
      config.backoffMaxMs,
    );
  }

  private schedule(sessionId: SessionId, reason: string, force = false): void {
    const state = this.state(sessionId);
    const config = this.sessionConfig(sessionId);
    if (isLoopReason(reason) && !config.resumeCompletedTurns) return;
    if (this.isSubagent(sessionId, state)) return; // 子代理会话由父代理处理, 不抢跑
    if (config.paused) {
      this.log(`跳过 ${sessionId}(${reason}): 自动继续已暂停`);
      return;
    }
    if (Date.now() < (this.pauseUntil.get(sessionId) ?? 0)) {
      this.log(`跳过 ${sessionId}(${reason}): 会话暂停中`);
      return;
    }
    if (state.pendingTimer !== undefined) return; // 已有待发送
    // 连续上限优先于冷却: 已经放弃的会话不该再安排冷却后的重试。
    // 自主循环的完成续跑(force)不受二者约束。
    if (!force && state.consecutive >= config.maxConsecutive) {
      this.log(
        `跳过 ${sessionId}(${reason}): 已连续自动继续 ${state.consecutive} 次, 等待用户介入或成功回合`,
      );
      return;
    }
    // 冷却(含失败尝试, 自适应退避): 不能直接丢弃这次恢复, 否则一次瞬时失败
    // 会把会话搁置到用户手动介入为止。
    if (!force) {
      const remaining = this.cooldownFor(state) - (Date.now() - state.lastAttemptAt);
      if (remaining > 0) {
        this.deferCooldownRetry(sessionId, reason, remaining);
        return;
      }
    }
    const timer = setTimeout(() => {
      if (state.pendingTimer !== timer) return;
      state.pendingTimer = undefined;
      state.pendingReason = undefined;
      // 保险丝: 定时器回调内任何异常(含 inactive context)都不得成为未捕获异常炸掉进程。
      try {
        void this.fire(sessionId, reason, force);
      } catch (error) {
        console.error(`[auto-continue] 定时发送异常 ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }, config.graceMs);
    state.pendingTimer = timer;
    state.pendingReason = reason;
    const template = this.templateFor(config, reason);
    this.log(
      `检测到非人为中断 ${sessionId}(${reason}), ${config.graceMs}ms 后自动发送「${template}」`,
    );
  }

  /**
   * 冷却期内的恢复: 等到冷却结束再重新调度。
   * 直接丢弃会让一次瞬时失败把会话搁置, 直到用户手动发消息才恢复。
   */
  private deferCooldownRetry(sessionId: SessionId, reason: string, remaining: number): void {
    const state = this.state(sessionId);
    if (state.cooldownRetryTimer !== undefined) clearTimeout(state.cooldownRetryTimer);
    state.pendingReason = reason;
    state.cooldownRetryTimer = setTimeout(() => {
      state.cooldownRetryTimer = undefined;
      state.pendingReason = undefined;
      try {
        this.schedule(sessionId, reason);
      } catch (error) {
        console.error(`[auto-continue] 冷却后重试异常 ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }, remaining + 10); // +10ms: 同 loop 重启; 否则 1ms 抖动可能让重检仍判为冷却期而再次丢弃
    this.log(`冷却中 ${sessionId}(${reason}), ${remaining}ms 后重试`);
  }

  /** 按调度原因选择续跑模板: loop 重启、无输出回合、max-tokens、自主循环, 其余用通用继续文本。 */
  private templateFor(config: AutoContinueConfig, reason: string): string {
    if (reason.startsWith('loop:')) return config.loopText;
    // 自主循环的两种原因都用循环文本(顺序在 `:silent` 之前: 循环模式决定文本)。
    if (isLoopReason(reason)) return config.continueTextLoop;
    if (reason.endsWith(':silent')) return config.continueTextSilent;
    if (reason.includes('max-tokens')) return config.continueTextMaxTokens;
    if (reason.includes('interrupted')) return config.continueTextInterrupted;
    return config.continueText;
  }

  private cancelPending(sessionId: SessionId, why: string): void {
    const state = this.state(sessionId);
    state.pendingReason = undefined;
    let cancelled = false;
    if (state.pendingTimer !== undefined) {
      clearTimeout(state.pendingTimer);
      state.pendingTimer = undefined;
      cancelled = true;
    }
    // 冷却后的重试同样属于「待发送」: 新回合或用户介入必须让它作废。
    if (state.cooldownRetryTimer !== undefined) {
      clearTimeout(state.cooldownRetryTimer);
      state.cooldownRetryTimer = undefined;
      cancelled = true;
    }
    if (state.loopRetryTimer !== undefined) {
      clearTimeout(state.loopRetryTimer);
      state.loopRetryTimer = undefined;
      cancelled = true;
    }
    if (cancelled) this.log(`取消 ${sessionId} 的自动继续(${why})`);
  }

  private fire(sessionId: SessionId, reason: string, force = false): void {
    if (this.disposed) return;
    const state = this.state(sessionId);
    const config = this.sessionConfig(sessionId);
    const manualResume = force && reason === MANUAL_NOTIFICATION_REASON;
    if (reason.endsWith(':silent') && !config.resumeSilentTurns) return;
    // 宽限期内循环被关闭: 发送前必须重新检查开关, 与 :silent 恢复同样处理。
    // 否则「关掉循环」后仍会多发出一次续跑。
    if (isLoopReason(reason) && !config.resumeCompletedTurns) return;
    if (this.isSubagent(sessionId, state)) return; // 子代理会话由父代理处理, 不抢跑
    if (config.paused && !manualResume) {
      this.log(`跳过 ${sessionId}(${reason}): 自动继续已暂停`);
      return;
    }
    if (!manualResume && Date.now() < (this.pauseUntil.get(sessionId) ?? 0)) {
      this.log(`跳过 ${sessionId}(${reason}): 会话暂停中`);
      return;
    }
    // 冷却(自适应退避)与连续上限; 通知按钮的强制续跑不受约束
    if (!force && Date.now() - state.lastAttemptAt < this.cooldownFor(state)) {
      this.log(`跳过 ${sessionId}(${reason}): 处于冷却期`);
      return;
    }
    if (!force && state.consecutive >= config.maxConsecutive) {
      this.log(`跳过 ${sessionId}(${reason}): 已连续自动继续 ${state.consecutive} 次, 等待用户介入或成功回合`);
      return;
    }
    // 模板填充: continueText 可含 {code}/{message}/{status}/{tool}/{turn}/{errorCount}/{sessionTitle}/{elapsed} 占位符
    const template = this.templateFor(config, reason);
    const text = this.buildContinueText(config, state, template);
    // 发送: followup 负责唤醒; 同步 inbox 插入事件会在唤醒前把本消息移到已有队列之前。
    const agent = this.ctx.agents.get(sessionId);
    if (agent === undefined) {
      this.log(`跳过 ${sessionId}(${reason}): 无 live agent`);
      return;
    }
    state.lastAttemptAt = Date.now(); // 先记账: 无论成败, 本次尝试都进入冷却
    try {
      const message = createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'user' },
      });
      // `followup` may publish the matching session event synchronously.
      trackPendingEcho(state, message.id);
      if (agent.inbox.nextTurn.length > 0) this.prioritizedFollowups.add(message.id);
      try {
        agent.followup(message);
      } catch (error) {
        forgetPendingEcho(state, message.id);
        throw error;
      } finally {
        this.prioritizedFollowups.delete(message.id);
      }
      const now = Date.now();
      // 自主循环的成功续跑不计入连续上限: 上限只约束失败(网络中断等)。
      if (reason !== LOOP_COMPLETED_REASON) state.consecutive += 1;
      state.pendingRecoveryAt = now; // 等待窗口内的下一个回合结束来判定恢复结果
      if (reason !== LOOP_COMPLETED_REASON) {
        this.recoveryAttempts.unshift({
          sessionId, at: now, consecutive: state.consecutive,
          reason: manualResume ? 'manual'
            : reason === 'loop:aborted' ? 'loop-guard'
            : reason.endsWith(':silent') || reason === LOOP_SILENT_REASON ? 'silent'
            : reason.endsWith(':interrupted') ? 'interrupted'
            : reason.endsWith(':max-tokens') ? 'max-tokens' : 'error',
        });
        this.recoveryAttempts.length = Math.min(this.recoveryAttempts.length, 20);
      }
      this.bumpStat({ sent: 1, ...(state.lastFailure !== undefined ? { code: state.lastFailure.code } : {}) });
      this.log(`已自动发送「${text}」到 ${sessionId}(${reason}), 第 ${state.consecutive} 次连续`);
      if (config.notify) {
        const copy = NOTICE_COPY[config.locale];
        this.notify(
          sessionId,
          copy.continuedTitle,
          copy.continuedBody(sessionId, text, state.consecutive),
          this.notifyOptions(sessionId, config.locale),
        );
      }
      if (state.consecutive >= config.maxConsecutive) {
        this.bumpStat({ gaveUp: 1 });
        this.log(`达到连续上限 ${config.maxConsecutive} 次, 停止自动继续 ${sessionId}`);
        if (config.notify) {
          const copy = NOTICE_COPY[config.locale];
          this.notify(
            sessionId,
            copy.stoppedTitle,
            copy.stoppedBody(sessionId, state.consecutive),
            this.notifyOptions(sessionId, config.locale),
          );
        }
      }
    } catch (error) {
      this.log(`发送异常 ${sessionId}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * 组装本次续跑消息: 模板填充 + 幂等护栏。
   * 护栏依据上一步工具调用的执行状态附加指引, 防止重跑副作用操作:
   * - 结果未确认(可能已部分执行)→ 提示先确认状态、不要重复执行
   * - 已确认成功 → 提示已完成、不要重复执行
   * - 已失败 → 不加护栏(重试工具本来就是目的)
   */
  private buildContinueText(
    config: AutoContinueConfig,
    state: SessionState,
    template: string,
  ): string {
    let text = fillTemplate(template, {
      facts: state.lastFailure,
      tool: state.tools.lastTool(),
      turn: state.lastTurn,
      errorCount: state.consecutive + 1,
      elapsedMs: state.lastFailureAt > 0 ? Date.now() - state.lastFailureAt : undefined,
    });
    if (!config.guardTools) return text;
    const guard = this.currentGuard(state);
    if (guard.kind === 'pending') {
      text += ` ${fillTemplate(config.guardPendingText, { tool: guard.tool, result: guard.result })}`;
    } else if (guard.kind === 'done') {
      text += ` ${fillTemplate(config.guardDoneText, { tool: guard.tool, result: guard.result })}`;
    }
    return text;
  }

  /** 上一步工具调用的护栏状态(实时路径, 由 mux 帧维护)。 */
  private currentGuard(state: SessionState): {
    kind: 'none' | 'pending' | 'done' | 'failed';
    tool?: string;
    result?: string;
  } {
    return state.tools.guard();
  }

  private async bootScanLoop(): Promise<void> {
    // Sessions restored after this window are too old for startup recovery.
    // Keep polling only within that window, including while globally paused.
    const deadline = Date.now() + this.getConfig().freshMs;
    for (let attempt = 0; !this.disposed; attempt += 1) {
      if (attempt > 0 && Date.now() >= deadline) return;
      try {
        if (await this.scanInterrupted()) return;
        const config = this.getConfig();
        if (!config.paused && config.scanOnBoot && this.storedSweep === undefined) {
          this.storedSweep = this.sweepStoredSessions(config, deadline)
            .catch(error => {
              if (!this.disposed) this.ctx.logger.error(`Stored session scan failed: ${String(error)}`);
            })
            .finally(() => { this.storedSweep = undefined; });
        }
      } catch (error) {
        if (this.disposed) return;
        // 宿主未就绪时每 3s 重试; 只节流记录日志, 避免刷屏。
        if (attempt % 10 === 0) {
          this.log(
            `扫描失败(${attempt + 1}): ${
              error instanceof Error ? error.message : String(error)
            }`,
          );
        }
      }
      const remaining = deadline - Date.now();
      if (this.disposed || remaining <= 0) return;
      await new Promise<void>((resolve) => {
        this.wakeBootScan = () => {
          if (this.bootScanTimer !== undefined) clearTimeout(this.bootScanTimer);
          this.bootScanTimer = undefined;
          this.wakeBootScan = undefined;
          resolve();
        };
        this.bootScanTimer = setTimeout(this.wakeBootScan, Math.min(3000, remaining));
      });
    }
  }

  /** Inspect newly available sessions; process each settled startup history once. */
  private async scanInterrupted(): Promise<boolean> {
    const config = this.getConfig();
    if (config.paused || !config.scanOnBoot) return false;
    const now = Date.now();
    const candidates: {
      session: Session;
      sessionId: SessionId;
      events: readonly SessionEvent[];
      lastEnd: SessionEvent<'turn/end'>;
      reasonKind: string;
      failure?: FailureFacts;
      lastActivityAt: number;
      listIndex: number;
    }[] = [];
    for (const agent of this.ctx.agents.list()) {
      let session: Session | undefined;
      let sessionId: SessionId | undefined;
      try {
        session = agent.session;
        // Check quarantine before reading metadata that may have failed previously.
        if (this.bootScannedSessions.has(session) || session.header?.origin === 'subagent') continue;
        sessionId = session.id;
        if (typeof sessionId !== 'string' || sessionId === '') throw new TypeError('session id is unavailable');
        if (this.sessionConfig(sessionId).paused) continue;
        const state = this.state(sessionId);
        if (state.pendingTimer !== undefined || state.consecutive >= config.maxConsecutive) continue;
        if (now - state.lastAttemptAt < this.cooldownFor(state)) continue;
        if (now < (this.pauseUntil.get(sessionId) ?? 0)) continue;
        const events = snapshotSessionEvents(session);
        // An empty, valid snapshot may still be waiting for history hydration.
        if (events.length === 0) continue;
        let lastEnd: SessionEvent<'turn/end'> | undefined;
        for (let i = events.length - 1; i >= 0; i -= 1) {
          const event = events[i];
          if (event?.type === 'turn/end') { lastEnd = event; break; }
        }
        const reasonKind = readReasonKind(lastEnd?.data.reason);
        const lastStart = latestTurnStart(events);
        const maintenance = lastStart?.data.turn === lastEnd?.data.turn && isMaintenanceTurnStart(lastStart);
        const silent = reasonKind === 'no-visible-output' && config.resumeSilentTurns;
        const superseded = lastEnd !== undefined && events.some((event) =>
          event.seq > lastEnd!.seq && (event.type === 'turn/start' ||
            (event.type === 'user/message' && event.data.source.kind === 'user')),
        );
        if (lastEnd === undefined || maintenance || reasonKind === undefined || (!isNonHumanReason(reasonKind) && !silent) ||
            lastEnd.time < now - config.freshMs || superseded) {
          this.bootScannedSessions.add(session);
          continue;
        }
        let failure: FailureFacts | undefined;
        if (reasonKind === 'error') {
          failure = parseFailureFacts((lastEnd.data.reason as { error?: unknown }).error);
          if (failure === undefined) {
            this.bootScannedSessions.add(session);
            console.error(`[auto-continue] 忽略畸形扫描 turn/end ${sessionId}: error details 无法解释`);
            continue;
          }
          if (config.classify && !isTransientFailure(failure, config.retryableErrorPatterns)) {
            this.bootScannedSessions.add(session);
            this.onTurnFailure(sessionId, 'scan:turn/end:error', failure);
            continue;
          }
        }
        candidates.push({
          session, sessionId, events, lastEnd, reasonKind, failure,
          lastActivityAt: events.reduce((latest, event) => Math.max(latest, event.time), 0),
          listIndex: candidates.length,
        });
      } catch (error) {
        if (session !== null && typeof session === 'object') this.bootScannedSessions.add(session);
        const identity = session ?? agent;
        if (identity !== null && typeof identity === 'object') {
          if (this.bootScanErrors.has(identity)) continue;
          this.bootScanErrors.add(identity);
        }
        this.logBootScanFailure(sessionId, error);
      }
    }
    // Limit recoveries, not healthy/permanent histories that cannot be resumed.
    candidates.sort((left, right) => right.lastActivityAt - left.lastActivityAt || left.listIndex - right.listIndex);
    let recoveries = 0;
    for (const candidate of candidates) {
      if (recoveries >= config.scanLimit) break;
      if (this.disposed) return true;
      const { session, sessionId, events, lastEnd, reasonKind, failure } = candidate;
      this.bootScannedSessions.add(session);
      const state = this.state(sessionId);
      try {
        this.applyGuardFromEvents(state, events, lastEnd.seq);
        const scanReason = `scan:turn/end:${reasonKind}${reasonKind === 'no-visible-output' ? ':silent' : ''}`;
        this.log(`扫描发现中断 ${sessionId}(turn/end:${reasonKind}), 交给恢复策略处理`);
        if (failure !== undefined) {
          state.lastFailure = failure;
          state.lastTurn = lastEnd.data.turn;
          state.lastFailureAt = lastEnd.time;
          this.onTurnFailure(sessionId, scanReason, failure);
        } else {
          if (reasonKind === 'no-visible-output') state.lastFailure = undefined;
          // 没有失败事实的恢复(如 interrupted)也要填 {turn}/{elapsed}, README 对所有继续文本承诺这些占位符。
          state.lastTurn = lastEnd.data.turn;
          state.lastFailureAt = lastEnd.time;
          this.schedule(sessionId, scanReason);
        }
        recoveries += 1;
      } catch (error) {
        state.tools.reset();
        this.cancelPending(sessionId, '启动扫描失败');
        this.logBootScanFailure(sessionId, error);
      }
    }
    return false;
  }

  /** Bound cold reads even if a backend ignores cancellation; release late leases. */
  private async readStored<T extends object>(read: (signal: AbortSignal) => Promise<T>, deadline: number): Promise<T> {
    const timeout = new AbortController();
    const signal = AbortSignal.any([this.stopStoredSweep.signal, timeout.signal]);
    const timer = setTimeout(() => timeout.abort(new Error('Stored session read timed out')), Math.max(0, Math.min(STORED_READ_TIMEOUT_MS, deadline - Date.now())));
    let onAbort: () => void;
    const cancelled = new Promise<never>((_resolve, reject) => {
      onAbort = () => reject(signal.reason);
      signal.addEventListener('abort', onAbort, { once: true });
      if (signal.aborted) onAbort();
    });
    const pending = Promise.resolve().then(() => { signal.throwIfAborted(); return read(signal); });
    void pending.then(value => {
      if (signal.aborted) (value as { [Symbol.dispose]?: () => void })[Symbol.dispose]?.();
    }).catch(() => {});
    try {
      return await Promise.race([pending, cancelled]);
    } finally {
      clearTimeout(timer);
      signal.removeEventListener('abort', onAbort!);
    }
  }

  /**
   * 存储扫描: 枚举持久化会话, 把尾部命中恢复谓词的未加载会话物化为
   * live agent。宿主重启后 agent 仅在客户端打开会话时才懒加载, 不物化
   * 则启动扫描永远看不到它们; 谓词与上方扫描一致, 仅失败类原因。
   */
  private async sweepStoredSessions(config: AutoContinueConfig, deadline: number): Promise<void> {
    const query = this.ctx.get('sessionQuery');
    if (query === undefined) return;
    const records = await this.readStored(signal => query.listSessions(signal), deadline);
    if (!Array.isArray(records)) throw new TypeError('stored session listing is not an array');
    if (!this.storedSweepAnnounced) {
      this.storedSweepAnnounced = true;
      this.ctx.logger.info(`存储扫描就绪: ${records.length} 个会话记录`);
    }
    let observed = 0;
    for (const record of records) {
      if (this.disposed || Date.now() >= deadline || this.getConfig().paused || !this.getConfig().scanOnBoot) return;
      if (typeof record?.header?.id !== 'string' || record.header.id === '') {
        this.logBootScanFailure(undefined, new TypeError('stored session record has no id'));
        continue;
      }
      const sessionId = record.header.id;
      if (this.sessionConfig(sessionId).paused || Date.now() < (this.pauseUntil.get(sessionId) ?? 0)) continue;
      if (record.live || this.storedSwept.has(sessionId)) continue;
      this.storedSwept.add(sessionId);
      if (record.header.origin === 'subagent') continue;
      observed += 1;
      let observation: StoredObservation | undefined;
      try {
        const stored: StoredObservation = await this.readStored(signal => query.observeSession(sessionId, { projectionMode: 'all', signal }), deadline);
        observation = stored;
        if (this.disposed) return;
        if (this.sessionConfig(sessionId).paused) {
          this.storedSwept.delete(sessionId);
          continue;
        }
        const events = validateSessionEvents(stored.events);
        if (events.length === 0) continue;
        // 快照之后客户端可能已打开该会话: 归还 live 扫描, 避免与 live 路径
        // 重复上报, 也避免物化撞上写归属。
        if (this.ctx.agents.get(sessionId) !== undefined) continue;
        let lastEnd: SessionEvent<'turn/end'> | undefined;
        for (let i = events.length - 1; i >= 0; i -= 1) {
          const event = events[i];
          if (event?.type === 'turn/end') { lastEnd = event; break; }
        }
        const lastStart = latestTurnStart(events);
        // 兜底分支: 真实 sessionQuery 冷读会把内存中的 interruptedTurnClosers
        // 折叠进返回日志(尾部即合成 turn/end), 上方 closed-tail 才是生产主路
        // 径。这里覆盖两种例外——不折叠的宿主实现, 以及 listSessions 快照与
        // observeSession 之间客户端刚打开、切在轮次中间的 live 视图。
        const openTurn = lastStart !== undefined && (lastEnd === undefined || lastStart.seq > lastEnd.seq);
        if (isMaintenanceTurnStart(lastStart) && (openTurn || lastStart?.data.turn === lastEnd?.data.turn)) continue;
        let reasonKind: string | undefined;
        let freshAt: number;
        if (openTurn) {
          reasonKind = 'interrupted';
          freshAt = events[events.length - 1]?.time ?? 0;
        } else {
          reasonKind = readReasonKind(lastEnd?.data.reason);
          freshAt = lastEnd?.time ?? 0;
        }
        // 过期或被取代的永久错误与 live 扫描一致地静默跳过, 不再单独上报。
        if (reasonKind === undefined || freshAt < Date.now() - config.freshMs) continue;
        if (reasonKind !== undefined && !openTurn) {
          const silent = reasonKind === 'no-visible-output' && config.resumeSilentTurns;
          // 尾随 turn/start 已按 openTurn 处理, 这里只剩用户接管一种取代形态。
          const superseded = events.some((event) =>
            lastEnd !== undefined && event.seq > lastEnd.seq && event.type === 'user/message' && event.data.source.kind === 'user',
          );
          if ((!isNonHumanReason(reasonKind) && !silent) || superseded) continue;
          // 镜像 live 扫描的裁决: 畸形/永久错误不值得物化——物化后同样会被拦下。
          if (reasonKind === 'error') {
            const failure = parseFailureFacts((lastEnd!.data.reason as { error?: unknown }).error);
            if (failure === undefined) {
              console.error(`[auto-continue] 忽略畸形存储 turn/end ${sessionId}: error details 无法解释`);
              continue;
            }
            // 永久错误同样走 onTurnFailure, 镜像 live 路径的统计与通知旁效。
            if (config.classify && !isTransientFailure(failure, config.retryableErrorPatterns)) {
              this.onTurnFailure(sessionId, 'sweep:turn/end:error', failure);
              continue;
            }
          }
        }
        const presetId = stored.projections?.values.agentPreset ?? stored.header.agentPreset;
        const loggedConfig = foldRequestHeader(events)?.config;
        if (!await this.materializeStored(
          sessionId,
          presetId,
          loggedConfig === undefined ? undefined : { provider: loggedConfig.provider, model: loggedConfig.model },
        )) {
          this.storedSwept.delete(sessionId);
          return;
        }
        this.storedSweepFailures.delete(sessionId);
        this.wakeBootScan?.();
        this.ctx.logger.info(openTurn
          ? `扫描物化存储会话 ${sessionId}(日志止于 turn/start, 视作 interrupted), 交给启动扫描接管`
          : `扫描物化存储会话 ${sessionId}(turn/end:${reasonKind}), 交给启动扫描接管`);
      } catch (error) {
        if (this.disposed) return;
        // 观察或物化失败允许下一轮重试; 连续触达上限后放弃, 并清掉计数——
        // 已永久跳过的会话不再进入该映射, 不给长存活宿主留死重。
        const failures = (this.storedSweepFailures.get(sessionId) ?? 0) + 1;
        if (failures < SWEEP_MAX_FAILURES) {
          this.storedSweepFailures.set(sessionId, failures);
          this.storedSwept.delete(sessionId);
        } else {
          this.storedSweepFailures.delete(sessionId);
        }
        this.ctx.logger.error(`存储会话 ${sessionId} 物化失败: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        observation?.[Symbol.dispose]?.();
        if (observed % SWEEP_OBSERVE_BATCH === 0 && !this.disposed) {
          await new Promise<void>(resolve => setTimeout(resolve, 0));
        }
      }
    }
  }

  /**
   * 按会话记录的 preset 组合把存储会话恢复为 live agent(镜像会话控制
   * 器的 adopt 路径: preset 挂载 + 会话已记录的模型选择回装)。模型选择
   * 以日志记录的 request-header 播种 agentOptions——{{model}}/{{provider}}
   * 提示变量与首次请求路由都读它, 驱动器还会因路由吻合而自行回装日志
   * 记录的 effort; 无落点(从未发过请求的会话)回落宿主默认。恢复时追
   * 加的合成 turn/end(`interrupted`)随后由常规扫描按既有关卡恢复。
   */
  private async materializeStored(
    sessionId: SessionId,
    presetId: string | undefined,
    logged: { provider: string; model: string } | undefined,
  ): Promise<boolean> {
    if (this.disposed || this.sessionConfig(sessionId).paused || !this.getConfig().scanOnBoot) return false;
    const presets = this.ctx.get('agentPresets');
    // Mirrors session-controller's adopt: without agent options the agent has no
    // provider/model, so prompt variables like {{model}} have no value and the
    // request carries no route.
    const defaultModel = this.ctx.get('agentDefaultModel');
    const selection = defaultModel?.currentSelection();
    const agentOptions = logged !== undefined
      ? { provider: logged.provider, model: logged.model }
      : selection === undefined ? undefined : { provider: selection.provider, model: selection.model };
    if (presets === undefined) {
      await this.ctx.agents.resume({ resumeSessionId: sessionId, agentOptions, signal: this.stopStoredSweep.signal });
      return true;
    }
    const resolvedId = (await presets.resolve(presetId)).id;
    if (this.disposed || this.sessionConfig(sessionId).paused || !this.getConfig().scanOnBoot) return false;
    if (this.ctx.agents.get(sessionId) !== undefined) return true;
    await this.ctx.agents.resume({
      resumeSessionId: sessionId,
      agentOptions,
      signal: this.stopStoredSweep.signal,
      setup: async (agentCtx) => {
        await presets.mount(agentCtx, resolvedId);
      },
    });
    return true;
  }

  /** Captured identity only: even session.id can throw when the header is damaged. */
  private logBootScanFailure(sessionId: SessionId | undefined, error: unknown): void {
    console.error(`[auto-continue] 启动扫描跳过会话 ${sessionId ?? '(id unavailable)'}: ${
      error instanceof Error ? error.message : String(error)
    }`);
  }

  /** 从历史事件恢复上一步工具调用状态(扫描路径的幂等护栏)。 */
  private applyGuardFromEvents(
    state: SessionState,
    events: readonly SessionEvent[],
    untilSeq: number,
  ): void {
    state.tools.restore(events, untilSeq);
  }
}
