#!/usr/bin/env node
/**
 * dsh-ppt-master 自检。
 *
 * 覆盖三类检查：
 *   1. DSH 插件契约 —— 复刻 `installBundle` 的硬校验（不满足会装不上）；
 *   2. skill 载荷 —— frontmatter 可解析、`${SKILL_DIR}` 全部展开；
 *   3. 发布卫生 —— 无本机专属路径、无凭据、无垃圾文件。
 *
 * 无外部依赖：`node verify.mjs`。
 */

import { readFile, readdir, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join, relative } from 'node:path';

const PKG_DIR = dirname(fileURLToPath(import.meta.url));
const results = [];

/**
 * 记录一条检查结果。
 * @param {string} status 'PASS' | 'FAIL' | 'WARN'
 * @param {string} label 检查项名称
 * @param {string} detail 说明
 */
function check(status, label, detail) {
	results.push([status, label, detail]);
}

/** 读取并解析包根 package.json。 */
async function readManifest() {
	return JSON.parse(await readFile(join(PKG_DIR, 'package.json'), 'utf8'));
}

/** 递归收集文件路径。 */
async function walk(dir, out = []) {
	for (const entry of await readdir(dir, { withFileTypes: true })) {
		const full = join(dir, entry.name);
		if (entry.isDirectory()) await walk(full, out);
		else if (entry.isFile()) out.push(full);
	}
	return out;
}

// ── 1. 插件契约 ────────────────────────────────────────────────────────────

const manifest = await readManifest();
const pkgName = manifest.name;

check(
	typeof pkgName === 'string' && /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/.test(pkgName) ? 'PASS' : 'FAIL',
	'包名合法',
	pkgName ?? '(缺失)',
);

// dsh.bundle.patch 必须存在，且指向真实文件。
const patchRel = manifest.dsh?.bundle?.patch;
let patchText = '';
if (typeof patchRel !== 'string' || patchRel === '') {
	check('FAIL', 'dsh.bundle.patch 声明', '缺失 → 安装时报 not-bundle');
} else {
	try {
		patchText = await readFile(join(PKG_DIR, patchRel), 'utf8');
		check('PASS', 'dsh.bundle.patch 声明', patchRel);
	} catch {
		check('FAIL', 'dsh.bundle.patch 声明', `${patchRel} 不存在 → 安装时报 not-bundle`);
	}
}

// patch 必须列进 files，否则不进 tarball。
const filesField = Array.isArray(manifest.files) ? manifest.files : [];
const patchIncluded = typeof patchRel === 'string' && filesField.some((f) => patchRel.replace(/^\.\//, '').startsWith(f.replace(/\/$/, '')));
check(patchIncluded ? 'PASS' : 'FAIL', 'patch 列入 files', patchIncluded ? patchRel : '未列入 → 装完找不到 patch');

// patch 里必须有 - insert:，且 name 严格等于包名。
const hasInsert = /^\s*-\s*insert:/m.test(patchText);
check(hasInsert ? 'PASS' : 'FAIL', 'patch 含 - insert:', hasInsert ? '有' : '缺失 → 挂载后模块解析失败');

// ⚠ 这里刻意**不再**要求 `insert.name === 包名`。
// 那条约束在 installBundle 的 JSON Schema 里写作
//   allOf: [{ not: { required: ["insert"] } }, ...]
// —— 只作用于**非 insert 的覆盖补丁**。insert 列表可以指向任意模块，
// 官方 `dsh-preset-pojia` 就是这么引用的。本 patch 挂的是官方**声明行**
// `@deepseek-ai/dsh-agent-preset`，包名出现在该行的 `plugins:` 列表里。
// （参考：`@deepseek-ai/dsh-agent-preset` 的声明行 id 是 Loader 地址，
// `config.id` 才是会话保存的预设标识。）

const PRESET_PKG = '@deepseek-ai/dsh-agent-preset';
const insertNames = [...patchText.matchAll(/^\s*name:\s*['"]?([^'"\s#]+)['"]?\s*$/gm)].map((m) => m[1]);

check(
	insertNames.includes(PRESET_PKG) ? 'PASS' : 'FAIL',
	'insert 声明行是 agent-preset',
	insertNames.includes(PRESET_PKG) ? PRESET_PKG : `patch 里是 ${JSON.stringify(insertNames)}`,
);

// 本包必须作为预设内的一个插件行被引用，否则装上了也没有工具。
const selfRow = new RegExp(`^\\s*-\\s*id:\\s*\\S+\\s*\\n\\s*name:\\s*['"]?${pkgName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}['"]?\\s*$`, 'm');
check(
	selfRow.test(patchText) ? 'PASS' : 'FAIL',
	'预设内引用了本包',
	selfRow.test(patchText) ? `${pkgName} 是预设的一个插件行` : '预设 plugins: 里找不到本包 → 装了也没工具',
);

// 预设必须有 config.id（会话保存的标识）与 config.plugins。
const presetConfig = /config:\s*\n(?:\s+.*\n)*?\s+id:\s*(\S+)/.exec(patchText);
check(
	presetConfig !== null ? 'PASS' : 'FAIL',
	'预设声明了 config.id',
	presetConfig === null ? '缺失 → 会话无法记住这个预设' : presetConfig[1],
);
check(
	/^\s+plugins:\s*$/m.test(patchText) ? 'PASS' : 'FAIL',
	'预设声明了 plugins 列表',
	/^\s+plugins:\s*$/m.test(patchText) ? '有' : '缺失 → 空预设',
);

// condition 类表达式只能出现在 patch 里（YAML 里的 !!js 标签）。
// 若出现 !!js 必须是合法的 `disabled:` 用法，避免写错导致 load 失败。
const jsTags = [...patchText.matchAll(/^\s*(\S+):\s*!!js\s+(.+)$/gm)].map((m) => [m[1], m[2]]);
const badTags = jsTags.filter(([key, expr]) => key !== 'disabled' || !/^process\.platform\s*[!=]==?\s*'[^']+'$/.test(expr.trim()));
check(badTags.length === 0 ? 'PASS' : 'FAIL', '!!js 标签用法正确', badTags.length === 0 ? `${jsTags.length} 处，均为 disabled: process.platform` : JSON.stringify(badTags));

// group 节点必须给 isolate 命名域，否则资产会发布到根 realm 撞车。
const groupCount = (patchText.match(/name:\s*cordis:group/g) ?? []).length;
const isolateCount = (patchText.match(/^\s+isolate:\s*$/gm) ?? []).length;
check(
	groupCount === isolateCount ? 'PASS' : 'FAIL',
	'每个 group 都有 isolate 域',
	`group ${groupCount} 个 / isolate ${isolateCount} 个`,
);

// 构造期强制 config 的行：这类包在**构造函数里**校验 config（不是 Config schema，
// 所以 config 缺字段是「构造抛错 → 整行挂载失败」，而不是被静默忽略）。
// 后果是预设卡片直接显示红色「加载失败」并无法被选中 —— 实测踩到过：
// `dsh-plan-mode` 不传 config 时 resolveConfig({}) 抛
// "PlanModeConfig needs a string `section`"，整份预设报废。
// 判定依据：这些包的 lib 里存在 `XxxConfig needs ...` 形态的构造期断言。
const REQUIRES_CONFIG = [
	['@deepseek-ai/dsh-plan-mode', 'section'],
];
for (const [pkg, key] of REQUIRES_CONFIG) {
	const rowRe = new RegExp(
		`^[ \\t]*-[ \\t]*id:[^\\n]*\\n[ \\t]*name:[ \\t]*['"]?${pkg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}['"]?[ \\t]*\\n((?:[ \\t]+[^\\n]*\\n)*)`,
		'm',
	);
	const m = rowRe.exec(patchText);
	if (m === null) continue;
	const body = m[1];
	const hasConfig = /^[ \t]+config:[ \t]*$/m.test(body);
	// `config:` 下必须真的给了这个键，且值非空 —— 空串同样会抛错。
	const valueRe = new RegExp(`^[ \\t]+${key}:[ \\t]*(\\|[-+]?)?[ \\t]*(.*)$`, 'm');
	const keyMatch = valueRe.exec(body);
	const inlineValue = keyMatch?.[2]?.trim() ?? '';
	const blockValue = keyMatch?.[1] !== undefined;
	const nonEmpty = blockValue || inlineValue.length > 0;
	check(
		hasConfig && keyMatch !== null && nonEmpty ? 'PASS' : 'FAIL',
		`${pkg.split('/').pop()} 带必需 config.${key}`,
		!hasConfig
			? `缺 config → 构造抛错，整份预设显示「加载失败」`
			: keyMatch === null
				? `config 里缺 ${key} → 构造抛错`
				: !nonEmpty
					? `${key} 为空 → 构造抛错（空串同样被拒）`
					: 'ok',
	);
}

// 提供者完整性：预设里的行有跨行 inject 依赖，漏掉提供者会让那一行永远停在
// "waiting for <service>"（预设「装上了」却静默少能力 —— 最难查的一类故障）。
// 实测踩到过：`dsh-tool-workflow` 的 inject 含 workflowEngine，而
// `dsh-workflow-ptc` 才是提供者，漏了它 tool-workflow 就永远不激活。
const REQUIRES = [
	['@deepseek-ai/dsh-tool-workflow', '@deepseek-ai/dsh-workflow-ptc'],
];
for (const [consumer, provider] of REQUIRES) {
	if (!patchText.includes(consumer)) continue;
	check(
		patchText.includes(provider) ? 'PASS' : 'FAIL',
		`${consumer.split('/').pop()} 的提供者在场`,
		patchText.includes(provider) ? provider : `缺 ${provider} → 该行会一直 waiting`,
	);
}

// 入口文件必须真实存在（dshmarket 的 hasLoadableEntry 校验）。
const mainRel = manifest.main;
let mainOk = false;
if (typeof mainRel === 'string') {
	try {
		mainOk = (await stat(join(PKG_DIR, mainRel))).isFile();
	} catch {
		mainOk = false;
	}
}
check(mainOk ? 'PASS' : 'FAIL', 'main 入口存在', mainOk ? mainRel : `${mainRel} 不存在 → 可能被当作损坏包卸载`);

// peerDependencies 里的 @deepseek-ai/dsh* 必须被运行时满足。
// 本包刻意零 peer：预发布版本号（0.1.6-alpha.1）只匹配同 major.minor.patch
// 且带预发布段的区间，写死任何 dsh peer 都会在别的运行时上 incompatible-version。
const peers = Object.keys(manifest.peerDependencies ?? {});
const dshPeers = peers.filter((n) => n === '@deepseek-ai/dsh' || n.startsWith('@deepseek-ai/dsh-'));
check(
	dshPeers.length === 0 ? 'PASS' : 'WARN',
	'无 @deepseek-ai/dsh* peer',
	dshPeers.length === 0 ? '零运行时依赖，任何运行时都可装' : `存在 ${JSON.stringify(dshPeers)}，需确认版本区间`,
);

// ── 2. skill 载荷 ──────────────────────────────────────────────────────────

const skillDir = join(PKG_DIR, 'skills', 'ppt-master');
const skillFile = join(skillDir, 'SKILL.md');
let skillRaw = '';
try {
	skillRaw = await readFile(skillFile, 'utf8');
	check('PASS', 'SKILL.md 存在', relative(PKG_DIR, skillFile).replaceAll('\\', '/'));
} catch {
	check('FAIL', 'SKILL.md 存在', '未找到 skill 载荷');
}

// 配套的精简入口 skill（用户要求的「再精简一份」）。
const liteDir = join(PKG_DIR, 'skills', 'ppt-master-dsh');
const liteFile = join(liteDir, 'SKILL.md');
let liteRaw = '';
try {
	liteRaw = await readFile(liteFile, 'utf8');
	check('PASS', '精简 SKILL.md 存在', relative(PKG_DIR, liteFile).replaceAll('\\', '/'));
} catch {
	check('FAIL', '精简 SKILL.md 存在', '未找到 ppt-master-dsh 载荷');
}

// 载荷必须列进 files。
const skillsIncluded = filesField.some((f) => f.replace(/\/$/, '') === 'skills');
check(skillsIncluded ? 'PASS' : 'FAIL', 'skills/ 列入 files', skillsIncluded ? 'skills' : '未列入 → 不进 tarball');

// 复用 provider 自己的解析器，保证测的就是跑的那份。
const { __internals } = await import(new URL('./lib/index.js', import.meta.url).href);
const { attributes, body } = __internals.splitFrontmatter(skillRaw);

check(
	typeof attributes.name === 'string' && attributes.name === 'ppt-master' ? 'PASS' : 'FAIL',
	'frontmatter name',
	JSON.stringify(attributes.name),
);
check(
	typeof attributes.description === 'string' && attributes.description.length > 20 ? 'PASS' : 'FAIL',
	'frontmatter description',
	`${(attributes.description ?? '').length} 字符`,
);

// 展开后不得残留 ${SKILL_DIR}。
const expanded = __internals.expandSkillDir(body, 'X:/probe');
const leftover = (expanded.match(/\$\{SKILL_DIR\}/g) ?? []).length;
const original = (body.match(/\$\{SKILL_DIR\}/g) ?? []).length;
check(
	leftover === 0 ? 'PASS' : 'FAIL',
	'${SKILL_DIR} 全部展开',
	`原文 ${original} 处 → 展开后残留 ${leftover}`,
);
check(original > 0 ? 'PASS' : 'WARN', '原文确实用了 ${SKILL_DIR}', `${original} 处`);

// ${TEMPLATE_DIR} 必须保留（运行时由用户赋值）。
const tplKept = (expanded.match(/\$\{TEMPLATE_DIR\}/g) ?? []).length;
const tplOriginal = (body.match(/\$\{TEMPLATE_DIR\}/g) ?? []).length;
check(
	tplKept === tplOriginal ? 'PASS' : 'FAIL',
	'${TEMPLATE_DIR} 原样保留',
	`原文 ${tplOriginal} 处 → 展开后 ${tplKept} 处`,
);

// 展开出来的路径必须是绝对路径且用正斜杠。
const probe = __internals.expandSkillDir('${SKILL_DIR}/scripts/x.py', __internals.resolveSkillDir());
check(
	/^[A-Za-z]:\//.test(probe) || probe.startsWith('/') ? 'PASS' : 'FAIL',
	'展开为绝对路径',
	probe,
);

// 脚本子目录必须在位。
for (const sub of ['scripts', 'references', 'templates', 'workflows']) {
	let ok = false;
	try {
		ok = (await stat(join(skillDir, sub))).isDirectory();
	} catch {
		ok = false;
	}
	check(ok ? 'PASS' : 'FAIL', `skill 子目录 ${sub}/`, ok ? '存在' : '缺失');
}

// ── 2b. 精简 skill 与 lib 模块 ─────────────────────────────────────────────

if (liteRaw !== '') {
	const lite = __internals.splitFrontmatter(liteRaw);
	check(
		lite.attributes.name === 'ppt-master-dsh' ? 'PASS' : 'FAIL',
		'精简 skill frontmatter name',
		JSON.stringify(lite.attributes.name),
	);
	const liteExpanded = __internals.expandSkillDir(lite.body, __internals.resolveSkillDir());
	const liteLeft = (liteExpanded.match(/\$\{(?:SKILL_DIR|PAYLOAD_DIR)\}/g) ?? []).length;
	const liteOrig = (lite.body.match(/\$\{(?:SKILL_DIR|PAYLOAD_DIR)\}/g) ?? []).length;
	check(
		liteLeft === 0 ? 'PASS' : 'FAIL',
		'精简 skill 占位符全部展开',
		`原文 ${liteOrig} 处 → 残留 ${liteLeft}`,
	);
	// 精简版必须真的说到工具，否则它就只是个没用的壳。
	const toolMentions = [...new Set(liteExpanded.match(/ppt_[a-z_]+/g) ?? [])];
	check(
		toolMentions.length >= 8 ? 'PASS' : 'FAIL',
		'精简 skill 覆盖工具用法',
		`提到 ${toolMentions.length} 个 ppt_* 工具`,
	);
	// 硬停/纪律必须写进去 —— 这是 skill 不可被工具替代的那部分价值。
	const discipline = ['八项确认', '手写', 'spec_lock'].filter((k) => liteExpanded.includes(k));
	check(
		discipline.length === 3 ? 'PASS' : 'FAIL',
		'精简 skill 保留核心纪律',
		discipline.join(' / ') || '关键字都没出现',
	);
	// 精简版必须比原版短，否则「精简」名不副实。
	const ratio = liteRaw.length / Math.max(skillRaw.length, 1);
	check(ratio < 0.25 ? 'PASS' : 'WARN', '精简版确实更短', `${skillRaw.length} → ${liteRaw.length} 字节（${(ratio * 100).toFixed(1)}%）`);

	/**
	 * 载荷压缩：绝对路径只应出现一次。
	 *
	 * 背景：模型看到的 skill 正文会把 `${PAYLOAD_DIR}` 展开成绝对路径。1.0.2 之前
	 * 该路径在正文里出现 21 次，占 8809 字符载荷的 26% —— 纯粹是重复的噪音。
	 * 改成「根路径写一次 + 其余用相对路径」后应降到 1 次。
	 */
	const absRoot = __internals.resolveSkillDir('ppt-master');
	const absCount = liteExpanded.split(absRoot).length - 1;
	check(
		absCount <= 1 ? 'PASS' : 'FAIL',
		'精简 skill 绝对路径只出现一次',
		`${absCount} 次（长度 ${absRoot.length}）`,
	);

	/**
	 * 省 token 纪律必须写进正文。
	 *
	 * 这些不是文风问题：真实手机会话里 `read` 工具 0 次调用、bash 读了 110 次文件、
	 * `job_output wait:true` 硬阻塞 4~5 分钟导致用户发火。把它们固化成检查项，
	 * 避免后续改文档时被无意删掉。
	 */
	const tokenRules = [
		['read', '用 read 工具读文件'],
		['不要 `job_output` 长等', '禁止长等'],
		['texts', '批量度量'],
		['回退', '渲染回退说明'],
	];
	const missingRules = tokenRules.filter(([needle]) => !liteExpanded.includes(needle));
	check(
		missingRules.length === 0 ? 'PASS' : 'FAIL',
		'精简 skill 含省 token 纪律',
		missingRules.length === 0 ? tokenRules.map(([, d]) => d).join(' / ') : `缺：${missingRules.map(([, d]) => d).join('、')}`,
	);
}

// lib 三个模块都必须真实存在且能 import。
for (const mod of ['lib/index.js', 'lib/tools.js', 'lib/runner.js']) {
	let ok = true;
	let detail = '';
	try {
		await stat(join(PKG_DIR, mod));
	} catch {
		ok = false;
		detail = '文件不存在';
	}
	if (ok) {
		try {
			await import(new URL(`./${mod}`, import.meta.url).href);
		} catch (error) {
			ok = false;
			detail = `import 失败：${error.message}`;
		}
	}
	check(ok ? 'PASS' : 'FAIL', `模块可加载 ${mod}`, ok ? 'ok' : detail);
}

// 工具定义必须真的产出一批 ppt_* 工具，且每个都是合法对象 schema。
const { createToolDefinitions } = await import(new URL('./lib/tools.js', import.meta.url).href);
const defs = createToolDefinitions({ skillDir: 'X:/probe' });
check(Array.isArray(defs) && defs.length >= 25 ? 'PASS' : 'FAIL', '工具数量', `${defs.length} 个`);

/**
 * 渲染闸门必须有可用的回退路径。
 *
 * 背景：上游 `render_inspection.py` 只支持 playwright，拿不到就直接 exit 3。
 * 而 Android 上 playwright 没有可发行版，导致这道「强制视觉闸门」在手机端完全
 * 跑不起来 —— 实测模型只好自己发现 rsvg-convert 再手写渲染循环。1.0.3 起
 * `ppt_render` 在 playwright 不可用时自动回退 rsvg-convert。
 */
const renderDef = defs.find((d) => d.name === 'ppt_render');
check(
	typeof renderDef?.execute === 'function' ? 'PASS' : 'FAIL',
	'ppt_render 有自定义执行（承载回退）',
	typeof renderDef?.execute === 'function' ? 'ok' : '缺少 execute',
);
const runnerSrc = await readFile(join(PKG_DIR, 'lib/runner.js'), 'utf8');
check(
	/export async function renderWithRsvg\b/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'runner 导出 rsvg 回退渲染器',
	/export async function renderWithRsvg\b/.test(runnerSrc) ? 'renderWithRsvg' : '未找到 renderWithRsvg',
);
check(
	/rsvg-convert/.test(runnerSrc) && /DSH_PPT_RSVG/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'回退渲染器可被 DSH_PPT_RSVG 覆盖',
	'rsvg-convert',
);

/**
 * Android / Termux 上 Python 的定位。
 *
 * 背景：手机端 PATH 里可能没有 Python（真的没装），但一旦装在 Termux 前缀下，
 * 宿主进程的 PATH 未必包含它。所以候选表必须覆盖已知前缀的绝对路径。
 */
check(
	/prefixCandidates/.test(runnerSrc) && /termux\/usr/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'Python 探测覆盖 Termux 前缀',
	'prefixCandidates + termux/usr',
);
/**
 * ⚠️ 正则刻意匹配 `apt-get install` + `python python-pip` 两个词，而不是照抄整行：
 * 中间夹的 flag（`-y`、`--no-install-recommends`）会变，但「有一条能直接粘贴的
 * apt 命令装 python 与 pip」这个**语义**不变。照抄整行会让 flag 一调就误报 FAIL。
 */
check(
	/pkgin? install|pkg install|apt-get install[^\n]*python python-pip/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'Android 上给出可执行的安装指引',
	'含 Termux 安装步骤',
);

/**
 * pip 命令的可粘贴性。
 *
 * 背景：环境报告的 `install` 字段会被空格拼成**一条** `pip install a b c` 命令。
 * 曾经在 playwright 那组写成 `'playwright   # 之后还要跑：playwright install chromium'`，
 * 于是 shell 把 `#` 之后的 `flask google-genai edge-tts` 全部当注释丢掉 ——
 * 恰好是被截掉的那三个包用户最需要装。这类 bug 只在一行里，肉眼极难发现，
 * 所以固化成检查。
 */
const installFields = [...runnerSrc.matchAll(/install:\s*'([^']*)'/g)].map((m) => m[1]);
const installsWithComment = installFields.filter((s) => s.includes('#'));
check(
	installFields.length > 0 && installsWithComment.length === 0 ? 'PASS' : 'FAIL',
	'依赖安装字段不含注释',
	installFields.length === 0
		? '没解析到 install 字段'
		: installsWithComment.length === 0
			? `${installFields.length} 组，无 # 注释`
			: `含 # 的组：${installsWithComment.join(' | ')}`,
);
check(
	/postInstall:\s*'playwright install chromium'/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'playwright 浏览器安装是独立步骤',
	'postInstall 单独表达',
);

/**
 * Android 上原生扩展必须走 apt，不能拼进 `pip install`。
 *
 * 背景（2026-10-10 真机实测）：PyPI 没有 android_arm64 轮子，
 * `pip install lxml` 直接失败 ——
 *   Error: Please make sure the libxml2 and libxslt development packages are installed.
 * 而 pip 会**先把整组下完再报错**，模型看到的是「装了十几分钟然后失败」，
 * 再照着 `ppt_env` 给的同一条命令重试。Termux 仓库里 python-pillow /
 * python-lxml / python-numpy / python-pymupdf 都有预编译包，装完即 import 成功。
 *
 * 这条检查同时钉住两件事：分组里确实声明了 `apt:`，且报告生成处真的按平台拆了
 * 两条命令（`aptCommand` / `pipCommand`）。
 */
check(
	/apt:\s*'python-pillow python-lxml python-numpy'/.test(runnerSrc) &&
		/apt:\s*'python-pymupdf'/.test(runnerSrc)
		? 'PASS'
		: 'FAIL',
	'原生扩展声明了 apt 安装方式',
	'python-pillow / python-lxml / python-numpy / python-pymupdf',
);
check(
	/aptCommand:/.test(runnerSrc) && /const pipRows =/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'环境报告按平台拆分 apt / pip 命令',
	'aptCommand + pipRows',
);
/**
 * apt 命令必须带 `--no-install-recommends`（2026-10-10 真机实测）。
 *
 * 背景：Termux 的 `python-pip` 把 clang / make / pkg-config 写在 **Recommends** 里，
 * 而 apt 默认装 Recommends —— 于是整个 LLVM（llvm / lld / libllvm）被拖进来。
 * 同一台设备同一条命令实测：
 *
 *   默认          ：10 个包，139 秒（其中 clang/llvm/lld/libllvm/pkg-config/make 占 6 个）
 *   --no-install-recommends： 2 个包， 16 秒
 *
 * 而那堆编译器对「装 Termux 预编译包」毫无用处（`python-pillow` / `python-lxml` /
 * `python-numpy` / `python-pymupdf` / `librsvg` 实测带不带这个 flag 包数完全相同）。
 *
 * ⚠️ 三处必须同时改，少一处模型就会照着没带 flag 的那条命令跑：
 *   ① `runner.js` 无 Python 时的 hint（引导它先装 python/pip）
 *   ② `tools.js` 的 `ppt_env` 输出（真正被模型抄走的那条）
 *   ③ `tools.js` 的 `ppt_env` 工具描述（模型读的第一手材料）
 * 所以三个文件片段都查。
 */
const toolsSrc = await readFile(join(PKG_DIR, 'lib/tools.js'), 'utf8');
check(
	/apt-get install -y --no-install-recommends \$\{info\.aptCommand\}/.test(toolsSrc) ? 'PASS' : 'FAIL',
	'ppt_env 输出的 apt 命令带 --no-install-recommends',
	'apt-get install -y --no-install-recommends ${info.aptCommand}',
);
check(
	/apt-get install -y --no-install-recommends python python-pip/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'无 Python 时的引导 hint 也带 --no-install-recommends',
	'apt-get install -y --no-install-recommends python python-pip',
);
/**
 * 真跑一次 `environmentReport()`，断言 Android 分支的实际输出形状。
 *
 * ⚠️ 这里**刻意不用字符串存在性检查**：那种写法很容易变成「永远不会失败」的
 * 空洞断言（改个变量名就失效，或者原文删掉后检查还在）。本项模拟 Android
 * 环境（PATH 里带 /system/bin、清掉 PREFIX）后调用真函数，直接看返回值。
 */
const { environmentReport } = await import(new URL('lib/runner.js', import.meta.url).href);
const savedPath = process.env.PATH;
const savedPrefix = process.env.PREFIX;
process.env.PATH = `${process.env.PATH ?? ''}:/system/bin`;
delete process.env.PREFIX;
let androidReport = null;
try {
	androidReport = await environmentReport();
} catch (error) {
	androidReport = { error: String(error?.message ?? error) };
} finally {
	process.env.PATH = savedPath;
	if (savedPrefix !== undefined) process.env.PREFIX = savedPrefix;
}
check(
	androidReport?.android === true ? 'PASS' : 'FAIL',
	'环境报告带 android 标志',
	`android=${androidReport?.android}`,
);
check(
	typeof androidReport?.aptCommand === 'string' && typeof androidReport?.pipCommand === 'string'
		? 'PASS'
		: 'FAIL',
	'环境报告给出 aptCommand / pipCommand 两个字段',
	`apt="${androidReport?.aptCommand ?? ''}" pip="${androidReport?.pipCommand ?? ''}"`,
);
/**
 * `planInstall` 的确定性单测 —— 喂一份**全缺**的清单，直接看拆出来的两条命令。
 *
 * ⚠️ 不依赖本机装没装依赖：真机跑 `environmentReport()` 时本机依赖齐全，
 * 走不到「缺失」那条分支，那样写出来的检查会永远 PASS（空洞断言）。
 * 这里直接构造输入，所以**去掉 `aptRows` 过滤就会立刻 FAIL**。
 */
const { planInstall, DEPENDENCY_GROUPS, requiredMissingRows } = await import(
	new URL('lib/runner.js', import.meta.url).href
);
const FULL_REPORT = [
	{ name: '核心', missing: ['pptx', 'docx', 'openpyxl'], install: 'python-pptx python-docx openpyxl' },
	{ name: '核心（原生扩展）', missing: ['PIL', 'lxml', 'numpy'], install: 'Pillow lxml numpy', apt: 'python-pillow python-lxml python-numpy' },
	{ name: 'PDF 解析', missing: ['fitz'], install: 'PyMuPDF', apt: 'python-pymupdf' },
	{ name: '视觉质检', missing: ['playwright'], install: 'playwright', postInstall: 'playwright install chromium', unavailableOnAndroid: true },
];
const androidPlan = planInstall(FULL_REPORT, true);
const desktopPlan = planInstall(FULL_REPORT, false);

check(
	androidPlan.aptCommand === 'python-pillow python-lxml python-numpy python-pymupdf' ? 'PASS' : 'FAIL',
	'Android 的 apt 命令含全部原生扩展',
	androidPlan.aptCommand,
);
check(
	!/\b(lxml|Pillow|numpy|PyMuPDF|playwright)\b/.test(androidPlan.pipCommand) ? 'PASS' : 'FAIL',
	'Android 的 pip 命令不含原生扩展与 playwright',
	`pip="${androidPlan.pipCommand}"`,
);
check(
	androidPlan.pipCommand.includes('python-pptx') ? 'PASS' : 'FAIL',
	'Android 的 pip 命令仍含纯 Python 包',
	`pip="${androidPlan.pipCommand}"`,
);
check(
	desktopPlan.aptCommand === '' && desktopPlan.pipCommand.includes('Pillow') ? 'PASS' : 'FAIL',
	'非 Android 平台仍全部走 pip（行为不变）',
	`apt="${desktopPlan.aptCommand}" pip="${desktopPlan.pipCommand}"`,
);
check(
	desktopPlan.postInstall.includes('playwright install chromium') &&
		!androidPlan.postInstall.includes('playwright install chromium')
		? 'PASS'
		: 'FAIL',
	'playwright 浏览器步骤只在非 Android 平台出现',
	`desktop=${desktopPlan.postInstall.length} android=${androidPlan.postInstall.length}`,
);
check(
	/unavailableOnAndroid/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'playwright 标注为 Android 不可用',
	'避免给出必然失败的 pip 命令',
);

/**
 * `curl_cffi` 必须被排除在 Android 的 pip 命令之外。
 *
 * 背景（2026-10-10 真机实测，这是本次最贵的一个坑）：`curl_cffi` 依赖 `cffi`，
 * cffi 在 Android 上只能源码构建，需要 `aarch64-linux-android-clang`。实测
 * `pip install curl_cffi` 跑 **117 秒**后：
 *
 *   error: [Errno 2] No such file or directory: 'aarch64-linux-android-clang'
 *   ERROR: Failed building wheel for cffi
 *
 * 而 pip 是**原子**的 —— 同一条命令里一个包失败，整条命令一个包都不装。
 * 实测 `pip install requests curl_cffi PyYAML` → RC=1，之后
 * requests / yaml / curl_cffi **全部 False**。
 *
 * 所以它留在 pip 命令里会连带废掉它后面的每个包（PyYAML / flask / google-genai /
 * edge-tts），而模型只看到一句 `Failed building wheel for cffi`。
 *
 * ⚠️ **断言必须作用在真实的 `DEPENDENCY_GROUPS` 上**，不能喂一份自造的副本：
 * 本项目实测过一次 —— 用自造输入写的断言，在有人把 `curl_cffi` 合并回 `requests`
 * 组时照样 PASS（空洞断言）。所以这里把真实分组构造出「全缺」报告再跑 `planInstall`。
 */
const REAL_FULL_REPORT = DEPENDENCY_GROUPS.map((g) => ({
	name: g.name,
	missing: [...g.mods],
	install: g.install,
	apt: g.apt,
	postInstall: g.postInstall,
	unavailableOnAndroid: g.unavailableOnAndroid === true,
}));
const realAndroidPlan = planInstall(REAL_FULL_REPORT, true);
const realDesktopPlan = planInstall(REAL_FULL_REPORT, false);
check(
	!realAndroidPlan.pipCommand.includes('curl_cffi') &&
		realAndroidPlan.pipCommand.includes('PyYAML') &&
		realAndroidPlan.pipCommand.includes('flask')
		? 'PASS'
		: 'FAIL',
	'Android 的 pip 命令排除 curl_cffi（避免整条命令全废）',
	`pip="${realAndroidPlan.pipCommand}"`,
);
/**
 * 另外两个「Android 上必然构建失败」的包也必须被排除。
 *
 * 同一次真机逐个实测（`pip install --dry-run`，tuna 源）：
 *
 *   nbconvert     → rpds-py      （Rust 扩展）33 秒后 Failed to build
 *   google-genai  → cryptography （Rust 扩展）16 秒后 Failed to build
 *
 * 两者都只服务可选支路（.ipynb 笔记本 / Gemini 配图），但 pip 的原子性会让它们
 * **废掉整条 pip 命令** —— 实测 `nbconvert` 在场时 python-pptx / PyYAML / flask
 * 等 13 个包**一个都没装上**。
 *
 * ⚠️ 断言作用在真实 `DEPENDENCY_GROUPS` 上（同 curl_cffi 那条的理由）。
 */
check(
	!realAndroidPlan.pipCommand.includes('nbconvert') &&
		!realAndroidPlan.pipCommand.includes('google-genai')
		? 'PASS'
		: 'FAIL',
	'Android 的 pip 命令排除 nbconvert / google-genai（Rust 依赖装不上）',
	`pip="${realAndroidPlan.pipCommand}"`,
);
check(
	realAndroidPlan.pipCommand.includes('python-pptx') &&
		realAndroidPlan.pipCommand.includes('openpyxl') &&
		realAndroidPlan.pipCommand.includes('edge-tts')
		? 'PASS'
		: 'FAIL',
	'排除后主流程必需的包仍在 pip 命令里',
	`pip="${realAndroidPlan.pipCommand}"`,
);
check(
	realDesktopPlan.pipCommand.includes('nbconvert') &&
		realDesktopPlan.pipCommand.includes('google-genai')
		? 'PASS'
		: 'FAIL',
	'非 Android 平台仍保留 nbconvert / google-genai（行为不变）',
	`pip="${realDesktopPlan.pipCommand}"`,
);
check(
	realDesktopPlan.pipCommand.includes('curl_cffi') ? 'PASS' : 'FAIL',
	'非 Android 平台仍保留 curl_cffi（行为不变）',
	`pip="${realDesktopPlan.pipCommand}"`,
);
/**
 * `librsvg`（rsvg-convert）必须进 Android 的 apt 命令。
 *
 * 真机实测缺口（2026-10-10）：`rsvg-convert` 是 Android 上**唯一**能用的渲染后端
 * ——playwright 在 Android 上没有发行版，`ppt_render` 必然走 rsvg 回退。但它是
 * 可执行文件而不是 Python 模块，原先的体检只查 Python 模块，**从不提示装 librsvg**。
 * 于是全新环境里两个后端都缺，视觉闸门整条断掉，而提示还说「会自动回退 rsvg-convert」。
 *
 * ⚠️ 断言直接看真实分组拆出来的 apt 命令（不是自造输入）。
 */
check(
	realAndroidPlan.aptCommand.includes('librsvg') ? 'PASS' : 'FAIL',
	'Android 的 apt 命令含 librsvg（rsvg-convert 渲染回退）',
	`apt="${realAndroidPlan.aptCommand}"`,
);
check(
	!realDesktopPlan.aptCommand.includes('librsvg') &&
		!realDesktopPlan.pipCommand.includes('rsvg-convert')
		? 'PASS'
		: 'FAIL',
	'非 Android 平台不提 rsvg-convert（它不在 PyPI 上）',
	`apt="${realDesktopPlan.aptCommand}" pip含rsvg=${realDesktopPlan.pipCommand.includes('rsvg-convert')}`,
);
check(
	DEPENDENCY_GROUPS.some((g) => g.which === 'rsvg-convert' && g.androidOnly === true)
		? 'PASS'
		: 'FAIL',
	'rsvg-convert 组声明了 which 探测与 androidOnly',
	'非 Python 依赖走文件存在性探测，桌面端跳过',
);

/**
 * `ok` 必须忽略「本平台永远装不上」的组。
 *
 * 背景（2026-10-10 真机端到端验收暴露）：Android 上有 4 组依赖永远装不上
 * （playwright / curl_cffi / nbconvert / google-genai，都缺 android 轮子）。
 * 若把它们计入 `ok`，那么在任何一台手机上 `ok` 都恒为 false ——
 * 而这个字段被 `ppt_env` 当作工具的成功信号返回，模型会据此认为环境没准备好，
 * 反复重试安装或直接放弃流水线。实测修复前最终体检就是 `ok=false`，
 * 而当时所有**能装的**依赖都已就绪。
 *
 * ⚠️ 断言作用在导出的纯函数 + **真实分组**上（不是自造输入，也不是查源码字符串）：
 * 查字符串在「过滤条件写反」时照样 PASS；而真跑 `environmentReport()` 在本机
 * 会走「找不到 Python」的 early return（`groups: []`），永远测不到这段逻辑。
 */
const realRequiredAndroid = requiredMissingRows(REAL_FULL_REPORT, true);
const realRequiredDesktop = requiredMissingRows(REAL_FULL_REPORT, false);
check(
	realRequiredAndroid.every((r) => r.unavailableOnAndroid !== true) &&
		realRequiredAndroid.length < REAL_FULL_REPORT.length
		? 'PASS'
		: 'FAIL',
	'ok 判定忽略 Android 上永远装不上的组（否则恒为 false）',
	`必需组=${realRequiredAndroid.length}/${REAL_FULL_REPORT.length}`,
);
check(
	realRequiredDesktop.every((r) => r.androidOnly !== true) ? 'PASS' : 'FAIL',
	'ok 判定忽略非 Android 上的 androidOnly 组',
	`桌面必需组=${realRequiredDesktop.length}`,
);

/**
 * 禁止 Python 往包目录里写字节码。
 *
 * 背景：上游脚本会 `import` 同目录的 `config.py` 等模块，Python 默认把这些
 * `.pyc` 写进 `__pycache__/` —— 而 `.py` 就住在**已安装的包目录**里。于是
 * 用户 node_modules 里会凭空多出文件，本机打包时还会把它们打进 tarball
 * （1.0.3 真的发出去过一次）。唯一的根因修法是让子进程带
 * `PYTHONDONTWRITEBYTECODE=1`：`.npmignore` 对 `files` 白名单无效，
 * `files` 也不支持 `!` 取反 — 两者都实测过，不管用。
 */
check(
	/PYTHONDONTWRITEBYTECODE/.test(runnerSrc) ? 'PASS' : 'FAIL',
	'子进程禁止写 Python 字节码',
	'PYTHONDONTWRITEBYTECODE=1',
);
const spawnSites = (runnerSrc.match(/spawn\(bin, args, \{/g) ?? []).length;
const envSites = (runnerSrc.match(/env: childEnv\(/g) ?? []).length;
check(
	spawnSites > 0 && envSites === spawnSites ? 'PASS' : 'FAIL',
	'所有 spawn 点都注入了子进程环境',
	`${envSites}/${spawnSites} 处`,
);
check(
	typeof manifest?.scripts?.prepack === 'string' ? 'PASS' : 'FAIL',
	'打包前自动清理字节码（prepack）',
	'兜底防再次误发',
);

/**
 * 文字度量必须支持批量。
 *
 * 背景：实测 `ppt_svg_metrics` 被调 22 次、每次只量一条（平均输出 31 字符）。
 * 批量入口把 N 次进程启动 + N 次模型往返压成 1 次。
 */
const metricsDef = defs.find((d) => d.name === 'ppt_svg_metrics');
check(
	Array.isArray(metricsDef?.parameters?.properties?.texts?.items?.type ? [1] : null) ? 'PASS' : 'FAIL',
	'ppt_svg_metrics 声明 texts 批量参数',
	metricsDef?.parameters?.properties?.texts ? 'texts: array' : '缺少 texts 参数',
);
check(
	/runPythonCode/.test(await readFile(join(PKG_DIR, 'lib/tools.js'), 'utf8')) ? 'PASS' : 'FAIL',
	'批量度量走单进程内联 Python',
	'runPythonCode',
);

const badTools = [];
for (const d of defs) {
	if (typeof d.name !== 'string' || !/^ppt_[a-z0-9_]+$/.test(d.name)) badTools.push(`${d.name}: 名字不合法`);
	if (d.parameters?.type !== 'object') badTools.push(`${d.name}: parameters.type 不是 object`);
	// 运行时（checkObjectSchemaTail）只在 additionalProperties **存在**时校验它必须是
	// 布尔，并不强制要求出现。所以这里也只查「出现即合法」，别比运行时更严。
	if (Object.hasOwn(d.parameters ?? {}, 'additionalProperties') && typeof d.parameters.additionalProperties !== 'boolean') {
		badTools.push(`${d.name}: additionalProperties 不是布尔`);
	}
	// required 必须是字符串数组，且名字都在 properties 里 —— 这条运行时是真的会拒。
	const req = d.parameters?.required;
	if (req !== undefined) {
		if (!Array.isArray(req) || req.some((k) => typeof k !== 'string')) badTools.push(`${d.name}: required 不是字符串数组`);
		else {
			const props = d.parameters.properties ?? {};
			const ghost = req.filter((k) => !Object.hasOwn(props, k));
			if (ghost.length > 0) badTools.push(`${d.name}: required 点了不存在的 ${ghost.join(',')}`);
		}
	}
	if (typeof d.execute !== 'function') badTools.push(`${d.name}: execute 不是函数`);
	if (d.output?.schema?.type !== 'object') badTools.push(`${d.name}: output.schema 非 object 根`);
	if (typeof d.output?.render !== 'function') badTools.push(`${d.name}: output.render 不是函数`);
	if (d.timeoutMs !== undefined && !(Number.isFinite(d.timeoutMs) && d.timeoutMs > 0)) badTools.push(`${d.name}: timeoutMs 非法`);
}
check(badTools.length === 0 ? 'PASS' : 'FAIL', '每个工具定义合法', badTools.length === 0 ? `${defs.length} 个全通过` : badTools.slice(0, 4).join('; '));

// 名字不得重复（重复会让后者覆盖前者）。
const dupNames = defs.map((d) => d.name).filter((n, i, a) => a.indexOf(n) !== i);
check(dupNames.length === 0 ? 'PASS' : 'FAIL', '工具名无重复', dupNames.length === 0 ? '唯一' : [...new Set(dupNames)].join(', '));

// 保留名不得占用。
check(!defs.some((d) => d.name === 'run_code') ? 'PASS' : 'FAIL', '未占用保留名 run_code', 'ok');

// ── 3. 发布卫生 ────────────────────────────────────────────────────────────

const allFiles = await walk(PKG_DIR);
const relFiles = allFiles.map((f) => relative(PKG_DIR, f).replaceAll('\\', '/'));

// 垃圾文件不得混入。
const junk = relFiles.filter((f) => /(^|\/)(__pycache__|\.git|node_modules|\.pytest_cache)(\/|$)/.test(f) || /\.pyc$/.test(f));
check(junk.length === 0 ? 'PASS' : 'FAIL', '无垃圾文件', junk.length === 0 ? `${allFiles.length} 个文件` : junk.slice(0, 5).join(', '));

// 本机专属路径不得出现。
// 排除本文件：它必须字面写出这些模式串才能搜它们，否则会自己命中自己。
const SELF = fileURLToPath(import.meta.url);
const MACHINE = ['XIAOPAN', 'C:\\Users\\', 'Desktop\\dsh', 'Desktop/dsh'];
const textFiles = allFiles.filter((f) => f !== SELF && /\.(md|json|js|mjs|yml|yaml|py|txt)$/.test(f));
const machineHits = [];
for (const f of textFiles) {
	const text = await readFile(f, 'utf8');
	for (const needle of MACHINE) {
		if (text.includes(needle)) machineHits.push(`${relative(PKG_DIR, f)} → ${needle}`);
	}
}
check(
	machineHits.length === 0 ? 'PASS' : 'FAIL',
	'无本机专属路径',
	machineHits.length === 0 ? `扫了 ${textFiles.length} 个文本文件` : machineHits.slice(0, 5).join('; '),
);

// 凭据不得出现。
const SECRET = [/sk-[A-Za-z0-9]{20,}/, /AIza[0-9A-Za-z_-]{30,}/, /ghp_[A-Za-z0-9]{30,}/, /npm_[A-Za-z0-9]{30,}/];
const secretHits = [];
for (const f of textFiles) {
	const text = await readFile(f, 'utf8');
	for (const re of SECRET) {
		const m = re.exec(text);
		if (m !== null) secretHits.push(`${relative(PKG_DIR, f)} → ${m[0].slice(0, 8)}…`);
	}
}
check(secretHits.length === 0 ? 'PASS' : 'FAIL', '无凭据泄漏', secretHits.length === 0 ? '干净' : secretHits.join('; '));

// .env 实体文件不得打包（只允许 .env.example）。
const envFiles = relFiles.filter((f) => /(^|\/)\.env$/.test(f));
check(envFiles.length === 0 ? 'PASS' : 'FAIL', '无 .env 实体', envFiles.length === 0 ? '只有 .env.example' : envFiles.join(', '));

// 许可文件必须随包。
check(filesField.includes('LICENSE') ? 'PASS' : 'WARN', 'LICENSE 列入 files', '本包 MIT');
check(
	filesField.includes('LICENSE.ppt-master') ? 'PASS' : 'WARN',
	'上游许可列入 files',
	'PPT Master (Hugo He) MIT',
);

// ── 输出 ───────────────────────────────────────────────────────────────────

const width = Math.max(...results.map(([, label]) => label.length));
for (const [status, label, detail] of results) {
	console.log(`${status}  ${label.padEnd(width)}  ${detail}`);
}
const failed = results.filter(([s]) => s === 'FAIL').length;
const warned = results.filter(([s]) => s === 'WARN').length;
console.log(`\n${results.length - failed}/${results.length} 通过${warned > 0 ? `（${warned} 条 WARN）` : ''}`);
process.exit(failed === 0 ? 0 : 1);
