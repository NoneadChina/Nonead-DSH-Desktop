# Visual style: zine

Risograph zine / DIY poster — misregistered color layers, halftone dots, a tightly limited palette, handmade print grit. Indie-publishing texture over polish. For culture decks, design talks, indie brands, anything wanting a printed, hand-assembled feel.

---

## 1. Shape & decoration

- Shape language: cut-and-paste blocks, offset color shapes, rough frames; outlines in a near-black ink tone. Corner radius low or zero — print-flat, not soft-digital.
- Decoration: the riso print artifacts — 1-3px color-layer misregistration, halftone-dot `<pattern>` texture, overlapping color blocks that imply a third color where they cross. Texture is the decoration.
- Whitespace: poster-like — bold focal blocks with raw margins; deliberate roughness over clean alignment.

## 2. Typography character

- Punk-DIY contrast: a heavy poster display face for headlines, a plain readable sans for body, monospace for annotation (typewriter / photocopier feel).
- Big headline tension against quiet body; slight intentional looseness reads as hand-set rather than mechanical.

> Families are chosen at confirmation `g`; this style asks for a display-poster × plain-sans × monospace-annotation *character*.

## 3. Using the deck's colors

- A strictly limited spot palette (riso logic) on a warm paper field; two ink layers do most of the work and a third spot color appears rarely (<5%).
- Color is laid as flat spot fills, not gradients; overlap and offset of the same few inks create depth and the third-color illusion. Scarcity and overlap, not variety.

> HEX values come from confirmation `e`; this style governs the flat-spot, misregistered-overlay discipline — it names no colors.

## 4. Texture / elevation

- Flat print, no digital elevation. Depth from layer offset and halftone grain, not shadows. Warm-paper grain via faint texture / low-opacity halftone is on-brand; avoid drop shadows and slick gradients.

## 5. Paired image-rendering

`screen-print` — duotone / spot-ink imagery that shares the riso print aesthetic.
