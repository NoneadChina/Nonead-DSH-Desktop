/**
 * 装在真实 Cordis + 真实 ToolRuntime / SkillRegistry 上的冒烟测试。
 *
 * 与 verify.mjs 的分工：verify.mjs 查静态契约与发布卫生，本脚本查「装进去
 * 真的能用」—— 工具能不能注册、schema 能不能通过校验、execute 能不能跑通、
 * skill provider 能不能被解析。需要一份 DSH profile 的 node_modules 提供官方包。
 *
 * 用法：
 *   node probe-load.mjs <profiles/node_modules 的绝对路径>
 */

import { pathToFileURL } from 'node:url';
import { join } from 'node:path';
import { existsSync } from 'node:fs';

const base = process.argv[2];
if (base === undefined) {
	console.error('用法: node probe-load.mjs <profiles/node_modules 绝对路径>');
	process.exit(2);
}

const at = (p) => pathToFileURL(join(base, p)).href;
const results = [];
/** 记录一条断言。 */
function check(ok, label, detail = '') {
	results.push([ok ? 'PASS' : 'FAIL', label, detail]);
}

const { Context } = await import(at('@deepseek-ai/cordis/lib/index.js'));
const systemPrompt = await import(at('@deepseek-ai/dsh-system-prompt/lib/index.js'));
const tools = await import(at('@deepseek-ai/dsh-tools/lib/index.js'));
const skills = await import(at('@deepseek-ai/dsh-skill/lib/index.js'));

const ctx = new Context();

// tools 服务需要 systemPrompt 先就位（ToolRuntime.inject = ['systemPrompt']）。
await ctx.plugin(systemPrompt.default ?? systemPrompt);
await ctx.plugin(tools.default ?? tools);

const registry = new skills.SkillRegistry(ctx);
ctx.set('skills', registry);

const plugin = await import(new URL('./lib/index.js', import.meta.url).href);
await ctx.plugin(plugin);

// ── 工具 ────────────────────────────────────────────────────────────────────

const schemas = ctx.tools.schemas();
check(Array.isArray(schemas), 'schemas() 可调用', `返回 ${schemas?.length ?? 0} 条`);

const names = schemas.map((s) => s.name).sort();
const expected = [
	'ppt_animation',
	'ppt_batch_validate',
	'ppt_beautify_identity',
	'ppt_beautify_inventory',
	'ppt_check_annotations',
	'ppt_contact_sheet',
	'ppt_convert',
	'ppt_env',
	'ppt_export',
	'ppt_fill',
	'ppt_icons',
	'ppt_image_gen',
	'ppt_image_search',
	'ppt_images_analyze',
	'ppt_images_rotate',
	'ppt_intake',
	'ppt_latex',
	'ppt_narration',
	'ppt_notes_split',
	'ppt_project',
	'ppt_pptx_to_svg',
	'ppt_render',
	'ppt_spec_update',
	'ppt_svg_extract_assets',
	'ppt_svg_finalize',
	'ppt_svg_metrics',
	'ppt_svg_position',
	'ppt_svg_quality',
	'ppt_template_import',
	'ppt_template_register',
	'ppt_visual_review',
	'ppt_watermark_remove',
];

const missing = expected.filter((n) => !names.includes(n));
const extra = names.filter((n) => !expected.includes(n));
check(missing.length === 0, '预期的工具全部注册', missing.length === 0 ? `${expected.length} 个` : `缺 ${missing.join(', ')}`);
if (extra.length > 0) check(false, '无意外工具', extra.join(', '));

// 每个工具的 parameters 都必须是合法对象 schema（注册时已经断言过，这里复核形状）。
let shapeOk = true;
const problems = [];
for (const s of schemas) {
	if (s.parameters?.type !== 'object') {
		shapeOk = false;
		problems.push(`${s.name}: parameters.type=${s.parameters?.type}`);
	}
	if (typeof s.description !== 'string' || s.description.length < 20) {
		shapeOk = false;
		problems.push(`${s.name}: description 过短`);
	}
}
check(shapeOk, '每个工具的 parameters/description 合法', problems.length === 0 ? '全部通过' : problems.join('; '));

// ── 真跑一次 ppt_env（不需要 Python 之外的东西）────────────────────────────

const envTool = ctx.tools.get('ppt_env');
check(envTool !== undefined, 'ppt_env 可查到', envTool === undefined ? '未注册' : 'ok');

if (envTool !== undefined) {
	try {
		const out = await envTool.execute({}, {});
		const text = out?.report ?? '';
		check(typeof text === 'string' && text.length > 0, 'ppt_env 执行有输出', text.split('\n').slice(0, 2).join(' / '));
		check(/解释器|没找到/.test(text), 'ppt_env 报告了解释器状态', text.includes('解释器') ? '找到解释器' : '未找到（已如实报告）');
	} catch (error) {
		check(false, 'ppt_env 执行有输出', String(error?.message ?? error));
	}
}

// ── 真跑一次 ppt_project validate（走完整 spawn 链路）──────────────────────

const projectTool = ctx.tools.get('ppt_project');
if (projectTool !== undefined) {
	try {
		// 故意指向不存在的路径：要求它「跑起来并如实返回非零」，而不是崩掉。
		const out = await projectTool.execute({ action: 'validate', project: 'Z:/definitely-not-here-xyz' }, {});
		check(typeof out?.output === 'string' && out.output.length > 0, 'ppt_project 能跑通 spawn 链路', `exitCode=${out?.exitCode}`);
		check(out?.ok === false, '不存在的项目如实报非零', `exitCode=${out?.exitCode}`);
	} catch (error) {
		check(false, 'ppt_project 能跑通 spawn 链路', String(error?.message ?? error));
	}
}

// ── skill provider ──────────────────────────────────────────────────────────

const all = await registry.list();
const pptSkills = all.filter((s) => s.name === 'ppt-master' || s.name === 'ppt-master-dsh');
check(pptSkills.length === 2, '两个 skill 都注册上了', pptSkills.map((s) => s.name).join(', ') || '(无)');

for (const wanted of ['ppt-master', 'ppt-master-dsh']) {
	const skill = await registry.get(wanted);
	if (skill === undefined) {
		check(false, `skill ${wanted} 可取回`, 'undefined');
		continue;
	}
	const body = skill.content ?? '';
	const leftover = (body.match(/\$\{SKILL_DIR\}/g) ?? []).length;
	const leftoverPayload = (body.match(/\$\{PAYLOAD_DIR\}/g) ?? []).length;
	check(body.length > 500, `skill ${wanted} 正文非空`, `${body.length} 字符`);
	check(leftover === 0 && leftoverPayload === 0, `skill ${wanted} 占位符全部展开`, `残留 SKILL_DIR=${leftover}, PAYLOAD_DIR=${leftoverPayload}`);
	// 展开后的路径必须真的存在。精简 skill 只打印载荷**根目录**，其余用相对路径；
	// 完整版 skill 则在正文里散布脚本绝对路径 —— 两种都要能验。
	const absPaths = (body.match(/[A-Za-z]:[\\/][^\s`"')]+|\/(?:data|home|usr|opt)[^\s`"')]+/g) ?? [])
		.map((s) => s.replace(/[.,;:]+$/, ''))
		.filter((s) => s.includes('ppt-master'));
	const existing = absPaths.filter((s) => existsSync(s));
	check(
		existing.length > 0,
		`skill ${wanted} 路径指向载荷`,
		existing.length > 0
			? `命中 ${existing.length}/${absPaths.length} 个真实路径`
			: `无真实路径（候选 ${absPaths.length} 个）`,
	);
}

// ── 输出 ────────────────────────────────────────────────────────────────────

const width = Math.max(...results.map(([, label]) => label.length));
for (const [status, label, detail] of results) console.log(`${status}  ${label.padEnd(width)}  ${detail}`);
const failed = results.filter(([s]) => s === 'FAIL').length;
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exit(failed === 0 ? 0 : 1);
