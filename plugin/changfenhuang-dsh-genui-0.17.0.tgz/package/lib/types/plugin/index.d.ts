/**
 * GenUI plugin: teaches the model the ```dsh-ui fence syntax for emitting
 * declarative UI components inline in its reply. The browser half renders the
 * fence through GenuiBlock (ui-primitives); this host half only tells the
 * model the language exists, so a session without the plugin simply never
 * emits fences and nothing changes.
 *
 * The section uses the host's centrally allocated structured-output placement.
 * @module @changfenhuang/dsh-genui
 */
import { Context } from '@deepseek-ai/cordis';
import type { IncomingMessage, ServerResponse } from 'node:http';
/** Strong validator for one asset: its content hash (assets are built output and fixed per release). */
export declare function assetEtag(body: Uint8Array): string;
/** Whether an `If-None-Match` header already names `etag` (comma list, `*`, or weak `W/` forms). */
export declare function etagMatches(header: string | string[] | undefined, etag: string): boolean;
/** The handler itself (registered via the optional webServer probe). */
export declare function serveGenuiAsset(req: IncomingMessage, res: ServerResponse, assetDirectory?: string): Promise<void>;
/** 默认按内容任务主动使用 UI，组件规范由 genui Skill 提供。 */
export declare const GENUI_SECTION_TEXT = "Render reply UI with a `dsh-ui` JSON block:\n\n```dsh-ui\n{\"items\":[{\"type\":\"callout\",\"content\":\"\u4E00\u4E2A items \u5BF9\u8C61\u4E00\u4E2A\u7EC4\u4EF6\"},{\"type\":\"table\",\"columns\":[\"\u7EC4\u4EF6\",\"\u5B57\u6BB5\"],\"rows\":[[\"callout\",\"content\"]]}]}\n```\n\nBefore emitting UI, MUST call the skill tool to load `genui`.\nRFC2119: MUST=\u5FC5\u987B\uFF1BSHOULD=\u63A8\u8350\uFF1BMAY=\u53EF\u9009\u3002\n\n\u5F53\u524D\u4F7F\u7528\u5B8C\u6574\u6863\uFF08fenceSection: full\uFF09\u3002\u4E0B\u5217\u4EFB\u52A1 SHOULD \u4F18\u5148\u76F4\u63A5\u7528\u6700\u5C0F\u7684\u5408\u9002\u7EC4\u4EF6\u5448\u73B0\uFF0C\u4E0D\u5FC5\u7B49\u7528\u6237\u63D0\u9192\uFF1A\n- \u6309\u5171\u540C\u7EF4\u5EA6\u6BD4\u8F83\u9009\u9879\u6216\u53D6\u820D \u2192 table / choices\uFF1B\u5C55\u793A\u524D\u540E\u89C6\u89C9\u5DEE\u5F02 \u2192 compare\u3002\n- \u7528\u6570\u503C\u89E3\u91CA\u8D8B\u52BF\u3001\u5360\u6BD4\u6216\u591A\u9879\u6307\u6807\u5173\u7CFB \u2192 chart / echart / table\uFF1B\u5355\u4E2A\u6570\u5B57\u65E0\u9700\u5F3A\u884C\u51FA\u7EC4\u4EF6\u3002\n- \u7406\u89E3\u7ED3\u679C\u4F9D\u8D56\u6B65\u9AA4\u987A\u5E8F\u3001\u5206\u652F\u6216\u7ED3\u6784\u5173\u7CFB \u2192 steps / diagram / mermaid\u3002\n- \u9700\u8981\u7B5B\u9009\u3001\u9009\u62E9\u6216\u8BA1\u7B97 \u2192 input / select / choices + \u76F8\u5E94\u7ED3\u679C\u7EC4\u4EF6\u3002\n\u666E\u901A\u89E3\u91CA\u548C\u77ED\u6E05\u5355\u9ED8\u8BA4\u6B63\u6587\uFF0C\u4EC5\u5728\u9700\u8981\u6BD4\u8F83\u3001\u5173\u7CFB\u8868\u8FBE\u6216\u4EA4\u4E92\u65F6\u7528\u7EC4\u4EF6\uFF1B\u4E0D\u6309\u6761\u6570\u3001\u5B57\u6570\u6216\u56DE\u7B54\u957F\u5EA6\u89E6\u53D1\uFF0C\u6CA1\u6709\u7EC4\u4EF6\u6570\u91CF\u914D\u989D\u3002\u4FE1\u606F\u53EA\u5448\u73B0\u4E00\u6B21\u3002MUST \u670D\u4ECE\u7528\u6237\u660E\u786E\u7684\u7EAF\u6587\u5B57\u8981\u6C42\u3002card MAY \u7528\u4F5C\u5BB9\u5668\u3002\n\u751F\u6210\u56F4\u680F\u672C\u8EAB\u4E0D\u662F\u4ED3\u5E93\u89C6\u89C9\u6539\u52A8\uFF0C\u65E0\u9700\u4E3A\u6B64\u8BFB\u6E90\u7801\u3001\u5199\u6587\u4EF6\u3001\u8D77\u670D\u52A1\uFF1B\u7528\u6237\u8981\u6C42\u5F00\u53D1\u6216\u6392\u9519\u65F6\u518D\u6309\u9700\u64CD\u4F5C\u3002\n\nRules:\n- LANGUAGE: MUST match reply+UI to conversation language; NEVER infer it from examples/tools. Replace `<user-language ...>`; never emit placeholders literally.\n- JSON MUST \u4E25\u683C\u5408\u6CD5\uFF1A\u22653 \u8282\u70B9\u6216\u542B table \u65F6 MUST \u8C03 validate_dsh_ui\uFF0C\u6309\u8BCA\u65AD\u4FEE\u6539\u5E76\u91CD\u9A8C\uFF1B\u901A\u8FC7\u540E MUST \u9010\u5B57\u590D\u5236 native_fence_json / validated_json / repaired_json\uFF0C\u4E0D\u91CD\u65B0\u7F16\u5199\u3002\u5C0F\u56F4\u680F\u5B57\u6BB5\u5B58\u7591\u4E5F\u5148\u9A8C\u8BC1\u3002\n- warning=block_markdown\uFF1A\u6309 replacement \u6539\u5199\u5E76\u91CD\u9A8C\u3002\n- \u89C4\u6A21: \u2264200 \u8282\u70B9\u3001\u5D4C\u5957\u22648 \u5C42\uFF08\u8D85\u51FA\u88AB\u622A\u65AD\uFF09\u3002\u7EC4\u4EF6\u8282\u70B9\u5FC5\u987B\u5E26\u5B57\u7B26\u4E32 `type`\uFF0C\u5B57\u6BB5\u9075\u5FAA genui skill\u3002\n- LOCAL-FIRST + actions: UI \u80FD\u81EA\u5DF1\u5B8C\u6210\u7684\u72B6\u6001\u53D8\u5316\u5728\u672C\u5730\u5904\u7406\uFF1Baction \u7528\u4E8E\u9700\u8981\u6A21\u578B\u53C2\u4E0E\u7684\u64CD\u4F5C\u3002\u4EA4\u4E92\u4EE5 [genui-action] name + \u7EC4\u4EF6\u6570\u636E\u56DE\u4F20\u3002\n- Secrets ban: \u4E0D\u7D22\u53D6\u5BC6\u7801\u3001API Key\u3001Token\u3001\u6062\u590D\u7801\uFF1B\u9700\u8981\u65F6\u62D2\u7EDD\u5E76\u89E3\u91CA\u3002\n- Tool channel: render_ui \u7528\u4E8E\u5DE5\u5177\u7ED3\u679C\u533A\u57DF\u7684\u72EC\u7ACB UI\uFF1B\u6B63\u6587\u5185\u8054\u7528\u56F4\u680F\uFF0C\u6301\u7EED\u66F4\u65B0\u7684\u4F1A\u8BDD\u9762\u677F\u7528 panel:true\u3002\u56F4\u680F\u548C\u5DE5\u5177\u90FD\u80FD\u4EA4\u4E92\u5E76\u4FDD\u5B58\u72B6\u6001\uFF0C\u6309\u5448\u73B0\u4F4D\u7F6E\u9009\u62E9\u3002\n- \u56F4\u680F\u4F4D\u7F6E\uFF1A`dsh-ui` \u53EA\u5199\u5728**\u56DE\u7B54\u6B63\u6587**\uFF1B\u5199\u5728 reasoning/\u601D\u8003\u5757\u91CC\u4E0D\u6E32\u67D3\u3001\u7528\u6237\u770B\u4E0D\u5230\u2014\u2014\u601D\u8003\u91CC\u9A8C\u8BC1\u597D spec\uFF0C\u6B63\u6587\u518D\u8F93\u51FA\u540C\u4E00\u4EFD\u3002\n- Panel: \"panel\":true \u53EA\u6E32\u67D3\u8FDB\u4F1A\u8BDD\u9762\u677F dock \u5E76\u539F\u5730\u66F4\u65B0\uFF1B\"append\":true \u8FFD\u52A0\uFF0C\u4E0A\u9650 200 \u8282\u70B9/200 \u6B21\uFF0C\u6EE1\u4E86\u53D1 replace\u3002\u9762\u677F\u6765\u7684 [genui-action] \u53EA\u56DE\u4E00\u4E2A panel:true \u56F4\u680F + \u81F3\u591A\u4E00\u884C 10 \u5B57\u5185\u786E\u8BA4\u3002";
/** 最小围栏提示词要求模型加载完整组件规范。 */
export declare const GENUI_MINIMAL_SECTION_TEXT = "fenceSection: minimal. RFC2119: MUST=required; MAY=optional.\nMAY emit reply-body `dsh-ui` JSON; MUST follow user preference.\nBefore emitting UI, MUST call the skill tool to load `genui`.\n\u751F\u6210\u56F4\u680F\u65E0\u9700\u6539\u6587\u4EF6\u6216\u542F\u52A8\u5E94\u7528\u3002\n\n```dsh-ui\n{\"items\":[{\"type\":\"text\",\"content\":\"Example\"}]}\n```";
/**
 * Register the GenUI output-language section and the render_ui tool.
 * @param ctx - cordis context.
 */
export declare const name = "@changfenhuang/dsh-genui";
export declare const inject: string[];
/**
 * Plugin config as the host passes it (unvalidated: the node half deliberately
 * imports no schema library, so a profile can set these keys directly).
 */
export interface GenuiPluginConfig {
    /**
     * 在最终 dsh-ui 围栏无法渲染的回合中请求模型发送一次修正版（issue #160）。
     * 默认开启，设置为 false 可以关闭同回合围栏修正。GenUI 回合只返回思考或空白时，仍由宿主重试。
     * 每回合和每个围栏正文最多请求一次，子代理不触发，每次修正请求会消耗模型步数。
     */
    fenceFeedback?: boolean;
    /**
     * 是否注册 render_ui 模型工具。默认开启，设置为 false 时关闭；不影响 validate_dsh_ui 和 dsh-ui 围栏渲染。
     */
    renderUiTool?: boolean;
    /** 围栏提示档位：full（默认）主动用于适合的任务，minimal 只教语法，false 关闭该提示段。 */
    fenceSection?: 'full' | 'minimal' | false;
}
/** 注册 GenUI 围栏提示词、工具及可选宿主能力。 */
export declare function apply(ctx: Context, config?: GenuiPluginConfig): void;
