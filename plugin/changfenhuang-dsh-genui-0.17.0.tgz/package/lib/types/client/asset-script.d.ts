/** Load an engine in the same document where it will run. */
export declare function loadAssetScript(owner: Document, src: string, file: string, key: string): Promise<unknown>;
/** Mermaid measures inside its own document to avoid the transcript's style cascade. */
export declare function createMermaidRenderDocument(): Document;
