import { type ReactNode } from 'react';
interface MermaidZoomDialogProps {
    /** The same sanitized SVG string the card already shows; never re-rendered. */
    readonly html: string;
    readonly open: boolean;
    readonly onClose: () => void;
}
/**
 * Full-size viewer for one rendered Mermaid diagram.
 *
 * The dialog stays inside the block subtree rather than portalling to
 * document.body, so it inherits the host theme tokens (the same choice the
 * single-image viewer makes) and works unchanged in a standalone artifact.
 * Only CSS transforms move the diagram: no second mermaid.render, no bitmap.
 */
export declare function MermaidZoomDialog({ html, open, onClose }: MermaidZoomDialogProps): ReactNode;
export {};
