/** 二进制与 Base64 互转（导出器与内联媒体共用）。 */
/** 将二进制内容编码为不会闭合 script 标签的 Base64。 */
export declare function bytesToBase64(bytes: Uint8Array): string;
/** 将图片字节包装为 data URL。 */
export declare function bytesToDataUrl(bytes: Uint8Array, mime: string): string;
