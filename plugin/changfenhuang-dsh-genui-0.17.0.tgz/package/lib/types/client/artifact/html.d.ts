import { type GenuiArtifactV1 } from './types.ts';
import type { GenuiSpec } from '../spec.ts';
/**
 * 将媒体相对地址转换为导出页面所在站点的绝对地址。
 *
 * Walks the same writable media fields the inline step uses, so every media
 * kind (including `compare` panels and `entity-card` portraits, which the old
 * per-type visit skipped) resolves the same way.
 */
export declare function resolveMediaUrls(spec: GenuiSpec, baseURI: string): GenuiSpec;
/** 使用已下载的运行文件生成完整的独立 HTML 文档。 */
export declare function createStandaloneHtmlDocument(artifact: GenuiArtifactV1, bundles: ReadonlyMap<string, Uint8Array>, baseURI?: string, media?: ReadonlyMap<string, string>): string;
/**
 * 获取独立运行文件及规格实际使用的图形引擎，生成单文件 HTML。
 *
 * Same-origin images are read once and embedded as `data:` URLs so the
 * exported page shows them without the host process, a cookie, or a network
 * (issue #453). Anything unreadable keeps its absolute URL.
 */
export declare function buildStandaloneHtml(rawArtifact: GenuiArtifactV1): Promise<string>;
