import type { GenuiSpec } from '../spec.ts';
interface GenuiMediaRef {
    src: string;
    set: (next: string) => void;
    image: boolean;
}
/** DSH Desktop serves its Web UI and file API on this protocol. */
export declare function isDesktopMediaUrl(url: URL): boolean;
/** Collect every writable media field, including fields that are not nodes. */
export declare function collectGenuiMediaRefs(spec: GenuiSpec): GenuiMediaRef[];
/** Read same-origin images with the active host session. The HTML stores each source once. */
export declare function inlineStandaloneMedia(spec: GenuiSpec, baseURI: string, fetchImpl?: typeof fetch): Promise<Map<string, string>>;
export {};
