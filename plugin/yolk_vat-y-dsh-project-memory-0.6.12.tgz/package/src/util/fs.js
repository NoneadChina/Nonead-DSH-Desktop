import {
  accessSync, closeSync, constants, existsSync, mkdirSync, openSync, readdirSync, readFileSync, renameSync, statSync,
  unlinkSync, writeFileSync,
} from 'node:fs'
import { execFileSync } from 'node:child_process'
import { readFile } from 'node:fs/promises'
import { createHash, randomUUID } from 'node:crypto'
import os from 'node:os'
import path from 'node:path'
import { sessionWorkingDir } from './session-dir.js'

/**
 * 原子写 JSON：先写同目录的 `<file>.<pid>.tmp`，再 rename 覆盖目标；先建父目录，失败时只删自己的 `.tmp`。
 * 重试 rename 没有意义；崩溃（kill -9 / 断电）走不到 catch，残留由 `cleanStaleTmp()` 兜底
 * （它扫不到 `~/.config/dsh-project-memory/`）。
 * @param {string} file - 目标文件绝对路径。
 * @param {unknown} data - 要序列化的 JSON 值。
 * @throws 序列化失败或写盘/rename 失败时原样抛出（调用方决定回退策略）。
 */
const TRANSIENT_FS_CODES = new Set(['EPERM', 'EBUSY', 'EACCES'])

/**
 * Windows 上 rename/unlink 会被杀毒/索引/备份瞬时占用（EPERM/EBUSY），同参数重试一次通常就过。
 * 只在**瞬时错误码**上重试；真实失败（EISDIR/ENOSPC/EACCES 持续）立即抛出，保持"失败要清 .tmp 并抛出"。
 */
function retryTransient(op, attempts = 3) {
  let last
  for (let i = 0; i < attempts; i++) {
    try {
      return op()
    } catch (err) {
      last = err
      if (!TRANSIENT_FS_CODES.has(err?.code)) throw err
      if (i + 1 < attempts) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10 * (i + 1))
    }
  }
  throw last
}

export function writeJsonAtomic(file, data, { ensureDir = true } = {}) {
  const dir = path.dirname(file)
  if (ensureDir) mkdirSync(dir, { recursive: true })
  const tmp = `${file}.${process.pid}.tmp`
  const payload = JSON.stringify(data)
  const write = () => {
    retryTransient(() => writeFileSync(tmp, payload))
    retryTransient(() => renameSync(tmp, file))
  }
  try {
    write()
  } catch (err) {
    let failure = err
    // 目录可能在两次写之间被外部删掉；`ensureDir: false` 的快路径不能假设目录一定在——
    // 补建后重做一次，仍失败才按原契约抛。
    if (err?.code === 'ENOENT') {
      try {
        mkdirSync(dir, { recursive: true })
        write()
        return
      } catch (retryErr) {
        failure = retryErr
      }
    }
    try {
      unlinkSync(tmp)
    } catch {
      // tmp 已不在（rename 其实成功了）或不可删；两种都无需处理
    }
    throw failure
  }
}

/**
 * 删除文件并对 Windows 的瞬时占用（EPERM/EBUSY/EACCES）重试。
 *
 * 为什么需要：`unlinkSync` 和 `renameSync` 一样会被杀毒/索引器短暂占用。删除失败若被当成
 * "已经没了"，删除意图（`forget` / 索引清理）会被静默丢掉，下一次 load 时旧 shard 又会复活。
 * @param {string} file - 目标文件。
 * @throws 真实失败（ENOENT 之外且重试仍失败）时原样抛出。
 */
export function unlinkWithRetry(file) {
  return retryTransient(() => unlinkSync(file))
}

/** 本机标识：锁的存活判定只在同机可信（跨机只能退回 mtime）。 */
const LOCK_HOST = os.hostname()
const LOCK_FILE = '.write.lock'
let lockSeq = 0

/**
 * 读锁文件（不存在/读失败返回 null）。旧格式是裸 pid，新格式是 JSON（pid + host + token），两种都要能读。
 * @param {string} file
 * @returns {null | { text: string, meta: { pid?: number, host?: string, token?: string }, ageMs: number }}
 */
function readLockState(file) {
  try {
    const text = readFileSync(file, 'utf8')
    const ageMs = Date.now() - statSync(file).mtimeMs
    let meta = null
    try {
      const parsed = JSON.parse(text)
      if (parsed && typeof parsed === 'object') meta = parsed
    } catch {
      // 旧格式：裸 pid
    }
    if (!meta) meta = { pid: Number.parseInt(text.trim(), 10) }
    return { text, meta, ageMs }
  } catch {
    return null
  }
}

/**
 * 进程启动时刻（Linux：`/proc/<pid>` 的 ctime）。其它平台读不到就返回 null。
 * 只用于识别 **pid 复用**：新进程的启动时刻晚于旧锁的 `at`，就是"锁确实死了"的硬证据。
 * @param {number} pid
 * @returns {number|null}
 */
function processStartMs(pid) {
  try {
    return statSync(`/proc/${pid}`).ctimeMs
  } catch {
    return null
  }
}

/** 进程是否还活着。EPERM = 存在但属于别人，按活着算。 */
function pidAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false
  try {
    process.kill(pid, 0)
    return true
  } catch (err) {
    return err?.code === 'EPERM'
  }
}

/** 时钟抖动 / NTP 校正的容差：`at` 早于开机时刻这么多才算"上次开机的残留"。 */
const BOOT_SLACK_MS = 60_000
/** 锁自带的 `boot` 标记与本次开机相差多少才算换了启动（`os.uptime()` 的取值精度远小于它）。 */
const BOOT_MATCH_TOLERANCE_MS = 10 * 60_000

/**
 * 本次开机时刻（epoch ms）。`os.uptime()` 在 Windows / macOS 上也可用，而 `/proc` 只有 Linux——
 * 判"锁是上次开机留下的"不能依赖 `/proc`（Windows 上 `processStartMs()` 恒为 null）。
 * @returns {number}
 */
function bootTimeMs() {
  const uptime = Number(os.uptime())
  return Date.now() - (Number.isFinite(uptime) && uptime > 0 ? uptime * 1000 : 0)
}

/**
 * 锁是否可回收（stale）。判定顺序：跨开机残留 → 跨机/无 pid（只按 mtime）→ pid 已死 → pid 复用 →
 * 显式硬上限。**同机 + pid 活着**默认绝不回收（宁可等，也不能双写），只有三条硬证据能推翻它：
 * 锁写于上次开机之前、锁自带的 boot 标记与本次不符、持有时间超过 `maxHoldMs`。
 *
 * 前两条是为 Windows 补的：那里没有 `/proc`，`processStartMs()` 恒为 null，重启后 pid 极易被
 * 复用（系统服务拿到旧号），旧实现于是把残留锁当成"活锁"永久拒绝写入，且落盘失败默认静默。
 * @param {{meta: object, ageMs: number}} state
 * @param {{staleMs: number, hardLimit: number, maxHoldMs?: number}} opts
 *   `hardLimit` 是跨机/无 pid 的绝对兜底；`maxHoldMs` 是"同机活锁"的持有上限（0 = 不设上限）。
 * @returns {boolean}
 */
function lockIsStale(state, { staleMs, hardLimit, maxHoldMs = 0 }) {
  if (!state) return true
  const { meta, ageMs } = state
  const at = Date.parse(meta.at || '')
  const sameHost = !meta.host || meta.host === LOCK_HOST
  // 跨机 / 旧格式没有 pid：只能按 mtime，hardLimit 是最后兜底。
  // 这两条**必须**先返回：开机时刻的判断只对"本机写的锁"成立——网络盘上另一台机器持锁时，
  // 它的 `at` 早于本机本次开机是常态，拿它当证据会抢掉一台真正在写的机器（原作者在此处
  // 刻意选了"宁可等也不能双写"，这条不能被顺手扩到跨机）。
  if (!sameHost || !Number.isInteger(meta.pid)) {
    return ageMs > staleMs || ageMs > hardLimit
  }
  const boot = bootTimeMs()
  // 写于本机上一次开机之前：持有者早已随重启消失，无论 pid 是否存活都是残留。Windows 上没有
  // /proc，`processStartMs()` 恒为 null，这是"重启后 pid 被复用"唯一能识破的证据。
  if (Number.isFinite(at) && at < boot - BOOT_SLACK_MS) return true
  // 锁自带的开机标记与本次不符：系统时钟被改过时 `at` 不可信，`boot` 仍可判。
  if (Number.isFinite(meta.boot) && Math.abs(boot - meta.boot) > BOOT_MATCH_TOLERANCE_MS) return true
  if (!pidAlive(meta.pid)) return true
  // 活着：正常绝不回收；例外是 pid 被复用（新进程启动晚于旧锁）。
  // 没有 `at` 的旧锁无法判断 → 信任存活，宁可等也不能双写。
  const started = processStartMs(meta.pid)
  if (started !== null && Number.isFinite(at) && started > at + 5000) return true
  // 同一次启动里 pid 也可能被别的进程复用（Windows 上无从从 pid 本身看出）：持有时间远超
  // 一次同步写盘就不再当作"有人正在写"。**只在调用方显式给了上限时生效**（默认关闭，
  // 保持"活锁绝不回收"的既有契约）。
  if (maxHoldMs > 0 && ageMs > maxHoldMs) return true
  return false
}

/**
 * 目录级写锁（跨进程）：`.write.lock` 内容 `{pid, host, token, at}`，**释放要校验 token**，
 * 绝不 unlink 别人的锁；拿不到锁返回 null（调用方必须把这次写当成失败，而不是"等会儿会写"）。
 * `ensureDir: false` 只跳过预防性 mkdir（9p/NTFS ~4ms），ENOENT 时仍补建重试一次，否则外部删除会变成永久写失败。
 * @param {string} dir 目标目录（不存在则创建）
 * @param {{timeoutMs?: number, staleMs?: number, hardStaleMs?: number, maxHoldMs?: number, ensureDir?: boolean}} [opts]
 *   `maxHoldMs` 是"同机 + pid 存活"的持有上限（毫秒，0 = 不设）：给写路径用，避免同一次启动内
 *   pid 被别的进程复用后残留锁永远挡住写入（Windows 上无法从 pid 本身识破复用）。
 * @returns {null | (() => void)} 释放函数；拿不到锁返回 null
 */
export function acquireDirLock(dir, { timeoutMs = 2000, staleMs = 10000, hardStaleMs = 0, maxHoldMs = 0, ensureDir = true } = {}) {
  if (ensureDir) {
    try {
      mkdirSync(dir, { recursive: true })
    } catch {
      return null
    }
  }
  const file = path.join(dir, LOCK_FILE)
  const hardLimit = hardStaleMs > 0 ? hardStaleMs : staleMs * 10
  const token = `${process.pid}-${Date.now().toString(36)}-${++lockSeq}-${randomUUID().slice(0, 8)}`
  const payload = JSON.stringify({
    pid: process.pid,
    host: LOCK_HOST,
    token,
    at: new Date().toISOString(),
    // 本次开机时刻：跨重启的残留锁靠它识破（Windows 没有 /proc，pid 存活不足以证明持有者还在）。
    boot: bootTimeMs(),
  })
  const deadline = Date.now() + timeoutMs
  const sleeper = new Int32Array(new SharedArrayBuffer(4))
  let recoveredDir = false
  for (;;) {
    try {
      const fd = openSync(file, 'wx')
      try {
        writeFileSync(fd, payload)
      } finally {
        closeSync(fd)
      }
      return () => releaseDirLock(file, token)
    } catch (err) {
      if (err?.code === 'ENOENT' && !recoveredDir) {
        // 目录在 load 之后被外部删掉：只恢复一次，避免目录不可写时死循环。
        recoveredDir = true
        try {
          mkdirSync(dir, { recursive: true })
        } catch {
          return null
        }
        continue
      }
      if (err?.code !== 'EEXIST') return null
      const state = readLockState(file)
      if (!state) {
        // 锁文件在、但读不出来（EACCES / 同名目录）：按 deadline 放弃，不忙等。
        if (Date.now() >= deadline) return null
        Atomics.wait(sleeper, 0, 0, 10)
        continue
      }
      if (lockIsStale(state, { staleMs, hardLimit, maxHoldMs })) {
        // 只删"刚刚读到的那个内容"：两次读之间锁可能已被别人抢到并重写。
        // 回收失败（只读目录、Windows 杀毒/索引器长期占用）不能无条件 continue：那会变成
        // 无 deadline、无等待的同步自旋，timeoutMs 被完全忽略，save()/commit()/退出 flush 卡死。
        if (Date.now() >= deadline) return null
        try {
          if (readFileSync(file, 'utf8') === state.text) unlinkWithRetry(file)
        } catch {
          // 已被别处回收，或杀毒瞬时占用；下一轮继续判定
        }
        Atomics.wait(sleeper, 0, 0, 10)
        continue
      }
      if (Date.now() >= deadline) return null
      Atomics.wait(sleeper, 0, 0, 10)
    }
  }
}

/**
 * 释放锁：内容还是自己的 token 才删，旧格式（裸 pid）只在自己 pid 匹配时删——第二道闸。
 * @param {string} file
 * @param {string} token
 */
function releaseDirLock(file, token) {
  try {
    const text = readFileSync(file, 'utf8')
    let meta = null
    try {
      const parsed = JSON.parse(text)
      if (parsed && typeof parsed === 'object') meta = parsed
    } catch {
      // 旧格式
    }
    if (meta && typeof meta.token === 'string') {
      if (meta.token !== token) return
    } else if (text.trim() !== String(process.pid)) {
      return
    }
    // 释放失败不能静默：锁文件还在、pid 又是自己，下一次 acquire 会把自己当成活锁
    // （同机 pid 存活默认不回收，save 的 maxHoldMs 是 10 分钟），后续写入会被堵住。
    // 先对 Windows 的 EPERM/EBUSY 做瞬时重试；仍删不掉就把内容改成 pid 0（死进程），
    // 下一次 acquire 能立即判 stale，而不是等 10 分钟。
    try {
      unlinkWithRetry(file)
    } catch {
      try {
        writeFileSync(file, JSON.stringify({
          pid: 0,
          host: LOCK_HOST,
          token: 'released',
          at: new Date().toISOString(),
        }))
      } catch {
        // 连覆盖也失败：只能等 staleMs 兜底，不能因此抛给调用方
      }
    }
  } catch {
    // 已被回收或目录不可写：不影响调用方
  }
}

/**
 * 读锁状态（诊断/测试用）：谁持有、多久了、是否会被当成 stale。
 * @param {string} dir
 * @param {{staleMs?: number, hardStaleMs?: number, maxHoldMs?: number}} [opts]
 * @returns {null | { pid: number|undefined, host: string|undefined, token: string|undefined, ageMs: number, stale: boolean }}
 */
export function inspectDirLock(dir, { staleMs = 10000, hardStaleMs = 0, maxHoldMs = 0 } = {}) {
  const state = readLockState(path.join(dir, LOCK_FILE))
  if (!state) return null
  return {
    pid: state.meta.pid,
    host: state.meta.host,
    token: state.meta.token,
    ageMs: state.ageMs,
    stale: lockIsStale(state, {
      staleMs,
      hardLimit: hardStaleMs > 0 ? hardStaleMs : staleMs * 10,
      maxHoldMs,
    }),
  }
}

export function assertReadableFile(filePath, maxFileSizeMb) {
  if (typeof filePath !== 'string' || !filePath) {
    throw new Error('file_path must be a non-empty string')
  }
  let stats
  try {
    accessSync(filePath, constants.R_OK)
    stats = statSync(filePath)
  } catch {
    throw new Error(`File not readable: ${filePath}`)
  }
  if (!stats.isFile()) {
    throw new Error(`Not a regular file: ${filePath}`)
  }
  if (maxFileSizeMb && stats.size > maxFileSizeMb * 1024 * 1024) {
    throw new Error(`File too large (${(stats.size / 1024 / 1024).toFixed(1)} MB), limit is ${maxFileSizeMb} MB`)
  }
  return filePath
}

/** Windows-style absolute path (`D:\dir`, `C:/dir`) — not absolute on POSIX. */
const WINDOWS_ABSOLUTE_PATH = /^[A-Za-z]:[\\/]/

/**
 * 校验索引根目录：必须存在且是目录，写盘前拒绝。Linux/macOS 上传入 `D:\project\foo` 会被
 * 解析成 `<cwd>/D:\project\foo`，并被 mkdirSync 真的建出来。
 * `requested` 只用于在报错里点明"这看起来是 Windows 路径"。
 */
export function assertIndexRoot(root, requested = root) {
  let stats
  try {
    stats = statSync(root)
  } catch {
    const hint = process.platform !== 'win32' && WINDOWS_ABSOLUTE_PATH.test(String(requested))
      ? ` The argument looks like a Windows path, which is not absolute on ${process.platform}.`
      : ''
    throw new Error(`Index root does not exist: ${root}.${hint}`)
  }
  if (!stats.isDirectory()) {
    throw new Error(`Index root is not a directory: ${root}`)
  }
  return root
}

export function sha256OfBuffer(buf) {
  return createHash('sha256').update(buf).digest('hex')
}

export async function sha256OfFile(filePath) {
  const buf = await readFile(filePath)
  return { hash: sha256OfBuffer(buf), size: buf.length }
}

/**
 * 单次同步读：同一 buffer 同时供内容哈希与正文解码使用，替代二次读盘。逐文件 `async readFile`
 * 的线程池往返是批量索引的主要开销（实测 2000 文件 260ms → 单次同步读 ~6ms）；
 * 未变更文件无需解码。
 */
export function readFileForIndex(filePath) {
  const buffer = readFileSync(filePath)
  return { hash: sha256OfBuffer(buffer), size: buffer.length, buffer }
}

export async function readTextFile(filePath, maxBytes = 2 * 1024 * 1024) {
  // 先 stat 再读：上限的意义是"别把整个文件读进内存"。先读后判会把 127 MB 拉进 RSS 再抛错，
  // 而 watch/lazy 每轮重试会让它反复发生。
  if (Number.isFinite(maxBytes)) {
    let size = 0
    try {
      size = statSync(filePath).size
    } catch {
      size = 0 // 交给下面的 readFile 报真实错误（不存在 / 无权限）
    }
    if (size > maxBytes) {
      throw new Error(`File too large to index as text (${(size / 1024 / 1024).toFixed(1)} MB)`)
    }
  }
  const buf = await readFile(filePath)
  if (buf.length > maxBytes) {
    // stat 与 read 之间文件被改大：兜底再判一次
    throw new Error(`File too large to index as text (${(buf.length / 1024 / 1024).toFixed(1)} MB)`)
  }
  return buf.toString('utf8')
}

// 逐目录名排除。除构建产物外，收了 macOS/Homebrew 的巨型噪音目录（家目录 `Library`/`Applications`、
// `/opt/homebrew` 下的 `Cellar`/`Caskroom`/`Frameworks`），它们是吃满内存的那批（issue #5）。
const DEFAULT_IGNORE = new Set([
  '.git', 'node_modules', 'dist', 'build', '.next', 'venv', '.venv',
  '__pycache__', '.idea', '.vscode', '.dsh-project-memory', '.cache',
  'coverage', '.turbo', 'target', 'vendor', 'third_party', 'thirdparty', 'obj',
  'Library', 'Applications', 'Cellar', 'Caskroom', 'Frameworks', 'DerivedData',
  'Pods', 'bower_components', 'jspm_packages', 'logs',
])

/** 单次扫描的默认上限。0 / 负数 / 非数字 = 不限制。 */
export const DEFAULT_SCAN_FILES = 20000
export const DEFAULT_SCAN_DEPTH = 12

/** 从 config 解析扫描上限：0 / 负数 / 非数值一律回落到出厂值，上限只能放宽不能取消。 */
export function scanLimits(config) {
  const files = Number(config?.maxScanFiles)
  const depth = Number(config?.maxScanDepth)
  return {
    maxFiles: Number.isFinite(files) && files > 0 ? files : DEFAULT_SCAN_FILES,
    maxDepth: Number.isFinite(depth) && depth > 0 ? depth : DEFAULT_SCAN_DEPTH,
  }
}

/**
 * 遍历目录，返回 `{ files, truncated, capped, skipped, unreadable }`。
 * `truncated` 必须分开报告两个来源：`capped`（撞到 maxFiles/maxDepth）与 `unreadable`
 * （某目录 readdirSync 失败）。读不到 ≠ 不存在：不置 truncated，调用方会把未见到的文件当
 * "已删除"清掉（派生索引静默丢失）；后者也绝不能拿本轮未见到的文件去删旧条目。
 */

/**
 * 一个目录是否**自带 store**。判据用 `format.json`：走过一次 `save()` 的 store 必有它，
 * 误建/刚建的空 `.dsh-project-memory` 没有——那种不能作为跳过的依据，否则内容两头都没了。
 */
export function hasOwnStore(dir, memoryDirName) {
  return existsSync(path.join(dir, memoryDirName, 'format.json'))
}

/**
 * 列出 `root` 下**自带 store** 的子目录（有独立索引）。用于查询未命中时给模型指路：
 * BFS、限深 3 层、最多列 8 个、最多看 300 个目录，且不往已知的子根里下探。
 */
export function nestedStoreRoots(root, memoryDirName, { maxDepth = 3, maxEntries = 8, maxVisited = 300 } = {}) {
  const found = []
  const queue = [[root, 0]]
  let visited = 0
  while (queue.length && found.length < maxEntries && visited < maxVisited) {
    const [dir, depth] = queue.shift()
    visited++
    let entries
    try {
      entries = readdirSync(dir, { withFileTypes: true })
    } catch {
      continue
    }
    for (const entry of entries) {
      if (found.length >= maxEntries) break
      if (!entry.isDirectory() || entry.name.startsWith('.')) continue
      if (DEFAULT_IGNORE.has(entry.name)) continue
      const full = path.join(dir, entry.name)
      if (hasOwnStore(full, memoryDirName)) {
        found.push(full)
        continue // 已知的子根不再往里下探
      }
      if (depth + 1 <= maxDepth) queue.push([full, depth + 1])
    }
  }
  return found.sort()
}

export function walkDir(root, opts = {}) {
  const ignoreNames = opts.ignoreNames || DEFAULT_IGNORE
  const maxFiles = Number.isFinite(opts.maxFiles) && opts.maxFiles > 0 ? opts.maxFiles : Infinity
  const maxDepth = Number.isFinite(opts.maxDepth) && opts.maxDepth > 0 ? opts.maxDepth : Infinity
  // 传 memoryDir 名即开启「嵌套根不重复索引」，与 findProjectRoot 对子树返回子根的规则一致；
  // 否则父 store 会把子项目内容再存一份（实测 9075/9081 个文件是重复副本）。
  const nestedStoreName = opts.nestedStoreName || null
  // `roots.exclude` 是子树级前缀匹配：命中的目录整棵剪掉，命中的文件直接不收。
  const policy = isCompiledRootPolicy(opts.policy)
    ? opts.policy
    : isCompiledRootPolicy(opts.config)
      ? opts.config
      : opts.config ? compileRootPolicy(opts.config) : null
  const out = []
  const skipped = []
  const unreadable = []
  const stack = [[root, 0]]
  let capped = false
  let truncated = false
  let hitFileCap = false
  while (stack.length) {
    const [dir, depth] = stack.pop()
    let entries
    try {
      entries = readdirSync(dir, { withFileTypes: true })
    } catch {
      // 读不到 ≠ 不存在：置 unreadable/truncated 让调用方跳过清理，否则这片子树被当"已删除"。
      unreadable.push(dir)
      truncated = true
      continue
    }
    for (const entry of entries) {
      // 隐藏路径一律不进语料（与 listProjectFiles 的 git 分支同一口径）：配置/状态/密钥
      // （`.env`、`.ssh`）默认落在点文件里；作者真要索引就显式 `index_doc`。
      if (entry.name.startsWith('.')) continue
      const full = path.join(dir, entry.name)
      if (entry.isDirectory()) {
        if (ignoreNames.has(entry.name)) continue
        if (policy && excludedEntryForAbs(full, policy)) continue
        if (nestedStoreName && hasOwnStore(full, nestedStoreName)) {
          skipped.push(full)
          continue
        }
        if (depth + 1 > maxDepth) {
          truncated = true
          capped = true
          continue
        }
        stack.push([full, depth + 1])
      } else {
        if (policy && excludedEntryForAbs(full, policy)) continue
        if (out.length >= maxFiles) {
          truncated = true
          capped = true
          hitFileCap = true
          break
        }
        out.push(full)
      }
    }
    if (hitFileCap) break
  }
  out.sort()
  skipped.sort()
  unreadable.sort()
  return { files: out, truncated, capped, skipped, unreadable }
}

/**
 * git 工作区文件（已跟踪 + 未跟踪且未被忽略）；git 不可用/不是仓库时返回 null。
 * `--exclude-standard` 让嵌套 `.gitignore` 也生效。
 * @param {string} root 项目根
 * @returns {string[]|null} 仓库相对路径（`/` 分隔）
 */
function gitListedFiles(root) {
  try {
    const out = execFileSync('git', ['-C', root, 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], {
      encoding: 'utf8',
      maxBuffer: 64 * 1024 * 1024,
      stdio: ['ignore', 'pipe', 'ignore'],
      // GUI 宿主（Electron 打包的 dsh）从 Windows 起子进程时，不隐藏就会闪一个控制台窗口。
      windowsHide: true,
    })
    return out.split('\0').filter(Boolean)
  } catch {
    return null
  }
}

/**
 * 项目文件清单：git 仓库走 `git ls-files`（尊重 `.gitignore`），非 git 目录回退 {@link walkDir}；
 * 返回形状与 walkDir 一致，调用方无需分支。
 * @param {string} root 项目根
 * @param {object} [opts] 同 walkDir，另加 `gitAware: false` 强制走 walkDir
 * @returns {{files: string[], truncated: boolean, capped: boolean, skipped: string[], unreadable: string[]}}
 */
export function listProjectFiles(root, opts = {}) {
  const policy = isCompiledRootPolicy(opts.policy)
    ? opts.policy
    : isCompiledRootPolicy(opts.config)
      ? opts.config
      : opts.config ? compileRootPolicy(opts.config) : null
  const listed = opts.gitAware === false ? null : gitListedFiles(root)
  if (listed === null) return walkDir(root, opts)
  const maxFiles = Number.isFinite(opts.maxFiles) && opts.maxFiles > 0 ? opts.maxFiles : Infinity
  const maxDepth = Number.isFinite(opts.maxDepth) && opts.maxDepth > 0 ? opts.maxDepth : Infinity
  const nestedName = opts.nestedStoreName || null
  const nested = nestedName
    ? nestedStoreRoots(root, nestedName).map((p) => relativePath(root, p))
    : []
  const files = []
  const skipped = new Set()
  let capped = false
  for (const raw of listed) {
    const rel = String(raw).split(path.sep).join('/')
    if (!rel) continue
    const segs = rel.split('/')
    // 与 walkDir 同一口径：隐藏路径（任一段以 `.` 开头）与内置忽略名单都不进语料。
    // 两份清单必须一致，否则同一棵树在 `git init` 前后索引内容会变；隐藏路径默认是
    // 配置/状态/密钥（`.env`、`.ssh`），非 git 目录没有"被跟踪=作者同意"这层信号。
    // 真要索引某个隐藏文件，走显式 `index_doc`（它不受扫描清单限制）。
    if (segs.some((s) => s.startsWith('.'))) continue
    // 与 walkDir 同口径：`DEFAULT_IGNORE` 只作用于**目录段**，根目录下一个叫 `build`
    // 的普通文件仍然要收（此前对文件名也判，`git init` 前后语料会变）。
    if (segs.slice(0, -1).some((s) => DEFAULT_IGNORE.has(s))) continue
    const abs = path.join(root, rel)
    // 与 walkDir 同一判据：exclude 是子树级前缀。必须在 maxDepth 之前——被排除文件不该把
    // 扫描标成 truncated（否则本轮不清理"未见到的旧条目"）。
    if (policy && excludedEntryForAbs(abs, policy)) continue
    // 文件的“目录深度”是 segs.length - 1；walkDir 的 maxDepth 也按目录层数计，
    // 此前用 segs.length 会让 git 分支少收浅一层，并在同一棵树上报不同的 capped。
    if (segs.length - 1 > maxDepth) {
      capped = true
      continue
    }
    const under = nested.find((n) => rel === n || rel.startsWith(`${n}/`))
    if (under) {
      skipped.add(path.join(root, under))
      continue
    }
    if (files.length >= maxFiles) {
      capped = true
      break
    }
    try {
      if (!statSync(abs).isFile()) continue
    } catch {
      continue
    }
    files.push(abs)
  }
  files.sort()
  return { files, truncated: capped, capped, skipped: [...skipped].sort(), unreadable: [] }
}

/** 单个文件是否被 git 忽略（仅 git 仓库；非 git 目录返回 false）。 */
export function isGitIgnored(root, filePath) {
  if (!root || !filePath || !existsSync(path.join(root, '.git'))) return false
  try {
    execFileSync('git', ['-C', root, 'check-ignore', '-q', '--', relativePath(root, filePath)], {
      stdio: 'ignore',
      windowsHide: true,
    })
    return true
  } catch {
    return false
  }
}

/**
 * 批量版 `isGitIgnored`：一次 `git check-ignore --stdin` 判定一批相对路径。
 * 逐个判定的成本几乎全在**起进程**上（9p 实测 30ms/次、ext4 2.7ms/次，Windows 上更高），
 * 一次懒索引 flush 里往往十几个文件，必须并成一次。
 *
 * @param {string} root 项目根
 * @param {string[]} rels 项目相对路径（`relativePath()` 的形状，`/` 分隔）
 * @returns {Set<string>} 被忽略的那些 rel（原样返回，便于与调用方的 rel 对齐）
 */
export function isGitIgnoredBatch(root, rels) {
  const ignored = new Set()
  if (!root || !rels || rels.length === 0) return ignored
  if (!existsSync(path.join(root, '.git'))) return ignored
  if (rels.length === 1) {
    if (isGitIgnored(root, path.join(root, rels[0]))) ignored.add(rels[0])
    return ignored
  }
  try {
    // `-z` 让输入输出都以 NUL 分隔：文件名里带换行/空格也不会错位。
    const out = execFileSync('git', ['-C', root, 'check-ignore', '--stdin', '-z'], {
      input: rels.join('\0') + '\0',
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'ignore'],
      maxBuffer: 16 * 1024 * 1024,
    })
    for (const p of String(out).split('\0')) if (p) ignored.add(p)
    return ignored
  } catch (err) {
    // status 1 = 正常：一条都没被忽略（check-ignore 用退出码表达"有/没有"）。
    if (err?.status === 1) return ignored
    // 其它失败（老 git 不支持 --stdin、输入过长、非仓目录）：退回逐条判定，语义不变，只是慢。
    for (const rel of rels) if (isGitIgnored(root, path.join(root, rel))) ignored.add(rel)
    return ignored
  }
}

export function isSupportedDoc(ext) {
  return ['.pdf', '.md', '.markdown', '.txt'].includes(ext)
}

const DUMP_REFLECTION = /(?:==\s*TYPE\s|\bVersion=\d+\.\d+\.\d+\.\d+|loaded:\s*\S+,\s*Version=)/

export function looksLikeDump(text, maxBytes = 4096) {
  if (!text) return false
  const head = String(text).slice(0, maxBytes)
  if (!/^(\uFEFF)?\s*={3,}/.test(head)) return false
  return DUMP_REFLECTION.test(head)
}

export function isSupportedCode(ext) {
  return [
    '.js', '.mjs', '.cjs', '.ts', '.mts', '.cts', '.jsx', '.tsx', '.py', '.java', '.go',
    '.rs', '.c', '.cpp', '.cc', '.h', '.hpp', '.cs', '.php', '.rb',
    '.swift', '.kt', '.kts', '.sh', '.zsh',
  ].includes(ext)
}

export function relativePath(root, filePath) {
  return path.relative(root, filePath).split(path.sep).join('/')
}

/**
 * 路径里是否有以 `.` 开头的段（与扫描口径一致）：隐藏路径默认是配置/状态/密钥，
 * 不进入自动索引面（显式 `index_doc` 仍可索引）。按 `/` 切分后逐段判断，
 * 因此 `.env`、`.github/x.md`、`src/.cache/y.js` 都算隐藏。
 * @param {string} relOrAbs 项目相对或绝对路径
 * @returns {boolean}
 */
export function isHiddenPath(relOrAbs) {
  return String(relOrAbs || '').split(/[\\/]/).some((seg) => seg.startsWith('.'))
}

/**
 * `insight.files` 的写入期归一：schema 承诺「项目相对路径」，不校验就会让项目外绝对路径原样落盘。
 * 规则：反斜杠 → `/`、去掉 `./`、去重；项目内绝对路径转相对；其余（项目外绝对、
 * `..` 逃出根、无根时无法判定）**丢弃**并回报，调用方负责把丢弃数量说出来。
 * @param {unknown} files - 原始 files（工具参数 / 编辑表单）。
 * @param {string} root - 目标项目根（`save_lesson` 的 root 参数即权威）。
 * @returns {{files: string[], dropped: string[]}} 归一后的相对路径，以及被丢弃的原值。
 */
export function normalizeCitationFiles(files, root) {
  const kept = []
  const dropped = []
  const base = typeof root === 'string' && root.trim() ? path.resolve(root) : null
  for (const raw of Array.isArray(files) ? files : []) {
    if (typeof raw !== 'string') continue
    const value = raw.trim().replace(/\\/g, '/')
    if (!value) continue
    const looksAbsolute = value.startsWith('/') || /^[A-Za-z]:\//.test(value)
    // Windows 盘符路径在 POSIX 上 `path.isAbsolute()` 是 false：不能把它当项目内相对路径
    // 落成 `C:/...`（那会生成一个永远不存在的引用）。真正的 POSIX 绝对路径仍走下面的
    // base/relative 判定，项目外的照常丢弃。
    if (looksAbsolute && !path.isAbsolute(value)) {
      dropped.push(raw)
      continue
    }
    if (base === null && looksAbsolute) {
      dropped.push(raw)
      continue
    }
    const abs = base === null ? null : path.resolve(base, looksAbsolute ? value : value.replace(/^\.\//, ''))
    let rel = value.replace(/^\.\//, '')
    if (abs !== null) {
      const inside = path.relative(base, abs)
      if (inside === '' || inside === '..' || inside.startsWith(`..${path.sep}`) || path.isAbsolute(inside)) {
        dropped.push(raw)
        continue
      }
      rel = inside.split(path.sep).join('/')
    }
    if (!rel || rel === '..' || rel.startsWith('../')) {
      dropped.push(raw)
      continue
    }
    if (!kept.includes(rel)) kept.push(rel)
  }
  return { files: kept, dropped }
}

export const CASE_INSENSITIVE_FS = process.platform === 'win32' || process.platform === 'darwin'

export function storeKey(rel, platform = process.platform) {
  return platform === 'win32' || platform === 'darwin' ? rel.toLowerCase() : rel
}

/** store 目录名（配置项 `memoryDir`；调用方可能来自工具参数，缺省时兜底成默认值）。 */
export const DEFAULT_MEMORY_DIR = '.dsh-project-memory'

/** 已经告过警的 `memoryDir` 值：同一个坏值在进程里只吵一次。 */
const warnedMemoryDir = new Set()

function defaultMemoryDirWarning(value) {
  if (warnedMemoryDir.has(value)) return
  warnedMemoryDir.add(value)
  console.warn(
    `[dsh-project-memory] memoryDir ${JSON.stringify(value)} must stay inside the project root; `
    + `using ${DEFAULT_MEMORY_DIR} instead.`,
  )
}

/**
 * `memoryDir` → 真正使用的目录名（读写两侧唯一的归一入口）。
 *
 * 合法值 = **项目根内的一段相对路径**。会让 store 落到根外、或落到根上（`save()` 的自我忽略
 * 随后把整个仓库从 git 视角隐藏）的形态一律回落到默认目录并告警一次：空/空白、`.`、`..`、
 * 含 `..` 段（`a/../b`）、绝对路径（POSIX `/x`、Windows `C:\\x`）。嵌套目录（`a/b`）仍允许——
 * 它仍在根内。空串的兜底在这里收口，`memoryRootFor()` 与 `memoryDirName()` 不再各写一遍。
 */
export function safeMemoryDirName(raw, warn = defaultMemoryDirWarning) {
  const value = typeof raw === 'string' ? raw.trim() : ''
  if (!value) return DEFAULT_MEMORY_DIR
  if (
    value === '.' || value === '..'
    || path.isAbsolute(value)
    || WINDOWS_ABSOLUTE_PATH.test(value)
    || value.split(/[\\/]+/).includes('..')
  ) {
    warn(value)
    return DEFAULT_MEMORY_DIR
  }
  return value
}

/**
 * 项目根 → store 目录。
 *
 * 空串/空白必须回落到默认目录：`path.join(root, '')` 等于项目根本身，而 `save()` 的自我忽略
 * 会在那里写一个内容为 `*` 的 `.gitignore`（把整个仓库从 git 的视角隐藏），`format.json` /
 * `shards/` 也会污染源码树。`.`, `..` 与绝对路径同理。
 */
export function memoryRootFor(indexRoot, memoryDir) {
  return path.join(indexRoot, safeMemoryDirName(memoryDir))
}

export function memoryDirName(config) {
  return safeMemoryDirName(config?.memoryDir)
}

/**
 * 危险根目录：整体扫描/监听它们会直接吃满内存（家目录、`/opt/homebrew`）。判定是**精确匹配**：
 * 只拒绝这些目录**本身**，子目录照常可用（`~/Library` 拒绝，`~/Library/…/MyProj` 可用）。
 * 四类：文件系统根（含 Windows 盘符根）；家目录及所有祖先 + 系统型子目录；每用户私有与共享/
 * 系统临时目录（macOS 的 os.tmpdir() 与共享 /tmp 是两个路径）；系统/包管理器前缀（按平台分组）。
 */
function safeHomedir() {
  try {
    return os.homedir()
  } catch {
    return null
  }
}

/**
 * POSIX 的**共享/系统**临时目录。刻意与 `os.tmpdir()` 分开：macOS 上它是 `/var/folders/…/T`
 * 这个每用户私有目录，共享的 `/tmp`（→ `/private/tmp`）根本不在名单里。
 */
const POSIX_SHARED_TEMP = ['/tmp', '/var/tmp', '/private/tmp', '/private/var/tmp', '/var/folders', '/dev/shm']

/**
 * 危险根集合（判定用，`isUnsafeRoot` 的底座）。参数化是为了能在任意平台验证各平台分支
 * （测试用 `path.win32` 模拟 Windows）；生产路径只调用无参形式。系统前缀按平台分组：
 * `C:\opt`、`C:\usr` 在 Windows 上是正常用户目录，跨平台套用会误伤。
 * @returns {{ unsafe: Set<string>, sharedTemp: Set<string> }} `sharedTemp` 单独返回，只为让拒绝
 *   文案能说清"是共享临时目录"；两套集合由同一次调用产出，不会漂移。
 */
export function collectUnsafeRootSets({
  platform = process.platform,
  home = safeHomedir(),
  tmp = os.tmpdir(),
  env = process.env,
  pathApi = path,
} = {}) {
  const set = new Set()
  const sharedTemp = new Set()
  const push = (target) => (p) => {
    if (!p || typeof p !== 'string') return
    let abs
    try {
      abs = pathApi.resolve(p)
    } catch {
      return
    }
    target.add(storeKey(abs, platform))
  }
  const add = push(set)
  const addTemp = push(sharedTemp)

  // 每用户私有临时目录 + 共享/系统临时目录，都算"共享临时目录"（拒绝文案上同类）。
  addTemp(tmp)
  if (platform === 'win32') {
    addTemp(env.TEMP)
    addTemp(env.TMP)
    if (env.SystemRoot) addTemp(pathApi.join(env.SystemRoot, 'Temp'))
    if (env.windir) addTemp(pathApi.join(env.windir, 'Temp'))
  } else {
    for (const p of POSIX_SHARED_TEMP) addTemp(p)
  }
  for (const key of sharedTemp) set.add(key)

  let homeAbs = null
  try {
    homeAbs = home ? pathApi.resolve(home) : null
  } catch {
    homeAbs = null
  }
  if (homeAbs) {
    // 家目录 + 它的所有祖先：往上任何一级当根都会把整台机器扫进来。
    let dir = homeAbs
    for (;;) {
      add(dir)
      const parent = pathApi.dirname(dir)
      if (parent === dir) break
      dir = parent
    }
    for (const sub of platform === 'win32' ? ['AppData', 'Application Data'] : ['Library', 'Applications', '.Trash']) {
      add(pathApi.join(homeAbs, sub))
    }
  }

  if (platform === 'win32') {
    for (const name of ['SystemRoot', 'windir', 'ProgramFiles', 'ProgramFiles(x86)', 'ProgramData']) {
      add(env[name])
    }
  } else {
    // POSIX 系统前缀 + 工具链前缀。ARM Mac 的 Homebrew 是 git clone 到 `/opt/homebrew` 的，
    // 那里**有 `.git`**，单靠"只认项目标记"仍会把整个 Homebrew 判成项目根。
    for (const p of [
      '/usr', '/usr/local', '/usr/local/Homebrew', '/usr/local/Cellar',
      '/opt', '/opt/homebrew', '/opt/local',
      '/etc', '/var', '/bin', '/sbin', '/dev', '/proc', '/sys', '/run',
      '/System', '/Library', '/Applications', '/private', '/cores',
      '/home/linuxbrew', '/home/linuxbrew/.linuxbrew', '/nix',
    ]) {
      add(p)
    }
  }
  return { unsafe: set, sharedTemp }
}

/** 兼容入口：只要判定集合。 */
export function collectUnsafeRoots(opts) {
  return collectUnsafeRootSets(opts).unsafe
}

const UNSAFE = collectUnsafeRootSets()
const UNSAFE_DIRS = UNSAFE.unsafe
const SHARED_TEMP_DIRS = UNSAFE.sharedTemp

// ---------------------------------------------------------------------------
// 用户可配置的根名单（`roots.allow` / `roots.deny` / `roots.exclude`）。三个字段口径不同：
//   - allow / deny：**精确匹配**，只针对目录本身（`/srv/shared` 不拒 `/srv/shared/myproj`）；
//   - exclude：**路径边界前缀匹配**，整棵子树不进索引，也不能在子树里推出新根。
// 优先级：exclude > deny > allow > 内置名单（allowUnsafeRoots 只放开内置名单）；文件系统根永不为根。
// ---------------------------------------------------------------------------

const ROOT_POLICY_FIELDS = ['allow', 'deny', 'exclude']

/** 每条告警只打一次：配置在进程内是静态的，重复刷屏没有信息量。 */
const warnedRootPolicyEntries = new Set()

function warnRootPolicyOnce(key, message, warn) {
  if (warnedRootPolicyEntries.has(key)) return
  warnedRootPolicyEntries.add(key)
  const log = typeof warn === 'function' ? warn : console.error
  log(`[dsh-project-memory] ${message}`)
}

function expandHomeEntry(value, home, pathApi) {
  if (value === '~') return home
  if (value.startsWith('~/') || value.startsWith('~\\')) {
    return home ? pathApi.resolve(home, value.slice(2)) : null
  }
  return value
}

function normalizeRootPolicyEntries(list, field, { platform, pathApi, home, warn }) {
  const out = []
  if (list === undefined || list === null) return out
  if (!Array.isArray(list)) {
    warnRootPolicyOnce(
      `shape:${field}`,
      `config.roots.${field} must be an array of absolute paths; ignoring it.`,
      warn,
    )
    return out
  }
  for (const raw of list) {
    if (typeof raw !== 'string') {
      warnRootPolicyOnce(
        `type:${field}:${typeof raw}`,
        `config.roots.${field} contains a non-string entry; ignoring it (only absolute path strings are accepted).`,
        warn,
      )
      continue
    }
    const value = raw.trim()
    if (!value) continue
    const expanded = expandHomeEntry(value, home, pathApi)
    if (expanded === null) {
      warnRootPolicyOnce(
        `home:${field}:${value}`,
        `config.roots.${field} entry ${JSON.stringify(value)} cannot be expanded: the home directory is unavailable.`,
        warn,
      )
      continue
    }
    if (!pathApi.isAbsolute(expanded)) {
      warnRootPolicyOnce(
        `relative:${field}:${value}`,
        `config.roots.${field} entry ignored (not an absolute path): ${JSON.stringify(value)}. ` +
          'Relative paths would be resolved against the host cwd and are unpredictable; use an absolute path or ~/...',
        warn,
      )
      continue
    }
    let abs
    try {
      abs = pathApi.resolve(expanded)
    } catch {
      warnRootPolicyOnce(
        `resolve:${field}:${value}`,
        `config.roots.${field} entry ignored (cannot be resolved): ${JSON.stringify(value)}.`,
        warn,
      )
      continue
    }
    out.push({ abs, key: storeKey(abs, platform), raw: value })
  }
  return out
}

function isCompiledRootPolicy(value) {
  return Boolean(value && typeof value === 'object' && value.__rootPolicy === true)
}

/**
 * 把插件 config 编译成一份可复用的根判定策略。参数化（platform / pathApi / home / env）
 * 是为了在任意平台验证 Windows 语义，与 `collectUnsafeRootSets()` 一致；生产路径只用无参形式。
 * @param {object} [config] 插件 config（只读 `config.roots` 与 `config.allowUnsafeRoots`）
 * @param {{platform?: string, pathApi?: object, home?: string|null, env?: object, warn?: Function,
 *   allowUnsafe?: boolean, unsafeDirs?: Set<string>, sharedTemp?: Set<string>}} [opts]
 * @returns {object} 策略对象（内部结构，调用方应通过 rootRejection/isUnsafeRoot/isExcludedPath 使用）
 */
export function compileRootPolicy(config, opts = {}) {
  const platform = opts.platform || process.platform
  const pathApi = opts.pathApi || path
  const home = Object.prototype.hasOwnProperty.call(opts, 'home') ? opts.home : safeHomedir()
  const warn = opts.warn
  const rawRoots = config && typeof config === 'object' ? config.roots : undefined
  const roots = rawRoots && typeof rawRoots === 'object' && !Array.isArray(rawRoots) ? rawRoots : {}
  if (rawRoots !== undefined && (typeof rawRoots !== 'object' || rawRoots === null || Array.isArray(rawRoots))) {
    warnRootPolicyOnce(
      'shape:roots',
      'config.roots must be an object with `allow` / `deny` / `exclude` arrays; ignoring it.',
      warn,
    )
  }

  const entries = {}
  for (const field of ROOT_POLICY_FIELDS) {
    entries[field] = normalizeRootPolicyEntries(roots[field], field, { platform, pathApi, home, warn })
  }

  let builtin = opts.unsafeDirs || null
  let sharedTemp = opts.sharedTemp || null
  if (!builtin || !sharedTemp) {
    // 只有完全没传模拟参数时才复用模块级集合；显式给了 platform/pathApi/home/tmp/env 任一个
    // 就按参数重算，否则模拟结果会悄悄沿用当前机器那份名单。
    const simulated = ['platform', 'pathApi', 'home', 'tmp', 'env'].some((key) =>
      Object.prototype.hasOwnProperty.call(opts, key),
    )
    if (!simulated && platform === process.platform) {
      builtin = builtin || UNSAFE_DIRS
      sharedTemp = sharedTemp || SHARED_TEMP_DIRS
    } else {
      const sets = collectUnsafeRootSets({
        platform,
        home,
        tmp: Object.prototype.hasOwnProperty.call(opts, 'tmp') ? opts.tmp : os.tmpdir(),
        env: opts.env || process.env,
        pathApi,
      })
      builtin = builtin || sets.unsafe
      sharedTemp = sharedTemp || sets.sharedTemp
    }
  }

  const allowEntries = new Map(entries.allow.map((e) => [e.key, e.raw]))
  const denyEntries = new Map(entries.deny.map((e) => [e.key, e.raw]))
  return {
    __rootPolicy: true,
    platform,
    pathApi,
    home,
    allowUnsafeRoots: config?.allowUnsafeRoots === true || opts.allowUnsafe === true,
    allow: new Set(allowEntries.keys()),
    deny: new Set(denyEntries.keys()),
    exclude: entries.exclude,
    allowEntries,
    denyEntries,
    builtin,
    sharedTemp,
  }
}

function policyFor(configOrPolicy, opts) {
  if (isCompiledRootPolicy(configOrPolicy)) return configOrPolicy
  return compileRootPolicy(configOrPolicy, opts)
}

/** `parent` 是否等于 `child` 或它的祖先（按路径分隔符，含子树）。 */
function isInsideKey(parentKey, childKey, sep) {
  if (parentKey === childKey) return true
  const prefix = parentKey.endsWith(sep) ? parentKey : `${parentKey}${sep}`
  return childKey.startsWith(prefix)
}

function excludedEntryForAbs(abs, policy) {
  if (!policy.exclude.length) return null
  let absResolved
  try {
    absResolved = policy.pathApi.resolve(abs)
  } catch {
    return null
  }
  const key = storeKey(absResolved, policy.platform)
  for (const entry of policy.exclude) {
    if (isInsideKey(entry.key, key, policy.pathApi.sep)) return entry
  }
  return null
}

/**
 * 某个文件/目录是否落在 `roots.exclude` 的子树里。
 * @returns {{abs: string, key: string, raw: string}|null} 命中的条目（用于报告），否则 null
 */
export function excludedEntryForPath(filePath, configOrPolicy, opts) {
  if (typeof filePath !== 'string' || !filePath) return null
  const policy = policyFor(configOrPolicy, opts)
  let abs
  try {
    abs = policy.pathApi.resolve(filePath)
  } catch {
    return null
  }
  return excludedEntryForAbs(abs, policy)
}

/** 文案用的「为什么是它」。 */
function unsafeReason(abs, policy = {}) {
  const platform = policy.platform || process.platform
  const pathApi = policy.pathApi || path
  const key = storeKey(abs, platform)
  const parsed = pathApi.parse(abs)
  if (key === storeKey(parsed.root, platform)) return 'the filesystem root'
  if (policy.home) {
    try {
      if (key === storeKey(pathApi.resolve(policy.home), platform)) return 'your home directory'
    } catch {
      // 家目录不可解析：继续按临时/系统目录归类
    }
  } else {
    try {
      if (key === storeKey(path.resolve(os.homedir()), platform)) return 'your home directory'
    } catch {
      // 同上
    }
  }
  const shared = policy.sharedTemp || SHARED_TEMP_DIRS
  if (shared.has(key)) return 'the shared temp directory'
  return 'a system directory that is never a project root'
}

/**
 * 根判定的**唯一实现**：返回 null（可用）或一条命中记录（`kind`/`field`/`entry`/`reason`），
 * 调用方据此生成"是哪条命中的、该改哪个字段"的拒绝文案。
 * 优先级：exclude → deny → 内置（allow 与 allowUnsafeRoots 只作用于内置名单）→ 文件系统根永远拒绝。
 * @param {string} root 候选根
 * @param {object} [configOrPolicy] 插件 config，或 `compileRootPolicy()` 的返回值
 */
export function rootRejection(root, configOrPolicy, opts) {
  const policy = policyFor(configOrPolicy, opts)
  if (typeof root !== 'string' || !root) {
    return { kind: 'invalid', field: null, entry: null, reason: 'not a usable directory path' }
  }
  let abs
  try {
    abs = policy.pathApi.resolve(root)
  } catch {
    return { kind: 'invalid', field: null, entry: null, reason: 'not a usable directory path' }
  }
  const platform = policy.platform
  const key = storeKey(abs, platform)
  const parsed = policy.pathApi.parse(abs)
  if (!parsed.dir || key === storeKey(parsed.root, platform)) {
    return { kind: 'filesystem-root', abs, field: null, entry: null, reason: 'the filesystem root' }
  }
  const excluded = excludedEntryForAbs(abs, policy)
  if (excluded) {
    return {
      kind: 'exclude',
      abs,
      field: 'roots.exclude',
      entry: excluded.raw,
      reason: `inside the subtree excluded by ${JSON.stringify(excluded.raw)}`,
    }
  }
  if (policy.deny.has(key)) {
    return {
      kind: 'deny',
      abs,
      field: 'roots.deny',
      entry: policy.denyEntries.get(key) || null,
      reason: 'listed in roots.deny',
    }
  }
  if (policy.builtin.has(key) && !policy.allowUnsafeRoots && !policy.allow.has(key)) {
    return { kind: 'builtin', abs, field: 'roots.allow', entry: null, reason: unsafeReason(abs, policy) }
  }
  return null
}

/** 这个目录能否当项目记忆根？纯判定，无副作用。 */
export function isUnsafeRoot(root, configOrPolicy, opts) {
  return rootRejection(root, configOrPolicy, opts) !== null
}

const CONFIG_LOCATION = 'under `- id: project-memory` → `config:`'

/** 把命中记录变成一句可执行的拒绝文案。 */
function rootRejectionMessage(target, rejection) {
  const head = `Refusing to use ${target} as a project memory root: `
  switch (rejection.kind) {
    case 'filesystem-root':
      return (
        head +
        'it is the filesystem root. That can never be a project memory root; pass a project directory instead.'
      )
    case 'exclude':
      return (
        head +
        `it is inside the subtree excluded by \`roots.exclude\` entry ${JSON.stringify(rejection.entry)}. ` +
        `Remove that entry from \`config.roots.exclude\` ${CONFIG_LOCATION} if this directory should be a root.`
      )
    case 'deny':
      return (
        head +
        `it is listed in \`roots.deny\`${rejection.entry ? ` as ${JSON.stringify(rejection.entry)}` : ''}. ` +
        `Remove that entry from \`config.roots.deny\` ${CONFIG_LOCATION} to allow it.`
      )
    case 'builtin':
      return (
        head +
        `it is ${rejection.reason}, a built-in protected root. Indexing or watching it would walk the whole ` +
        'directory tree (hundreds of thousands of files) and exhaust memory. Pass a project directory instead, ' +
        `or add this exact directory to \`config.roots.allow\` ${CONFIG_LOCATION} if you really mean it ` +
        '(or set `allowUnsafeRoots: true` to allow every built-in protected directory).'
      )
    default:
      return head + `${rejection.reason}. Pass an absolute project directory instead.`
  }
}

export class UnsafeRootError extends Error {
  constructor(root, requested, options = {}) {
    const target = requested && String(requested).trim() ? String(requested) : String(root)
    const rejection = options.rejection || rootRejection(root, options.config)
    super(rootRejectionMessage(target, rejection))
    this.name = 'UnsafeRootError'
    this.root = root
    this.code = rejection.kind
    this.kind = rejection.kind
    this.reason = rejection.reason
    this.field = rejection.field
    this.entry = rejection.entry
  }
}

/**
 * 校验「这个根可以当项目记忆根」：所有把目录当根写盘的入口都必须先过这一关（写盘前拒绝）。
 * `allowUnsafe` 是旧的内部兼容参数，等同 `allowUnsafeRoots: true`——只放开内置名单，
 * 绝不会越过 `roots.deny` / `roots.exclude`。
 */
export function assertSafeRoot(root, { requested = root, allowUnsafe = false, config } = {}) {
  const policy = isCompiledRootPolicy(config)
    ? (allowUnsafe && !config.allowUnsafeRoots ? { ...config, allowUnsafeRoots: true } : config)
    : compileRootPolicy(config, { allowUnsafe })
  const rejection = rootRejection(root, policy)
  if (!rejection) return root
  throw new UnsafeRootError(root, requested, { rejection })
}

/**
 * 解析「当前工作目录」：显式 root 优先，但**相对路径按会话工作目录解析**，而不是宿主的
 * `process.cwd()`——web profile 里一个进程会服务多个会话，cd 之后两者的 cwd 不是一回事。
 * 没有显式 root 时返回会话工作目录本身；会话信息缺失（测试 / 老宿主）才退回进程 cwd。
 * @param {object|null} exec 宿主工具执行上下文（`exec.agent.session`）
 * @param {string|null} [explicitRoot] 工具参数里的 root，可为绝对或相对路径
 * @returns {string} 绝对路径
 */
export function resolveIndexRoot(exec, explicitRoot) {
  // 会话当前工作目录：0.2.1+ 读 workingDirectory 投影（cd 后会变），老宿主回退 header.cwd。
  const sessionCwd = sessionWorkingDir(exec?.agent?.session, { agent: exec?.agent })
  const base = sessionCwd ? path.resolve(sessionCwd) : path.resolve(process.cwd())
  if (explicitRoot && String(explicitRoot).trim()) return path.resolve(base, String(explicitRoot))
  return base
}

// ---------------------------------------------------------------------------
// 项目根推导 —— 全插件唯一的策略实现。顺序（前两者"声明"，后两者"推定"）：
//   1. 显式传入的 root；2. 显式登记过的根（watch_repo / watchManager）；
//   3. 最近的含 VCS 或构建/清单标记的祖先；4. 会话工作目录本身 —— 只要它是安全目录。
// 都没有 → null（该文件不落任何记忆）。cwd 是人选择的工作位置；兜底 dirname(file) 会把家目录锁成项目（#5）。
// ---------------------------------------------------------------------------

/** VCS 边界：最强的项目根信号（`.git` 在 worktree 里是文件，existsSync 同样命中）。 */
export const VCS_MARKERS = ['.git', '.hg', '.svn']

/**
 * 构建/清单标记。**刻意不含 `.dsh-project-memory`**：那是插件自己创建的，算作标记会自我固化——
 * 在会话 cwd 建出它之后，读该目录下任意文件都会把根解析回该目录。
 */
export const PROJECT_MARKERS = [
  'package.json', 'tsconfig.json', 'deno.json', 'deno.jsonc',
  'go.mod', 'Cargo.toml', 'pyproject.toml', 'requirements.txt', 'setup.py',
  'pom.xml', 'build.gradle', 'build.gradle.kts', 'settings.gradle', 'settings.gradle.kts',
  'CMakeLists.txt', 'Makefile', 'composer.json', 'Gemfile', 'mix.exs', 'Package.swift',
]

/** 探针文件名：findProjectRoot 期望文件路径，用目录内的探针路径问"这个目录的根是谁"。 */
export const PROJECT_PROBE = '__dsh-project-memory__.probe'

/** 该目录**自身**是否带项目标记（不向上找）。用于判断根是"声明的"还是"推定的"。 */
export function hasProjectMarker(dir) {
  if (typeof dir !== 'string' || !dir) return false
  let abs
  try {
    abs = path.resolve(dir)
  } catch {
    return false
  }
  for (const marker of VCS_MARKERS) if (existsSync(path.join(abs, marker))) return true
  for (const marker of PROJECT_MARKERS) if (existsSync(path.join(abs, marker))) return true
  return false
}

function isInside(parent, child) {
  const rel = path.relative(parent, child)
  return rel === '' || (rel !== '..' && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel))
}

/** 显式登记的根里，包含该文件的**最深**那一个（最长前缀匹配）。 */
function longestRootContaining(roots, absPath) {
  let best = null
  for (const root of roots) {
    if (typeof root !== 'string' || !root) continue
    let resolved
    try {
      resolved = path.resolve(root)
    } catch {
      continue
    }
    if (!isInside(resolved, absPath)) continue
    if (!best || resolved.length > best.length) best = resolved
  }
  return best
}

function resolveDir(dir) {
  try {
    return path.resolve(dir)
  } catch {
    return null
  }
}

/**
 * 根来源：显式登记的根 / VCS 标记 / 项目标记 / 会话工作目录兜底。
 * 调用方（懒索引的根缓存）据此区分"看到的标记"与"还没有标记时的推断"——只有前者能缓存。
 */
export const ROOT_SOURCES = Object.freeze({
  EXTRA: 'extra',
  VCS: 'vcs',
  PROJECT: 'project',
  SESSION: 'session',
})

/**
 * 自底向上找最近的根标记。**一次遍历同时看 VCS 与 PROJECT**，语义仍是 VCS 优先：
 * 先命中的 VCS 直接返回（它一定最深的）；没有 VCS 就返回最深的 PROJECT。每层只 readdir
 * 一次（两组标记各走一遍祖先链、每个 marker 一次 existsSync 在 WSL/NTFS 上实测 ~119ms/次）。
 * @returns {{dir: string, source: 'vcs'|'project'}|null}
 */
function nearestRootByMarkers(absPath, vcsMarkers, projectMarkers, isUnsafe) {
  let project = null
  let dir = path.dirname(absPath)
  for (;;) {
    // 撞到危险根边界就停：不把边界当根，也不再向上。已记录的 PROJECT 命中仍有效（在边界下方）。
    if (isUnsafe(dir)) return project ? { dir: project, source: ROOT_SOURCES.PROJECT } : null
    let names = null
    try {
      names = new Set(readdirSync(dir))
    } catch {
      names = null
    }
    if (names) {
      if (vcsMarkers.some((marker) => names.has(marker))) return { dir, source: ROOT_SOURCES.VCS }
      if (!project && projectMarkers.some((marker) => names.has(marker))) project = dir
    }
    const parent = path.dirname(dir)
    if (parent === dir) return project ? { dir: project, source: ROOT_SOURCES.PROJECT } : null
    dir = parent
  }
}

/**
 * 项目根推导（**只认标记与显式声明，绝不从文件路径兜底**）。`roots.exclude` 是最强的否定：
 * 文件落在被排除子树里 → 直接 null，不再向上找标记，也不退回会话工作目录。
 *
 * 比 `findProjectRoot` 多返回 `source`：调用方需要区分"看到的标记"和"没有标记时的会话目录兜底"，
 * 二者不能同等缓存（见 `src/lazy.js` 的根缓存：兜底是"这一带还没有标记"的推断，项目可能刚建出来）。
 *
 * @param {string} filePath 目标文件（也接受目录内探针文件路径）
 * @param {{ extraRoots?: Iterable<string>, sessionRoot?: string|null, isUnsafe?: (dir: string) => boolean,
 *   config?: object, policy?: object }} [opts] `extraRoots` 显式登记的根；`sessionRoot` 作为**最后**一级推定。
 * @returns {{root: string|null, source: 'extra'|'vcs'|'project'|'session'|null}}
 */
export function findProjectRootWithSource(filePath, opts = {}) {
  if (typeof filePath !== 'string' || !filePath) return { root: null, source: null }
  const policy = isCompiledRootPolicy(opts.policy)
    ? opts.policy
    : isCompiledRootPolicy(opts.config)
      ? opts.config
      : compileRootPolicy(opts.config, { allowUnsafe: opts.allowUnsafe === true })
  const isUnsafe = typeof opts.isUnsafe === 'function'
    ? opts.isUnsafe
    : (dir) => rootRejection(dir, policy) !== null
  let abs
  try {
    abs = path.resolve(filePath)
  } catch {
    return { root: null, source: null }
  }
  if (excludedEntryForAbs(abs, policy)) return { root: null, source: null }
  const explicit = longestRootContaining(opts.extraRoots || [], abs)
  if (explicit) {
    return isUnsafe(explicit) ? { root: null, source: null } : { root: explicit, source: ROOT_SOURCES.EXTRA }
  }

  // 标记优先于会话根兜底；VCS 优先于 PROJECT（"a marker above the cwd still wins" 是既有契约）。
  const byMarker = nearestRootByMarkers(abs, VCS_MARKERS, PROJECT_MARKERS, isUnsafe)
  if (byMarker) return { root: byMarker.dir, source: byMarker.source }

  const session = resolveDir(opts.sessionRoot)
  if (session && !isUnsafe(session) && isInside(session, abs)) return { root: session, source: ROOT_SOURCES.SESSION }
  return { root: null, source: null }
}

/**
 * 项目根推导：只要根，语义与 `findProjectRootWithSource` 完全一致。
 * @param {string} filePath 目标文件（也接受目录内探针文件路径）
 * @param {{ extraRoots?: Iterable<string>, sessionRoot?: string|null, isUnsafe?: (dir: string) => boolean,
 *   config?: object, policy?: object }} [opts]
 * @returns {string|null}
 */
export function findProjectRoot(filePath, opts = {}) {
  return findProjectRootWithSource(filePath, opts).root
}

/**
 * **会话记忆根**：声明优先（标记）→ 会话工作目录（安全时）→ null（家目录/系统目录且无标记）。
 * `config` 里的 `roots.*` 与 `allowUnsafeRoots` 与工具侧共用同一套判定。
 */
export function resolveProjectMemoryRoot(cwd, config) {
  const base = resolveDir(cwd) || resolveDir(process.cwd())
  if (!base) return null
  return findProjectRoot(path.join(base, PROJECT_PROBE), { sessionRoot: base, config })
}

/**
 * 工具侧的根解析：显式 root 优先（并校验安全），否则取会话记忆根；都拿不到抛 `UnsafeRootError`。
 */
export function resolveSafeIndexRoot(exec, explicitRoot, config) {
  const allowUnsafe = config?.allowUnsafeRoots === true
  const explicit = explicitRoot && String(explicitRoot).trim() ? String(explicitRoot) : null
  // 显式 root 也走 resolveIndexRoot：相对路径必须按**会话**工作目录解析（见该函数注释）。
  const cwd = resolveIndexRoot(exec, explicit)
  if (explicit) {
    return assertSafeRoot(cwd, { requested: explicit, allowUnsafe, config })
  }
  const root = resolveProjectMemoryRoot(cwd, config)
  if (root) return root
  // allowUnsafeRoots 只放开内置名单；cwd 被 deny / exclude / 文件系统根命中时仍然拒绝。
  if (allowUnsafe && !rootRejection(cwd, config)) return cwd
  throw new UnsafeRootError(cwd, cwd, { config })
}

/** 尽力而为的会话记忆根：拿不到就返回 null（用于审计镜像这类旁路，不抛错）。 */
export function sessionMemoryRootOrNull(exec, config) {
  try {
    return resolveSafeIndexRoot(exec, null, config)
  } catch {
    return null
  }
}