# Release checklist / 发布前检查清单

Run from the repository root on Windows (Node 24) unless noted.

在仓库根目录执行（Windows、Node 24）。

Target version / 目标版本：**v0.8.7**。

## 1. Pre-flight / 预检

```powershell
npm run check                      # build + syntax + all tests
node scripts/build-client.mjs --check
```

Expected: tests all pass, `lib/client.js is up to date`.

## 2. Package contents / 包内容

```powershell
npm pack --dry-run --cache .tmp\npm-cache
```

Expected: **33 files / ~380 KB** unpacked from a clean tree (~148 KB tarball). The tarball must contain exactly these areas — no `src/`, `test/`, `scripts/`,
`.github/`, `.tmp/` or project-memory files:

- `lib/` (host + generated client bundle)
- `assets/icons/` (the four SVG icon sources linked from the design doc)
- `locale/` (`zh.json`, `en.json`, `ja.json`, `es.json`, `fr.json`, `de.json`, `ru.json`, `pt.json`)
- `cordis.patch.yml`
- `README.md`, `README.zh.md`, `CHANGELOG.md`, `LICENSE`, `docs/E2E.md`, `docs/RELEASE.md`

## 3. Extracted-package smoke / 解包冒烟

```powershell
npm pack --cache .tmp\npm-cache
# extract the printed .tgz to .tmp/release-check and run:
node --input-type=module -e "import('file:///<...>/package/lib/index.js').then(m => console.log(m.name, m.PLUGIN_VERSION))"
```

The host entry must expose `name`, `PLUGIN_VERSION`, `RPC_CHANNEL`; the client
bundle must load through `window.__ModuleLoader__` and export `apply`.

## 4. Runtime smoke / 真实运行冒烟

Restart DSH Desktop, refresh, then check:

- the desktop starter finishes within its 60-second watchdog (no `web boot` stall, no safe-mode banner with this plugin disabled), and the log contains `[dsh-nonead-prompt-recall] host ready v0.8.7` with **no** `RPC channel registration failed: cannot get property "webServer" without inject` line (0.8.5 registers the channel under `['connection', 'webServer']`; without it the settings page sits on "Loading…" forever);
- the starter does not fall back to recovery mode (`web boot: N entries did not activate` must not appear — the 0.8.2 fix moved the optimize button into the list slot `conversation.input.right`);
- Settings → 提示词历史 opens with real data (never a permanent "读取中…"), the nav row sits directly **above** the desktop-only 桌面设置 row with the same icon/label spacing as native rows, and the page is the v0.8.5 single-column layout (header → status strip → capture settings → history management → **Prompt optimization** as the last card at the bottom), export / import / clear above the history list, and clicking **模型提示词（只读）** expands the built-in prompt with its version and character count — a failure there must read like `unknown endpoint: …`, never `connection: invalid server-response failure` (0.8.4 puts `details` on every failure envelope, which is what DSH's client requires);
- the sparkle button appears to the right of the model selector and rewrites a non-empty draft;
- clicking it switches the icon to a spinning arc that rotates **in place** at the icon centre (CSS `transform-box:view-box` + `transform-origin:50% 50%`); the undo arrow appears only after a successful rewrite, and a failure shows a toast;
- switch Settings → General → Language across 中文 / English / 日本語 / Español / Français / Deutsch / Русский / Português and confirm the section label, page copy and `/prompt-recall status` follow the selection;
- empty composer + ↑ recalls the newest prompt, ↑ walks older, ↓ walks back;
- `/prompt-recall status` responds;
- 导出 JSON downloads a file; 导入并预览 shows the preview and merges on confirm;
- **提示词优化**：模型选择器右侧的四角星在空草稿时置灰、有文本时可点；点击后原文不动、成功后替换、返回箭头可撤销；含 `@` 引用的草稿改写后 chip 原位保留；助手流式输出期间仍可用；
- 设置页把「提示词优化」**点击**关掉后四角星立即消失（点击即保存，无需再点页面级保存），重新开启后恢复；
- 查看器展开显示提示词全文、版本、字符数，复制可用且无编辑入口；
- restart DSH and confirm history and settings survive.

See [E2E.md](./E2E.md) for the full manual matrix (keyboard, command, settings,
backup paths, and the 17-step prompt-optimization pass).

## 5. Publish / 发布

The package is public: [dsh-nonead-prompt-recall](https://www.npmjs.com/package/dsh-nonead-prompt-recall). `0.8.4` is the latest published release — it shipped 0.8.0 / 0.8.2 / 0.8.3 together (prompt optimization, the slot-conflict boot fix, the settings-page layout and the RPC failure envelope). `0.8.5` (settings page stuck on "Loading…", nav order), `0.8.6` (startup-stall → safe-mode hotfix) and `0.8.7` (settings-page 404 on current DSH, now served over the `/api` fetch route) are prepared and still have to be published. `0.6.3` added the metadata fix and `0.6.2` was the first version.

包已公开发布：`0.8.4` 是最新已发布版本——0.8.0 / 0.8.2 / 0.8.3 一并随 0.8.4 发布（提示词优化、插槽冲突导致的启动修复、设置页布局、RPC 失败封套）。`0.8.5`（设置页卡在「读取中…」、导航顺序）、`0.8.6`（启动卡死→安全模式的热修）与 `0.8.7`（当前 DSH 上设置页 404，改用 `/api` fetch 路由）已就绪、待发布。`0.6.3` 修了元数据，`0.6.2` 是首个版本。

Prerequisite: `npm login`. This account asks for proof-of-presence on every publish (OTP prompt or the browser URL npm prints), so publishing from a terminal the maintainer controls is the reliable path.

前提：已 `npm login`。本账号每次发布都要求 proof-of-presence（OTP 或 npm 打印的浏览器链接），因此由维护者在自己终端执行最稳妥。

```powershell
npm publish --access public
```

Notes / 注意：

- npm 11 may create a `0.0.0-stage` placeholder while the real version waits for approval; inspect with `npm stage list`, finish with `npm stage approve <id>`. The placeholder is never the `latest` tag.
- Read the registry, not the local cache: `npm view dsh-nonead-prompt-recall dist-tags --prefer-online` or `https://registry.npmjs.org/dsh-nonead-prompt-recall/latest`.
- Compare `dist.shasum` with the locally built tarball (`npm pack`) to prove the uploaded file is the one built here.

Then install from the registry:

```powershell
dsh plugin --profile <profile> add dsh-nonead-prompt-recall
```

For a local build, install by directory instead (`file:<absolute path>`).

## 6. Rollback / 回滚

- `npm unpublish dsh-nonead-prompt-recall@<version>` (within the registry window),
  then publish a fixed patch version;
- locally: disable/remove the plugin in the Plugins page and restart DSH.

## Versioning / 版本约定

- Update `package.json` `version` and add a matching `CHANGELOG.md` heading in
  the same commit; keep `README.md`, `README.zh.md` and `docs/E2E.md` version
  references in sync.
- `PLUGIN_VERSION` is read from `package.json`; never edit it separately.
