import type { ForeignSource } from './registry.ts';
export declare function createDsh4Source(): ForeignSource;
export declare const dsh4Source: ForeignSource;
