import type { ForeignImportResult, HermesInput } from './types.ts';
export declare function convertHermes(input: HermesInput): ForeignImportResult;
