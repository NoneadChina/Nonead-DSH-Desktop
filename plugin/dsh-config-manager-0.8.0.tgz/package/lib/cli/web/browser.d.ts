export declare function openInBrowser(url: string, platform?: NodeJS.Platform): void;
