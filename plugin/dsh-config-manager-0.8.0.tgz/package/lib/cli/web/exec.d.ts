export declare function createExec(platform?: NodeJS.Platform): (cmd: string) => Promise<string>;
