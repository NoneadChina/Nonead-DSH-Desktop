/**
 * 读文本文件；不可读返回 **null** —— 语义差异由调用方显式表达（**不得把 null 统一成 ''**）：
 *  - 档案管理器用 null 参与「该档案没有清单 → 视为非 DSH profile」的判定；
 *  - 运行时 / 启动器用 `readTextSafe(p) ?? ''`，靠 `JSON.parse('')` 抛错来「忽略这条记录」。
 */
export declare function readTextSafe(path: string): string | null;
/** 文件名片段清洗（profile 名已过校验；这里只是防意外字符）。 */
export declare function sanitizeFilePart(name: string): string;
