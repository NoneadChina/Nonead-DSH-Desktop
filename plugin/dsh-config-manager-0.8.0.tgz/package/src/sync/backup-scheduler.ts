/**
 * BackupScheduler：宿主后台定时全量备份调度器（P0-3）。
 *
 * 与 AutoSyncScheduler（同步通道自动同步）并列的独立能力：按固定间隔把当前 DSH
 * 完整配置导出为全量备份 ZIP（复用 Exporter 引擎，走 exportsDir）。
 *
 * 生命周期：
 *  - start()：读 backup-schedule.json；enabled 时启动定时器；无条件执行一次
 *    「启动触发备份」（受 startupMinIntervalMs 阈值约束）。
 *  - stop()：清定时器、标记不再调度。
 *  - reload()：重新读配置并重排定时器（配置保存路由调用）。
 *  - runOnce({ manual })：执行一次全量备份（受 runs.register('backup-schedule') 防重）。
 *    `manual: true` = 用户显式点「立即备份」：**不受自动调度开关 enabled 约束**（issue #43 ——
 *    手动语义是「现在就给我做一份」，与自动调度开没开无关；缺省 enabled:false 时旧行为是静默空转）。
 *    不传 = 自动 / 启动 / 外部调度路径，仍严格受 enabled 约束。
 *
 * 安全不变量（硬约束）：
 *  - 定时备份恒 includeSecrets=false 且不加密——加密密码仅内存且不能持久化，
 *    与自动同步恒不含 secret 同语义；要加密备份请走手动导出。
 *  - 出参只写非敏感摘要（文件名/大小/分区/计数），日志经 redact 兜底。
 *
 * 扩展点（供生态调度层 / 测试注入）：
 *  - 外部调度器（dsh-automation cron、任务看板）可直接调 runOnce() 触发备份，
 *    或复用 P0-1 的 config_backup 模型工具在 agent 会话内驱动。
 */
import type { Logger } from '../utils/logger.ts';
import { engineMsg } from './messages.ts';
import type { MsgFunc } from '../core/messages.ts';
import type { RunRegistry } from '../core/run-registry.ts';
import type { ConfigAdapter, HostContext, SecretScanner } from '../core/types.ts';
import type { MutationLockPort } from '../utils/env-lock.ts';
import type { LockBlockReason } from '../utils/env-lock.ts';
import { runWithMutationLock, EnvironmentLockUnavailableError, LOCK_BLOCK_MESSAGE, LOCK_BLOCK_BRIEF, lockSkipToken } from '../utils/env-lock.ts';
import { Exporter } from '../core/exporter.ts';
import { randomBytes } from 'node:crypto';
import { join } from 'node:path';
import { readBackupSchedule, writeBackupSchedule, nextBackupDelayMs } from './backup-schedule-config.ts';
import type { BackupScheduleConfig, BackupRunStatus } from './backup-schedule-config.ts';
import { shouldTriggerStartupRun } from './autosync-scheduler.ts';
import { AUTO_BACKUP_PREFIX, pruneAutoBackupsByPolicy } from './backup-files.ts';
import { DEFAULT_RETENTION_POLICY } from './retention-policy.ts';
import type { RetentionPolicy } from './retention-policy.ts';
import { formatDateStamp } from '../utils/time.ts';

export interface BackupRunResult {
  status: BackupRunStatus;
  zip?: string;
  sizeBytes?: number;
  sections?: string[];
  skipReason?: string;
  error?: string;
  consecutiveFailures: number;
}

export interface BackupSchedulerOptions {
  /** 同步状态目录（$DSH_HOME/dsh-config-manager/sync；配置存 backup-schedule.json） */
  syncDir: string;
  /** 导出 ZIP 落盘目录（$DSH_HOME/dsh-config-manager/exports） */
  exportsDir: string;
  host: HostContext;
  adapters: ConfigAdapter[];
  runs: RunRegistry;
  msg: MsgFunc;
  /** 插件版本（manifest.exporter.version） */
  exporterVersion?: string;
  /**
   * M1（G-09 接线）：secret 扫描器。必须与 HTTP 导出路由（makeRoutes）、Agent 模型工具
   * config_backup（registerModelTools）共用**同一个实例**（宿主 index.ts 注入的
   * createConfiguredSecretScanner 单一实例），否则三条全量导出路径的扫描档位漂移：
   * 文件类分区（skills/agentPresets/agentInstructions/pluginFiles/sessions/self）的凭据告警
   * 与 redactedHits 统计会不一致。定时备份是**无人值守**路径，用户不会自己发现静默漏扫。
   * 缺省 undefined → Exporter 落回 defaultSecretScanner()（无 scanText）→ 文件类分区不扫描
   * （旧行为；向后兼容既有调用方与测试）。
   */
  scanner?: SecretScanner;
  /** 时间源（测试注入） */
  now?: () => Date;
  /** 注入配置读写（测试可内存实现） */
  readConfig?: () => Promise<BackupScheduleConfig>;
  writeConfig?: (cfg: BackupScheduleConfig) => Promise<void>;
  /** 定时备份产物保留策略（GFS 分层；缺省 = 「保留最近 10 个」，与旧行为等价）。
   *  兼容路径：仍接受 `number`（= 旧 API），内部转成 `{keepLast: n, keepMonthly: 0, keepYearly: 0}`。 */
  retention?: RetentionPolicy | number;
  /** 注入计时器（测试用；缺省 setInterval/clearInterval） */
  setTimer?: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
  clearTimer?: (timer: ReturnType<typeof setTimeout>) => void;
  /** 日志（缺省 host.log） */
  log?: Logger;
  /** Phase 2 跨进程环境锁端口（可选注入；缺省无锁环境） */
  mutationLock?: MutationLockPort;
  /** Phase 3 SAFE MODE：注入同步谓词（被挡 → backup skipped），供 runWithMutationLock isBlocked 用。 */
  isBlocked?: () => boolean;
  /**
   * Phase 6：迁移历史追加（best-effort）。定时备份完成后回调，供宿主统一审计史记录。
   * 缺省 = 不记录（不破坏既有调用方）。
   */
  appendHistoryFn?: (entry: {
    /** 'backup' = 自动/定时调度产出；'backup-manual' = 用户手动「立即备份」（issue #43 起见区分）。 */
    kind: 'backup' | 'backup-manual';
    result: 'success' | 'failed' | 'skipped';
    sections: string[];
    source: 'backup-scheduler';
    summary: string;
    error?: string;
  }) => Promise<void>;
  /** Phase 3 recovery（可选注入）：backup export 包 intent journal（P0-A，可选 §20.3）。 */
  phase3Recovery?: {
    runExternalIntent(opts: {
      operationType: string;
      lockCtx: import('../utils/env-lock.ts').MutationLockContext;
      intent: { adapter: string; ref: string; kind: string };
      fn: () => Promise<unknown>;
    }): Promise<{ operationId: string; result: unknown }>;
  };
}

export class BackupScheduler {
  private readonly syncDir: string;
  private readonly exportsDir: string;
  private readonly host: HostContext;
  private readonly adapters: ConfigAdapter[];
  private readonly runs: RunRegistry;
  private readonly msg: MsgFunc;
  private readonly exporterVersion: string;
  private readonly scanner: SecretScanner | undefined;
  private readonly now: () => Date;
  private readonly readConfig: () => Promise<BackupScheduleConfig>;
  private readonly writeConfig: (cfg: BackupScheduleConfig) => Promise<void>;
  private readonly retention: RetentionPolicy;
  private readonly setTimer: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
  private readonly clearTimer: (timer: ReturnType<typeof setTimeout>) => void;
  private readonly log: Logger;
  private readonly mutationLock: MutationLockPort | undefined;
  private readonly isBlocked: (() => boolean) | undefined;
  private readonly phase3Recovery: BackupSchedulerOptions['phase3Recovery'];
  private readonly appendHistoryFn: BackupSchedulerOptions['appendHistoryFn'];

  private timer: ReturnType<typeof setTimeout> | undefined;
  private stopped = false;
  private running = false;

  constructor(opts: BackupSchedulerOptions) {
    this.syncDir = opts.syncDir;
    this.exportsDir = opts.exportsDir;
    this.host = opts.host;
    this.adapters = opts.adapters;
    this.runs = opts.runs;
    this.msg = opts.msg;
    this.exporterVersion = opts.exporterVersion ?? '0.1.0';
    this.scanner = opts.scanner;
    this.now = opts.now ?? (() => new Date());
    this.readConfig = opts.readConfig ?? (() => readBackupSchedule(this.syncDir));
    this.writeConfig = opts.writeConfig ?? ((cfg) => writeBackupSchedule(this.syncDir, cfg));
    // 兼容路径：number（旧 API）= keepLast，分层关闭 → 与既有行为逐字节等价
    this.retention = typeof opts.retention === 'number'
      ? { keepLast: opts.retention, keepMonthly: 0, keepYearly: 0 }
      : (opts.retention ?? DEFAULT_RETENTION_POLICY);
    this.setTimer = opts.setTimer ?? ((fn, ms) => setTimeout(fn, ms));
    this.clearTimer = opts.clearTimer ?? ((t) => clearTimeout(t));
    this.log = opts.log ?? this.host.log;
    this.mutationLock = opts.mutationLock;
    this.isBlocked = opts.isBlocked;
    this.phase3Recovery = opts.phase3Recovery;
    this.appendHistoryFn = opts.appendHistoryFn;
  }

  /** 启动：读配置 → enabled 时排定时器 → 执行一次启动触发备份。 */
  start(): void {
    if (this.stopped) return;
    this.refreshTimer();
    void this.startupRun();
  }

  /** 停止：清定时器、标记不再调度；正在执行的任务允许自然结束。 */
  stop(): void {
    this.stopped = true;
    if (this.timer !== undefined) {
      this.clearTimer(this.timer);
      this.timer = undefined;
    }
  }

  /** 重新加载配置（配置保存后调用；重排定时器）。 */
  async reload(): Promise<void> {
    if (this.stopped) return;
    this.refreshTimer();
  }

  private refreshTimer(): void {
    if (this.timer !== undefined) {
      this.clearTimer(this.timer);
      this.timer = undefined;
    }
    void this.readConfig().then((cfg) => {
      if (this.stopped || !cfg.enabled) return;
      // P0-⑤：固定间隔档返回 interval ms；custom（每周固定时刻）返回到下一个
      // 触发点的 delay（非法配置 → null 不排期，等待下次 reload/配置修正）。
      const delay = nextBackupDelayMs(cfg, this.now());
      if (delay === null) {
        this.log.warn('定时备份 custom 档缺少有效 customSchedule，暂不排期', { interval: cfg.interval });
        return;
      }
      this.timer = this.setTimer(() => {
        this.timer = undefined;
        if (this.stopped) return;
        void this.runOnce()
          .catch((err) => {
            this.log.error('定时备份触发失败', { error: err instanceof Error ? err.message : String(err) });
          })
          .then(() => {
            // 本轮结束（成功 / 跳过 / 失败）后重新排定下一次；refreshTimer 重读配置，
            // 期间若被关闭（enabled=false）则不再排期。
            if (!this.stopped) this.refreshTimer();
          });
      }, delay);
    }).catch(() => { /* 读配置失败静默 */ });
  }

  /** 启动触发备份（受 startupMinIntervalMs 阈值约束）。 */
  private async startupRun(): Promise<void> {
    try {
      const cfg = await this.readConfig();
      if (!cfg.enabled) return;
      if (!shouldTriggerStartupRun(cfg.lastRunAt, cfg.startupMinIntervalMs, this.now().getTime())) {
        this.log.info('定时备份启动触发跳过：距上次运行未达阈值');
        return;
      }
      await this.runOnce();
    } catch (err) {
      this.log.error('启动触发备份失败', { error: err instanceof Error ? err.message : String(err) });
    }
  }

  /**
   * 执行一次全量备份（防重：同一时刻至多一个备份任务）。
   *
   * `opts.manual = true`（用户点「立即备份」）**绕过** `enabled` 开关（issue #43）：缺省
   * `enabled: false` 时旧行为是静默空转，而这恰好是从未配置过定时的用户最可能点的按钮。
   * 自动 / 启动 / 外部调度路径不传，仍严格受 `enabled` 约束；手动路径只写运行状态，
   * 绝不改写 `enabled`（不偷偷替用户打开自动调度）。
   */
  async runOnce(opts: { manual?: boolean } = {}): Promise<BackupRunResult> {
    const manual = opts.manual === true;
    /** 日志 / 迁移历史的来源词：手动触发不得冒充「定时备份」。 */
    const trigger = manual ? engineMsg('sync.backupTriggerManual') : engineMsg('sync.backupTriggerScheduled');
    if (this.running) {
      return { status: 'skipped', skipReason: 'running', consecutiveFailures: 0 };
    }
    const cfg = await this.readConfig();
    if (!cfg.enabled && !manual) {
      return { status: 'skipped', skipReason: 'disabled', consecutiveFailures: cfg.consecutiveFailures };
    }

    this.running = true;
    let runId: string | null = null;
    try {
      const run = this.runs.register('backup-schedule');
      runId = run.runId;
    } catch {
      this.running = false;
      return { status: 'skipped', skipReason: 'conflict', consecutiveFailures: cfg.consecutiveFailures };
    }

    try {
      // 本轮开始前先自愈：可证的 stale 残留锁会让每轮备份直接 skipped，用户不重启就永远不备份。
      // 只删可证的（owner 确证死亡 / PID 复用）；不可证的仍走下面 runWithMutationLock 的 skipped 分支。
      try { await this.mutationLock?.reclaimProvableStaleLock?.() } catch { /* 预检失败不改变既有路径 */ }
      // Phase 2 锁：定时备份写入 exports 属 GLOBAL mutation（与 Sync push / 手动备份互斥）。
      // 无锁环境（测试）→ 不锁定直接执行；锁被占用 → 返回 failed（destructive 不执行）。
      const result: BackupRunResult = await runWithMutationLock(this.mutationLock, { op: 'backup-schedule', target: 'exports', isBlocked: this.isBlocked }, async (lockCtx) => {
        const doExport = async (): Promise<BackupRunResult> => {
        const exporter = new Exporter({
          ctx: this.host,
          adapters: this.adapters,
          encryption: null, // 定时备份恒不加密：加密密码仅内存且不能持久化
          exporterVersion: this.exporterVersion,
          msg: this.msg,
          // M1（G-09 接线）：与 HTTP 导出路由 / config_backup 同一个 scanner 实例。
          // 缺省 undefined → Exporter 落回无 scanText 的默认扫描器（旧行为）。
          scanner: this.scanner,
        });
        // 显式落 exportsDir（与 host 路由同构；Exporter 缺省 outPath 是相对文件名，不落目录）
        // auto 前缀 = 定时备份产物标识：列表来源 Badge + cache-cleaner 豁免 + 保留策略清理依据
        const outPath = join(this.exportsDir, `${AUTO_BACKUP_PREFIX}${formatDateStamp(this.now())}-${randomBytes(3).toString('hex')}.zip`);
        const { report } = await exporter.export({
          includeSecrets: false, // 恒不含 secret（与自动同步同语义）
          outPath,
        });
        const backupResult: BackupRunResult = {
          status: 'success',
          zip: report.file.name,
          sizeBytes: report.file.sizeBytes,
          sections: report.included.map((s) => s.section),
          consecutiveFailures: 0,
        };
        await this.writeConfig({
          enabled: cfg.enabled,
          interval: cfg.interval,
          // P0-⑤：保留 custom 档的每周时刻（否则保存 custom 档后 runOnce 成功会把它丢掉）
          ...(cfg.customSchedule !== undefined ? { customSchedule: cfg.customSchedule } : {}),
          // m-retention：保留用户配置的 GFS 保留策略（同理，不能被运行结果覆盖丢失）
          ...(cfg.retention !== undefined ? { retention: cfg.retention } : {}),
          startupMinIntervalMs: cfg.startupMinIntervalMs,
          consecutiveFailures: 0,
          lastRunAt: this.now().toISOString(),
          lastRunStatus: 'success',
        });
        this.log.info(`${trigger}完成`, {
          zip: backupResult.zip,
          sizeBytes: backupResult.sizeBytes,
          sections: backupResult.sections,
        });
        // 保留策略：按 GFS policy 选出应保留的 auto 前缀产物，其余删除（尽力而为，
        // 失败仅记日志不阻断——下次成功备份时再清）。
        // 生效策略优先级：持久化配置 policy（用户在 UI 改的） > 构造注入值（缺省 = 最近 10 个）。
        try {
          const effectiveRetention = cfg.retention ?? this.retention;
          const removed = await pruneAutoBackupsByPolicy(this.exportsDir, effectiveRetention);
          if (removed.length > 0) {
            this.log.info('定时备份保留策略清理', { removed, retention: effectiveRetention });
          }
        } catch (err) {
          this.log.warn('定时备份保留策略清理失败', { error: err instanceof Error ? err.message : String(err) });
        }
        return backupResult;
        };
        // Phase 3 P0-A：backup export 记 intent journal（声明已接线，关闭 P1 gap）
        if (this.phase3Recovery !== undefined && lockCtx !== null) {
          return (await this.phase3Recovery.runExternalIntent({
            operationType: 'backup-schedule', lockCtx,
            intent: { adapter: 'backup', ref: 'exports', kind: 'Backup' }, fn: doExport,
          })).result as BackupRunResult;
        }
        return doExport();
      });
      await this.appendHistory(result, undefined, manual);
      return result;
    } catch (err) {
      // issue #31：被挡时按分类说真话——**残留锁（持有者已确证死亡）不是「另一项任务进行中」**，
      // 且它重试/重启都不会自愈，必须显式回收。文案与 423 响应、autosync 日志同源
      // （LOCK_BLOCK_MESSAGE），避免同一句指引在多条路径上再次漂移（#27 只接了 autosync，
      // 本路径漏接 → 实测 9 天内 57 次静默跳过，用户无从知道要回收残留锁）。
      if (err instanceof EnvironmentLockUnavailableError) {
        // stale 与 stale-degraded 同属「重试不会自愈」，都走 warn（都带显式回收指引）。
        if (err.reason === 'stale' || err.reason === 'stale-degraded') {
          this.log.warn(`${trigger}跳过：${LOCK_BLOCK_MESSAGE[err.reason]}`);
        } else {
          this.log.info(`${trigger}跳过：${LOCK_BLOCK_MESSAGE[err.reason]}`);
        }
        const skipped: BackupRunResult = { status: 'skipped', skipReason: lockSkipToken(err.reason), consecutiveFailures: cfg.consecutiveFailures };
        // skipReason 保持稳定的机器 token（客户端据此本地化）；历史摘要用同源**短**文案，
        // 不留裸 token（issue #31 ②：中文前缀 + 英文 token 的历史行）。
        await this.appendHistory(skipped, err.reason, manual);
        return skipped;
      }
      const error = err instanceof Error ? err.message : String(err);
      const result: BackupRunResult = {
        status: 'failed', error, consecutiveFailures: cfg.consecutiveFailures + 1,
      };
      await this.writeConfig({
        ...cfg,
        lastRunAt: this.now().toISOString(),
        lastRunStatus: 'failed',
        consecutiveFailures: cfg.consecutiveFailures + 1,
        lastRunMessage: error,
      });
      this.log.warn(`${trigger}失败（连续 ${cfg.consecutiveFailures + 1} 次）`, { error });
      await this.appendHistory(result, undefined, manual);
      return result;
    } finally {
      this.running = false;
      if (runId !== null) {
        try {
          this.runs.finish(runId, { kind: 'backup-schedule' });
        } catch {
          /* 尽力而为 */
        }
      }
    }
  }

  /** Phase 6：定时备份迁移历史（best-effort；失败仅日志，不阻断）。
   *  lockReason：被环境锁挡下时的分类（issue #31）——摘要据此给同源短文案，
   *  而不是把 'mutation-locked' 这个机器 token 原样写进用户可见的历史行。 */
  private async appendHistory(result: BackupRunResult, lockReason?: LockBlockReason, manual = false): Promise<void> {
    if (this.appendHistoryFn === undefined) return;
    // issue #43：手动与定时备份在同一份迁移史里必须可区分 —— 来源词与 kind 同源判定，
    // 避免「日志说手动、条目说定时」两处漂移。
    const trigger = manual ? engineMsg('sync.backupTriggerManual') : engineMsg('sync.backupTriggerScheduled');
    try {
      await this.appendHistoryFn({
        kind: manual ? 'backup-manual' : 'backup',
        result: result.status,
        sections: result.status === 'success' ? (result.sections ?? []) : [],
        source: 'backup-scheduler',
        summary: result.status === 'success'
          ? engineMsg('sync.backupHistoryDone', { trigger, zip: result.zip ?? '' })
          : result.status === 'skipped'
            ? engineMsg('sync.backupHistorySkipped', { trigger, reason: lockReason !== undefined ? LOCK_BLOCK_BRIEF[lockReason] : (result.skipReason ?? '') })
            : engineMsg('sync.backupHistoryFailed', { trigger }),
        error: result.status === 'failed' ? (result.error ?? undefined) : undefined,
      });
    } catch (err) {
      this.log.warn('定时备份迁移历史写入失败（best-effort 忽略）', { error: err instanceof Error ? err.message : String(err) });
    }
  }
}


