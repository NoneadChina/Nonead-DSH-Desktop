/**
 * Migration History 区块（config-manager-history）表面文案：zh 为源语言，en 镜像每个键。
 * 独立命名空间、独立文件：不触碰共享的 locales.ts，零冲突。
 * 键集合经 `HistoryKey` 类型在 client/index.ts 注册处做编译期校验。
 */
import type { MigrationKind, MigrationResult } from '../../core/migration-history.ts';

type KindKey = `history.kind.${MigrationKind}`;
type ResultKey = `history.result.${MigrationResult}`;
type CommonKey =
  | 'history.subtitle'
  | 'history.empty'
  | 'history.loading'
  | 'history.corruptedBanner'
  | 'history.corruptedCount'
  | 'history.stats.total'
  | 'history.stats.success'
  | 'history.stats.failed'
  | 'history.stats.skipped'
  | 'history.filter.kind'
  | 'history.filter.result'
  | 'history.filter.recent'
  | 'history.filter.recent.all'
  | 'history.filter.recent.50'
  | 'history.filter.recent.200'
  | 'history.search.placeholder'
  | 'history.export.json'
  | 'history.export.markdown'
  | 'history.exported'
  | 'history.exporting'
  | 'history.exportError'
  | 'history.refresh'
  | 'history.refreshError'
  | 'history.retention.label'
  | 'history.retention.hint'
  | 'history.retention.unlimited'
  | 'history.retention.units'
  | 'history.retention.current'
  | 'history.retention.runNow'
  | 'history.retention.running'
  | 'history.retention.cleaned'
  | 'history.retention.noop'
  | 'history.retention.saveError'
  /** ⓘ 说明按钮的可访问名（与主字典 / market / sync / recovery 同口径，见 info-hint-guard t6-4） */
  | 'common.infoHint';

export type HistoryKey = KindKey | ResultKey | CommonKey;

export const zh = {
  'common.infoHint': '查看说明',
  'history.subtitle': '统一记录全部破坏性/迁移操作（导入/恢复/回滚/档案/同步/备份/快照操作），只可追加、不可修改或删除，跨重启持久，可查询可导出。',
  'history.empty': '暂无迁移记录。',
  'history.loading': '加载迁移历史…',
  'history.corruptedBanner': '检测到无法读取/可能被篡改的历史条目',
  'history.corruptedCount': '{count} 条已跳过 · 不参与导出',
  'history.stats.total': '总数',
  'history.stats.success': '成功',
  'history.stats.failed': '失败',
  'history.stats.skipped': '跳过',
  'history.filter.kind': '操作类型',
  'history.filter.result': '结果',
  'history.filter.recent': '时间范围',
  'history.filter.recent.all': '全部',
  'history.filter.recent.50': '最近 50 条',
  'history.filter.recent.200': '最近 200 条',
  'history.search.placeholder': '搜索摘要 / 错误 / 分区…',
  'history.export.json': '导出 JSON',
  'history.export.markdown': '导出 Markdown',
  'history.exported': '已导出',
  'history.exporting': '导出中…',
  'history.exportError': '导出失败',
  'history.refresh': '刷新',
  'history.refreshError': '刷新失败',
  'history.retention.label': '自动清理',
  'history.retention.hint': '历史条目超过上限时自动删除最旧的；0 = 不限制。清理本身不写历史条目，避免「清理把自己写进历史」的死循环。',
  'history.retention.unlimited': '不限制',
  'history.retention.units': '{count} 条',
  'history.retention.current': '磁盘上 {count} 条',
  'history.retention.runNow': '立即清理',
  'history.retention.running': '清理中…',
  'history.retention.cleaned': '已清理 {count} 条',
  'history.retention.noop': '无需清理',
  'history.retention.saveError': '保存自动清理策略失败',
  'history.kind.import': '导入',
  'history.kind.restore': '快照恢复',
  'history.kind.rollback': '回滚',
  'history.kind.profile-create': '档案新建',
  'history.kind.profile-select': '设置下次启动档案',
  'history.kind.profile-switch': '档案切换',
  'history.kind.profile-delete': '档案删除',
  'history.kind.profile-rename': '档案重命名',
  'history.kind.profile-save': '档案保存',
  'history.kind.profile-import': '档案导入',
  'history.kind.sync-apply': '从远端合并',
  'history.kind.autosync': '自动同步',
  'history.kind.recovery': '恢复/回滚编排',
  'history.kind.backup': '定时备份',
  'history.kind.backup-manual': '手动备份',
  'history.kind.snapshot-delete': '快照删除',
  'history.kind.snapshot-prune': '快照保留清理',
  'history.result.success': '成功',
  'history.result.failed': '失败',
  'history.result.skipped': '跳过',
  'history.result.pending': '待裁决',
} as const satisfies Record<HistoryKey, string>;

export const en = {
  'common.infoHint': 'Show description',
  'history.subtitle': 'Unified append-only audit trail of all destructive/migration operations (import/restore/rollback/profile/sync/backup/snapshot), durable across restarts, queryable and exportable.',
  'history.empty': 'No migration records yet.',
  'history.loading': 'Loading migration history…',
  'history.corruptedBanner': 'Detected unreadable or possibly tampered history entries',
  'history.corruptedCount': '{count} skipped · not exported',
  'history.stats.total': 'Total',
  'history.stats.success': 'Success',
  'history.stats.failed': 'Failed',
  'history.stats.skipped': 'Skipped',
  'history.filter.kind': 'Operation',
  'history.filter.result': 'Result',
  'history.filter.recent': 'Time range',
  'history.filter.recent.all': 'All',
  'history.filter.recent.50': 'Latest 50',
  'history.filter.recent.200': 'Latest 200',
  'history.search.placeholder': 'Search summary / error / section…',
  'history.export.json': 'Export JSON',
  'history.export.markdown': 'Export Markdown',
  'history.exported': 'Exported',
  'history.exporting': 'Exporting…',
  'history.exportError': 'Export failed',
  'history.refresh': 'Refresh',
  'history.refreshError': 'Refresh failed',
  'history.retention.label': 'Auto-cleanup',
  'history.retention.hint': 'Delete the oldest entries once the limit is exceeded; 0 = unlimited. Cleanup writes no history entry, so it can never feed itself.',
  'history.retention.unlimited': 'Unlimited',
  'history.retention.units': '{count} entries',
  'history.retention.current': '{count} on disk',
  'history.retention.runNow': 'Clean up now',
  'history.retention.running': 'Cleaning…',
  'history.retention.cleaned': 'Removed {count}',
  'history.retention.noop': 'Nothing to remove',
  'history.retention.saveError': 'Failed to save auto-cleanup policy',
  'history.kind.import': 'Import',
  'history.kind.restore': 'Snapshot restore',
  'history.kind.rollback': 'Rollback',
  'history.kind.profile-create': 'Profile created',
  'history.kind.profile-select': 'Next-launch profile set',
  'history.kind.profile-switch': 'Profile switch',
  'history.kind.profile-delete': 'Profile delete',
  'history.kind.profile-rename': 'Profile rename',
  'history.kind.profile-save': 'Profile save',
  'history.kind.profile-import': 'Profile import',
  'history.kind.sync-apply': 'Merge from remote',
  'history.kind.autosync': 'Autosync',
  'history.kind.recovery': 'Recovery/rollback',
  'history.kind.backup': 'Scheduled backup',
  'history.kind.backup-manual': 'Manual backup',
  'history.kind.snapshot-delete': 'Snapshot delete',
  'history.kind.snapshot-prune': 'Snapshot retention',
  'history.result.success': 'Success',
  'history.result.failed': 'Failed',
  'history.result.skipped': 'Skipped',
  'history.result.pending': 'Needs decision',
} as const satisfies Record<HistoryKey, string>;

