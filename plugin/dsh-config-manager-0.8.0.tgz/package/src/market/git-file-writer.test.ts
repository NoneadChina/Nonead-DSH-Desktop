/**
 * m-market：GitFileWriterClient / createGitFileWriter 单测。
 * 覆盖：clone + 写文件 + commit + push 全流程；幂等（无变化不 push）；
 * PR 分支（branch + baseRef + upstream fetch + force push）；错误脱敏（token 不进错误消息、
 * 凭据临时文件用后即删）；仓库地址校验；工作副本非空拒绝。
 * 全部通过注入 exec mock + 真实临时目录 fs（不碰真实 git / 网络）。
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

import { createGitFileWriter, GitFileWriterError } from './git-file-writer.ts';
import type { GitExecFn, GitExecResult } from '../sync/git/git-transport.ts';

const TEST_TOKEN = 'gho_abcdefghijklmnopqrstuvwxyz123456';

interface ExecCall {
  cmd: string;
  args: string[];
  opts: { cwd?: string; timeoutMs?: number; env?: Record<string, string> };
}

/** 记录 exec 调用并按命令返回脚本化结果的 mock */
function installExec(script: (call: ExecCall) => GitExecResult): { exec: GitExecFn; calls: ExecCall[] } {
  const calls: ExecCall[] = [];
  const exec: GitExecFn = async (cmd, args, opts) => {
    const call = { cmd, args, opts };
    calls.push(call);
    return script(call);
  };
  return { exec, calls };
}

/** 默认成功脚本：clone/config/add/commit/push 全 0；diff 有变化（code 1）触发 commit+push */
function okScript(options: { changed?: boolean } = {}): (call: ExecCall) => GitExecResult {
  return (call) => {
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: options.changed === false ? 0 : 1 };
    return { stdout: '', stderr: '', code: 0 };
  };
}

/** 提取真实 git 命令：剥离前置的 `-c <value>` 凭据参数对（可能有 1~2 对） */
function gitCommandOf(call: ExecCall): string {
  const args = call.args;
  let i = 0;
  while (args[i] === '-c') i += 2;
  return args[i] ?? '';
}

/** 从 capture call args 提取 credential store 文件路径（--file=...） */
function credFileOf(calls: ExecCall[]): string | null {
  for (const c of calls) {
    for (const arg of c.args) {
      const m = /^credential\.helper=store --file=(.+)$/.exec(arg);
      if (m?.[1]) return m[1]!.replace(/^"|"$/g, '');
    }
  }
  return null;
}

async function tempWorkDir(t: test.TestContext): Promise<string> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'gfw-test-'));
  t.after(async () => { await fs.rm(dir, { recursive: true, force: true }).catch(() => {}); });
  return dir;
}

test('git-file-writer: clone + 写文件 + commit + push（默认分支），凭据临时文件用后即删', async (t) => {
  const { exec, calls } = installExec(okScript());
  const workDir = await tempWorkDir(t);
  const writer = createGitFileWriter({
    credentials: { getToken: async () => TEST_TOKEN },
    exec,
    timeoutMs: 5000,
  });

  const result = await writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-configs',
    workDir,
    entries: [
      { path: 'items/my-config/manifest.json', content: '{"id":"my-config"}' },
      { path: 'items/my-config/config.zip', content: new Uint8Array([1, 2, 3]) },
    ],
    commitMessage: 'publish: add my-config v1.0.0',
  });

  assert.equal(result.pushed, true);
  assert.equal(result.branch, 'default');

  // 命令序：clone → config user.name → config user.email → add → diff → commit → push
  const firsts = calls.map((c) => gitCommandOf(c));
  assert.deepEqual(firsts, ['clone', 'config', 'config', 'add', 'diff', 'commit', 'push']);
  // clone 带凭据（-c credential.helper=store --file=...）
  const cloneCall = calls[0]!;
  assert.ok(cloneCall.args.some((a) => a.startsWith('credential.helper=store --file=')), 'clone 必须注入 credential helper');
  // push 同样带凭据
  const pushCall = calls[calls.length - 1]!;
  assert.deepEqual(pushCall.args.slice(pushCall.args.length - 4), ['push', '-u', 'origin', 'HEAD']);
  assert.ok(pushCall.args.some((a) => a.startsWith('credential.helper=store --file=')), 'push 必须注入 credential helper');
  // issue #103：store 以 username 作查找键，只清 helper 不钉 username 会被全局 .gitconfig 顶掉
  for (const call of [cloneCall, pushCall]) {
    assert.ok(call.args.includes('credential.username=oauth2'), 'clone/push 必须钉住 credential.username（与 store 文件同源）');
  }
  // commit message 原样传递
  const commitCall = calls.find((c) => gitCommandOf(c) === 'commit')!;
  assert.ok(commitCall.args.includes('publish: add my-config v1.0.0'));

  // 文件真实写入（自动建目录）
  const manifestRaw = await fs.readFile(path.join(workDir, 'items/my-config/manifest.json'), 'utf8');
  assert.equal(manifestRaw, '{"id":"my-config"}');
  const zipRaw = new Uint8Array(await fs.readFile(path.join(workDir, 'items/my-config/config.zip')));
  assert.deepEqual(Array.from(zipRaw), [1, 2, 3]);

  // 凭据临时文件用后即删
  const credFile = credFileOf(calls);
  assert.ok(credFile !== null, '必须创建过 credential store 文件');
  await assert.rejects(fs.stat(credFile!), /ENOENT/);
});

test('git-file-writer: 内容无变化 → pushed:false，不产生 commit/push（幂等）', async (t) => {
  const { exec, calls } = installExec(okScript({ changed: false }));
  const workDir = await tempWorkDir(t);
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });

  const result = await writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-configs',
    workDir,
    entries: [{ path: 'index.json', content: '{}' }],
    commitMessage: 'noop',
  });

  assert.equal(result.pushed, false);
  assert.ok(!calls.some((c) => c.args[0] === 'commit'), '无变化不得 commit');
  assert.ok(!calls.some((c) => c.args[0] === 'push'), '无变化不得 push');
});

test('git-file-writer: PR 分支场景（branch + baseRef + upstream fetch + force push）', async (t) => {
  // remote get-url upstream 失败（全新 clone 无 upstream）→ 触发 remote add upstream；diff 有变化
  const { exec, calls } = installExec((call) => {
    if (gitCommandOf(call) === 'remote' && call.args.includes('get-url')) {
      return { stdout: '', stderr: 'error: No such remote', code: 128 };
    }
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: 1 };
    return { stdout: '', stderr: '', code: 0 };
  });
  const workDir = await tempWorkDir(t);
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });

  const result = await writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-config-market',
    workDir,
    upstreamUrl: 'https://github.com/xiajiajun516/dsh-config-market',
    branch: 'dsh-market-sync/my-config',
    baseRef: 'upstream/main',
    force: true,
    entries: [{ path: 'index.json', content: '{"items":[]}' }],
    commitMessage: 'market: add my-config',
  });

  assert.equal(result.pushed, true);
  assert.equal(result.branch, 'dsh-market-sync/my-config');

  const argsOf = (cmd: string): string[] => calls.find((c) => gitCommandOf(c) === cmd)?.args ?? [];
  // upstream：remote add upstream + fetch（公开仓库匿名，不带凭据）
  const remoteAdd = calls.find((c) => gitCommandOf(c) === 'remote' && c.args.includes('add') && c.args.includes('upstream'))!;
  assert.ok(remoteAdd.args.includes('https://github.com/xiajiajun516/dsh-config-market'), 'upstream url 必须是官方仓库');
  const fetchCall = calls.find((c) => gitCommandOf(c) === 'fetch')!;
  assert.ok(fetchCall.args.includes('upstream'));
  assert.ok(!fetchCall.args.some((a) => a.startsWith('credential.helper=')), 'fetch 官方公开仓库必须零凭据');
  // checkout -B <branch> upstream/main
  const co = argsOf('checkout');
  assert.deepEqual(co.slice(1), ['-B', 'dsh-market-sync/my-config', 'upstream/main']);
  // push -u origin <branch> --force-with-lease
  const push = argsOf('push');
  assert.deepEqual(push.slice(push.length - 5), ['push', '-u', 'origin', 'dsh-market-sync/my-config', '--force-with-lease']);
});

test('git-file-writer: 已存在工作副本 → 显式 fetch + merge --ff-only（不读 FETCH_HEAD、不重新 clone）', async (t) => {
  const workDir = await tempWorkDir(t);
  await fs.mkdir(path.join(workDir, '.git'), { recursive: true }); // 假装已 clone
  const { exec, calls } = installExec((call) => {
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: 0 };
    // 分支探测：rev-parse --abbrev-ref HEAD → main（detached 会返回 HEAD，走静默跳过）
    if (gitCommandOf(call) === 'rev-parse' && call.args.includes('--abbrev-ref')) return { stdout: 'main\n', stderr: '', code: 0 };
    return { stdout: '', stderr: '', code: 0 };
  });
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });

  await writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-configs',
    workDir,
    entries: [{ path: 'a.txt', content: '1' }],
    commitMessage: 'noop',
  });

  assert.ok(!calls.some((c) => gitCommandOf(c) === 'clone'), '已存在副本不得重新 clone');
  // 并发下 `git pull` 会把 FETCH_HEAD 写成多行 for-merge、pull 自己 fatal（真机 SAFE MODE 根源）
  assert.ok(!calls.some((c) => gitCommandOf(c) === 'pull'), '不得再用 git pull');
  const fetchCall = calls.find((c) => gitCommandOf(c) === 'fetch');
  assert.ok(fetchCall !== undefined, '必须显式 fetch');
  assert.deepEqual(fetchCall!.args.slice(-3), ['fetch', 'origin', '+refs/heads/main:refs/remotes/origin/main']);
  const mergeCall = calls.find((c) => gitCommandOf(c) === 'merge');
  assert.ok(mergeCall !== undefined, '必须 merge --ff-only');
  assert.deepEqual(mergeCall!.args.slice(-3), ['merge', '--ff-only', 'origin/main']);
  assert.ok(!calls.some((c) => c.args.some((a) => a.includes('FETCH_HEAD'))), '绝不读 FETCH_HEAD');
});

test('git-file-writer: 并发写入同一个工作副本 → git 调用不重叠（工作副本锁）', async (t) => {
  const workDir = await tempWorkDir(t);
  await fs.mkdir(path.join(workDir, '.git'), { recursive: true }); // 假装已 clone
  let active = 0;
  let maxActive = 0;
  const { exec } = installExec((call) => {
    active += 1;
    maxActive = Math.max(maxActive, active);
    active -= 1;
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: 0 }; // 无变化 → 幂等返回
    return { stdout: '', stderr: '', code: 0 };
  });
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });
  const write = (): Promise<unknown> => writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-configs',
    workDir,
    entries: [{ path: 'a.txt', content: '1' }],
    commitMessage: 'noop',
  });
  await Promise.all([write(), write()]);
  assert.equal(maxActive, 1, '同一上传工作副本的 git 操作必须串行（并发会撞 index.lock / 写坏 FETCH_HEAD）');
});

test('git-file-writer: push 失败 → 错误消息脱敏（token 与 repoUrl 均被掩码）', async (t) => {
  const { exec } = installExec((call) => {
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: 1 }; // 有变化 → 走 commit + push
    if (gitCommandOf(call) === 'push') {
      return { stdout: '', stderr: `fatal: couldn't find remote ref ${TEST_TOKEN} @ ${'https://github.com/xiaojun/dsh-configs'}`, code: 128 };
    }
    return { stdout: '', stderr: '', code: 0 };
  });
  const workDir = await tempWorkDir(t);
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });

  await assert.rejects(
    writer.writeFiles({
      repoUrl: 'https://github.com/xiaojun/dsh-configs',
      workDir,
      entries: [{ path: 'a.txt', content: '1' }],
      commitMessage: 'x',
    }),
    (err: unknown) => {
      assert.ok(err instanceof GitFileWriterError);
      assert.ok(!err.message.includes(TEST_TOKEN), '错误消息不得回显 token');
      assert.ok(err.message.includes('[REDACTED]') || err.message.includes('[REPO_URL]'), 'token/repoUrl 必须被掩码');
      return true;
    },
  );
});

test('git-file-writer: 仓库地址校验（userinfo / 空白拒绝）→ 零命令执行', async () => {
  const { exec, calls } = installExec(okScript());
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });
  await assert.rejects(
    writer.writeFiles({
      repoUrl: 'https://user:token@github.com/x/y',
      workDir: os.tmpdir(),
      entries: [{ path: 'a', content: '1' }],
      commitMessage: 'x',
    }),
    GitFileWriterError,
  );
  assert.equal(calls.length, 0, '地址非法必须零 git 命令执行');
});

test('git-file-writer: 工作副本非空且非 git 仓库 → 拒绝', async (t) => {
  const workDir = await tempWorkDir(t);
  await fs.writeFile(path.join(workDir, 'junk.txt'), 'x');
  const { exec, calls } = installExec(okScript());
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });
  await assert.rejects(
    writer.writeFiles({
      repoUrl: 'https://github.com/x/y',
      workDir,
      entries: [{ path: 'a', content: '1' }],
      commitMessage: 'x',
    }),
    GitFileWriterError,
  );
  assert.ok(!calls.some((c) => c.args[0] === 'clone'), '非空非仓库目录不得 clone');
});

// issue #120：Android 上 credential helper 走 `sh -c`，helper 无法执行 ⇒ 换 env 注入认证头重试。
test('git-file-writer: credential helper 无法执行 → 用 env 注入认证头重试 push 成功', async (t) => {
  const workDir = await tempWorkDir(t);
  const { exec, calls } = installExec((call) => {
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: 1 }; // 有变化 → commit + push
    if (gitCommandOf(call) === 'push' && call.opts.env === undefined) {
      return {
        stdout: '',
        stderr: "fatal: cannot exec 'git credential-store --file=/data/user/0/x/cache/tmp/dsh-git-cred-1/credential get': No such file or directory",
        code: 128,
      };
    }
    return { stdout: '', stderr: '', code: 0 };
  });
  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec });

  const result = await writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-configs',
    workDir,
    entries: [{ path: 'a.txt', content: '1' }],
    commitMessage: 'publish',
  });

  assert.equal(result.pushed, true);
  const pushes = calls.filter((c) => gitCommandOf(c) === 'push');
  assert.equal(pushes.length, 2, 'helper 失败后必须重试一次');
  const retry = pushes[1]!;
  assert.ok(!retry.args.some((a) => a.startsWith('credential.helper=store')), '重试不得再走 helper');
  assert.equal(retry.opts.env?.['GIT_CONFIG_COUNT'], '2');
  assert.equal(retry.opts.env?.['GIT_CONFIG_KEY_0'], 'credential.helper');
  assert.equal(retry.opts.env?.['GIT_CONFIG_VALUE_0'], '');
  assert.equal(retry.opts.env?.['GIT_CONFIG_KEY_1'], 'http.https://github.com/.extraheader');
  assert.equal(
    retry.opts.env?.['GIT_CONFIG_VALUE_1'],
    'AUTHORIZATION: basic ' + Buffer.from('oauth2:' + TEST_TOKEN).toString('base64'),
  );
  assert.ok(!retry.args.join(' ').includes(TEST_TOKEN), 'token 不得进 argv');
});

test('git-file-writer: clone 遇 helper 无法执行 → 清掉半成品目录后重试', async (t) => {
  const workDir = await tempWorkDir(t);
  let cloneAttempts = 0;
  const { exec } = installExec((call) => {
    if (gitCommandOf(call) === 'clone') {
      cloneAttempts += 1;
      if (cloneAttempts === 1) {
        return { stdout: '', stderr: "fatal: cannot exec 'git credential-store get': No such file or directory", code: 128 };
      }
    }
    if (gitCommandOf(call) === 'diff') return { stdout: '', stderr: '', code: 0 };
    return { stdout: '', stderr: '', code: 0 };
  });
  // 第一次 clone 前造一个半成品目录：真实 git 失败会留下 .git 残骸，重试前必须清空
  const scriptedExec: GitExecFn = async (cmd, args, opts) => {
    if (args.includes('clone') && cloneAttempts === 0) {
      await fs.mkdir(path.join(workDir, '.git', 'partial'), { recursive: true });
    }
    return exec(cmd, args, opts);
  };

  const writer = createGitFileWriter({ credentials: { getToken: async () => TEST_TOKEN }, exec: scriptedExec });
  const result = await writer.writeFiles({
    repoUrl: 'https://github.com/xiaojun/dsh-configs',
    workDir,
    entries: [{ path: 'a.txt', content: '1' }],
    commitMessage: 'noop',
  });

  assert.equal(cloneAttempts, 2, 'clone 失败后必须重试一次');
  assert.equal(result.pushed, false);
  // 第一轮留下的 .git 残骸必须被清掉，目录里只剩本轮写入的文件
  assert.deepEqual(await fs.readdir(workDir), ['a.txt']);
});
