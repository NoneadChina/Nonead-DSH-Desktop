# MCP连接器：DeepSeek Harness 的专业数据源市场



> DeepSeek Harness 的 MCP 数据市场：汇聚各类垂直领域数据厂商与开放数据源，通过超百个 MCP连接器接入 MCP Server，统一授权、查找工具与连接排障。

<!-- catalog-directory:start -->
## 按分类寻找连接器

覆盖全部 9 个分类，数量按连接器去重统计。点击分类查看完整列表；以下为部分连接器示例。

| 分类 | 连接器数量 | 主要连接器 |
|---|---:|---|
| [企业数据](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E4%BC%81%E4%B8%9A%E6%95%B0%E6%8D%AE) | 2 | [企查查·企业工商](https://github.com/duhu2000/dsh-mcp-connector/blob/main/catalog/catalog.json)、[企查查·招投标](https://github.com/duhu2000/dsh-mcp-connector/blob/main/catalog/catalog.json) |
| [金融投资](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E9%87%91%E8%9E%8D%E6%8A%95%E8%B5%84) | 14 | [Wind·股票数据](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/wind-stock-data.json)、[TuShare](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/tushare.json)、[AKShare](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/akshare.json) 等 |
| [法律合规](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E6%B3%95%E5%BE%8B%E5%90%88%E8%A7%84) | 5 | [企查查·法律数据](https://github.com/duhu2000/dsh-mcp-connector/blob/main/catalog/catalog.json)、[北大法宝·法律检索](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/pkulaw-legal.json)、[巴西参议院开放数据](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/brazil-senate-open-data.json) 等 |
| [调研分析](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E8%B0%83%E7%A0%94%E5%88%86%E6%9E%90) | 42 | [飞常准航空数据](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/variflight-aviation-data.json)、[智慧芽专利与文献](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/patsnap.json)、[OpenAlex 全球学术研究](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/openalex-research-catalog.json) 等 |
| [办公协作](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E5%8A%9E%E5%85%AC%E5%8D%8F%E4%BD%9C) | 17 | [腾讯文档](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/tencent-docs.json)、[飞书开放平台](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/feishu.json)、[Notion](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/notion.json) 等 |
| [开发工具](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E5%BC%80%E5%8F%91%E5%B7%A5%E5%85%B7) | 23 | [GitHub](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/github.json)、[Playwright](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/playwright.json)、[Chrome DevTools](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/chrome-devtools.json) 等 |
| [设计创意](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E8%AE%BE%E8%AE%A1%E5%88%9B%E6%84%8F) | 10 | [Canva 可画](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/canva.json)、[draw.io](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/drawio.json)、[可灵 AI（AceDataCloud）](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/kling.json) 等 |
| [效率工具](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E6%95%88%E7%8E%87%E5%B7%A5%E5%85%B7) | 7 | [企查查·智能文档解析](https://github.com/duhu2000/dsh-mcp-connector/blob/main/catalog/catalog.json)、[高德地图](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/amap.json)、[百度地图](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/baidu-maps.json) 等 |
| [其他](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md#%E5%85%B6%E4%BB%96) | 2 | [FlyBest·AI 订酒店](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/flybest-hotels.json)、[QVerisMCP](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/connectors/qveris-capability-network.json) |

[完整分类目录](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md) · [近期新增](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/RECENT-ADDITIONS.md)
<!-- catalog-directory:end -->

从持续更新的连接器目录接入 MCP Server；跨当前范围内已启用连接查找工具，查看易读参数、来源和最后成功缓存时间，并在发现异常时检查连接或重新发现工具。支持 OAuth 2.0 PKCE、API Key、Streamable HTTP/stdio 与 `mcpServers` JSON 导入。

OAuth 是否可用取决于服务商的客户端注册、账号权限与授权政策；连接已保存、工具已发现和业务调用成功应分别验证。

> 注：“技能扩展”指通过 MCP 工具和 Prompt 扩展智能体能力，本包不会伪装成独立 DSH Skill。

[English documentation](https://github.com/duhu2000/dsh-mcp-connector/blob/main/README.en.md) · [English overview](#english-overview)

### English overview

**MCP Connector for DeepSeek Harness** is a specialist data marketplace connecting data providers and open data sources, with authorization, cross-connection tool search and troubleshooting in one panel. Browse a continuously updated catalog of 100+ connectors; connect through OAuth 2.0 PKCE, API keys, Streamable HTTP/stdio or `mcpServers` JSON import.

Install into the profile loaded by your host: use `--profile desktop` with the Desktop-provided CLI, or `--profile web` for default Web. See [installation](#安装), then select **EN** in the toolbar. The interface supports Chinese and English; provider descriptions and user content keep their original language. Provider accounts, permissions and any provider fees are separate from this plugin. Saving a connection or discovering tools does not guarantee a successful business call.

![MCP Connector — English interface](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/en/01-market-overview.jpg)

*Credential-free Mock demonstration; counts are fixtures, not production statistics.* [Full English guide and demo](https://github.com/duhu2000/dsh-mcp-connector/blob/main/README.en.md)

### 中文界面与使用说明

**中英文界面：** 顶部工具栏直接展示「中文 / EN」按钮，完整语言名称保留在提示中，并记住当前浏览器中的主动选择。插件 Host 默认跟随 DSH 显式语言偏好，缺失时保持中文；可配置 `locale: zh-CN` 或 `locale: en`。面板切换不重启 DSH；详情见 [语言设置](docs/I18N.md)。

### 首页推荐

首页“推荐”默认展开十张数据源卡片：企查查·企业工商、Wind·股票数据、高德地图、智慧芽专利与文献、企查查·法律数据、北大法宝·法律检索、TuShare、OpenAlex 全球学术研究、PubMed 生物医学文献、IMF 全球宏观经济统计。按固定顺序展示，不因连接状态重排；这是数据场景推荐，不是使用量排行。社区接入不代表数据机构官方 MCP；授权、额度与实际调用需分别验证。办公与开发连接器仍可通过分类和搜索找到。

![Homepage recommendations](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/08-ten-recommendations.jpg)

### 工具查找与故障处理

在“工具”页统一查找当前工作区可见、已启用连接的工具。输入工具名或描述，再按连接、服务和最近发现状态筛选；点击“参数详情”查看类型、必填项与嵌套结构。未选择工作区时，仅展示全局连接。

结果标注来源和最后成功缓存时间。发现失败时仍可查看已有缓存，但不代表服务当前可调用。展开“连接状态与故障处理”，按建议使用“检查连接”或“重新发现工具”。健康连接五分钟后到期，页面保持连接时后台检查到期任务；失败时退避，鉴权失败暂停自动重试。

详见[工具工作台教程](docs/USER-GUIDE.md#51-工具工作台统一查找工具)。工具页用于发现与诊断，不执行目标工具；参数摘要与原始安全缓存均有裁剪边界。

### 企查查智能按需模式（开发分支预览，尚未发布）

在已验证的 Native Host `0.2.2-rc.1` 上，正常插件启动可自动提供“智能工具”入口。首期只识别当前配置账号、单个明确授权下的企业数据六个服务；默认保持兼容模式，一次预览确认即可为新会话启用按需模式，已有会话保留原模式。无需逐服务修改注入配置。

真实工具仍须完整定义指纹绑定的独立只读核验，来源合并仍须独立等价核验；本分支不自动生成这些批准，未核验时 prepare 会拒绝。生产安装与真实收益尚待验收。支持边界、恢复和回退见[按会话工具注入说明](docs/SESSION-TOOL-INJECTION.md#企查查企业数据智能按需模式开发分支预览)。

[用户手册](docs/USER-GUIDE.md) · [第三方连接器上架指南](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md) · [首次贡献](docs/FIRST-CONTRIBUTION.md) · [参与贡献](CONTRIBUTING.md) · [问题反馈](https://github.com/duhu2000/dsh-mcp-connector/issues)

[![CI](https://github.com/duhu2000/dsh-mcp-connector/actions/workflows/ci.yml/badge.svg)](https://github.com/duhu2000/dsh-mcp-connector/actions/workflows/ci.yml)
[![npm](https://img.shields.io/npm/v/dsh-mcp-connector.svg)](https://www.npmjs.com/package/dsh-mcp-connector)
[![npm downloads](https://img.shields.io/npm/dm/dsh-mcp-connector.svg)](https://www.npmjs.com/package/dsh-mcp-connector)
[![GitHub stars](https://img.shields.io/github/stars/duhu2000/dsh-mcp-connector?style=flat)](https://github.com/duhu2000/dsh-mcp-connector/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/duhu2000/dsh-mcp-connector?style=flat)](https://github.com/duhu2000/dsh-mcp-connector/forks)
[![GitHub Release](https://img.shields.io/github/v/release/duhu2000/dsh-mcp-connector)](https://github.com/duhu2000/dsh-mcp-connector/releases/latest)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Registry connectors](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2Fduhu2000%2Fdsh-mcp-connector-registry%2Fmain%2Fcatalog-stats.json&query=%24.registryCount&label=Registry%20connectors&color=5865f2)](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/catalog-stats.json)
[![Marketplace cards](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2Fduhu2000%2Fdsh-mcp-connector-registry%2Fmain%2Fcatalog-stats.json&query=%24.marketCount&label=Marketplace%20cards&color=16a34a)](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/catalog-stats.json)

### 按数据场景找连接器

企业数据、金融投资、法律合规与调研分析是专业数据入口；办公协作、开发工具等能力可在完整目录中查找。

[浏览完整分类目录](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/CONNECTOR-DIRECTORY.md) · [查看近期新增数据源](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/RECENT-ADDITIONS.md)

目录随正式卡片上架更新，无需等待插件发版。候选草稿不计入已上架数量；连接与工具发现成功不等于全部业务调用已验证。

<!-- npm-download-trend:start -->
[![npm 累计下载趋势](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/metrics/npm-downloads.png)](https://github.com/duhu2000/dsh-mcp-connector/blob/main/docs/metrics/npm-downloads.json)
npm 下载次数包含升级、重复安装及自动化下载，不等于独立用户数或成功安装数；数据截止日期见图中 UTC 标注。[安装使用](#开始使用) · [首次成功教程](docs/tutorials/FIRST-SUCCESS-SCENARIOS.md)
<!-- npm-download-trend:end -->

## 开始使用

在插件市场搜索完整包名 **`dsh-mcp-connector`**，或按当前宿主实际加载的 profile 安装。Desktop 先启动应用完成初始化，通过应用菜单“管理 dsh 命令…”注册或修复配套 CLI，完全退出应用后在新终端执行：

```bash
dsh plugin --profile desktop add dsh-mcp-connector
```

默认 Web 使用：

```bash
dsh plugin --profile web add dsh-mcp-connector
```

自定义部署请替换 profile 名称；设置了 `DSH_HOME` 时，终端须沿用与宿主相同的值。npm 安装的 CLI 可能拒绝管理 `desktop`，此时应使用 Desktop 配套 CLI。

安装或升级后完全重启 DeepSeek Harness Desktop 或 `dsh web`，然后打开左侧「MCP连接器」；也可从“设置 → 插件 → 插件配置 → MCP连接器”直接打开。

Desktop 需要完全退出并重新启动应用；Web 需要停止原 `dsh web` 进程再启动，只刷新网页不会重新加载后端插件。

**先完成一件事：**[查询一家企业的简介](docs/tutorials/ONE-SUCCESS-CASE.md)，按步骤核对授权、工具来源和真实返回。想写体验文章？使用[社区分享素材包](docs/tutorials/SHARING-KIT.md)，包含演示素材、文章提纲和脱敏记录模板。

首次使用建议依次确认：连接已保存且范围正确 → “工具”页能找到预期工具与来源 → 在正常 DSH 会话中通过 Host 审批链完成一次服务商许可的只读调用。缓存可见不等于当前服务可调用。

[首次成功入口：安装 → 连接 → 找到工具 → 首次只读调用](docs/tutorials/README.md)。按任务深入：[三个可验收场景包](docs/tutorials/FIRST-SUCCESS-SCENARIOS.md) · [迁移现有 `mcpServers` JSON](docs/tutorials/JSON-MIGRATION.md) · [OAuth 授权诊断](docs/tutorials/OAUTH-DIAGNOSTICS.md) · [跨连接找工具与恢复](docs/tutorials/TOOL-SEARCH-RECOVERY.md) · [可信状态文案](docs/tutorials/TRUSTED-STATUS-COPY.md)。

![MCP 连接器 43 秒演示](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/demo.gif)

如果它帮你更快地接入 MCP Server，欢迎 [GitHub 点个 Star](https://github.com/duhu2000/dsh-mcp-connector/stargazers)、[提交新的连接器](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md)或[参与贡献](CONTRIBUTING.md)。

## MCP连接器能做什么

| 能力 | 用户得到什么 |
|---|---|
| 持续更新的连接器目录 | 浏览精选与 9 类业务连接器；Registry 更新后刷新即可获取新卡片 |
| 多种接入方式 | 使用 OAuth 2.0 PKCE、API Key、Streamable HTTP/stdio 或 `mcpServers` JSON 接入 |
| 跨连接工具查找 | 在当前范围内已启用连接的最后成功缓存中按名称或描述搜索，并按连接、服务和状态筛选 |
| 易读参数与来源 | 查看类型、必填、枚举、嵌套摘要、来源、缓存时间及安全裁剪后的 Schema |
| 连接排障 | 根据明确的阶段和错误码检查连接或重新发现工具，同时保留可用的最后成功缓存 |
| 作用域与治理 | 管理 project/global 可见范围以及 Connection、Server、Tool 三层规则 |
| 按会话工具注入 | 连接保持在线，对选定连接默认隐藏 schema，只在当前 Agent 临时激活精确工具 |
| 安全生命周期 | 支持凭据本机存储、授权刷新、脱敏备份、快照回滚及失败时保留原连接 |
| 插件更新 | 检测新版本，并在宿主提供兼容 Update Provider 时显示进度、失败原因和回滚结果 |

## 功能

- 左侧主导航入口：DSH `>=0.2.0-rc.2` 使用官方 `sidebar.panellist` 行与原生主面板，继承宿主选中态、折叠提示和无障碍行为；DSH `0.1.x` 自动回退到兼容入口。
- 侧边栏入口可按当前 profile 隐藏；隐藏后仍可从“设置 → 插件 → 插件配置 → MCP连接器”临时打开现有连接器弹框，用完即关。
- 图形化市场：默认“全部”按推荐与 9 类业务分类分章节展示，每章先展示 4 张并可展开；分类栏固定可见，单分类页展示全部卡片。
- 图形化添加：手动 HTTP/stdio、`mcpServers` JSON、连接器描述 URL 三种入口，失败时保留表单并给出修复建议。
- 连接器详情：精选 Prompt 优先展示，点击可带入 DSH 新会话；工具按 Server 分组，支持描述、搜索、参数详情和独立滚动。实时发现失败时显示带时间/陈旧标记的最后成功工具缓存。
- 实时状态：页面通过同源 SSE 接收连接、目录、健康、工具、治理和作用域变化通知并自动刷新；事件不携带连接标识、端点、错误或凭据。
- Prompt 模板：使用 `{{company}}` 等变量，发送前填写真实查询主体。
- 三种接入：OAuth 2.0 PKCE、自定义 HTTP/stdio、导入 `mcpServers` JSON；也支持从连接器描述 URL 安装。OAuth 动态注册兼容公共客户端以及 `client_secret_post` / `client_secret_basic` 机密客户端。
- 市场 Bearer/API Key 连接器先执行 MCP initialize 连通性与凭据校验，全部 HTTP Server 通过后才持久化凭据并进入“已安装”；stdio 卡片可声明多个本机凭据字段及其环境变量映射。
- 生命周期管理：连接持久化、重启恢复、启停、断开、OAuth 自动刷新/退避恢复与撤销；同 issuer 卡片共享一次授权，跨进程锁与独立原子 Grant journal 防止 Desktop/Web 并行时重复消耗 Refresh Token。
- 配置原地编辑：自定义和 JSON 导入连接可在“已安装”中编辑标准化 JSON 并重新连接；敏感值以本机保留标记处理，校验、启动或保存失败时原连接继续可用。
- 本地参数覆盖（#146，0.2.76）：无凭据市场 stdio 连接支持在首次连接确认框填写“高级本地参数”，以及在已安装列表编辑 `argsAppend`、`env`、`cwd`，不修改目录或连接身份；已有值不回传浏览器，支持快照恢复和清除覆盖。首次连接留空沿用市场参数，已有连接留空保留原覆盖；启动失败保留表单可修改重试。不支持 OAuth、凭据绑定、CLI 桥接或完整参数替换；真实 Desktop/Windows 验收尚未完成。
- 配置备份：一键复制/下载可再次导入的脱敏 JSON；连接变更前自动保存最多 20 个本机快照，支持预览与原子恢复。凭据、本地路径和 OAuth Grant 不进入导出结果。
- 连接作用域：新连接可选当前 Workspace 项目或 profile 全局；支持先预览 Server/工具影响，再复制、移动或按 revision 回滚。凭据只存一份，project-only 工具由 DSH Host 强制隔离。
- 三层治理：Connection、Server、Tool 规则按 Tool > Server > Connection > 默认允许解析；变更先预览、按 revision 提交并可回滚，由 DSH Host 的 schema/lookup/dispatch restriction 与最终执行 Guard 真实生效。
- 按会话工具注入：“已安装”连接可选“始终注入”或“按会话启用”。后者不断开 Server，只由 Host 在当前 Agent 隐藏业务工具；明确预览和确认后临时激活精确工具，最长 30 分钟，会话或进程结束后清空。
- 可解释诊断：只报告实际观察结果；未检查或 Host 状态不可见时显示“状态未知”，并提供失败阶段、稳定错误码、建议动作、检查时间和进程内最近成功时间。
- 目录运营：内置目录、远程 registry、本地覆盖，支持 `published` 上下架与 `featured` 精选。
- 独立远程 Registry：新市场卡片合并后客户端刷新即可见，无需重新发布 npm；远程不可用时自动回退内置目录。
- 插件版本与一键更新：版本发现独立于安装来源；页面通过 Update Provider 适配层探测安全更新能力。DSH Market API v1 是首个适配器，支持进度、稳定失败码、回滚及按宿主能力提供的重启/刷新操作；无可用 Provider 时回退到当前插件市场或 npm。
- Registry 工具链：Schema/唯一性/密钥审计、MCP/OAuth 无凭据探针、每周健康巡检。
- 旧企查查 OAuth 插件迁移：扫描并复制工商、法律授权。已迁移的客户可以从市场的“连接异常”或已安装行查看冲突插件、残留条目和恢复步骤。
- 对话工具：`mcp_connector_catalog`、`connect`、`configure`、`import_json`、`export_config`、`snapshot`、`install_from_url`、`status`、`scope`、`health_check`、`policy`、`set_enabled`、`session_tools`、`disconnect`、`refresh_catalog`、`publish`、`tools_list`、`tool_search`、`tool_detail`。搜索/详情只做渐进式能力发现，不执行目标 MCP 工具。

<!-- catalog-stats:start -->
截至 2026-11-17，公共 Registry 已发布 118 条连接器描述；与随包的 4 张企查查卡片合并去重后，市场页可浏览 122 张卡片，覆盖企业数据、金融投资、法律合规、开发工具、办公协作、调研分析、设计创意、效率工具、其他 9 类。首页推荐由当前插件版本的推荐规则决定，不以 Registry featured 数量代表首页推荐数量。Registry 可独立持续更新，实际数量以客户端刷新后的市场页签徽标和上方实时统计徽标为准。
<!-- catalog-stats:end -->

## 界面与演示

| 市场总览 | 连接器详情与精选 Prompt |
|---|---|
| ![市场总览](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/01-market-overview.jpg) | ![连接器详情](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/02-connector-detail.jpg) |
| 工具发现、描述与独立滚动 | JSON 导入 |
| ![工具发现](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/03-tool-discovery.jpg) | ![JSON 导入](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/04-json-import.jpg) |
| 统一工具搜索与来源 | 参数详情与安全 Schema |
| ![统一工具搜索](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/05-unified-tool-search.png) | ![工具参数详情](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/06-tool-parameters.png) |
| 连接诊断与最后成功缓存 |  |
| ![连接诊断](https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/docs/screenshots/07-connection-diagnostics.png) |  |

<!-- generated:media -->截图与 GIF 采集自 v0.2.113（2026-11-18）无凭据 Mock 页面，展示界面而非真实业务验收；市场数量是测试夹具。来源与更新方法见 [素材说明](docs/screenshots/README.md)。<!-- /generated:media -->

## 安装

要求：DeepSeek Harness Desktop/web profile，Node.js 20 或更高版本。

Desktop 使用配套 CLI，初始化后完全退出应用再安装；默认 Web 使用 `web`：

```bash
# Desktop 配套 CLI
dsh plugin --profile desktop add dsh-mcp-connector
# 默认 Web
dsh plugin --profile web add dsh-mcp-connector
```

自定义部署以实际 profile 为准，并在终端沿用宿主的 `DSH_HOME`。默认 Web 也可使用安装脚本（其他 profile 需设置 `DSH_PROFILE`）：

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/duhu2000/dsh-mcp-connector/main/install.sh)
```

重复执行安装命令即可升级。安装或升级后需完全退出并重启 DeepSeek Harness Desktop；使用 `dsh web` 时需先停止原进程再启动，`EADDRINUSE 127.0.0.1:3080` 表示已有实例正在运行。

## 使用

1. 点击左侧“MCP连接器”，或从“设置 → 插件 → 插件配置 → MCP连接器”点击“打开 MCP连接器”。
2. 在市场中选择连接器，确认“当前项目”或“所有项目（全局）”，再完成授权或配置。
3. 打开卡片详情，可点击示例 Prompt 的发送按钮，在当前工作区创建/复用空白会话并写入草稿。已有文字或附件时会保留原草稿并另建会话；核对后再自行发送。
4. 在“已安装”或对话工具中查看、停用、恢复或断开连接。
5. 连接后打开“工具”页，按工具名或描述查找能力，使用连接/服务筛选定位来源；授权、费用及正式调用仍由相应服务与 DSH Host 管理。

连接成功后，工具按 `mcp__<serverName>__*` 前缀提供给模型。

分类浏览、鉴权与连接状态、自定义 HTTP/stdio、JSON 导入、脱敏备份、可解释诊断、兼容矩阵、责任边界与故障排查见完整的[用户手册](docs/USER-GUIDE.md)。

## 中文教程与生态入口

- [用户手册：安装、授权、诊断、兼容性与故障排查](docs/USER-GUIDE.md)
- [首次成功入口：安装、连接、找工具和首次只读调用](docs/tutorials/README.md)
- [任务教程：JSON 迁移、OAuth 诊断、跨连接找工具与恢复](docs/USER-GUIDE.md#按任务开始)
- [配置备份：脱敏导出、快照与恢复边界](docs/CONFIG-BACKUP.md)
- [连接作用域：project/global 继承、复制、移动与回滚](docs/CONNECTION-SCOPES.md)
- [连接、Server 与 Tool 治理](docs/TOOL-GOVERNANCE.md)
- [按会话启用工具：显式激活、TTL 与 Host 安全边界](docs/SESSION-TOOL-INJECTION.md)
- [工具试运行：官方 API 证据与安全设计](docs/TOOL-TRIAL-DESIGN.md)
- [插件更新：版本检测、Provider 与回滚](docs/PLUGIN-UPDATE.md)
- [国际化：`locale` 配置、词典约定与翻译完备性门禁](docs/I18N.md)
- [市场注册：本地卡片、公共 Registry 与 OAuth 要求](docs/MARKET-REGISTRATION.md)
- [第三方连接器上架指南](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md)
- [首次贡献：从 good first issue 到第一个 PR](docs/FIRST-CONTRIBUTION.md)
- [开发、Fork 与贡献指南](CONTRIBUTING.md)
- [增长基线与月度复盘模板](docs/GROWTH-BASELINE.md)

## 配置

Bundle 默认配置位于 `cordis.patch.yml`：

```yaml
- id: mcp-connector
  name: dsh-mcp-connector
  config:
    catalogUrl: 'https://cdn.jsdelivr.net/gh/duhu2000/dsh-mcp-connector-registry@main/catalog.json'
    persistSecrets: true
    entryPrefix: mcp
    refreshSkewMs: 300000
    openBrowser: true
    showSidebarEntry: true
    compactManagementTools: false
    locale: 'auto'
    frameAncestors: ['self']
```

`catalogUrl` 默认通过 jsDelivr CDN 读取公共 [dsh-mcp-connector-registry](https://github.com/duhu2000/dsh-mcp-connector-registry)，支持 ETag/TTL 缓存；主源失败时自动尝试 GitHub raw 备用源，再回退到上次缓存或随包内置目录。jsDelivr 的分支 URL 可能存在缓存延迟，因此 Registry 合并后的新卡片不保证秒级出现。需要离线/私有模式时可将 `catalogUrl` 显式设为空字符串；显式配置其他目录 URL 时不会自动切换到公共备用源。

远程目录请求（包括备用源）支持 `HTTP_PROXY`、`HTTPS_PROXY`、`NO_PROXY` 及其小写形式；同时存在时小写变量优先，未设置 `HTTPS_PROXY` 时 HTTPS 请求使用 `HTTP_PROXY`。代理地址须为 HTTP(S) URL；需要直连的目标可加入 `NO_PROXY`（例如 `localhost,127.0.0.1`）。Node.js 20+ 无需添加 `--use-env-proxy`；此行为不会修改 Host 的全局 fetch dispatcher 或 MCP 传输配置。

代理变量必须存在于正在运行的 DSH 进程中。修改后请完全退出并重启 DSH Desktop，或从已设置变量的终端启动 `dsh web`；修改 Windows 用户环境变量不会更新已有进程。连接器不会读取系统代理设置，也不会猜测本机代理地址。

`entryLocation` 控制入口出现在哪里，取值为 `both`（默认：侧栏图标与设置页的快捷打开按钮都可用）、`sidebar`（只保留侧栏图标，设置页不提供打开按钮）、或 `settings`（隐藏侧栏图标，只从设置页进入）。三档都至少保留一处入口，避免面板变得无法打开。传给插件配置的非法值会被 schema 拒绝，而不是静默接受。

从旧版升级时，若设置文档里只有 `showSidebarEntry` 而没有 `entryLocation`，插件按旧字段的实际行为翻译：`true` → `both`（旧版侧栏可见、设置页也有打开按钮），`false` → `settings`。这样升级既不会悄悄删掉既有入口，也不会让隐藏过的侧栏重新出现。分层解析中用户自己的覆盖优先于部署基线；「恢复默认」会同时清掉新字段与旧的布尔覆盖。

在 **设置 → MCP连接器** 中可以切换入口位置或恢复默认。当前 Desktop 通过 `configForms` 将偏好写入当前 profile；旧版宿主通过 `settingsScope` 保存。若宿主未提供这两种服务，或未提供放置卡片的设置页入口，仍可从侧栏打开连接器。要更改入口位置，请在启用了设置服务和设置页的宿主中打开同一 profile。

`showSidebarEntry` 默认为 `true`，为兼容既有配置保留；一旦显式设置 `entryLocation`，它不再影响界面。关闭入口只隐藏快捷方式，不停用连接器、已连接 MCP Server 或工具。

`compactManagementTools` 默认为 `false`，兼容原有对话管理工具。希望降低管理工具上下文开销时，可在插件配置中设为 `true` 并重载插件（必要时重启 DSH），下一次推理使用新工具集：

- 只注册 `mcp_connector_discover`（市场、连接状态、缓存工具搜索/详情）和 `mcp_connector_session_tools`（原有会话工具可见性管理）两个入口。
- 连接、授权、编辑、导入、快照、迁移等管理操作使用 **MCP连接器界面**；精简模式没有任意工具执行代理，也不自动加载全部管理工具。纯对话部署或依赖旧工具名的自动化应保持 `false`。
- 此开关不减少已连接服务的业务工具数量，不停用连接、不迁移凭据、不修改作用域/治理规则。业务工具需要按需可见时，仍使用原有“按会话启用”。会话确认、TTL 与 Host 审批保持不变。
- 例如发现入口可用 `{"action":"search","query":"天气","limit":5}`；查询连接状态可用 `{"action":"status"}`。详情使用 `action=detail` 和必填 `toolName`，市场搜索使用 `action=catalog` 与可选 `keyword`。
- 设回 `false` 并重载插件可恢复旧管理工具名；不要同时运行两份插件。工具数量和 schema 大小的减少不等于实测 token 或费用节省。

`locale` 选择面板与对话工具返回文案的语言，默认为 `'auto'`：跟随用户在 DSH「设置 → Language」里的选择（即 `@deepseek-ai/dsh-client-locale` 的 `preference`），读不到时再按 `LC_ALL` / `LC_MESSAGES` / `LANG`，仍无法识别时回退中文。界面语言属于用户偏好，插件不覆盖它：中文用户不做任何设置仍是中文（中文是 DSH 默认语言），在 DSH 里选了 English 的用户会直接得到英文。也可写成 `'zh-CN'` / `'en'` 强制指定。修改后需重载插件。

连接器名称、厂商、分类、URL 与错误码不参与翻译，两种语言使用同一份目录。详见 [docs/I18N.md](docs/I18N.md)。

`frameAncestors` 默认为 `['self']`，即面板页面（`/mcp-connector/ui/`）的 CSP 只允许同源页面内嵌，是既有行为，不做任何放宽。在桌面壳（Tauri/Electron）里把面板嵌进壳窗口时，祖先源与面板自身不同源，浏览器会以 `Framing '...' violates the following Content Security Policy directive: "frame-ancestors 'self'"` 拦截并导致面板白屏；此时需要由部署方/用户显式追加外壳源：

```yaml
frameAncestors: ['self', 'http://tauri.localhost', 'tauri://localhost']
```

这是有意的安全取舍，不是遗漏：`frame-ancestors` 无法验证嵌入方到底是谁，所以插件不会默认把 Tauri 之类的外壳源硬编码进去——写进白名单就等于允许任何跑在该源上的页面内嵌本机面板。取值只接受 CSP 关键字（`self` / `none` / `*`）与 host-source（`https://*.example.com`、`127.0.0.1:3080`、`tauri://localhost`、`http://tauri.localhost:1420` 等，可带 scheme、端口与路径）；含 `;`、逗号、空格或 `'unsafe-inline'` 一类非 host-source 关键字的值会被整条丢弃（避免 CSP 头注入），过滤后为空则回退 `['self']`，而不是放行任意源。请只填自己信任的源。

## 兼容性与责任边界

| 项目 | 当前边界 |
|---|---|
| 宿主与运行时 | DSH Desktop / `web` profile，Node.js 20+ |
| MCP 客户端 | 官方 `@deepseek-ai/dsh-mcp-client` `^0.1.1-rc.2` |
| 传输 | Streamable HTTP、stdio；旧 `sse` 归一为 Streamable HTTP |
| 配置作用域 | Workspace project / profile global；全局由项目继承，Host 强制隔离，支持预览、复制/移动和 revision 回滚 |
| 配置交换 | JSON 导入、脱敏导出、最多 20 个本机快照、预览与原子恢复 |
| 治理与执行 | Connection / Server / Tool allow/deny，预览、revision 提交与回滚；暂无工具试运行 |
| 会话注入 | 默认 always；可对单条连接显式选择 session，由 Host restriction + guard 按 Agent 隔离，内存 TTL 最长 30 分钟 |

插件负责目录、授权、连接记录、官方客户端条目、治理规则、只读健康检查、工具发现和诊断；DSH Host 与官方 MCP 客户端负责 transport、stdio 子进程、工具注册、正式工具执行及权限/审批链。治理通过 Host 官方 restriction/guard 生效，插件不会从浏览器旁路调用 MCP 工具。详细状态语义、限制与排障见[用户手册第 7–10 节](docs/USER-GUIDE.md#75-如何理解连接诊断)。

## 开发与发布门禁

```bash
npm run check
npm run marketing:check:live
npm run registry:build
npm run registry:validate
npm run market:check
npm run dev:ui
```

`marketing/metadata.json` 是 npm 描述/关键词、GitHub About/Topics、中英文首屏 CTA 和外部分发文案的事实源。`check` 会离线阻断仓库内漂移；`marketing:check:live` 进一步核对线上 GitHub 与 npm，供元数据调整和月度复盘时执行。`market:check` 检查外部 DSH 市场 PR 与线上目录；`dev:ui` 启动不含真实凭据的本地 mock 市场。CI 使用 `--legacy-peer-deps` 安装显式测试依赖，DSH 运行期 peer 仍由 Host 提供。`v*` Tag 会触发 GitHub Actions；Tag 必须与 `package.json` 版本一致。Release 通过 npm Trusted Publishing (GitHub OIDC) 发布，不依赖长期 `NPM_TOKEN`。

公共 Registry 每次合并后会生成 `catalog-stats.json`；本仓库的定时工作流每小时同步中英文介绍和统计快照。npm 页面中的静态正文随版本发布更新，上方动态统计徽标则直接读取 Registry，可在不发布新 npm 版本时保持实时数量一致。

<!-- generated:version -->当前公开版本为 [`dsh-mcp-connector@0.2.113`](https://www.npmjs.com/package/dsh-mcp-connector)，对应 [GitHub Release v0.2.113](https://github.com/duhu2000/dsh-mcp-connector/releases/tag/v0.2.113)。<!-- /generated:version -->

版本能力与变更记录见 [CHANGELOG.md](CHANGELOG.md)。
Desktop 发版回归见 [docs/DESKTOP-E2E.md](docs/DESKTOP-E2E.md)。
市场卡片、公共 registry 与 OAuth 一键授权要求见 [docs/MARKET-REGISTRATION.md](docs/MARKET-REGISTRATION.md)。
stdio 传输的架构、透传边界与安全约束见 [docs/STDIO-SUPPORT.md](docs/STDIO-SUPPORT.md)。
第三方服务商提交市场卡片请阅读 Registry 的[第三方连接器上架指南](https://github.com/duhu2000/dsh-mcp-connector-registry/blob/main/docs/ONBOARDING.md)，无需修改插件代码或等待插件重新发布 npm。

## 安全与限制

- 凭证只持久化在本机 DSH storage 边界：连接记录使用 storage domain，OAuth 轮换凭据同步保存到 `$DSH_HOME/storages/mcp_connector_grants_v1`。该目录为 0700、文件为 0600；凭证不进入市场目录、Git 仓库、页面、日志或对话历史。
- 市场 Key/Token 校验失败时不写入 storage domain；鉴权、超时、DNS、TLS/网络错误会分类提示。
- 未检查或 Host 状态不可见时显示“状态未知”，不会冒充健康；健康摘要与最近成功时间当前只保留在插件进程内。
- 外部 URL 默认仅允许 HTTPS，HTTP 默认仅允许回环地址。用户自建连接可在明确风险确认后放行 RFC1918 IPv4 / RFC4193 IPv6 ULA 字面量；域名、公网 HTTP、链路本地与云元数据地址仍拒绝。
- 远程目录/描述响应限制 2 MiB，Web API 请求限制 1 MiB；原始 JSON 在归一化前扫描凭据字段。
- 完整覆盖 Streamable HTTP 与 stdio；旧 `sse` 配置在导入/恢复时归一为 Streamable HTTP。重启恢复 stdio 连接时使用透明的启动保护进程包装原命令，`env/cwd` 与持久化记录保持不变；工具注册和正式执行仍由 `@deepseek-ai/dsh-mcp-client` 负责。
- 恢复连接的 `server/discover`、`initialize` 与首次 `tools/list`（含分页）按 `requestTimeoutMs` 限时，最长每次 15 秒；超时结束该连接的子进程，而不是让可选 MCP 卡住 Host 启动。连接保持启用，首次发现完成后的请求仍使用 Host 原有超时。
- 对本身不是 MCP Server 的官方 CLI，使用独立的[受控 CLI Provider](docs/CLI-PROVIDERS.md)桥接为 stdio MCP；只允许代码登记的命令与参数，首个钉钉 `dws` Provider 仅开放只读能力。
- stdio 会启动本机进程：仅导入或连接可信命令/软件包。市场目录只能用 `credentialFields` + `credentialBindings` 声明输入与 env 映射，不得携带真实 token/secret；用户填写值只写入本机连接记录并交给 Host。
- OAuth DCR 的 `client_secret` 与 Access/Refresh Token 采用相同的本机存储边界，不会进入市场 API、状态输出或日志。
- OAuth 连接失败会标明资源发现、服务发现、客户端注册、授权回调或 Token 换取阶段；DCR HTTP 403 表示服务商拒绝未准入客户端，不是用户未点击授权。
- 脱敏导出把 Token/API Key、静态 Header/env 值、stdio 参数、本地目录及带查询参数的 URL 替换为占位符；OAuth 只保留重新授权引用。快照中的完整配置仍只在当前 profile 的 storage domain 内。
- 顶部入口通过 DSH 稳定 `data-slot` 定位并使用 React Portal；DSH 若移除该标记，入口会回退到底部，不影响连接器功能。
- 企查查旧授权经确认后复制。遇到迁移冲突，按指引停用相应旧插件或残留服务条目并完整重启 DSH。授权失效时需要重新授权。[客户处理步骤](docs/USER-GUIDE.md#企查查旧插件迁移后显示连接异常)
- project/global 作用域仅在当前 DSH profile 内生效；不会跨 profile 同步。删除 Workspace 后，原 project-only 绑定保持 fail closed，需手动移动到其他项目或全局。
- 当前没有工具试运行；治理与作用域都由 DSH Host 正式工具执行链强制应用。试运行已完成官方 API 复核，但在 out-of-turn 审批编排和 MCP 副作用元数据缺口补齐前保持 design blocked。快照不能恢复服务端已撤销的 OAuth Grant。

## License

MIT
