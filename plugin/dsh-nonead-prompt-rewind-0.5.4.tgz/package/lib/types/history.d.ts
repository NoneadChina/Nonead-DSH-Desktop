/**
 * Rewind history: one audit record per rewind attempt, partitioned by
 * workspace, bounded per partition.
 *
 * Layout (docs/DEVELOPMENT-GUIDE.zh.md §6.2):
 *
 *   <root>/<workspaceKey>/history.json
 *
 * Each partition keeps the newest `limit` entries (`historyLimit`, default 10).
 * Everything here is host-side and fs-only: the client reads it over the
 * `history` RPC endpoint, never from disk.
 *
 * Invariants:
 * - Writing history NEVER changes a rewind's outcome: callers fire-and-forget
 *   and this module swallows nothing but reports through `onWarn`.
 * - One partition is one file: read-modify-write runs inside a per-path queue,
 *   and the write is tmp+rename (never half-written).
 * - A corrupt file is renamed aside (`history.json.corrupt-<epoch>`) and
 *   replaced with an empty partition — never silently deleted.
 *
 * @module dsh-rewind/history
 */
/** On-disk history schema. */
export declare const HISTORY_FILE_VERSION: 1;
/** File name inside one partition. */
export declare const HISTORY_FILE = "history.json";
/** One workspace partition identity, as stored inside the file. */
export interface HistoryWorkspace {
    readonly key: string;
    readonly workspaceId?: string;
    readonly path?: string;
}
/** Which half of a rewind actually moved. */
export type HistoryOutcome = 'success' | 'failed' | 'partial';
/** How the undo restored state. */
export type UndoMode = 'files' | 'files+refill' | 'files+resend';
/** One rewind attempt. */
export interface HistoryEntry {
    /** `${at}-${randomUUID().slice(0,8)}` */
    readonly opId: string;
    /** Redundant copy of the partition key (guards hand-moved files). */
    readonly workspaceKey: string;
    readonly workspaceId?: string;
    readonly sessionId: string;
    readonly sessionTitle?: string;
    readonly at: number;
    readonly targetSeq: number;
    /** Whether this rewind actually touched files (a journal exists ⇒ undoable). */
    readonly hadFiles: boolean;
    readonly outcome: HistoryOutcome;
    /** Number of log events shadowed by the marker. */
    readonly shadowedEvents: number;
    /** Target message text, newlines collapsed, at most 80 chars. */
    readonly messagePreview: string;
    readonly attachments: number;
    readonly files?: {
        readonly restored: number;
        readonly deleted: number;
        readonly skipped: number;
        readonly uncovered: number;
        /** At most 20 affected paths, relative forms, tail truncated by the reader. */
        readonly preview: readonly string[];
    };
    readonly errorCode?: string;
    /** Host-rendered reason, at most 200 chars. */
    readonly errorText?: string;
    /** Previous non-undone entry of the same session (the rewind chain). */
    readonly chainPrev?: string;
    /**
     * Archive of the folded-away conversation, relative to the archive root
     * (`<sessionId>/<opId>.md`). Absent when archiving was off or failed.
     */
    readonly archivePath?: string;
    /** `journal + rescue` still on disk at write time. */
    undoable: boolean;
    /** Set once: an entry may be undone at most once. */
    undoneAt?: number;
    undoOutcome?: 'success' | 'partial';
    undoMode?: UndoMode;
}
/** One partition file. */
export interface HistoryFile {
    readonly version: typeof HISTORY_FILE_VERSION;
    readonly workspace: HistoryWorkspace;
    entries: HistoryEntry[];
}
/** Constructor options. */
export interface HistoryOptions {
    /** `<dsh home>/rewind-history` (created on demand). */
    readonly root: string;
    /** Per-partition cap (the caller's `historyLimit`). */
    readonly limit: number;
    /** Whether to record the message preview at all (`historyPreview`). */
    readonly preview: boolean;
    /** Injectable clock (tests). */
    readonly now?: () => number;
    /** Injectable warning sink (tests). */
    readonly onWarn?: (message: string, detail?: unknown) => void;
}
/**
 * A workspace record as the host's registry exposes it.
 *
 * `workspaceRegistry.list()` serves `Workspace` ENTITIES, whose identifier
 * field is `id`; `workspaceId` is the spelling used by the RPC `WorkspaceView`
 * and by older registry shapes. Both are accepted so the reverse lookup keeps
 * working across DSH lines: reading only `workspaceId` yielded `undefined`,
 * which blew up inside `safeKeySegment` as
 * "Cannot read properties of undefined (reading 'replace')".
 */
export interface WorkspaceLike {
    readonly id?: string;
    readonly workspaceId?: string;
    readonly path?: string;
    readonly sessionIds?: readonly string[];
}
/**
 * The identifier a registry record carries, under either spelling.
 * @param workspace - one registry record.
 * @returns the non-empty identifier, or undefined when the record has none.
 */
export declare function workspaceIdOf(workspace: WorkspaceLike): string | undefined;
/** Cap on the per-entry path preview list. */
export declare const PREVIEW_PATH_LIMIT = 20;
/** Cap on the stored message preview. */
export declare const PREVIEW_TEXT_LIMIT = 80;
/** Cap on the stored host error text. */
export declare const ERROR_TEXT_LIMIT = 200;
/** Hard ceiling of one partition file (defends against a corrupted preview). */
export declare const PARTITION_BYTES_CAP: number;
/**
 * Resolve the partition key for a session from the Host workspace registry.
 * The Session object carries no `workspaceId` (verified on 0.2.2-alpha.2), so
 * ownership is a reverse lookup over `WorkspaceView.sessionIds`.
 *
 * @returns `ws-<id>` when accounted to a workspace, else undefined.
 */
export declare function workspaceKeyFromRegistry(sessionId: string, workspaces: readonly WorkspaceLike[] | undefined): {
    readonly key: string;
    readonly workspace: WorkspaceLike;
} | undefined;
/**
 * Derive a partition key from a directory when no workspace accounts for the
 * session. The caller MUST pass a canonical (realpath'd) directory: the raw
 * cwd string differs by case, short name, separator and drive spelling.
 */
export declare function cwdKey(canonicalDirectory: string): string;
/** The fallback partition for a session with neither workspace nor a directory. */
export declare function unknownKey(): string;
/** Keep only `[a-zA-Z0-9._-]`, reject `.` / `..` and empty results. */
export declare function safeKeySegment(raw: string | undefined): string;
/** Collapse whitespace/newlines and cap the stored message preview. */
export declare function previewText(text: string, enabled: boolean): string;
/** Cap the stored host error text. */
export declare function errorText(text: string): string;
/** Build a fresh entry id. */
export declare function newOpId(at: number): string;
/**
 * The bounded, partitioned history store. One instance per plugin mount; all
 * writes for one partition serialize through a per-path promise chain.
 */
export declare class HistoryStore {
    private readonly root;
    private readonly limit;
    private readonly preview;
    private readonly clock;
    private readonly warn;
    /** Per-partition write chain; failures do not poison the next write. */
    private readonly queue;
    /** Set by {@link dispose}: no further write may start. */
    private disposed;
    constructor(options: HistoryOptions);
    /** Absolute path of one partition file. */
    partitionPath(key: string): string;
    /**
     * Read one partition. Missing or unreadable files yield an empty partition;
     * a corrupt file is moved aside first (never deleted).
     */
    read(key: string): Promise<HistoryFile>;
    /** List one partition's entries, oldest first. */
    list(key: string): Promise<HistoryEntry[]>;
    /**
     * Append one entry to its partition, trimming the oldest overflow inside the
     * same serialized write. Never rejects: a history failure must not fail the
     * rewind that produced it.
     */
    append(entry: HistoryEntry): Promise<boolean>;
    /** Clear one partition; returns how many entries were removed. */
    clear(key: string): Promise<number>;
    /**
     * Patch one entry in place (undo bookkeeping). Returns false when the entry
     * is gone (trimmed away between the UI read and the click).
     */
    patch(key: string, opId: string, patch: Partial<HistoryEntry>): Promise<boolean>;
    /** The newest not-yet-undone entry of one session (the rewind chain tail). */
    static chainTail(entries: readonly HistoryEntry[], sessionId: string): HistoryEntry | undefined;
    /** Whether `entry` is the chain tail (the only undoable position). */
    static isChainTail(entries: readonly HistoryEntry[], entry: HistoryEntry): boolean;
    /** The previous not-undone entry of the same session, for `chainPrev`. */
    static previousOf(entries: readonly HistoryEntry[], sessionId: string): string | undefined;
    /**
     * Stop accepting writes and wait for the in-flight ones to settle. Called
     * from the plugin's disposer: a fire-and-forget append that lands after the
     * harness started tearing the data directory down races the cleanup and can
     * fail an otherwise clean unload (observed as ENOTEMPTY on Windows).
     */
    dispose(): Promise<void>;
    /**
     * Serialize one write per partition path. A rejected predecessor must not
     * block its successor, so both branches continue the chain.
     */
    private enqueue;
    /** Write tmp + rename, with the size cap applied to the serialized body. */
    private writeAtomic;
}
