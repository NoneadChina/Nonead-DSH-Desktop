import { type ArchiveInput, type ArchiveStats } from './archive.ts';
/** What one write produced. */
export interface ArchiveWrite {
    /** Path relative to the archive root: `<sessionId>/<opId>.md`. */
    readonly relativePath: string;
    /** Rendered counters (for the rewind result line / logging). */
    readonly stats: ArchiveStats;
}
/**
 * Render and persist one archive.
 *
 * @param root - archive root directory (absolute).
 * @param input - the session slice to archive.
 * @returns the written reference, or undefined when the path is unsafe or the
 *   write fails (the caller treats both as "no archive").
 */
export declare function writeRewindArchive(root: string, input: ArchiveInput): Promise<ArchiveWrite | undefined>;
/**
 * Read one archive back by its stored reference.
 * @param root - archive root directory (absolute).
 * @param relativePath - a value previously returned by {@link writeRewindArchive}.
 * @returns the markdown, or undefined when the reference is unsafe or unreadable.
 */
export declare function readRewindArchive(root: string, relativePath: string): Promise<string | undefined>;
