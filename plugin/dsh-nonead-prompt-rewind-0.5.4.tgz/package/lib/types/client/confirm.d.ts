/**
 * The rewind confirmation dialog (plain DOM, no React).
 *
 * One stage: the target is already fixed (the clicked message, or the picked
 * candidate); the dialog shows what will be withdrawn and which files will be
 * restored/deleted, then a single confirm rewinds **the conversation and the
 * files together**. There is no mode selection — see
 * `docs/DEVELOPMENT-GUIDE.zh.md` §4.1.
 *
 * Keyboard: focus starts on Cancel (a destructive confirm must not be the
 * default Enter target); Enter activates the focused button; Cmd/Ctrl+Enter
 * confirms directly; Esc cancels. The listener runs in the document capture
 * phase so Esc is stolen from the composer while the dialog is open. There is
 * no arrow-key cycle: two buttons are reachable with Tab alone.
 *
 * @module dsh-rewind/client/confirm
 */
import type { SessionFace } from '@deepseek-ai/dsh-api-session-controller/client';
import type { CommandNode } from '@deepseek-ai/dsh-client-ui-conversation/client';
import { type ChatOf } from './hidden.ts';
import type { PreviewCall } from './host-rpc.ts';
import type { RewindKey } from './locales.ts';
type Translate = (key: RewindKey, params?: Record<string, unknown>) => string;
export interface ConfirmOptions {
    readonly session: SessionFace;
    /** Durable variant: the target message seq. */
    readonly seq?: number;
    /** Durable variant: the target message time. */
    readonly time?: number;
    /** Pending variant: retract a pre-sent steering message (single-confirm). */
    readonly retract?: {
        readonly itemId: string;
        readonly text: string | null;
    };
    /** Pending variant: executed after the retract confirm closes the dialog. */
    readonly onRetract?: () => void;
    readonly preview: string;
    /** The button that opened the dialog (outside-click ignore target). */
    readonly anchor: HTMLElement;
    readonly t: Translate;
    /**
     * Execute the rewind — conversation and files together. The dialog closes
     * itself first; the callback owns the command + composer-refill lifecycle
     * (see `runRewindAndFill` in portals.tsx).
     */
    readonly onConfirm?: () => void;
}
/**
 * Register the composer focus channel (called once by the client plugin).
 * @param focus - returns the keyboard to one session's composer, caret included.
 */
export declare function registerComposerFocuser(focus: (sessionId: string) => void): void;
/** Close the current dialog, if any, handing the keyboard back to its composer. */
export declare function closeConfirm(): void;
/**
 * Seqs of the command nodes currently matching `match`. Sample BEFORE issuing
 * a new command of the same shape so the subsequent wait can exclude them: a
 * repeated rewind of the same target must not settle on the previous command's
 * stale outcome.
 */
export declare function knownCommandSeqs(session: SessionFace, chatOf: ChatOf, match: (node: CommandNode) => boolean): Set<number>;
/**
 * Resolve the outcome of the newest matching rewind command by watching the
 * session snapshot (command/run + command/done land as one CommandNode).
 * @returns the outcome text-bearing node, or null on timeout.
 */
export declare function waitForCommand(session: SessionFace, chatOf: ChatOf, match: (node: CommandNode) => boolean, timeoutMs: number | undefined, watch: (cb: () => void) => () => void): Promise<{
    kind: 'success' | 'error';
    text?: string;
} | null>;
/** Register the host RPC preview call (null clears it on unload). */
export declare function registerPreviewCall(call: PreviewCall | null): void;
/**
 * Open the rewind confirmation dialog. Single stage: the impact is fetched and
 * rendered in place; only [取消] and [回退] exist.
 */
export declare function openConfirm(opts: ConfirmOptions): void;
export {};
