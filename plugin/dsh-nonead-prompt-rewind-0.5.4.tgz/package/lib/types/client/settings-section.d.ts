/**
 * The plugin's own page inside Settings (`settings.section`, id `rewind`).
 *
 * It renders the rewind history for the CURRENT workspace only: the partition
 * is derived host-side from the active session (`WorkspaceView.sessionIds`
 * reverse lookup), so the client never passes a partition key and cannot read
 * another workspace's history.
 *
 * One entry at most is undoable: the newest not-yet-undone rewind of the active
 * session (the chain tail). Undo restores FILES only — the conversation cannot
 * come back, because `foldSurface` removed those nodes from the surface — and
 * the host refuses when a file changed after the rewind (`stale-undo`).
 *
 * Theming: every element carries a `dsh-rewind-history-*` class from
 * `./styles.ts` whose colours are dsw tokens, so light and dark follow the host
 * theme. No inline colours live here on purpose.
 *
 * @module dsh-rewind/client/settings-section
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ArchiveView, CapsView, HistoryView, UndoOutcome } from './host-rpc.ts';
import type { RewindKey } from './locales.ts';
import { type SettingsCardProps } from './settings-card.tsx';
/** Copy the page reads; the canonical key set lives in `./locales.ts`. */
export type SectionLabelKey = 'settings.nav' | 'settings.workspace' | 'settings.history.empty' | 'settings.history.refresh' | 'settings.history.clear' | 'settings.history.clearConfirm' | 'settings.history.export' | 'settings.history.copied' | 'settings.history.undone' | 'settings.history.undo' | 'settings.history.undoConfirm' | 'settings.history.conversationOnly' | 'settings.history.archive' | 'settings.history.archiveHide' | 'settings.history.archiveFailed' | 'settings.history.count' | 'settings.history.files' | 'settings.history.archiveTitle' | 'settings.history.unavailable' | 'settings.caps.degraded' | 'history.outcome.ok' | 'history.outcome.partial' | 'history.outcome.failed';
/** What the slot registration injects into the page. */
export interface SettingsSectionFace {
    /** The active session's id, or undefined when the window has none. */
    readonly currentSessionId: () => string | undefined;
    /** Read the current workspace's history over the host RPC channel. */
    readonly loadHistory: (sessionId: string) => Promise<HistoryView | undefined>;
    /** Clear the current workspace's history; returns how many were removed. */
    readonly clearHistory: (sessionId: string) => Promise<number | undefined>;
    /** Undo one completed rewind (chain tail only, once per entry). */
    readonly undoHistory: (sessionId: string, opId: string) => Promise<UndoOutcome | undefined>;
    /** Read one rewind's conversation archive (the folded-away dialogue). */
    readonly loadArchive: (sessionId: string, opId: string) => Promise<ArchiveView | undefined>;
    /** The host's capability report, so the page can name what is missing. */
    readonly loadCaps: (sessionId: string) => Promise<CapsView | undefined>;
}
/** Props the settings shell binds for this page. */
export type SettingsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'rewind'> & InjectFace<SettingsSectionFace> & Partial<SettingsCardProps>;
/**
 * The navigation glyph contributed to `settings.section.icon`, addressed by the
 * same `rewind` id as the page: a line that loops back on itself under a left
 * arrow. "Undo" says it in one stroke, and it stays legible at the shell's ~16px
 * nav size. A clock face was rejected on purpose — the harness already uses one
 * for the neighbouring Prompt history page, and two clock-like glyphs would
 * read as the same entry.
 *
 * Colour and the icon container stay the shell's job, so the stroke is
 * `currentColor` and the selected state needs no local styling.
 * @param props - the shell's requested square edge in px, plus the selected flag.
 * @returns the navigation icon element.
 */
export declare function SettingsNavIcon({ size }: Readonly<{
    size: number;
    active: boolean;
}>): React.ReactNode;
/**
 * The Rewind history settings page.
 * @param props - locale seat, shell props, and the injected history face.
 * @returns the page content.
 */
export declare function SettingsSection(props: SettingsSectionProps): React.ReactNode;
/** Re-export for the registration site so it does not import the key union twice. */
export type { RewindKey };
