/** `rewind` namespace dictionaries for the client plugin. */
/** English dictionary — the canonical key set (the harness fallback language). */
export declare const en: {
    'button.aria': string;
    'button.title': string;
    'button.retract.aria': string;
    'button.retract.title': string;
    'popover.title': string;
    'popover.noText': string;
    'popover.retract.title': string;
    'popover.retract.target': string;
    'popover.retract.hint': string;
    'popover.retract.confirm': string;
    'popover.chat': string;
    'popover.chat.hint': string;
    'popover.both': string;
    'popover.both.hint': string;
    'popover.checking': string;
    'popover.noChanges': string;
    'popover.backupDisabled': string;
    'popover.cancel': string;
    'popover.impact.loading': string;
    'popover.impact.failed': string;
    'popover.impact.none': string;
    'popover.impact.restore': string;
    'popover.impact.delete': string;
    'popover.impact.uncovered': string;
    'popover.confirm': string;
    'confirm.irreversible': string;
    'confirm.truncated': string;
    'popover.back': string;
    'backup.title': string;
    'backup.on': string;
    'backup.off': string;
    'cleanup.auto': string;
    'cleanup.auto.on': string;
    'cleanup.auto.off': string;
    'cleanup.maxAge': string;
    'cleanup.maxAge.hint': string;
    'cleanup.invalid': string;
    'cleanup.overridden': string;
    'cleanup.reset': string;
    'cleanup.save': string;
    'cleanup.saving': string;
    'cleanup.saveFailed': string;
    'cleanup.readonly': string;
    'cleanup.unavailable': string;
    'settings.nav': string;
    'settings.workspace': string;
    'settings.history.empty': string;
    'settings.history.refresh': string;
    'settings.history.clear': string;
    'settings.history.export': string;
    'settings.history.undone': string;
    'settings.caps.degraded': string;
    'history.outcome.ok': string;
    'history.outcome.partial': string;
    'history.outcome.failed': string;
    'settings.history.copied': string;
    'settings.history.copyFailed': string;
    'settings.history.clearConfirm': string;
    'undoError.wrongSession': string;
    'settings.history.unavailable': string;
    'settings.history.undo': string;
    'settings.history.undoConfirm': string;
    'settings.history.conversationOnly': string;
    'settings.history.archive': string;
    'settings.history.archiveHide': string;
    'settings.history.archiveFailed': string;
    'settings.history.count': string;
    'settings.history.files': string;
    'settings.history.archiveTitle': string;
    'undoError.alreadyUndone': string;
    'undoError.notUndoable': string;
    'undoError.notTop': string;
    'undoError.stale': string;
    'undoError.crossWorkspace': string;
    'undoError.failed': string;
};
/** The rewind namespace key union. */
export type RewindKey = keyof typeof en;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The in-place rewind controls' copy. */
        rewind: RewindKey;
    }
}
/** Chinese dictionary, checked complete against the en key set. */
export declare const zh: Record<RewindKey, string>;
/** Japanese dictionary, checked complete against the en key set. */
export declare const ja: Record<RewindKey, string>;
/** Spanish dictionary, checked complete against the en key set. */
export declare const es: Record<RewindKey, string>;
/** French dictionary, checked complete against the en key set. */
export declare const fr: Record<RewindKey, string>;
/** German dictionary, checked complete against the en key set. */
export declare const de: Record<RewindKey, string>;
/** Russian dictionary, checked complete against the en key set. */
export declare const ru: Record<RewindKey, string>;
/** Brazilian Portuguese dictionary, checked complete against the en key set. */
export declare const pt: Record<RewindKey, string>;
/**
 * Every dictionary this plugin ships, canonical first. Registration takes this
 * map as a whole, so shipping another language is one dictionary above plus one
 * entry here — no wiring change in `index.ts`.
 */
export declare const CLIENT_DICTS: {
    en: {
        'button.aria': string;
        'button.title': string;
        'button.retract.aria': string;
        'button.retract.title': string;
        'popover.title': string;
        'popover.noText': string;
        'popover.retract.title': string;
        'popover.retract.target': string;
        'popover.retract.hint': string;
        'popover.retract.confirm': string;
        'popover.chat': string;
        'popover.chat.hint': string;
        'popover.both': string;
        'popover.both.hint': string;
        'popover.checking': string;
        'popover.noChanges': string;
        'popover.backupDisabled': string;
        'popover.cancel': string;
        'popover.impact.loading': string;
        'popover.impact.failed': string;
        'popover.impact.none': string;
        'popover.impact.restore': string;
        'popover.impact.delete': string;
        'popover.impact.uncovered': string;
        'popover.confirm': string;
        'confirm.irreversible': string;
        'confirm.truncated': string;
        'popover.back': string;
        'backup.title': string;
        'backup.on': string;
        'backup.off': string;
        'cleanup.auto': string;
        'cleanup.auto.on': string;
        'cleanup.auto.off': string;
        'cleanup.maxAge': string;
        'cleanup.maxAge.hint': string;
        'cleanup.invalid': string;
        'cleanup.overridden': string;
        'cleanup.reset': string;
        'cleanup.save': string;
        'cleanup.saving': string;
        'cleanup.saveFailed': string;
        'cleanup.readonly': string;
        'cleanup.unavailable': string;
        'settings.nav': string;
        'settings.workspace': string;
        'settings.history.empty': string;
        'settings.history.refresh': string;
        'settings.history.clear': string;
        'settings.history.export': string;
        'settings.history.undone': string;
        'settings.caps.degraded': string;
        'history.outcome.ok': string;
        'history.outcome.partial': string;
        'history.outcome.failed': string;
        'settings.history.copied': string;
        'settings.history.copyFailed': string;
        'settings.history.clearConfirm': string;
        'undoError.wrongSession': string;
        'settings.history.unavailable': string;
        'settings.history.undo': string;
        'settings.history.undoConfirm': string;
        'settings.history.conversationOnly': string;
        'settings.history.archive': string;
        'settings.history.archiveHide': string;
        'settings.history.archiveFailed': string;
        'settings.history.count': string;
        'settings.history.files': string;
        'settings.history.archiveTitle': string;
        'undoError.alreadyUndone': string;
        'undoError.notUndoable': string;
        'undoError.notTop': string;
        'undoError.stale': string;
        'undoError.crossWorkspace': string;
        'undoError.failed': string;
    };
    zh: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
    ja: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
    es: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
    fr: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
    de: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
    ru: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
    pt: Record<"backup.off" | "backup.on" | "backup.title" | "button.aria" | "button.retract.aria" | "button.retract.title" | "button.title" | "cleanup.auto" | "cleanup.auto.off" | "cleanup.auto.on" | "cleanup.invalid" | "cleanup.maxAge" | "cleanup.maxAge.hint" | "cleanup.overridden" | "cleanup.readonly" | "cleanup.reset" | "cleanup.save" | "cleanup.saveFailed" | "cleanup.saving" | "cleanup.unavailable" | "confirm.irreversible" | "confirm.truncated" | "history.outcome.failed" | "history.outcome.ok" | "history.outcome.partial" | "popover.back" | "popover.backupDisabled" | "popover.both" | "popover.both.hint" | "popover.cancel" | "popover.chat" | "popover.chat.hint" | "popover.checking" | "popover.confirm" | "popover.impact.delete" | "popover.impact.failed" | "popover.impact.loading" | "popover.impact.none" | "popover.impact.restore" | "popover.impact.uncovered" | "popover.noChanges" | "popover.noText" | "popover.retract.confirm" | "popover.retract.hint" | "popover.retract.target" | "popover.retract.title" | "popover.title" | "settings.caps.degraded" | "settings.history.archive" | "settings.history.archiveFailed" | "settings.history.archiveHide" | "settings.history.archiveTitle" | "settings.history.clear" | "settings.history.clearConfirm" | "settings.history.conversationOnly" | "settings.history.copied" | "settings.history.copyFailed" | "settings.history.count" | "settings.history.empty" | "settings.history.export" | "settings.history.files" | "settings.history.refresh" | "settings.history.unavailable" | "settings.history.undo" | "settings.history.undoConfirm" | "settings.history.undone" | "settings.nav" | "settings.workspace" | "undoError.alreadyUndone" | "undoError.crossWorkspace" | "undoError.failed" | "undoError.notTop" | "undoError.notUndoable" | "undoError.stale" | "undoError.wrongSession", string>;
};
