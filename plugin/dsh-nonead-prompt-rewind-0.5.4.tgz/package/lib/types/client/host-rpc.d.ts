/**
 * The browser half of the rewind RPC channel: the confirmation dialog's impact
 * preview, the `/rewind` candidate list, and the rewind history the settings
 * section renders. All are host queries, so they travel over Connection RPC
 * instead of the human command channel.
 *
 * @module dsh-rewind/client/host-rpc
 */
import type { RewindCandidate } from './candidates.ts';
/** One file affected by a rewind. */
export interface PreviewFileImpact {
    readonly path: string;
    readonly action: 'restore' | 'delete';
}
/**
 * A recorded path whose CURRENT size is over the backup cap: no backup of that
 * state exists, so a rewind cannot restore it. The host reports these
 * separately from `files` for exactly that reason.
 */
export interface PreviewUncoveredPath {
    readonly path: string;
    readonly size?: number;
}
/** One impact probe resolved, failed, or timed out (`null`). */
export type PreviewOutcome = {
    readonly kind: 'success';
    readonly files: readonly PreviewFileImpact[];
    /** Absent on a host that predates the `uncovered` report. */
    readonly uncovered?: readonly PreviewUncoveredPath[];
    readonly backupOff: boolean;
} | {
    readonly kind: 'error';
    readonly text: string;
} | null;
/** Fetch one target's impact through the registered RPC call. */
export type PreviewCall = (sessionId: string, seq: number) => Promise<PreviewOutcome>;
type RpcResult = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
};
/** The slice of the client `connection` service this module reads. */
export interface ConnectionLike {
    readonly rpc: {
        call(channel: string, endpoint: string, payload: unknown, signal?: AbortSignal): Promise<RpcResult>;
    };
}
/** Resolve one target's file impact over RPC. */
export declare function previewOverRpc(connection: ConnectionLike | undefined, sessionId: string, seq: number): Promise<PreviewOutcome>;
/** Fetch the full rewind candidate list over RPC. */
export declare function candidatesOverRpc(connection: ConnectionLike | undefined, sessionId: string): Promise<readonly RewindCandidate[] | undefined>;
/** One history entry, as the host serializes it. */
export interface HistoryEntryView {
    readonly opId: string;
    readonly workspaceKey: string;
    readonly sessionId: string;
    readonly sessionTitle?: string;
    readonly at: number;
    readonly targetSeq: number;
    readonly hadFiles: boolean;
    readonly outcome: 'success' | 'failed' | 'partial';
    readonly shadowedEvents: number;
    readonly messagePreview: string;
    readonly attachments: number;
    readonly files?: {
        readonly restored: number;
        readonly deleted: number;
        readonly skipped: number;
        readonly uncovered: number;
        readonly preview: readonly string[];
    };
    readonly errorCode?: string;
    readonly errorText?: string;
    readonly chainPrev?: string;
    readonly undoable: boolean;
    /** Relative path of the folded-away conversation archive, when one exists. */
    readonly archivePath?: string;
    readonly undoneAt?: number;
    readonly undoOutcome?: 'success' | 'partial';
    readonly undoMode?: 'files' | 'files+refill' | 'files+resend';
}
/** The partition identity plus its entries (newest last). */
export interface HistoryView {
    readonly workspace: {
        readonly key: string;
        readonly workspaceId?: string;
        readonly path?: string;
    };
    readonly entries: readonly HistoryEntryView[];
}
/** Read the current workspace's rewind history over RPC. */
export declare function historyOverRpc(connection: ConnectionLike | undefined, sessionId: string): Promise<HistoryView | undefined>;
/** Clear the current workspace's rewind history; returns how many were removed. */
export declare function clearHistoryOverRpc(connection: ConnectionLike | undefined, sessionId: string): Promise<number | undefined>;
/** What the host reports it can do (a missing flag already degraded the UI). */
export interface CapsView {
    readonly history: boolean;
    readonly undo: boolean;
    readonly fileCheckpointing: boolean;
}
/** Read the host's capability report over RPC. */
export declare function capsOverRpc(connection: ConnectionLike | undefined, sessionId: string): Promise<CapsView | undefined>;
/** One undo attempt: done, partially done, or refused with a host code. */
export type UndoOutcome = {
    readonly kind: 'ok' | 'partial';
    readonly restored: number;
    readonly deleted: number;
} | {
    readonly kind: 'error';
    readonly code: string;
    readonly message: string;
};
/** Restore files to before one completed rewind (at most once per entry). */
export declare function undoOverRpc(connection: ConnectionLike | undefined, sessionId: string, opId: string): Promise<UndoOutcome | undefined>;
/** One rewind's conversation archive as markdown. */
export interface ArchiveView {
    /** Path relative to the archive root. */
    readonly path: string;
    /** The rendered markdown. */
    readonly text: string;
}
/** Read one rewind's conversation archive (the folded-away dialogue). */
export declare function archiveOverRpc(connection: ConnectionLike | undefined, sessionId: string, opId: string): Promise<ArchiveView | undefined>;
export {};
