/**
 * dsh-rewind host half: the `/rewind` command and the Claude-Code-style
 * checkpoint store, composed as one dual-face bundle row (the browser half
 * lives in `src/client/`).
 *
 * Rewind mechanism: planning is pure (`src/rewind.ts`); execution appends a
 * marker `user/message` whose `surfaceOp` replaces the target and every surface
 * node after it with itself, cutting only the model-visible surface
 * (`docs/architecture.md`).
 *
 * File restore (mode `both`) follows Claude Code's checkpointing: unless
 * `fileCheckpointingEnabled` is off, the plugin backs up each tracked
 * write-class edit BEFORE it happens (at the
 * `tools/execute` around-dispatch stage, so an approval short-circuit cannot
 * skip the capture and a denied call never records), commits the backup under
 * the turn's anchor message seq at `tools/post-execute`, and a rewind to
 * message N restores every backup anchored at or after N — modified files are
 * written back to their pre-edit content, files created after N are deleted.
 * Backups persist on disk under the dsh data directory (newest 100 message
 * groups per session), so restores work after a host restart, and they
 * read/write the real file system with plain `node:fs` — independent of the
 * fs service. See `src/snapshot.ts`.
 *
 * @module dsh-rewind
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { Session, SessionId } from '@deepseek-ai/dsh-session';
import { HistoryStore, type HistoryOutcome, type HistoryWorkspace } from './history.ts';
import z from '@deepseek-ai/schemastery';
import { SnapshotStore, type RestoreOutcome } from './snapshot.ts';
import { type CleanupSettings } from './snapshot-cleanup.ts';
export { SnapshotStore } from './snapshot.ts';
export type { CheckpointEntry, FileImpact, PruneStaleReport, RestoreOutcome, RestoreJournal, RestoreJournalState, RestoreReconcileReport } from './snapshot.ts';
export declare const name = "dsh-rewind";
export declare const inject: string[];
/**
 * The internal engine channel the client drives, so the rewind surface never
 * depends on a name a third-party plugin can take. Mirrored by `ENGINE_COMMAND`
 * in `src/client/hidden.ts` — the two bundles share no module.
 */
export declare const ENGINE_COMMAND = "prompt-rewind";
/** Plugin config. */
export interface RewindConfig {
    /** Checkpoint store root (exact path; beats the harness-home default). */
    readonly snapshotDir?: string;
    /** Harness home override (`config.dshHome` > `$DSH_HOME` > `~/.dsh`); feeds the default snapshot/cleanup paths. */
    readonly dshHome?: string;
    /** In-place content dedup (identical before-content → link). Default `true`. */
    readonly dedup?: boolean;
    /** Per-file backup cap in bytes; `0` disables the cap. Default {@link DEFAULT_MAX_FILE_BYTES}. */
    readonly maxFileBytes?: number;
    /** Newest anchor groups (user messages) kept per session. Default {@link MAX_ANCHOR_GROUPS}. */
    readonly maxAnchorGroups?: number;
    /** Automatic snapshot-sweep cadence in ms. Default {@link AUTO_SWEEP_INTERVAL_MS}. */
    readonly autoSweepIntervalMs?: number;
    /** Rewind-history entries kept PER workspace partition. Default 10. */
    readonly historyLimit?: number;
    /** Whether the history entry keeps the target message's text preview. Default true. */
    readonly historyPreview?: boolean;
    /**
     * File-count ceiling for the shell-boundary workspace scan. Default
     * {@link DEFAULT_SCAN_MAX_FILES}; `0` falls back to the same default.
     */
    readonly workspaceScanMaxFiles?: number;
    /**
     * Byte budget for ONE first-sighting pass. Default
     * {@link DEFAULT_SCAN_MAX_BYTES} (200 MiB); `0` falls back to the same
     * default. A workspace full of media would otherwise copy far more than a
     * checkpoint needs, so the pass stops once the next file would cross it and
     * leaves the rest untracked (a later command sees them again).
     */
    readonly workspaceScanMaxBytes?: number;
}
/** The default for {@link FileCheckpointingSettings.fileCheckpointingEnabled}. */
export declare const DEFAULT_FILE_CHECKPOINTING_ENABLED = true;
/**
 * The live file-checkpointing switch (Claude Code's
 * `fileCheckpointingEnabled`): whether NEW before-backups may be recorded.
 */
export interface FileCheckpointingSettings {
    readonly fileCheckpointingEnabled: Volatile<boolean>;
}
/** The live rewind-history switch (off ⇒ no entry is written). Optional on the
 * config surface: an absent value keeps the default (on). */
export interface HistorySettings {
    readonly historyEnabled?: Volatile<boolean>;
}
/**
 * The live workspace-scan switch: whether a mutating shell command first backs
 * up every workspace file the session has never recorded.
 *
 * Without it, a file that `write`/`edit` never touched (a downloaded script, a
 * generated artefact) has no before-image, so a later shell `rm`/`Remove-Item`
 * can never be rewound — the rewind reports success and leaves the file gone.
 * Absent config keeps the default (on), because the "restore everything"
 * guarantee only holds while the pass runs.
 */
export interface WorkspaceScanSettings {
    readonly workspaceScanEnabled?: Volatile<boolean>;
}
/**
 * The plugin's full configuration: store options plus the user-editable policy
 * fields. `.volatile()` resolves them into live references for the Plugins
 * page; the names say what they gate, because a bare `enabled` would read like
 * the entry's own `disabled:` flag.
 */
export interface Config extends RewindConfig, CleanupSettings, FileCheckpointingSettings, HistorySettings, WorkspaceScanSettings {
}
/** The `Config` schema the host resolves and projects as this entry's form. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    snapshotDir: z<string, string, "plain">;
    dshHome: z<string, string, "plain">;
    dedup: z<boolean, boolean, "defined">;
    maxFileBytes: z<number, number, "defined">;
    maxAnchorGroups: z<number, number, "defined">;
    autoSweepIntervalMs: z<number, number, "defined">;
    fileCheckpointingEnabled: z<boolean, boolean, "volatile-defined">;
    autoCleanupEnabled: z<boolean, boolean, "volatile-defined">;
    autoCleanupMaxAgeDays: z<number, number, "volatile-defined">;
    historyEnabled: z<boolean, boolean, "volatile-defined">;
    historyLimit: z<number, number, "volatile-defined">;
    historyPreview: z<boolean, boolean, "volatile-defined">;
    workspaceScanEnabled: z<boolean, boolean, "volatile-defined">;
    workspaceScanMaxFiles: z<number, number, "defined">;
    workspaceScanMaxBytes: z<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    snapshotDir: z<string, string, "plain">;
    dshHome: z<string, string, "plain">;
    dedup: z<boolean, boolean, "defined">;
    maxFileBytes: z<number, number, "defined">;
    maxAnchorGroups: z<number, number, "defined">;
    autoSweepIntervalMs: z<number, number, "defined">;
    fileCheckpointingEnabled: z<boolean, boolean, "volatile-defined">;
    autoCleanupEnabled: z<boolean, boolean, "volatile-defined">;
    autoCleanupMaxAgeDays: z<number, number, "volatile-defined">;
    historyEnabled: z<boolean, boolean, "volatile-defined">;
    historyLimit: z<number, number, "volatile-defined">;
    historyPreview: z<boolean, boolean, "volatile-defined">;
    workspaceScanEnabled: z<boolean, boolean, "volatile-defined">;
    workspaceScanMaxFiles: z<number, number, "defined">;
    workspaceScanMaxBytes: z<number, number, "defined">;
}>>, "plain">;
/** Result envelope of one rewind RPC endpoint. */
type RewindRpcResult = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
        readonly details: object;
    };
};
/** Handler shape of the Host Connection generic RPC registry. */
type RewindRpcHandler = (endpoint: string, payload: unknown, signal: AbortSignal, peer: unknown) => Promise<RewindRpcResult>;
/**
 * Read a service's RAW implementation out of a cordis context.
 *
 * A context proxy hands back a traced wrapper (so method calls see the caller's
 * active context), and its prototype is the service CLASS, not the instance —
 * deriving from it would drop every field the constructor assigned. The
 * implementation itself is reachable through the reflection store, keyed by the
 * service's isolation symbol.
 *
 * @param base - the context to read from.
 * @param name - the service name.
 * @returns the raw implementation, or undefined when it cannot be located.
 */
export declare function rawServiceOf(base: object, name: string): unknown;
/**
 * Re-derive a RAW service instance so that the lookups it performs INSIDE
 * `rpc.handle` resolve from the application root instead of the provider's own
 * context.
 *
 * Why this exists: `rpc.handle(channel, handler)` stores the channel through
 * `owner.effect(() => owner.webServer.register(route), ...)`, where `owner` is
 * the Connection service's own *define-site* context. `webServer` and
 * `connection` are provided by two DIFFERENT plugin fibres, so that read walks
 * the provider's fibre chain, dead-ends at the root fibre (`runtime === null`)
 * and throws `cannot get property "webServer" without inject` — the channel is
 * then never registered and every client query degrades to "host RPC is
 * unavailable" (Settings → Rewind history shows exactly that).
 *
 * A thin inheriting object with `ctx` redefined to the root keeps every method
 * and constructor field unchanged; only the define-site of the service's own
 * lookups moves, and the root context resolves `webServer` through its
 * unchecked path.
 *
 * @param raw - the raw service implementation (see {@link rawServiceOf}).
 * @param root - the application root context.
 * @returns the re-based service, or undefined when the shape is not as expected
 *   (the caller then falls back to the plain service and reports the failure).
 */
export declare function rebaseOnRoot<T extends object>(raw: T, root: object): T | undefined;
/** The slice of `ctx.agents` the RPC handler resolves a session through. */
interface AgentLookup {
    get(sessionId: SessionId): {
        readonly session: Session;
    } | undefined;
}
/** Serve the impact preview, the candidate list, and the rewind history over Connection RPC. */
export declare function createRewindRpcHandler(store: SnapshotStore, agentsOf: () => AgentLookup | undefined, checkpointingEnabled: () => boolean, historyOf: () => HistoryHost | undefined, workspaceOf: (session: Session) => HistoryWorkspace, inflightOf: () => InflightRewinds, settle?: RewindSettle): RewindRpcHandler;
/**
 * Re-sync the harness fs-observation-policy's per-session observation cache
 * after a both-mode restore. The restore writes/deletes through plain
 * `node:fs`, which the policy layer cannot see — that is about the
 * observation cache, not permission enforcement (the restore still touches
 * only the `planRestore` path set). Without this sync, the same
 * session's next write of a restored or rewind-deleted file is judged against
 * the STALE pre-restore observation (the file still "present" at its old
 * version), so the write tool's intent becomes `replaceIfVersion` and
 * `fs-local` refuses the now-missing file with `FS_STALE_VERSION` ("file no
 * longer exists — re-read the file, then retry") — even though the agent is
 * legitimately creating a fresh file after the rewind.
 *
 * Emitting authoritative observations on the same public `fs/observed` event
 * the read/write tools emit tells the policy layer the truth it cannot learn
 * otherwise: deleted files become `{ kind: 'absent' }` (next write uses
 * `createIfAbsent`); restored files become `{ kind: 'present', version }`
 * from a fresh stat (next write CASes against the current version and
 * succeeds). The safety model is unchanged: a LATER external modification
 * after this sync still trips the stale guard exactly as before — only the
 * inconsistency CREATED BY THE RESTORE ITSELF is healed.
 *
 * Per-file failures are silent no-ops: without fs, or when resolve/stat
 * fails, the pre-existing behavior (the write tool's remediated stale error
 * with its re-read hint) remains the fallback.
 *
 * @param ctx - context carrying the `fs/observed` event bus.
 * @param fs - the fs service, or undefined when the deployment has none.
 * @param agent - the rewound agent; its session is the observation owner.
 * @param outcome - the restore outcome (deleted/restored paths to sync).
 */
export declare function syncRestoreObservations(ctx: Context, fs: FileSystem | undefined, agent: RewindSettleAgent, outcome: RestoreOutcome): Promise<void>;
/** Sessions with a rewind currently executing (per-session in-flight guard). */
type InflightRewinds = Set<string>;
/** Everything one command path needs to append a history entry. */
export interface HistorySink {
    readonly store: HistoryStore;
    readonly workspace: HistoryWorkspace;
    readonly preview: boolean;
    /** Snapshot of the live switch at command time. */
    readonly enabled: boolean;
}
/**
 * The mount-level history surface: one store for the whole plugin lifetime.
 * The partition is resolved per session (see {@link historyWorkspaceOf}), so
 * this does not carry a workspace.
 */
export interface HistoryHost {
    readonly store: HistoryStore;
    readonly preview: boolean;
    /** Where conversation archives live (sibling of the history root). */
    readonly archiveRoot: string;
    /** Live switch: false ⇒ no entry is written (a volatile config read). */
    readonly enabled: () => boolean;
}
/** What the rewind path knows when the entry is written. */
interface HistoryDraft {
    readonly targetSeq: number;
    readonly outcome: HistoryOutcome;
    readonly hadFiles: boolean;
    readonly shadowed?: number;
    readonly attachments?: number;
    readonly preview?: string;
    readonly files?: {
        readonly restored: number;
        readonly deleted: number;
        readonly skipped: number;
        readonly uncovered: number;
        readonly preview: readonly string[];
    };
    readonly errorCode?: string;
    readonly errorText?: string;
    readonly undoable?: boolean;
    /** Relative archive path of the folded conversation, when one was written. */
    readonly archivePath?: string;
    /** The journal's id when the caller already minted one (success path). */
    readonly opId?: string;
    /** Fixed timestamp so the entry and the journal agree on "when". */
    readonly at?: number;
}
/** `targetSeq` marker for a failure that never got as far as planning. */
export declare const HISTORY_UNRESOLVED_SEQ = -1;
/**
 * Resolve the history partition for one session. The Session object carries no
 * `workspaceId` on 0.2.2-alpha.2, so ownership is a reverse lookup over
 * `WorkspaceView.sessionIds`. A session the registry does not account for lands
 * in the shared `_unknown` partition: without a trustworthy cwd on the Session,
 * inventing a path-derived key from a guess would mis-file the entry.
 */
export declare function historyWorkspaceOf(ctx: Context, session: Session): HistoryWorkspace;
/**
 * Append one history entry.
 *
 * Runs to completion before the command returns: the write is a few KB with an
 * atomic rename, and awaiting it removes a real race — a client that reads the
 * history right after a rewind would otherwise miss the entry it just created.
 * It still never throws and never alters the rewind result.
 */
export declare function recordHistoryEntry(sink: HistorySink | undefined, session: Session, draft: HistoryDraft): Promise<void>;
/** The target message's text, for the history preview (never throws). */
export declare function previewOfTarget(session: Session, seq: number): string;
/** Minimal agent shape the settle step needs: the session it belongs to. */
export type RewindSettleAgent = {
    readonly session: Session;
};
/**
 * Post-restore bookkeeping every path that rewrites the worktree must run.
 *
 * WHY this is shared: a rewind and a history-page undo BOTH write through plain
 * `node:fs`, so both invalidate the same two pieces of session state — the
 * harness fs-observation cache (see {@link syncRestoreObservations}) and this
 * plugin's incremental turn-anchor cache. Leaving either behind makes the next
 * write of a restored file fail as stale (the failed call then drops its
 * before-capture), which reads to the user as "the file stopped being tracked".
 */
export type RewindSettle = (agent: RewindSettleAgent, outcome: RestoreOutcome) => Promise<void>;
/**
 * The settings entry id this plugin's configuration is addressed by: the PROFILE
 * ROW id from the bundle's patch, not this fiber's nested include id. The loader
 * mounts a bundle's rows under an `include:` scope, so the fiber id carries that
 * prefix while the configuration editor keys entries and profile patches by the
 * bare row id.
 * @param entryId - this fiber's Loader entry id, when it has one.
 * @returns the configuration key, or undefined without an entry.
 */
export declare function profileEntryKey(entryId: string | undefined): string | undefined;
/**
 * Register the `/rewind` command and the checkpoint pipeline (before-capture
 * at `tools/execute`, disk commit at `tools/post-execute`).
 *
 * The command is fs-independent and registers immediately. The checkpoint
 * pipeline needs `fs` to resolve tracked paths to their real display paths,
 * so it mounts through a dynamic `ctx.inject(['fs'])` — it takes effect
 * whenever the fs service becomes available (and never fails the plugin's
 * load when a deployment has no fs; without it, no entries are recorded and
 * `both` restores report "no tracked changes").
 *
 * Capture runs in `tools/execute` (the around-dispatch stage), NOT in
 * `tools/pre-execute`: a pre-execute `{ kind: 'ask' }` short-circuit from
 * another plugin (e.g. dsh-edit-approval) skips later pre-execute listeners,
 * and a denied call never dispatches — so approved calls are still captured,
 * denied calls never leave a pending entry behind. Entries are committed to
 * disk at `tools/post-execute` under the turn's anchor message seq.
 *
 * @param ctx - context carrying `commands`, `tools`, and an optional `fs`.
 * @param config - resolved plugin config: the store options (`snapshotDir`,
 *  `dshHome`, `dedup`) plus the live policy (`fileCheckpointingEnabled`, cleanup
 *  `enabled`/`maxAgeDays`).
 */
export declare function apply(ctx: Context, config?: Config): void;
