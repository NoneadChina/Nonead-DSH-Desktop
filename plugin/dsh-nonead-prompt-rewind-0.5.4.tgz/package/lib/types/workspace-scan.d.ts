/**
 * Workspace discovery for the "restore everything" guarantee.
 *
 * The checkpoint store's original tracking rule is "a file enters the tracked
 * set only after a write-class tool (`write` / `edit`) has handled it". That
 * rule is why a file created or dropped by a shell command and later deleted by
 * another shell command could never be restored: the plugin never held any
 * before-image of it, so a rewind had nothing to write back.
 *
 * This module closes that gap from the other side: before a mutating shell
 * command runs, the workspace is walked and every regular file that the store
 * has never recorded becomes a first-sighting backup. From then on the ordinary
 * message-boundary re-check keeps its state current, so a later `rm` /
 * `Remove-Item` can be rewound exactly like a tool edit.
 *
 * The walk is deliberately bounded:
 * - directory names that never carry user source (dependency caches, build
 *   output, VCS internals) are pruned, so a repo with a populated
 *   `node_modules` does not turn into a 200k-file traversal;
 * - a hard file-count cap stops a pathological tree from stalling a tool call;
 * - symlinks are skipped for the same reason restores skip them — a link would
 *   make the backup name and the written name diverge.
 *
 * Discovery only answers "which regular files exist"; sizing, the per-file cap
 * and the actual byte copy stay in the store, so a huge file is rejected there
 * before it is ever read.
 */
/** Directory names pruned from the walk (matched case-insensitively). */
export declare const DEFAULT_SCAN_EXCLUDED_DIRS: readonly string[];
/** Byte-size ceiling for the whole walk: keeps a tool call responsive. */
export declare const DEFAULT_SCAN_MAX_FILES = 5000;
/**
 * Byte budget for one first-sighting pass. A workspace holding screen
 * recordings, datasets or model weights must not turn the first shell command
 * into a multi-gigabyte copy; once the budget is reached the remaining files
 * stay untracked (they are offered again by the next command).
 */
export declare const DEFAULT_SCAN_MAX_BYTES: number;
/** Directory-depth ceiling, so a deep tree cannot recurse without bound. */
export declare const DEFAULT_SCAN_MAX_DEPTH = 10;
/** Options for {@link discoverWorkspaceFiles}. */
export interface WorkspaceScanOptions {
    /** Directory names to prune (defaults to {@link DEFAULT_SCAN_EXCLUDED_DIRS}). */
    excludeDirs?: readonly string[];
    /** Hard cap on returned files (defaults to {@link DEFAULT_SCAN_MAX_FILES}). */
    maxFiles?: number;
    /** Maximum directory depth below `root` (defaults to {@link DEFAULT_SCAN_MAX_DEPTH}). */
    maxDepth?: number;
}
/**
 * List the regular files under `root`, depth-first, with caches and build
 * output pruned.
 *
 * Symlinks are skipped (both to directories and to files): a restore refuses a
 * linked path, so backing one up would only spend bytes on something that can
 * never be written back. An unreadable directory is skipped rather than thrown:
 * discovery is an optimisation over the tracked set, never a hard dependency of
 * the tool call it precedes.
 *
 * @param root - absolute directory to walk.
 * @param options - pruning and bound configuration.
 * @returns absolute paths of regular files, at most `maxFiles` of them.
 */
export declare function discoverWorkspaceFiles(root: string, options?: WorkspaceScanOptions): Promise<string[]>;
