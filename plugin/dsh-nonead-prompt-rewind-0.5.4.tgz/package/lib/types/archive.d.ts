/**
 * Rewind archives: the folded-away conversation, written to disk at rewind time.
 *
 * WHY: a rewind is irreversible for the CONVERSATION. It appends a marker whose
 * `surfaceOp` replaces the target and everything after it, and the surface is
 * rebuilt by replaying the log through `foldSurface` — the host offers only
 * `append` and `replace`, so there is no way to unfold it again. The events stay
 * in the append-only log, but nothing in the UI can reach them.
 *
 * This module closes that gap cheaply: before the marker shadows them, render the
 * affected surface events into a markdown archive under
 * `<dsh home>/rewind-archives/<session>/<opId>.md`. The history entry carries the
 * relative path, so the settings page can offer "open the archive" later.
 *
 * Nothing here touches the session log or the surface: it only reads events the
 * caller already holds and writes one new file.
 *
 * @module dsh-nonead-prompt-rewind/archive
 */
/** Directory (under the harness home) that holds every archive. */
export declare const ARCHIVE_DIR = "rewind-archives";
/** The structural slice of one session event an archive reads. */
export interface ArchiveEvent {
    readonly seq: number;
    readonly type: string;
    readonly time?: number;
    readonly data?: unknown;
}
/** Everything needed to render one archive. */
export interface ArchiveInput {
    /** Owning session id (used only in the header). */
    readonly sessionId: string;
    /** The history entry id this archive belongs to. */
    readonly opId: string;
    /** Rewind target: the user message the conversation was returned to. */
    readonly targetSeq: number;
    /** When the rewind ran (epoch ms). */
    readonly at: number;
    /** The full event log the caller already holds. */
    readonly events: readonly ArchiveEvent[];
    /** Surface events the marker shadows (the plan's `shadowedSeqs`, flattened). */
    readonly shadowedSeqs: readonly (number | readonly number[])[];
}
/**
 * Flatten the shadowed list. `sourceEventSeqs` groups events that shared one
 * surface node (a user message plus the runtime-context injection right after
 * it), so the nested form must be expanded before lookup — reading only the
 * scalars silently drops every user message.
 * @param seqs - the plan's shadowed seqs, possibly grouped.
 * @returns the flat, de-duplicated seq list in original order.
 */
export declare function flattenShadowedSeqs(seqs: readonly (number | readonly number[])[]): number[];
/** Counters reported by {@link renderArchiveMarkdown}. */
export interface ArchiveStats {
    readonly users: number;
    readonly assistants: number;
    readonly tools: number;
    readonly total: number;
}
/**
 * Render one archive as markdown.
 *
 * Only what a human needs is kept: human user messages, assistant text (tool
 * calls and reasoning are dropped), and a short excerpt per tool result. Injected
 * context rows (`source.kind !== 'user'`) are skipped — they are machine noise,
 * and a rewind of them is not something the user acted on.
 *
 * @param input - the session slice to render.
 * @returns the markdown body plus its counters.
 */
export declare function renderArchiveMarkdown(input: ArchiveInput): {
    readonly markdown: string;
    readonly stats: ArchiveStats;
};
/** One archive file's identity (relative to the archive root). */
export interface ArchiveRef {
    /** `<sessionId>/<opId>.md`, always POSIX-separated. */
    readonly relativePath: string;
}
/**
 * Build the relative archive path for one rewind.
 * @param sessionId - owning session.
 * @param opId - history entry id; it is `${millis}-${8 hex}` by construction.
 * @returns the relative reference.
 */
export declare function archiveRef(sessionId: string, opId: string): ArchiveRef;
/**
 * Resolve an archive reference against the root, refusing anything that escapes.
 * @param root - archive root (absolute).
 * @param relativePath - a value previously produced by {@link archiveRef}.
 * @returns the absolute path, or undefined when the reference is unsafe.
 */
export declare function resolveArchivePath(root: string, relativePath: string): string | undefined;
