/**
 * The branch picker popover: searchable local branch list with the current
 * branch checked, the dirtiness line, switch feedback (success/error), and
 * the footer flows (create branch / Git graph).
 * @module dsh-git-graph/client/chips/BranchPopover
 */
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { BranchesView, SwitchResult } from '../../core/types.ts';
import type { GitGraphKey } from '../locales.ts';
/** Props of the branch picker popover. */
export interface BranchPopoverProps {
    view: BranchesView;
    /** Workspace-level switch verb; resolves to a stable git error on rejection. */
    onSwitch: (branch: string) => Promise<SwitchResult>;
    /** Fired after a successful switch (the owner refetches its status). */
    onSwitched: () => void;
    /** Open the create-branch dialog. */
    onCreate: () => void;
    /** Open the Git graph panel. */
    onGraph: () => void;
    /** Open the create-worktree (new isolated session) dialog. */
    onCreateWorktree: () => void;
    /** Open the worktree manager. */
    onManageWorktrees: () => void;
    /** Close the popover (backdrop / after a successful switch). */
    onClose: () => void;
    t: Translate<GitGraphKey>;
    /** Open downward from the official hero row (the default opens upward from the dock row). */
    hero?: boolean;
}
type PopoverDirection = 'up' | 'down';
/**
 * Pick the side the popover opens on: the side with the room an ideal
 * (uncapped) card needs, else the side with the more room.
 *
 * Every seat has its own side — the dock row opens upward, the hero row opens
 * downward like the official workspace picker beside it — but the room is
 * measured, not assumed: a skin can put the hero row at the bottom of the page
 * (Claude Code's studio home does), where the room below is the footer, so a
 * card that only ever opened downward ran off the window and the composer's own
 * scroll container clipped it. Measuring the ideal height measures the list at
 * its natural size even while the card's `max-height` cap is in effect, so a
 * capped card does not make the room look larger than it is.
 *
 * @param anchor - the box the card is anchored to.
 * @param idealHeight - the popover's uncapped height.
 * @param viewportHeight - the window's height.
 * @param preferred - the side to keep while it has the room.
 */
export declare function resolvePopoverDirection(anchor: {
    top: number;
    bottom: number;
}, idealHeight: number, viewportHeight: number, preferred: PopoverDirection): PopoverDirection;
/**
 * The popover's height with its natural list: the chrome plus the list at its
 * content height, which the card's `max-height` cap has otherwise already
 * shrunk (a scrolled list reports its own box, not its content).
 *
 * The chrome is the card's own outer height minus the list's laid-out outer
 * height, so padding, gaps and every sibling (search box, notice, footer) come
 * along without walking them, and only the list's content has to be read from
 * the list itself.
 */
export declare function idealPopoverHeight(popover: HTMLElement): number;
/**
 * The branch picker popover.
 * @param props - see {@link BranchPopoverProps}.
 */
export declare function BranchPopover({ view, onSwitch, onSwitched, onCreate, onGraph, onCreateWorktree, onManageWorktrees, onClose, t, hero }: BranchPopoverProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=BranchPopover.d.ts.map