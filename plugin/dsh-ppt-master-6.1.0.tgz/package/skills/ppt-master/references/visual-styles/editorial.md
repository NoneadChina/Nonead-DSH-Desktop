# Visual style: editorial

Magazine-grade hierarchy. Columns, hairline rules, a serif / sans interplay, strong typographic structure. For finance, journalism, research, long-form analysis.

---

## 1. Shape & decoration

- Shape language: a rectilinear editorial scaffold favors thin rules and column dividers over repeated cards. Outlined, compound, or exact native contours remain available when they clarify ownership, contrast, sequence, or emphasis; restraint controls their visual weight, not the contour vocabulary. Rounding, when used, stays visually minimal.
- Composition geometry: an oversized drop cap or numeral anchoring the page; a pull quote breaking across columns; a full-height vertical rule the content hangs from; an asymmetric column split instead of mechanically even columns; a figure deliberately crossing a column edge.
- Decoration: hairline rules, kickers / eyebrows, pull quotes, drop-style emphasis — typographic, not graphic. Sparing.
- Whitespace: structured by columns and baseline rhythm; comfortable but information-rich.
- Multi-column text flow where content suits.

## 2. Typography character

- Serif / sans interplay: a serif for headlines or pull quotes against a clean sans body (or the reverse). Clear role contrast.
- Strong vertical hierarchy: kicker → headline → standfirst → body. Generous leading.

> Families are chosen at confirmation `g`; this style asks for an editorial serif/sans *pairing*, not specific fonts. This governs editable native text; decorative-lettering eligibility remains a separate carrier decision.

## 3. Using the deck's colors

- Mostly monochrome text on a light field; a restrained accent may emphasize a rule, highlighted figure, or kicker.
- Restraint — color marks structure and emphasis, not decoration.

> HEX values come from confirmation `e`; this style only governs the monochrome-with-structural-accent discipline — it names no colors.

## 4. Texture / elevation

- Flat to barely-raised. Rules and whitespace separate content, not shadows. Shadow only on a genuine floating element.

## 5. Paired image-rendering

`editorial` — magazine-style infographic look for AI images.

## 6. Illustration propensity

**supportive** — when illustration is selected, editorial elements can anchor, frame, pace, or clarify a page while typography and evidence retain authority. Role, scale, reuse, and placement stay Strategist judgment; an explicit user request wins either way, and `image_usage: none` writes no illustration rows.
