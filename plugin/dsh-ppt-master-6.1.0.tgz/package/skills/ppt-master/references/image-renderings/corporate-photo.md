# Rendering: corporate-photo

Editorial photography style — real subjects, natural composition, professional grading. Used for team photos, lifestyle shots, product photography, and real-world scenarios.

## 1. Style paragraph (paste-ready, 100 words)

> Editorial photography style with natural composition and professional color grading. Subjects appear as real people, real products, real environments — captured with depth-of-field and intentional lighting. Composition follows photographic principles: rule of thirds, leading lines, deliberate foreground/background separation. Lighting is natural or studio-soft, never harsh. Color grading matches the deck's palette temperament — corporate decks lean cool and restrained, lifestyle decks lean warm and golden. Subjects in team or workplace contexts appear diverse and professionally attired. Background is contextual and slightly blurred to keep focus on the subject. Overall feel is authentic, premium, magazine-quality.

---

## 2. Line, texture, depth

| Aspect | Treatment |
|---|---|
| Line quality | N/A — photographic |
| Texture | Natural — skin, fabric, environment textures preserved |
| Depth | True depth-of-field — subject sharp, background subtly blurred |
| Material | Real-world physical materials, professionally lit |
| Mood | Authentic, premium, magazine-editorial |

---

## 3. Human treatment

Apply [`image-generator.md`](../image-generator.md) §5.2 through this rendering's photographic grammar:

> Diverse, professionally attired subjects rendered photorealistically. Editorial photography composition, natural light or soft studio lighting. Subjects appear authentic and contemporary — no posed stock-photo stiffness, no exaggerated expressions, no fashion-shoot artificiality.

This rendering does not create a photorealism whitelist; other renderings choose their own anatomy, facial detail, texture, and realism under the same global rule.

## 4. Using the deck's HEX values

corporate-photo's relationship to HEX is **color grading**, not color fills:

- Primary HEX: dominant tone the image is graded toward (cool grade for navy primary, warm grade for terracotta primary)
- Secondary HEX: highlight tone in the lit areas
- Accent HEX: a subtle environment color (a sweater, a wall accent, a product detail) that picks up the deck's accent
- HEX values appear as **color cues** in the description, not as literal HEX strings in the image

---

## 5. Fewshot prompt snippets

**Snippet A — team workplace photo, text_policy: none**

> Editorial photography of a small modern team collaborating around a laptop in a contemporary office. Three to four diverse, professionally attired adults — varied ethnicities, varied ages — engaged in genuine conversation, no posed stock-photo stiffness. Natural window light from the side, soft shadows. Color grading is cool-corporate — image is subtly graded toward deep blue tones echoing the deck's primary `#1E3A5F`, with the background carrying soft light gray `#F8F9FA` walls and a single accent of warm wood or amber from a desk lamp echoing the accent `#D4AF37`. Shallow depth of field — subjects sharp, background gently blurred. Composed as a 1200×600 hero band with 8% inner padding. Diverse, professionally attired subjects rendered photorealistically. Editorial photography composition. Authentic, not stock-photo artificial. Color values are rendering guidance — HEX codes themselves do not appear in the image as text.
