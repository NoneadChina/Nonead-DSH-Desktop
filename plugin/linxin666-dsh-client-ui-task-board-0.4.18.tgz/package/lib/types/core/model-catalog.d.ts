/**
 * Host model catalog: the routes this deployment serves, the reasoning metadata
 * their adapters expose, and the normalization the board reads them through.
 *
 * The board publishes the catalog (the settings card's model and level pickers
 * read it) and resolves a card's pinned reasoning effort against it, so "this
 * model declares that level" is answered from the host's own configuration
 * instead of a guess. Framework-free (no cordis, no SDK imports) because both
 * halves compile it.
 *
 * @module dsh-task-board/core/model-catalog
 */
/** One resolved `provider/model` route. */
export interface ModelRoute {
    provider: string;
    model: string;
    /** Reasoning level the route is configured or resolved at; absent means inherit. */
    reasoningEffort?: string;
}
/** One reasoning-effort option an adapter exposes for an exact model route. */
export interface CatalogReasoningEffort {
    id: string;
    name?: string;
}
/** One adapter-discovered model of the host catalog. */
export interface CatalogModel {
    id: string;
    name?: string;
    reasoning?: {
        efforts: CatalogReasoningEffort[];
        defaultEffort?: string;
    };
}
/** One provider route and its models. */
export interface CatalogGroup {
    id: string;
    name?: string;
    models: CatalogModel[];
}
/** The host model catalog the board resolves routes and reasoning levels against. */
export interface ModelCatalogView {
    /** The route an unconfigured session starts at: the host's own configuration. */
    default?: ModelRoute;
    groups: CatalogGroup[];
}
/** Split a qualified `provider/model` route; undefined when it is not one. */
export declare function parseModelRoute(qualified: string | undefined): {
    provider: string;
    model: string;
} | undefined;
/**
 * Normalize the raw `session/modelCatalog` reply into the shape the board
 * reads. Everything is optional in the wire value, so every level is checked:
 * an unreadable catalog degrades to "unknown", never to a crash.
 * @param value - the raw gateway reply.
 * @returns the normalized catalog, or undefined when nothing usable arrived.
 */
export declare function normalizeCatalog(value: unknown): ModelCatalogView | undefined;
