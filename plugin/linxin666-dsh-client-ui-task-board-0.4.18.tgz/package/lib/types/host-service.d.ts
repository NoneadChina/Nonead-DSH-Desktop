import type { TypertGateway } from '@deepseek-ai/dsh-api-gateway';
import { HostTaskLedger } from './host-ledger.ts';
import { HostExecutionRunner, type GatewayPeer, type SessionCommandDispatcher, type TaskBoardWorkspaceRegistry } from './host-runner.ts';
import { PowerInhibitor } from './power-inhibitor.ts';
import { type TaskBoardAction, type TaskBoardEventPayload, type TaskBoardSnapshot } from './protocol.ts';
import type { CardDefaults } from './core/card-defaults.ts';
import { TaskBoardExtensionRegistry } from './host/extension-registry.ts';
import type { TaskBoardExtension } from './core/extension.ts';
import { type ScheduleMode } from './core/tasks.ts';
import type { ModelCatalogView } from './core/model-catalog.ts';
import type { TaskPermission } from './core/handover.ts';
import { type ModelInfoResolver, type TaskBoardAttachmentStore } from './host/attachments.ts';
/**
 * Provenance of one cron-triggered run: when the rule fired and the zone
 * its wall clock was read in. Passed into every launched prompt of that run so
 * a scheduled job knows its own clock rather than inferring one.
 */
export interface ScheduledRunContext {
    triggeredAt: number;
    timeZone: string;
    /** Whether this fire came from a recurring rule or a single planned instant. */
    mode: ScheduleMode;
    /** Cron expression of a recurring rule; absent on a one-shot. */
    cron?: string;
}
/**
 * The native timer face the Host arms through. The cordis `timer` service
 * (dsh-base's own `cordis-plugin-timer` row) provides it: its handles are
 * registered on the owning fiber, so unloading the board clears every armed
 * timer without this service tracking handles by hand. A composition that
 * serves no timer service falls back to the process globals.
 */
export interface HostTimerFace {
    timeout(callback: () => void, delay: number): () => void;
    interval(callback: () => void, delay: number): () => void;
}
export declare class TaskBoardHostService {
    readonly ledger: HostTaskLedger;
    readonly runner: HostExecutionRunner;
    readonly power: PowerInhibitor;
    /** The official attachment storage, read live so a late mount is honoured. */
    private readonly attachmentStore;
    private readonly listeners;
    /** The one recurring timer: the session-roster poll. */
    private pollTimer;
    /** Cadence of the roster poll, in seconds (a settings field; see the config schema). */
    private sessionPollSeconds;
    /** Pending delay that follows a failed poll pass, if one is armed. */
    private pollBackoffTimer;
    /** Consecutive failed poll passes; doubles the next retry delay. */
    private consecutivePollFailures;
    /** The armed schedule timer, if a trigger is pending. */
    private scheduleTimer;
    /** The instant the armed schedule timer targets (ms epoch), for resume detection. */
    private scheduleTarget;
    private disposed;
    private pollInFlight;
    private active;
    /**
     * Admission control for the session-creating half of a run: one board action
     * opens a whole subtree, and this is what keeps the Host from asking DSH for
     * every member's session at once (see {@link LaunchAdmissionQueue}).
     */
    private readonly launches;
    /**
     * Consecutive unreadable-history polls per open execution (see
     * {@link noteUnreadableInspection}). Cleared as soon as an inspection
     * resolves, so a transient reader failure never fails a card.
     */
    private readonly unreadablePolls;
    private preventIdleSleep;
    /** Live reader of the host model catalog; frozen per run group. */
    private readonly modelCatalog;
    private readonly timers;
    /** Live reader of the deployment's new-card defaults (published and applied per create). */
    private readonly cardDefaults;
    /**
     * Live reader of the run-launch admission width: how many launches may be in
     * flight at once. Read at every admission, so a settings edit bounds the next
     * launch without remounting the row. Absent means the default.
     */
    private readonly runLaunchWidth;
    /**
     * Live reader of the daily token cap; 0 means no gate. Read at each run
     * action, so closing or raising the cap binds the next action.
     */
    private readonly spendBudgetTokens;
    /** Today's measured spend: absent measurement reads as "cannot see", never as zero. */
    private readonly spendUsedToday;
    private lastPowerJson;
    private readonly now;
    /** The deployment's workspaces, consulted to resolve a card that pins none. */
    private readonly workspaceRegistry;
    /**
     * External provider extensions. The board owns task lifecycle and execution;
     * a provider observes them through the registry's capability face and never
     * reaches into the ledger itself.
     */
    readonly extensions: TaskBoardExtensionRegistry;
    constructor(gateway: TypertGateway, options?: {
        ledger?: HostTaskLedger;
        power?: PowerInhibitor;
        now?: () => number;
        commandDispatcher?: SessionCommandDispatcher;
        workspaceRegistry?: TaskBoardWorkspaceRegistry;
        /**
         * The owner peer every gateway request the runner makes speaks for.
         * Production passes the peer bound to the plugin fiber (see
         * {@link createOwnerPeer}); absent is fine for tests and bare mounts,
         * where the runner binds one to a fresh root context.
         */
        ownerPeer?: GatewayPeer;
        /**
         * Permission baseline of the confirmation gate: a fixed value, or a live
         * resolver the board re-reads so a Host Settings change needs no remount.
         */
        sessionDefaultPermission?: TaskPermission | (() => TaskPermission);
        maxSubtaskDepth?: number;
        /**
         * Live reader of the deployment's new-card defaults (volatile config reads).
         * The board publishes them for the create dialog and re-reads them for every
         * create that opts in, so a settings edit reaches the next created card
         * without remounting the row. Absent means the deployment configures none.
         */
        cardDefaults?: () => CardDefaults;
        timers?: HostTimerFace;
        /**
         * The host model catalog the card routes and reasoning levels resolve
         * against, read live so a deployment that mounts the model service after the
         * board still gains it. Absent means "no capability evidence": a pinned
         * effort is then not sent at all.
         */
        modelCatalog?: () => Promise<ModelCatalogView | undefined>;
        /**
         * Live admission width for run launches: the number of launches (one
         * session creation and its prompt each) that may be in flight at once. Read
         * per admission, so editing the setting bounds the next launch of a run that
         * is still queueing. Absent means the default width.
         */
        runLaunchWidth?: () => number;
        /**
         * Live daily token cap (a volatile config read). 0 — the default, and what
         * every deployment that never configured one keeps — ends the gate before
         * anything is measured. A positive cap refuses a run whose day already spent
         * it, on both the action path and the cron path.
         */
        spendBudgetTokens?: () => number;
        /**
         * Today's measured spend in tokens, or undefined when this deployment keeps
         * no readable usage ledger. Defaults to the family usage ledger reader.
         */
        spendUsedToday?: (now: number) => number | undefined;
        /**
         * The official attachment storage, read at request time. Absent means the
         * deployment stores no attachments: every attachment action is then
         * refused and the board publishes no attachment limits.
         */
        attachments?: () => TaskBoardAttachmentStore | undefined;
        /**
         * The model-info reader the image preflight uses. Absent means the
         * deployment serves no model information, and a route whose modalities are
         * unknown is allowed.
         */
        modelInfo?: () => ModelInfoResolver | undefined;
        /**
         * Whether this deployment runs the legacy Agent Teams runtime. Read at
         * launch, only for a run the board is about to force under the dispatcher
         * preset: such a deployment cannot orchestrate, so the run fails closed on
         * the card instead of deadlocking in a session nobody answers (issue #2031).
         * Absent means "not proven legacy", which keeps the force exactly as it is.
         */
        legacyAgentTeams?: () => boolean;
    });
    start(): void;
    /**
     * Apply the live configuration. The roster cadence is re-read on every
     * commit, so a settings edit takes effect without a restart; the poll is
     * scheduled at the new cadence immediately rather than waiting out the old
     * interval.
     * @param active - the board's master switch.
     * @param preventIdleSleep - whether the board holds an idle-sleep assertion.
     * @param sessionPollSeconds - roster-poll cadence in seconds (clamped).
     */
    setConfiguration(active: boolean, preventIdleSleep: boolean, sessionPollSeconds?: number): void;
    /**
     * The board's published snapshot.
     *
     * Every read path serializes this object — the HTTP `state` answer, the
     * `action` answer through {@link apply}, and the remote bridge's
     * `board.snapshot` — so a provider's integration credentials are stripped
     * once, here, instead of at each exit. The ledger keeps them verbatim for the
     * provider's own in-process read.
     */
    snapshot(): TaskBoardSnapshot;
    /**
     * Admit one external provider. Idempotent by extension id; the returned
     * disposer releases it (its stored data stays).
     */
    registerExtension(extension: TaskBoardExtension): () => void;
    /**
     * The host model catalog the settings card's model and reasoning-level
     * choices come from.
     * @returns the catalog, or an empty one when this deployment serves none.
     */
    modelCatalogOptions(): Promise<{
        catalog: ModelCatalogView;
    }>;
    /** SSE frame payload; deliberately skips the tasks deep-clone of {@link snapshot}. */
    eventPayload(): TaskBoardEventPayload;
    subscribe(listener: () => void): () => void;
    /**
     * Give a root card created without a workspace pin the workspace its creator
     * is in.
     *
     * An agent's `task_board_create` arrives with the calling session, and the
     * GUI submits the session the main view shows, so the card lands where the
     * work was asked for instead of where the Host process happens to run. A card
     * that names a workspace keeps it, and a subtask keeps inheriting its lineage
     * (the runner walks the ancestor chain for that).
     *
     * The initiator is client-asserted, so it only chooses among workspaces the
     * deployment already knows: it can neither register one nor reach outside the
     * list the user sees.
     * @param action - the action about to be applied.
     * @param initiator - the session that issued the action, when one was asserted.
     * @returns the action, with an inherited workspace on a root creation.
     */
    private withInheritedWorkspace;
    /**
     * Apply an action whose attachments the Host proved against the official
     * storage first.
     *
     * This is the board's trust boundary for attachment metadata: the browser
     * asserts the size, the type and the digest of every object it uploaded, and
     * the Host reads the stored objects back (an image is compared, a file is
     * streamed and its digest recomputed) before the ledger commits the claim.
     * An attachment the storage cannot prove is refused, so a spoofed client
     * claim never becomes a stored fact.
     */
    applyVerified(requestId: string, action: TaskBoardAction, initiator?: string): Promise<TaskBoardSnapshot>;
    /**
     * Prove every attachment of an action against the official storage.
     *
     * An action without attachments is untouched: the board keeps working in a
     * deployment that serves no attachment storage at all.
     */
    private verifyActionAttachments;
    apply(requestId: string, action: Extract<TaskBoardAction, {
        kind: 'extension-action';
    }>, initiator?: string): Promise<TaskBoardSnapshot>;
    apply(requestId: string, action: Exclude<TaskBoardAction, {
        kind: 'extension-action';
    }>, initiator?: string): TaskBoardSnapshot;
    apply(requestId: string, action: TaskBoardAction, initiator?: string): TaskBoardSnapshot | Promise<TaskBoardSnapshot>;
    /**
     * Apply one board-owned action with every gate intact. Provider capability
     * calls and the same-origin wire both land here, so the two surfaces can
     * never disagree about a card.
     */
    private applyBoardAction;
    /**
     * Refuse a run whose day already spent the cap.
     *
     * A cap of 0 — the shipped default — answers before the measurement is read:
     * no ledger file is opened and nothing is summed, which is what keeps a board
     * that never configured a cap identical to the one before it existed.
     *
     * The refusal is a thrown message rather than a code: the wire hands its text
     * to the caller as board-refused, exactly like every other refusal this board
     * makes.
     */
    private assertSpendCap;
    /** Route one provider action and answer the resulting board snapshot. */
    private handleExtensionAction;
    /** Current task id -> status map, for change detection around a mutation. */
    private statusMap;
    /** Emit a status change for every task whose column moved, isolated per callback. */
    private emitStatusChanges;
    dispose(): void;
    private launch;
    /**
     * Read the model catalog one run group freezes. The catalog is what decides
     * whether a card's pinned reasoning level may be sent to the session.
     */
    private readRunCatalog;
    /**
     * A {@link RunCatalogFreezer} that reads once and hands the SAME value to
     * every later caller of one run group. A read that fails is not cached: the
     * next member reads again, exactly as a per-execution read would have.
     */
    private catalogFreezerForRunGroup;
    /**
     * Give back the occurrence a launch consumed, for a launch that never reached
     * a session: a failed launch, or one the Host abandoned while it was still
     * waiting for an admission slot. A manual run, and a launch that DID reach a
     * session, are never refunded.
     */
    private refundUnstartedSchedule;
    /**
     * One roster pass, and whether it could read the session tree.
     *
     * The board reads the DSH session roster only while it has something the
     * roster can decide: an execution to inspect, or a card parked in the running
     * column whose verdict may arrive from a settle this process never saw. That
     * gate is what removes the cost the reporter measured — `session/list`
     * rebuilds every persisted session row (string conversion, object allocation,
     * a stat per record), and an idle board with no tasks was paying it every few
     * seconds forever.
     * @returns whether the roster was readable (an idle pass counts as readable).
     */
    private pollSessions;
    /**
     * The session a run may continue in, for a card that opted into reuse
     * (issue #1419). Reuse requires positive evidence that the previous session
     * is present and idle, and that evidence must be read for THIS launch: an
     * idle board no longer polls, so a roster cached from an earlier pass could
     * be hours old — either refusing a session that has been idle all along, or
     * prompting into one that started running since. A card that did not opt in
     * reads no roster at all, and a read that fails mints a fresh conversation
     * exactly as an unknown roster always did.
     * @param task - the task about to run.
     * @param force - continue the settled session regardless of the card's own
     *   opt-in (a rework), which the reuse rule accepts without waiving any of its
     *   evidence conditions.
     * @returns the session id to continue in, or undefined for a fresh session.
     */
    private reuseSessionFor;
    /**
     * The session a rework continues, or the refusal that says why it cannot.
     *
     * A rework exists for one conversation — the one the reviewer read before
     * sending the work back — so the evidence that this Host still reaches it is
     * required, exactly as it is for a card that opted into reuse. What a rework
     * does NOT get is the fresh-conversation fallback: launching there would hand
     * the reviewer's instructions to an agent that never saw the work, so the run
     * fails with a readable reason instead.
     * @param task - the card being reworked.
     * @returns the session id this rework continues in.
     */
    private reworkSessionFor;
    /** Reuse the session list this poll already fetched: one list RPC per tick, not 1 + E. */
    private reconcileExecutions;
    /**
     * Count one poll whose session history could not be read. A reader failure is
     * not progress: the session is not running (the runner only reads history for
     * one that is idle), so nothing will ever change that verdict. After
     * {@link UNREADABLE_SETTLE_POLLS} consecutive polls the execution is reported
     * failed with the recorded reason, instead of holding its card — and every
     * ancestor of it — in the running column with no way out. The first poll of
     * each streak is logged, so the Host log names the session.
     */
    private settleAndNotify;
    private noteUnreadableInspection;
    /** Drop the armed schedule timer and forget its target. */
    private clearScheduleTimer;
    /**
     * Boot / resume recovery: skip every occurrence that came due while the
     * board was not running and roll each schedule to its next future target,
     * then arm the timer for the nearest one. Rendering the occurrence is
     * deliberately not attempted: the ACL of a card that fired hours ago is
     * stale, and the board's own recovery contract is "missed triggers are
     * skipped, never replayed".
     */
    private recoverSchedule;
    /**
     * Arm the native timer at the nearest armed future trigger. One timer serves
     * every schedule: the ledger's next target is the only instant the Host has
     * to wake for. A target beyond the platform's timer ceiling re-arms in
     * segments, and a target already past (the wall clock jumped, or the process
     * was suspended) is handled immediately as a recovery.
     */
    private armSchedule;
    /**
     * One armed target became due. A fire landing well past its target is a
     * resume (suspend, throttle, forward clock jump) rather than a normal
     * occurrence, so it takes the recovery path instead of launching a run for a
     * long-stale instant.
     */
    private onScheduleFire;
    private armedSchedules;
    /**
     * Launch the one run a run request opened. A run request names one card and
     * opens one execution for it; the card's own session dispatches its subtasks
     * as subagents, so nothing else is enqueued here.
     *
     * The launch still goes through the admission queue, which admits at most
     * `runLaunchWidth` launches at a time — that bound now applies across
     * concurrent runs rather than across the members of one run.
     */
    private dispatchRuns;
    private scheduleLaunch;
    /**
     * Hand one launch to the admission queue, or abandon it on the spot when the
     * Host is already stopping: a queue entry created after {@link dispose} would
     * otherwise never be drained, and its card would sit in the running column
     * until the next Host start recovered it.
     */
    private enqueueLaunch;
    /** Whether one opened execution is still open in the ledger. */
    private isExecutionOpen;
    /**
     * Take one launch that never started out of the running column.
     *
     * Settled as CANCELLED, not failed: nothing about the run's work went wrong —
     * the Host stopped before the launch got a slot, which is exactly what the
     * next start's interrupted-start recovery records for an execution that never
     * reached a session. A scheduled occurrence that never reached a session is
     * refunded on the same terms as any other pre-session failure, so a run the
     * Host never started cannot silently spend the user's run budget.
     */
    private abandonQueuedRun;
    private schedulePoll;
    /**
     * Count one failed pass and arm the retry that follows it.
     *
     * A session tree that is down is retried on a doubling delay instead of
     * hammering it on the fixed cadence: the heartbeat would otherwise repeat
     * every failure — and every retry inside {@link HostExecutionRunner.listRunning}
     * — at exactly the interval the reporter measured.
     */
    private notePollFailure;
    /** Arm the retry that follows a failed pass, doubling up to the ceiling. */
    private armPollBackoff;
    /** Drop a pending retry; the next regular tick takes over. */
    private clearPollBackoff;
    /**
     * Re-arm from the ledger's current targets. Callers that just changed a
     * schedule (the host routes, the agent tools) invoke this after the write
     * commits, so a new or edited trigger arms without waiting for the next fire.
     */
    refreshSchedule(): void;
    private syncPowerReasons;
    private emit;
}
/**
 * Install stream error listeners on process.stderr and process.stdout so that
 * transient write failures (e.g. ENOSPC when the disk is full, or EPIPE on a
 * closed pipe) never emit unhandled 'error' events that kill the Node.js host process.
 */
export declare function installStreamErrorGuards(): void;
/**
 * Defensively log to console.error without letting stderr write failures
 * (e.g. ENOSPC from SyncWriteStream on redirected logs) crash the host process.
 */
export declare function safeConsoleError(message: string, ...args: unknown[]): void;
