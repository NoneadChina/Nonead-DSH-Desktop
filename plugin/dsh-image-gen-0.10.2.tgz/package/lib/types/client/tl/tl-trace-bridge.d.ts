/**
 * Delivery of a drawing plan to the workbench canvases.
 *
 * The `draw_reference` tool cannot put path data inline: the plan is tens of
 * kilobytes and the conversation is persisted, so the tool result carries only
 * a `traceId` (see presentationMeta) and this bridge hands that id to whichever
 * canvas is mounted. The canvas then fetches the plan from the trace-plan route
 * and plays it.
 *
 * A trace that arrives while no canvas is mounted is held, not dropped: the
 * canvas surfaces are tab-scoped and unmount when the user looks elsewhere, so
 * dropping on absence would mean the drawing only ever plays if the user
 * happened to be staring at the infinite canvas at that exact second. The
 * queue holds the newest trace only — a drawing is a one-shot show, and an
 * older plan is stale by the time a newer one exists.
 */
/** The identifying part of a trace result, as it arrives on a tool event. */
export interface TlTraceItem {
    traceId: string;
    /** Source pixel size, for the overlay's initial aspect box. */
    sourceWidth: number;
    sourceHeight: number;
    /** Region count, for the "N blocks" caption. */
    steps: number;
}
type TlTraceConsumer = (item: TlTraceItem) => void;
/** Whether any canvas is mounted to play a plan. */
export declare function hasTlTraceConsumer(): boolean;
/** The trace waiting for a canvas, if any. */
export declare function pendingTlTrace(): TlTraceItem | null;
/**
 * Register a canvas surface; returns its disposer. A trace that arrived while
 * nothing was mounted plays immediately, so opening the canvas after asking
 * for a drawing still shows it.
 */
export declare function registerTlTraceConsumer(consumer: TlTraceConsumer): () => void;
/** Hand a plan to every mounted canvas, or hold the newest one until one is. */
export declare function pushTlTrace(item: TlTraceItem): void;
/** Test seam: clear every consumer and the pending slot. */
export declare function resetTlTraceBridge(): void;
/**
 * Parse the plugin-owned trace metadata off a Tool result. Returns undefined
 * for anything that is not a draw_reference result, so callers can share one
 * event subscription with the image landings.
 */
export declare function traceResultFromMeta(value: unknown): TlTraceItem | undefined;
/**
 * Recover a trace from a `tool/ptc-dispatch` event, when the model called
 * draw_reference through run_code instead of directly.
 */
export declare function traceResultFromPtcDispatch(event: {
    readonly type: string;
    readonly data: Record<string, unknown>;
}): TlTraceItem | undefined;
export {};
