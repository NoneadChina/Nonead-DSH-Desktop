import type { Editor } from 'tldraw';
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
interface TraceStep {
    layer: number;
    d: string;
    area: number;
}
interface TracePlan {
    viewBox: [number, number, number, number];
    fills: string[];
    steps: TraceStep[];
}
export interface CanvasTraceProps {
    editor: Editor;
    traceId: string;
    /** Region count reported by the tool, shown before the plan arrives. */
    steps: number;
    /**
     * The absolutely-positioned host the surface is rendered into. Its rect is
     * the origin this component must subtract from tldraw's window-relative
     * screen coordinates.
     */
    hostRef?: {
        readonly current: HTMLDivElement | null;
    };
    /**
     * Receives the finished drawing as a rail image plus the page rectangle it
     * was drawn in, so the canvas can place it exactly where the playback was.
     */
    onLand?: ((attachment: ImageAttachmentRef, placement: {
        x: number;
        y: number;
        w: number;
        h: number;
    }) => void | Promise<void>) | undefined;
    onClose: () => void;
    lang?: 'zh' | 'en';
}
/**
 * Revealed region count at elapsed time `t`. Squaring the normalised time
 * gives the first (largest) regions most of the screen time and then speeds up
 * through the tiny ones, which is the same curve the drawai workbench uses.
 */
export declare function traceRevealCount(total: number, elapsedMs: number, durationMs: number): number;
/** Total playback time for a plan: short plans stay readable, long ones stay bounded. */
export declare function tracePlaybackDuration(total: number): number;
/** Paint order prefix: the first `count` steps accumulated per colour layer. */
export declare function traceLayerPaths(plan: TracePlan, count: number): string[];
/** Rebuild the finished SVG document from the plan, for download. */
export declare function tracePlanToSvg(plan: TracePlan): string;
/**
 * Draw the finished SVG into a canvas and encode it as PNG.
 *
 * SVG reaches the document as a bitmap because tldraw's image shapes render
 * through `<img>`, where an SVG with only a viewBox has no intrinsic size and
 * collapses to the 300x150 default. Width and height are injected for the same
 * reason: without them the browser has nothing to scale from.
 */
export declare function rasterizeSvg(svg: string, width: number, height: number): Promise<Blob>;
/** Upload rasterised bytes as a durable attachment so the canvas can land them. */
export declare function uploadDrawing(blob: Blob, name: string): Promise<ImageAttachmentRef>;
/** Rasterise one plan at a bounded resolution, then store it as an attachment. */
export declare function realizeDrawing(plan: TracePlan, name: string): Promise<ImageAttachmentRef>;
/** Page-space rectangle the drawing occupies, frozen when the trace starts. */
export interface TraceAnchor {
    x: number;
    y: number;
    w: number;
    h: number;
}
/**
 * Pick the page rectangle for a drawing of `aspect` (w/h): centred on what the
 * user is looking at right now, at 72% of the viewport. Frozen in page space so
 * later panning and zooming move it like canvas content instead of resizing it
 * to the window.
 */
export declare function anchorTraceInViewport(viewport: {
    center: {
        x: number;
        y: number;
    };
    w: number;
    h: number;
}, aspect: number): TraceAnchor;
export declare function CanvasTrace({ editor, traceId, steps, hostRef, onLand, onClose, lang }: CanvasTraceProps): import("react").JSX.Element;
/**
 * Map a page rectangle into the surface's own coordinate space.
 *
 * tldraw's screen space is window-relative (`pageToScreen` returns client
 * coordinates, which is why collaborator cursors need no offset), while the
 * surface is an absolutely positioned child of the canvas host. Subtracting the
 * host's own rect is what turns one into the other; without it the drawing is
 * pushed off the panel and clipped.
 */
export declare function projectAnchor(editor: Editor, anchor: TraceAnchor, host: HTMLElement | null): {
    left: number;
    top: number;
    width: number;
    height: number;
};
export {};
