/** Read-only route that hands one stored trace plan to the canvas. */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { TracePlanStore } from './trace-store.js';
export interface TraceRouteDeps {
    store: TracePlanStore;
}
/**
 * Serve one drawing plan by id. GET only: the plan is produced by the
 * `draw_reference` tool and never written from the browser, so there is
 * nothing to accept here.
 */
export declare function serveTracePlan(req: IncomingMessage, res: ServerResponse, deps: TraceRouteDeps): Promise<void>;
