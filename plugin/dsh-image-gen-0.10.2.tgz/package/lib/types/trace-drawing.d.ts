/** Named trace styles exposed by the tool. */
export declare const TRACE_PRESET_NAMES: readonly ["default", "lineart", "photo", "simple"];
export type TracePresetName = (typeof TRACE_PRESET_NAMES)[number];
/** Fragment density tiers, mirroring the workbench's three calibrated档. */
export declare const TRACE_FRAGMENT_NAMES: readonly ["low", "medium", "high"];
export type TraceFragments = (typeof TRACE_FRAGMENT_NAMES)[number];
/** One connected region of one colour: a self-contained path plus its area. */
export interface TraceDrawingStep {
    /** Index into `fills`; steps sharing a layer share a fill colour. */
    layer: number;
    /** SVG path data for this region, including its holes (nonzero winding). */
    d: string;
    /** Signed pixel area used for ordering; steps arrive largest first. */
    area: number;
}
/** The replayable drawing: paint `steps` in order, grouped by `fills`. */
export interface TraceDrawingPlan {
    viewBox: [number, number, number, number];
    fills: string[];
    steps: TraceDrawingStep[];
}
/** Numbers the model gets instead of the path data. */
export interface TraceSummary {
    width: number;
    height: number;
    colors: number;
    paths: number;
    loops: number;
    steps: number;
    svgChars: number;
    budget: number;
    attempts: number;
    drawnPixels: number | null;
    exactPixelCoverage: boolean;
    sourceWidth: number;
    sourceHeight: number;
}
/** Everything one trace produces. */
export interface TraceOutcome {
    /** Full SVG document, for export — never sent to the model verbatim. */
    svg: string;
    plan: TraceDrawingPlan;
    /**
     * Optional pencil pass derived from the same source, played before `plan`.
     * Null when the caller asked for no sketch or the edge pass found nothing.
     */
    sketch: TraceDrawingPlan | null;
    summary: TraceSummary;
    /** One-line tuning advice from upstream's own heuristics. */
    hint: string;
}
/**
 * One complete drawing session: the contour pass an illustrator starts with,
 * then the colour pass that fills it in.
 */
export interface TraceShow {
    sketch?: TraceDrawingPlan;
    colour: TraceDrawingPlan;
}
/** Trace knobs shared by the decoded-pixels and encoded-bytes entry points. */
export interface TraceOptions {
    /** Required: keep or drop the background. There is no automatic answer. */
    removeBg: boolean;
    preset?: TracePresetName;
    fragments?: TraceFragments;
    /** Palette size, 2–24. Also caps the number of visible colour layers. */
    colors?: number;
    /** RDP tolerance in work pixels; lower keeps more contour fidelity. */
    epsilon?: number;
    /** Regions under this area are merged into a neighbour. */
    minArea?: number;
    /** Long side cap for the work image; defaults to the calibrated 887. */
    maxLongSide?: number;
    /** SVG character budget; upstream default is 248000. */
    budget?: number;
    /** Derive a pencil sketch to play first; defaults to true. */
    sketch?: boolean;
}
/** One trace over an encoded image. */
export interface TraceRequest extends TraceOptions {
    /** Encoded image bytes (PNG is dependency free; JPEG/WebP need sharp). */
    bytes: Uint8Array;
}
/**
 * Trace an encoded raster into an SVG plus its replayable drawing plan.
 * @param request - image bytes and trace knobs.
 * @returns the SVG, the ordered plan, a model-facing summary and a tuning hint.
 */
export declare function traceImageToDrawing(request: TraceRequest): Promise<TraceOutcome>;
/**
 * Trace an already-decoded RGBA8 raster. Split out from `traceImageToDrawing`
 * so tests can exercise the pipeline without encoding a PNG first.
 *
 * Produces the colour pass plus, unless disabled, a pencil pass derived from
 * the same pixels. The sketch is best-effort: a picture with no edges worth
 * drawing simply plays the colour pass alone.
 */
export declare function traceRasterToDrawing(raster: {
    width: number;
    height: number;
    data: Uint8Array;
}, options: TraceOptions): TraceOutcome;
