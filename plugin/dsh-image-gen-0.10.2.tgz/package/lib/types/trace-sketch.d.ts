/**
 * Derive a pencil-sketch raster from a reference image.
 *
 * The tracer can only reproduce what is in the pixels, so "先起稿再上色" needs
 * an actual contour drawing to reproduce. Spending a model call on one would be
 * slow, non-deterministic and — for a picture the model has already been given
 * — redundant. Derive it locally instead: grayscale, Sobel magnitude, an
 * adaptive threshold, then a one-pixel dilation so the lines survive the
 * downsampling the tracer does internally.
 *
 * The result is a black-on-white line drawing: the contour pass an illustrator
 * makes before blocking in colour.
 */
/** RGBA8 bitmap, the same shape the tracer consumes. */
export interface SketchRaster {
    width: number;
    height: number;
    data: Uint8Array;
}
/**
 * Build a line drawing from a raster.
 * @param raster - source pixels (RGBA8).
 * @param maxSide - long side to compute the edges at; defaults to 1200.
 * @returns a black-on-white RGBA8 bitmap of the detected contours.
 */
export declare function sketchRaster(raster: SketchRaster, maxSide?: number): SketchRaster;
