import type { TraceShow } from './trace-drawing.js';
export interface TracePlanStoreOptions {
    /** Directory for restart-surviving copies; omit to stay memory-only. */
    dir?: string | undefined;
}
export declare class TracePlanStore {
    private readonly entries;
    private readonly dir;
    constructor(options?: TracePlanStoreOptions);
    /** Store one show and return the id the browser will use. */
    put(show: TraceShow): Promise<string>;
    /** The show behind an id: memory first, then the disk copy, else undefined. */
    get(id: string): Promise<TraceShow | undefined>;
    /** Write the disk copy; failures are logged and otherwise ignored. */
    private persist;
    /** Read one disk copy, dropping it when expired or malformed. */
    private read;
    private remove;
    /** Drop expired entries, then the oldest ones past the cap, in memory and on disk. */
    private evict;
    /** Delete disk copies left behind by a previous host process. */
    private evictDisk;
}
