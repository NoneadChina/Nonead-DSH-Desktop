#!/usr/bin/env node
/**
 * dsh-config-manager CLI（M3，criterion m3-cli-works）：
 * 离线快照列表/恢复 + 一键重装 DSH 命令，零 DSH 运行时依赖（仅 node 内置 + 本项目
 * core 引擎；绝不 import @deepseek-ai/*，peerDependencies 缺失也能跑）。
 *
 * 子命令一览、选项、退出码的**唯一事实源是 ./help.ts**（速查页 + 每命令详情页）：
 * 本文件只负责解析参数与执行，不再散写文案。
 *   dcm help                  速查页（按风险分组的命令表 + 通用选项）
 *   dcm <命令> --help         单命令详情页（说明 / 选项 / 退出码 / 示例）
 *   dcm help <命令>           同上
 *
 * 缺省数据目录 = $DSH_HOME/dsh-config-manager/snapshots（$DSH_HOME 缺省 ~/.dsh）。
 * 破坏性命令（restore / reinstall）的 SAFE MODE 门按「控制面根」定位标记：
 *   --data-root 显式给出 → 只用它；否则用 --data-dir 本身及其父目录 + 缺省根 $DSH_HOME/dsh-config-manager。
 * 插件配置了自定义 dataDir 时必须显式传 --data-root，否则安全门只能按候选位置保守检查。
 */
import os from 'node:os';
import fssync from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFile } from 'node:child_process';
import { createInterface } from 'node:readline/promises';
import { stdin as processStdin, stdout as processStdout } from 'node:process';

import {
  listSnapshots, planRestore,
  type RestorePlan, type RestoreReport, type SnapshotMeta,
} from '../core/restore.ts';
import {
  REINSTALL_ITEMS, buildReinstallPlan, isWindows, detectInstalledDshVersion,
  writeReinstallRecoveryPoint,
  type ReinstallPlan, type ReinstallItemId,
} from '../core/reinstall.ts';
import { EnvironmentLockManager, runWithMutationLock, EnvironmentLockUnavailableError, OWNERSHIP_FILE } from '../utils/env-lock.ts';
import { runSessionsRepair } from './sessions-repair.ts';
import { runSessionsInspect } from './sessions-inspect.ts';
import { runImportSource } from './import-source.ts';
import { probeCliRestoreResume, runCliRestore } from './restore-resume.ts';
import { renderCommandHelp, renderOverview } from './help.ts';
import { checkWriteGates, collectVerifyResults, readRunningInstances, SAFE_MODE_REFUSAL_CODE } from './actions.ts';
import { Phase3Recovery, readSafeModeMarkerSync, safeModeMarkerPath } from '../core/phase3-host.ts';
import {
  verifyBackupZip, type BackupVerifyResult, type BackupVerifyVerdict,
} from '../core/backup-verify.ts';
import {
  collectBackupEntries, buildSectionFlags, parseSectionsArg,
  OFFLINE_UNAVAILABLE_SECTIONS,
  type BackupCollection,
} from '../core/backup-plan.ts';
import { buildChecksums } from '../utils/hashing.ts';
import { stringifyJsonSafe } from '../utils/json.ts';
import { buildManifest, CHECKSUMS_FILE, MANIFEST_FILE } from '../schema/manifest.ts';
import { writeZip } from '../utils/zip.ts';
import type { Manifest, SectionId } from '../schema/types.ts';

/* ------------------------------------------------------------ 参数解析（纯函数） */

export type CliCommand =
  | 'snapshots' | 'restore' | 'reinstall' | 'recover-stale-lock'
  | 'verify' | 'backup' | 'import' | 'sessions' | 'web' | 'help';

export interface CliOptions {
  command: CliCommand;
  /**
   * 详情页主题（`dcm help <命令>` / `dcm <命令> --help`）。
   * 只在 command === 'help' 时有意义；认不认识由运行层判定（解析器不重复维护一份命令表）。
   */
  helpTopic?: string;
  /** --data-dir：快照数据目录（verify/backup 下为导出目录）覆盖 */
  dataDir?: string;
  /**
   * --data-root：插件数据根 dataDir（宿主 config.dataDir；SAFE MODE / 环境锁 / journal 都在它之下）。
   * 插件配置了自定义 dataDir 时必须显式给出——CLI 无法从 --data-dir 唯一反推该根。
   */
  dataRoot?: string;
  /** --id：目标快照 id（restore 缺省取最近非 rolled-back） */
  id?: string;
  /** --dry-run：只打印计划（restore / reinstall） */
  dryRun: boolean;
  /** --profile：管理的 DSH profile（缺省 web） */
  profile: string;
  /** --settings：覆盖 settings 文件路径 */
  settings?: string;
  /** --version：reinstall 要安装的 DSH 版本（缺省 latest） */
  version?: string;
  /** --yes：reinstall 非交互（全选 + 跳过确认） */
  yes: boolean;
  /** --list：reinstall 列出可选清理项后退出 */
  list: boolean;
  /** --wipe-config：reinstall 等价勾选全部数据类（settings/plugins/data） */
  wipeConfig: boolean;
  /** --json：verify 输出机器可读结果（便于 CI / 定时任务断言） */
  json: boolean;
  /** --sections <a,b,c>：backup 要打包的离线分区白名单（缺省取默认分区） */
  sections?: string;
  /** --out <path>：backup / import 输出 ZIP 路径（缺省写入导出目录，自动去重不覆盖） */
  out?: string;
  /** --from <source>：import 的外部来源 id（30 个之一） */
  from?: string;
  /** --cwd <dir>：import 的项目目录（契约 §8.2 的项目级路径；缺省 = 进程 cwd） */
  cwd?: string;
  /** --home <dir>：sessions repair 要修复的 DSH home（缺省 $DSH_HOME） */
  home?: string;
  /** --fix：sessions repair 真的落盘（缺省只报告） */
  fix?: boolean;
  /** --keep <dir>：sessions repair 的重复 id 保留哪一份（其余移入隔离目录，不删除） */
  keep?: string;
  /** --map old=new：sessions repair 的路径映射（可重复） */
  maps?: string[];
  /** verify 的位置参数（文件名或路径；与 --id 同义，最多一个） */
  positionals: string[];
  /** web：离线救急台监听端口（缺省 0 = 由内核分配，避免与 DSH 抢端口） */
  port?: number;
  /** web：启动后不自动打开浏览器（SSH / 无桌面场景） */
  noOpen?: boolean;
  /** web：空闲多少分钟自动退出（0 = 不自动退出；缺省 30） */
  idleTimeoutMin?: number;
}

export type ParseResult = { ok: true; options: CliOptions } | { ok: false; error: string };

const VALUE_FLAGS = new Map<string, 'dataDir' | 'dataRoot' | 'id' | 'profile' | 'settings' | 'sections' | 'out'>([
  ['--data-dir', 'dataDir'],
  ['--data-root', 'dataRoot'],
  ['--id', 'id'],
  ['--profile', 'profile'],
  ['--settings', 'settings'],
  ['--sections', 'sections'],
  ['--out', 'out'],
]);

/** 仅 verify 子命令允许的参数（--json 为布尔开关，不在 VALUE_FLAGS 内） */
const VERIFY_ONLY_FLAGS = new Set(['--json']);

/** 仅 backup 子命令允许的参数 */
const BACKUP_ONLY_FLAGS = new Set(['--sections', '--out']);

/** backup 明确不支持的 restore 系参数（--dry-run 对 backup 有效，故不在此表） */
const BACKUP_REJECTED_FLAGS = new Set(['--id', '--profile', '--settings']);

/**
 * 每个参数**真正被哪些子命令使用**（白名单，而不是「想起来才拒绝某一条」）。
 *
 * 为什么要有这张表：此前只有 `snapshots` 会拒绝 restore 系参数，于是
 * `verify --dry-run / --profile / --settings` 被**悄悄接受并忽略** —— 用户会以为自检跑成了
 * 「只读预演」。纪律是「本命令用不到的参数一律拒绝」，而不是「反正不影响结果就算了」。
 */
const FLAG_ALLOWED_COMMANDS = new Map<string, ReadonlySet<CliCommand>>([
  // --id：restore 的目标快照；verify 把它当位置参数的等价写法（见 help 的 verify 段）。
  ['--id', new Set<CliCommand>(['restore', 'verify'])],
  // --dry-run：restore（只打印计划）/ reinstall（只打印重装步骤）/ backup（只打印打包清单）。
  ['--dry-run', new Set<CliCommand>(['restore', 'reinstall', 'backup'])],
  // --profile：restore 要恢复的档案；web 用它决定救急台操作哪个档案（两条都真的在用，故放行）。
  ['--profile', new Set<CliCommand>(['restore', 'web'])],
  // --settings：只有 restore 的「覆盖 settings 文件路径」用得到。
  ['--settings', new Set<CliCommand>(['restore'])],
]);

/** 仅 reinstall 子命令允许的参数 */
const REINSTALL_ONLY_FLAGS = new Set(['--yes', '--list', '--wipe-config', '--version']);

/** 仅 import 允许的参数（--out/--dry-run 与 backup/restore 共用，故不在此表） */
const IMPORT_ONLY_FLAGS = new Set(['--from', '--cwd']);

/** 仅 web（离线救急台）允许的参数 */
const WEB_ONLY_FLAGS = new Set(['--port', '--no-open', '--idle-timeout']);

/** web 明确不支持的参数：宁可报错，也不悄悄忽略（它们属于读写命令，不属于只读台） */
const WEB_REJECTED_FLAGS = new Set([
  '--id', '--settings', '--dry-run', '--sections', '--out', '--yes', '--list',
  '--wipe-config', '--version', '--json', '--fix',
]);

/** recover-stale-lock 专用解析：只接受 --data-dir（用于定位 locks 目录），返回 dataDir 选项 */
function parseCliDataDir(argv: readonly string[]): ParseResult {
  const options: CliOptions = { command: 'recover-stale-lock', dryRun: false, profile: 'web', yes: false, list: false, wipeConfig: false, json: false, positionals: [] };
  for (let i = 1; i < argv.length; i += 1) {
    const flag = argv[i]!;
    if (flag === '--help' || flag === '-h') {
      return { ok: true, options: { ...options, command: 'help', helpTopic: 'recover-stale-lock' } };
    }
    if (flag === '--data-dir') {
      const value = argv[i + 1];
      if (value === undefined || value === '' || value.startsWith('-')) {
        return { ok: false, error: '参数 --data-dir 缺少值 / missing value for --data-dir' };
      }
      options.dataDir = value;
      i += 1;
    } else if (flag.startsWith('--data-dir=')) {
      options.dataDir = flag.slice('--data-dir='.length);
      if (options.dataDir === '') return { ok: false, error: '参数 --data-dir 缺少值 / missing value for --data-dir' };
    } else {
      return { ok: false, error: `未知参数 / unknown flag: ${flag}` };
    }
  }
  return { ok: true, options };
}

/*
 * 「本机有没有 DSH 在跑」的判据已抽到 src/cli/actions.ts 的 readRunningInstances
 * （救急台网页与 sessions repair 的安全门共用同一实现；旧实现把快照目录当 dataDir 用，
 * 缺省路径下找不到心跳 → 门形同虚设，已一并修正）。
 */



/**
 * sessions 专用解析：sessions repair [--home <dir>] [--fix] [--keep <dir>] [--map old=new]... [--json]
 *
 * 与 recover-stale-lock 同样的姿态：独立解析器，只接受本动作真正有意义的参数（绝不悄悄忽略）。
 */
function parseCliSessions(argv: readonly string[]): ParseResult {
  const options: CliOptions = {
    command: 'sessions', dryRun: false, profile: 'web', yes: false, list: false,
    wipeConfig: false, json: false, positionals: [], maps: [],
  };
  const rest = argv.slice(1);
  const action = rest[0];
  if (action === undefined) return { ok: false, error: 'sessions 需要子动作 / missing action: sessions repair' };
  if (action === '--help' || action === '-h') {
    return { ok: true, options: { ...options, command: 'help', helpTopic: 'sessions' } };
  }
  // T6：三个只读/安全动作 —— list（列出会话）/ doctor（体检）/ repair（预览或 --fix 执行）
  if (action !== 'repair' && action !== 'list' && action !== 'doctor') {
    return { ok: false, error: 'sessions 只支持 list / doctor / repair / unsupported action: ' + action };
  }
  options.positionals.push(action);
  for (let i = 1; i < rest.length; i += 1) {
    const flag = rest[i]!;
    if (flag === '--help' || flag === '-h') {
      return { ok: true, options: { ...options, command: 'help', helpTopic: 'sessions' } };
    }
    if (flag === '--fix') { options.fix = true; continue; }
    if (flag === '--apply') { options.fix = true; continue; }  // --apply 是 --fix 的可读别名（T6）
    if (flag === '--json') { options.json = true; continue; }
    if (flag === '--home' || flag === '--keep' || flag === '--map') {
      const value = rest[i + 1];
      if (value === undefined || value === '' || value.startsWith('-')) {
        return { ok: false, error: '参数 ' + flag + ' 缺少值 / missing value for ' + flag };
      }
      if (flag === '--home') options.home = value;
      else if (flag === '--keep') options.keep = value;
      else options.maps!.push(value);
      i += 1;
      continue;
    }
    if (flag.startsWith('--home=') || flag.startsWith('--keep=') || flag.startsWith('--map=')) {
      const at = flag.indexOf('=');
      const name = flag.slice(0, at);
      const value = flag.slice(at + 1);
      if (value === '') return { ok: false, error: '参数 ' + name + ' 缺少值 / missing value for ' + name };
      if (name === '--home') options.home = value;
      else if (name === '--keep') options.keep = value;
      else options.maps!.push(value);
      continue;
    }
    return { ok: false, error: '未知参数 / unknown flag: ' + flag };
  }
  return { ok: true, options };
}

/**
 * import 专用解析：`import --from <source> [--dry-run] [--out <path>] [--cwd <dir>] [--data-dir <dir>]`
 *
 * 与 sessions / recover-stale-lock 同样的姿态：只接受本动作真正有意义的参数（绝不悄悄忽略）。
 * `--from` 的值在这里**不做词表校验**：未知来源要由运行层给出「可用来源清单」——
 * 那需要真实注册表（CLI 与宿主共用同一份装配，见 src/foreign/registry.ts）。
 */
function parseCliImport(argv: readonly string[]): ParseResult {
  const options: CliOptions = {
    command: 'import', dryRun: false, profile: 'web', yes: false, list: false,
    wipeConfig: false, json: false, positionals: [],
  };
  const rest = argv.slice(1);
  for (let i = 0; i < rest.length; i += 1) {
    const flag = rest[i]!;
    if (flag === '--help' || flag === '-h') return { ok: true, options: { ...options, command: 'help', helpTopic: 'import' } };
    if (flag === '--dry-run') {
      options.dryRun = true;
      continue;
    }
    const at = flag.indexOf('=');
    const name = at >= 0 ? flag.slice(0, at) : flag;
    const isValueFlag = name === '--from' || name === '--cwd' || name === '--out' || name === '--data-dir';
    if (isValueFlag) {
      const value = at >= 0 ? flag.slice(at + 1) : rest[i + 1];
      if (value === undefined || value === '' || value.startsWith('-')) {
        return { ok: false, error: '参数 ' + name + ' 缺少值 / missing value for ' + name };
      }
      if (name === '--from') options.from = value;
      else if (name === '--cwd') options.cwd = value;
      else if (name === '--out') options.out = value;
      else options.dataDir = value;
      if (at < 0) i += 1;
      continue;
    }
    return { ok: false, error: '未知参数 / unknown flag: ' + flag };
  }
  if (options.from === undefined || options.from === '') {
    return { ok: false, error: 'import 需要 --from <来源> / import requires --from <source>' };
  }
  return { ok: true, options };
}

/** 解析 CLI 参数（纯函数；help 返回 command:'help'，未知/缺值返回错误） */
export function parseCli(argv: readonly string[]): ParseResult {  const command = argv[0];
  if (command === undefined) return { ok: false, error: '缺少子命令 / missing subcommand' };
  if (command === '--help' || command === '-h' || command === 'help') {
    const base: CliOptions = { command: 'help', dryRun: false, profile: 'web', yes: false, list: false, wipeConfig: false, json: false, positionals: [] };
    // `dcm help <命令>`：把主题带下去（认不认识由运行层判定，解析器不重复维护一份命令表）
    const topic = argv[1];
    if (command === 'help' && topic !== undefined && topic !== '' && !topic.startsWith('-')) {
      return { ok: true, options: { ...base, helpTopic: topic } };
    }
    return { ok: true, options: base };
  }
  if (command !== 'snapshots' && command !== 'restore' && command !== 'reinstall' && command !== 'sessions'
    && command !== 'recover-stale-lock' && command !== 'verify' && command !== 'backup' && command !== 'web'
    && command !== 'import') {
    return { ok: false, error: `未知子命令 / unknown subcommand: ${command}` };
  }
  if (command === 'sessions') return parseCliSessions(argv);
  if (command === 'import') return parseCliImport(argv);
  if (command === 'recover-stale-lock') {
    // recover-stale-lock：独立显式 recovery，不接受 destructive 执行参数（只能 --data-dir 定位锁目录）。
    // 只需 parseCliDataDir —— 它自己就会拒绝任何未知 flag。此前这里还有一道「逐 token 只许 --data-dir」的
    // 前置校验，会把 `--data-dir <dir>` 的**值**也当成非法 token 拒掉（只有 `--data-dir=<dir>` 能过），
    // 于是 help 里写的空格写法在这个「只剩 CLI 可用」的紧急路径上失效。
    return parseCliDataDir(argv);
  }

  const options: CliOptions = { command, dryRun: false, profile: 'web', yes: false, list: false, wipeConfig: false, json: false, positionals: [] };
  const rest = argv.slice(1);
  for (let i = 0; i < rest.length; i += 1) {
    const flag = rest[i]!;
    if (flag === '--help' || flag === '-h') {
      return { ok: true, options: { ...options, command: 'help', helpTopic: command } };
    }
    // 位置参数：仅 verify 接受（文件名或路径），其余子命令沿用「未知参数」拒绝
    if (!flag.startsWith('-')) {
      if (command === 'verify') {
        if (options.positionals.length >= 1) {
          return { ok: false, error: 'verify 只接受一个目标 / verify accepts a single target' };
        }
        options.positionals.push(flag);
        continue;
      }
      return { ok: false, error: `未知参数 / unknown flag: ${flag}` };
    }
    if (command !== 'verify' && VERIFY_ONLY_FLAGS.has(flag)) {
      return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (IMPORT_ONLY_FLAGS.has(flag)) {
      return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (command !== 'backup' && BACKUP_ONLY_FLAGS.has(flag)) {
      return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (command === 'backup' && BACKUP_REJECTED_FLAGS.has(flag)) {
      return { ok: false, error: `backup 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (flag === '--json') {
      options.json = true;
      continue;
    }
    // 本命令用不到的参数一律拒绝（绝不「悄悄接受并忽略」）：白名单见 FLAG_ALLOWED_COMMANDS。
    const allowedCommands = FLAG_ALLOWED_COMMANDS.get(flag);
    if (allowedCommands !== undefined && !allowedCommands.has(command)) {
      return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (command !== 'reinstall' && REINSTALL_ONLY_FLAGS.has(flag)) {
      return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (command !== 'web' && WEB_ONLY_FLAGS.has(flag)) {
      return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (command === 'web' && WEB_REJECTED_FLAGS.has(flag)) {
      return { ok: false, error: `web 子命令不支持参数 / flag not allowed here: ${flag}` };
    }
    if (flag === '--no-open') {
      options.noOpen = true;
      continue;
    }
    if (flag === '--home') {
      // --home 只属于 web（sessions 有自己的解析器）：其余子命令沿用改造前的拒绝行为
      if (command !== 'web') {
        return { ok: false, error: `${command} 子命令不支持参数 / flag not allowed here: ${flag}` };
      }
      const value = rest[i + 1];
      if (value === undefined || value === '' || value.startsWith('-')) {
        return { ok: false, error: '参数 --home 缺少值 / missing value for --home' };
      }
      options.home = value;
      i += 1;
      continue;
    }
    if (flag === '--port' || flag === '--idle-timeout') {
      const value = rest[i + 1];
      if (value === undefined || value === '' || value.startsWith('-')) {
        return { ok: false, error: `参数 ${flag} 缺少值 / missing value for ${flag}` };
      }
      const parsed = Number(value);
      if (!Number.isInteger(parsed) || parsed < 0 || (flag === '--port' && parsed > 65535)) {
        return { ok: false, error: `参数 ${flag} 需要 0 以上的整数 / ${flag} expects a non-negative integer` };
      }
      if (flag === '--port') options.port = parsed;
      else options.idleTimeoutMin = parsed;
      i += 1;
      continue;
    }
    if (flag === '--dry-run') {
      options.dryRun = true;
      continue;
    }
    if (flag === '--yes') {
      options.yes = true;
      continue;
    }
    if (flag === '--list') {
      options.list = true;
      continue;
    }
    if (flag === '--wipe-config') {
      options.wipeConfig = true;
      continue;
    }
    if (flag === '--version') {
      const value = rest[i + 1];
      if (value === undefined || value === '' || value.startsWith('-')) {
        return { ok: false, error: '参数 --version 缺少值 / missing value for --version' };
      }
      options.version = value;
      i += 1;
      continue;
    }
    const key = VALUE_FLAGS.get(flag);
    if (key === undefined) {
      return { ok: false, error: `未知参数 / unknown flag: ${flag}` };
    }
    const value = rest[i + 1];
    if (value === undefined || value === '' || value.startsWith('-')) {
      return { ok: false, error: `参数 ${flag} 缺少值 / missing value for ${flag}` };
    }
    if (key === 'sections') {
      // 分区名提前校验：未知/离线不可用的分区一律在这里拒绝（不留到收集阶段才报）
      const parsed = parseSectionsArg(value);
      if (!parsed.ok) return { ok: false, error: parsed.error };
    }
    options[key] = value;
    i += 1;
  }
  return { ok: true, options };
}

/** 解析 reinstall 交互多选输入：逗号/空格分隔的 1-based 编号；空串返回 null（用默认）。非法编号也返回 null。 */
export function parseSelectionInput(text: string): Set<ReinstallItemId> | null {
  const trimmed = text.trim();
  if (trimmed === '') return null;
  const parts = trimmed.split(/[,，\s]+/).filter((p) => p !== '');
  const indexes = parts.map((p) => Number(p));
  const valid = indexes.length > 0
    && indexes.every((n) => Number.isInteger(n) && n >= 1 && n <= REINSTALL_ITEMS.length);
  if (!valid) return null;
  const set = new Set<ReinstallItemId>();
  for (const n of indexes) set.add(REINSTALL_ITEMS[n - 1]!.id);
  return set;
}

/** 解析 reinstall 二次确认输入：仅 "YES" 或 "Y"（忽略大小写/空白）视为确认。 */
export function parseConfirmInput(text: string): boolean {
  const t = text.trim().toUpperCase();
  return t === 'YES' || t === 'Y';
}

/** $DSH_HOME：环境变量优先，缺省 ~/.dsh（dsh-home-paths 的简化规则，CLI 零依赖版） */
export function resolveDshHome(env: Record<string, string | undefined> = process.env): string {
  const fromEnv = env.DSH_HOME;
  if (fromEnv !== undefined && fromEnv !== '') return fromEnv;
  return path.join(os.homedir(), '.dsh');
}

/** 快照数据目录：--data-dir 覆盖优先，缺省 $DSH_HOME/dsh-config-manager/snapshots */
export function resolveDataDir(flag: string | undefined, env: Record<string, string | undefined> = process.env): string {
  if (flag !== undefined && flag !== '') return flag;
  return path.join(resolveDshHome(env), 'dsh-config-manager', 'snapshots');
}

/**
 * 插件「控制面根」候选（= 宿主 config.dataDir）：SAFE MODE 标记（<root>/transactions/safe-mode）、
 * 环境锁（<root>/locks）、journal 都在它之下 —— 与 src/index.ts 的 dataDir 派生、core/phase3-host.ts 的
 * safeModeMarkerPath 同一语义。
 *
 * CLI 的 --data-dir 只表达「快照目录 / 导出目录」，单凭它无法区分两种真实用法：
 *   a) --data-dir <root>/snapshots（文档语义）→ 控制面根 = 其父目录；b) --data-dir <root>（直接给数据根）；
 * 两者都进候选，另恒加缺省根 $DSH_HOME/dsh-config-manager —— 多查几处只会更保守，不会放过标记。
 * --data-root 显式给出时以它为准（权威判定，不再叠加推断候选）。
 */
export function resolveControlRoots(
  opts: { dataRoot?: string; dataDir?: string } = {},
  env: Record<string, string | undefined> = process.env,
): string[] {
  const out: string[] = [];
  const add = (dir: string): void => {
    const abs = path.resolve(dir);
    if (!out.includes(abs)) out.push(abs);
  };
  if (opts.dataRoot !== undefined && opts.dataRoot !== '') {
    add(opts.dataRoot);
    return out;
  }
  if (opts.dataDir !== undefined && opts.dataDir !== '') {
    add(opts.dataDir);
    add(path.dirname(path.resolve(opts.dataDir)));
  }
  add(path.join(resolveDshHome(env), 'dsh-config-manager'));
  return out;
}

/**
 * `recover-stale-lock` 的锁目录解析：在「候选控制面根」（与 SAFE MODE 同源）里挑第一个**真的躺着**
 * ownership 文件的 `<root>/locks`；全都没命中 → 缺省根 `$DSH_HOME/dsh-config-manager/locks`。
 *
 * 为什么不能写死缺省根（issue #36 的兜底路径）：宿主 `dataDir` 可被配置成非缺省值，写死会让残留锁
 * 「明明在磁盘上，CLI 却报没有」→ 用户只能手工删锁文件（正是本命令要消灭的处境）。
 */
export function resolveRecoverLocksDir(
  opts: { dataRoot?: string; dataDir?: string } = {},
  env: Record<string, string | undefined> = process.env,
): string {
  const fallback = path.join(resolveDshHome(env), 'dsh-config-manager', 'locks');
  for (const root of resolveControlRoots(opts, env)) {
    const candidate = path.join(root, 'locks');
    if (fssync.existsSync(path.join(candidate, OWNERSHIP_FILE))) return candidate;
  }
  return fallback;
}

/**
 * Phase 3 SAFE MODE 门：任一候选控制面根下存在 durable 标记 → 返回错误文案（调用方必须拒绝执行）。
 * 返回 null = 明确未阻断。
 * fail-closed：标记无法读取 / 无法判定（'unknown'）一律拒绝 —— 「读不到就放行」正是审计 P0-11 的静默旁路。
 */
export function checkSafeModeBlocked(roots: readonly string[]): string | null {
  if (roots.length === 0) {
    return '无法确定插件数据目录（控制面根），出于安全考虑拒绝执行 / cannot determine the plugin data root; refusing to run';
  }
  for (const root of roots) {
    const marker = safeModeMarkerPath(root);
    const state = readSafeModeMarkerSync(root);
    if (state === 'blocked') {
      return `存在未恢复的配置 transaction（SAFE MODE 激活，标记：${marker}）。destructive 操作被阻断：请先用恢复流程处理（GUI 恢复 / 显式 recover）后再重试。`;
    }
    if (state === 'unknown') {
      return `无法读取 SAFE MODE 标记（${marker}）或无法判定其状态，无法确认是否安全，已拒绝执行 / cannot read or determine the SAFE MODE marker; refusing to run.`;
    }
  }
  return null;
}

/** 快照 id 校验：拒绝路径分隔符/保留名（防 join 越界） */
export function validateSnapshotId(id: string): string {
  if (id === '' || id === '.' || id === '..' || id.includes('/') || id.includes('\\')) {
    throw new Error(`非法快照 id / invalid snapshot id: ${JSON.stringify(id)}`);
  }
  return id;
}

/** 缺省快照选择：metas 已按 createdAt 倒序，取第一个 status !== 'rolled-back' */
export function pickDefaultSnapshotId(metas: readonly SnapshotMeta[]): string | null {
  const eligible = metas.find((m) => m.status !== 'rolled-back');
  return eligible?.id ?? null;
}

/* ------------------------------------------------------------ 输出 */

export interface CliIo {
  log: (s: string) => void;
  error: (s: string) => void;
}

const defaultIo: CliIo = { log: (s) => console.log(s), error: (s) => console.error(s) };

/**
 * CLI 写进 manifest.exporter.version 的版本号。
 *
 * **运行时从 package.json 读取，不硬编码**：本仓库铁律是「版本必须同步多处」，
 * 再加一个常量就等于多一个会漂移的同步点（实测已发生：插件升到 0.1.59 后，
 * 这个常量仍停在 0.1.58，导致新产出的备份被标成旧版本）。
 * 只用 node 内置 `node:fs`，不引入 DSH 依赖，不破坏「CLI 零 @deepseek-ai 依赖」铁律。
 *
 * 路径解析：`src/cli/index.ts`（源码直跑）与 `lib/cli/index.js`（发布产物）都在包根下两级，
 * 因此 `../../package.json` 两种形态均正确。读取失败时回退为中性占位（绝不谎报具体版本）。
 */
function resolveCliVersion(): string {
  try {
    const pkgUrl = new URL('../../package.json', import.meta.url);
    const parsed = JSON.parse(fssync.readFileSync(pkgUrl, 'utf8')) as { version?: unknown };
    if (typeof parsed.version === 'string' && parsed.version !== '') return parsed.version;
  } catch {
    // 包结构不可解析（被裁剪/单文件打包）：回退中性占位，不谎报版本
  }
  return '0.0.0-unknown';
}

/** 进程内缓存（每次 CLI 运行只读一次 package.json） */
const CLI_EXPORTER_VERSION = resolveCliVersion();

export function printUsage(io: CliIo = defaultIo): void {
  io.log(renderOverview(CLI_EXPORTER_VERSION).join('\n'));
}

/**
 * 打印单命令详情页（`dcm <命令> --help` / `dcm help <命令>`）。
 *
 * 返回 false 表示不认识该命令名（调用方决定报错文案）；成功时已写完输出。
 * 文案与退出码都在 ./help.ts，本函数只做「渲染 → 输出」。
 */
export function printCommandUsage(name: string, io: CliIo = defaultIo): boolean {
  const lines = renderCommandHelp(name, CLI_EXPORTER_VERSION);
  if (lines === null) return false;
  io.log(lines.join('\n'));
  return true;
}


function printSnapshots(metas: SnapshotMeta[], io: CliIo): void {
  if (metas.length === 0) {
    io.log('（无快照 / no snapshots）');
    return;
  }
  const headers = ['ID', 'CREATED_AT', 'SOURCE_ZIP', 'STATUS', 'ENTRIES', 'HOST_FILES', 'PLUGINS'];
  const rows = metas.map((m) => [
    m.id, m.createdAt, m.sourceZip, m.status ?? 'unknown',
    String(m.entryCount), String(m.hostFileBackupCount), String(m.beforePluginCount),
  ]);
  const widths = headers.map((h, i) => Math.max(h.length, ...rows.map((r) => r[i]!.length)));
  const line = (cells: string[]): string => cells.map((c, i) => c.padEnd(widths[i]!)).join('  ').trimEnd();
  io.log(line(headers));
  for (const r of rows) io.log(line(r));
}

function printPlan(plan: RestorePlan, io: CliIo): void {
  io.log(`快照 / snapshot: ${plan.snapshotId}`);
  io.log(`创建时间 / createdAt: ${plan.createdAt}`);
  io.log(`来源备份 / sourceZip: ${plan.sourceZip}`);
  io.log(`插件基线 / plugin baseline: ${plan.pluginBaselineConfirmed ? '已确认 / confirmed' : '缺失 / missing（不计划插件卸载）'}`);
  io.log(`动作计划 / plan（${plan.actions.length} 项 actions）：`);
  for (const a of plan.actions) {
    const detail = a.detail !== undefined ? `（${a.detail}）` : '';
    io.log(`  [${a.kind.padEnd(14)}] ${a.description}${detail}`);
  }
  const s = plan.summary;
  io.log(
    `汇总 / summary: 整文件还原 ${s.hostFileRestores} · 整文件删除 ${s.hostFileRemoves}`
    + ` · 插件卸载 ${s.pluginRemoves} · 文件还原 ${s.fileRestores} · 文件删除 ${s.fileRemoves}`
    + ` · 凭据提示 ${s.credentialHints} · 跳过 ${s.skips}`,
  );
}

function printReport(report: RestoreReport, io: CliIo): void {
  io.log(`恢复完成 / restore done — 快照 ${report.snapshotId}`);
  io.log(`已还原 / restored（${report.restored.length}）：`);
  for (const r of report.restored) io.log(`  - ${r}`);
  io.log(`已卸载插件 / removed plugins（${report.removedPlugins.length}）：`);
  for (const p of report.removedPlugins) io.log(`  - ${p}`);
  io.log(`需人工处理 / manual hints（${report.manualHints.length}）：`);
  for (const h of report.manualHints) io.log(`  - ${h}`);
  io.log(`失败 / failed（${report.failed.length}）：`);
  for (const f of report.failed) io.log(`  - ${f.item}: ${f.reason}`);
  io.log(`跳过 / skipped（${report.skipped.length}）：`);
  for (const sk of report.skipped) io.log(`  - ${sk}`);
}

function printReinstallItems(io: CliIo): void {
  io.log('可选清理项 / selectable items（默认勾选项带 *，[危险] 需二次确认）:');
  const lines = REINSTALL_ITEMS.map((it, idx) => {
    const mark = it.defaultOn ? '*' : ' ';
    const risk = it.destructive ? ' [危险/destructive]' : '';
    return `  ${mark} ${idx + 1}. ${it.label} — ${it.desc}${risk}`;
  });
  io.log(lines.join('\n'));
}

function printReinstallPlan(plan: ReinstallPlan, io: CliIo): void {
  io.log(`重装计划 / reinstall plan — 版本 ${plan.version}`);
  if (plan.wipeConfig) {
    io.log('⚠ 该计划将清除 ~/.dsh 数据（settings/plugins/data），执行前会先备份到 .reinstall-backup / WARNING: will wipe ~/.dsh data');
  }
  io.log(`步骤 / steps（${plan.steps.length}）：`);
  for (const s of plan.steps) {
    const tag = s.dangerous ? '[D]' : '   ';
    io.log(`  ${tag} ${s.label}`);
    io.log(`      ${s.command}`);
  }
}

/* ------------------------------------------------------------ reinstall 交互与执行 */

export interface CliDeps {
  /** 交互提问（缺省用真实 stdin/stdout readline） */
  ask?: (prompt: string) => Promise<string>;
  /** 命令执行器（缺省跨平台：Windows powershell -Command / Unix bash -c） */
  exec?: (cmd: string) => Promise<string>;
  /** 平台（仅影响缺省 exec 的包装方式，缺省 process.platform） */
  platform?: NodeJS.Platform;
}

type Exec = (cmd: string) => Promise<string>;

/** 运行一条外部命令并返回 stdout（错误时 reject）。 */
function runExternal(file: string, args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(file, args, { encoding: 'utf8' }, (error, stdout) => {
      if (error !== null) {
        reject(error instanceof Error ? error : new Error(String(error)));
        return;
      }
      resolve(typeof stdout === 'string' ? stdout : String(stdout));
    });
  });
}

/**
 * 缺省跨平台执行器：Windows 经 `powershell -NoProfile -Command <cmd>`，
 * Unix 经 `bash -c <cmd>` 整条命令串直接跑（步骤命令含 PowerShell 内建与 npm）。
 * 同样用于 buildReinstallPlan 内的 `npm root -g` 路径解析。
 */
function createDefaultExec(platform: NodeJS.Platform = process.platform): Exec {
  return async (cmd: string): Promise<string> => {
    if (isWindows(platform)) {
      return runExternal('powershell', ['-NoProfile', '-Command', cmd]);
    }
    return runExternal('bash', ['-c', cmd]);
  };
}

let defaultRl: ReturnType<typeof createInterface> | undefined;
/** 缺省交互提问（懒建真实 readline；注入 ask 时不会创建）。 */
async function defaultAsk(prompt: string): Promise<string> {
  if (defaultRl === undefined) {
    defaultRl = createInterface({ input: processStdin, output: processStdout });
  }
  return defaultRl.question(prompt);
}
function closeDefaultAsk(): void {
  if (defaultRl !== undefined) {
    defaultRl.close();
    defaultRl = undefined;
  }
}

/** 交互多选：打印编号清单，按 "1,3,5" 输入，空回车用默认。 */
async function interactiveReinstallSelect(
  defaults: Set<ReinstallItemId>,
  io: CliIo,
  ask: (prompt: string) => Promise<string>,
): Promise<Set<ReinstallItemId>> {
  io.log('可选清理项 / selectable items（默认勾选项带 *，[危险] 需二次确认）:');
  const lines = REINSTALL_ITEMS.map((it, idx) => {
    const mark = defaults.has(it.id) ? '*' : ' ';
    const risk = it.destructive ? ' [危险/destructive]' : '';
    return `  ${mark} ${idx + 1}. ${it.label} — ${it.desc}${risk}`;
  });
  io.log(lines.join('\n'));
  io.log('输入数字多选（逗号/空格分隔，如 1,3,5），空回车用默认 / enter numbers, empty for default');
  for (;;) {
    const line = (await ask('选择 / select> ')).trim();
    if (line === '') return defaults;
    const parsed = parseSelectionInput(line);
    if (parsed === null) {
      io.log('输入无效，请重新输入（1~5，空回车用默认）/ invalid input, try again');
      continue;
    }
    return parsed;
  }
}

async function runReinstall(
  options: CliOptions,
  io: CliIo,
  env: Record<string, string | undefined>,
  deps: CliDeps,
): Promise<number> {
  const ask = deps.ask ?? defaultAsk;
  const exec: Exec = deps.exec ?? createDefaultExec(deps.platform);
  try {
    if (options.list) {
      printReinstallItems(io);
      return 0;
    }

    let selection: Set<ReinstallItemId>;
    if (options.yes) {
      // 非交互：全选 + 跳过二次确认
      selection = new Set(REINSTALL_ITEMS.map((it) => it.id));
    } else {
      const defaults: Set<ReinstallItemId> = new Set(
        REINSTALL_ITEMS.filter((it) => it.defaultOn).map((it) => it.id),
      );
      if (options.wipeConfig) {
        defaults.add('settings');
        defaults.add('plugins');
        defaults.add('data');
      }
      selection = await interactiveReinstallSelect(defaults, io, ask);
      const hasDestructive = [...selection].some((id) =>
        REINSTALL_ITEMS.find((it) => it.id === id)?.destructive === true,
      );
      if (hasDestructive || options.wipeConfig) {
        io.log('⚠ 所选动作包含清除 ~/.dsh 数据的危险步骤（执行前会先做 .reinstall-backup 备份）。/ WARNING: destructive ~/.dsh actions selected');
        if (!parseConfirmInput(await ask('输入 YES 确认继续 / type YES to continue> '))) {
          io.log('已取消 / cancelled');
          return 1;
        }
      }
    }

    const plan = await buildReinstallPlan(selection, options.version ?? 'latest', exec, env);

    if (options.dryRun) {
      printReinstallPlan(plan, io);
      return 0;
    }

    // Phase 3 SAFE MODE：存在未恢复 transaction → 拒绝 destructive（CLI 不旁路 SAFE MODE）。
    // 控制面根按候选定位（--data-root → --data-dir 派生 → 缺省根），不再写死 $DSH_HOME/dsh-config-manager。
    const safeMsg = checkSafeModeBlocked(resolveControlRoots({ dataRoot: options.dataRoot, dataDir: options.dataDir }, env));
    if (safeMsg !== null) {
      io.error(`拒绝执行：${safeMsg}`);
      return 1;
    }

    // 执行（Phase 2 锁：reinstall 卸载/清扫/重装属 GLOBAL destructive，必须成功获取环境锁）
    const lockHome = resolveDshHome(env);
    const lock = new EnvironmentLockManager({
      locksDir: path.join(lockHome, 'dsh-config-manager', 'locks'),
      op: 'cli-reinstall',
      target: plan.version,
      lockVersion: '0.1.0',
    });
    const failed: Array<{ label: string; command: string; reason: string }> = [];
    // Phase 3 P0-A：CLI reinstall 也建 intent journal（外部副作用不可证明 → crash 后 NEEDS_ATTENTION）。
    const cliDataDir = path.join(lockHome, 'dsh-config-manager');
    const recovery = new Phase3Recovery({ dataDir: cliDataDir, packageVersion: '0.1.0', fingerprintDataDir: cliDataDir });
    await recovery.initFingerprint().catch(() => undefined);
    try {
      await runWithMutationLock(lock, { op: 'cli-reinstall', target: plan.version }, async (lockCtx) => {
        const runReinstall = async (journalCtx?: { operationId?: string }): Promise<void> => {
          io.log(`开始重装 / reinstall started — 版本 ${plan.version}`);
          // Phase 4 F29/F30：在首个 destructive side effect（npm uninstall -g）前，写 durable
          // operation-bound recovery point。若涉及 program 步但无法探测旧版本 → fail-closed，不继续 uninstall。
          if (selection.has('program')) {
            const prev = await detectInstalledDshVersion(exec);
            if (prev === null) {
              const message = '无法探测当前已安装 DSH 版本，拒绝执行 program 步（fail-closed）：先手动确认 dsh --version 可用';
              failed.push({ label: 'program recovery point', command: 'detectInstalledDshVersion', reason: message });
              io.error(`✘ ${message}`);
              // 不执行任何步骤（避免在无 recovery point 下 uninstall）
              return;
            }
            try {
              const opId = journalCtx?.operationId ?? 'cli-reinstall';
              await writeReinstallRecoveryPoint(cliDataDir, {
                operationId: opId,
                environmentFingerprint: recovery.recoveryEnvFingerprint,
                previousInstalledVersion: prev,
                requestedTargetSpec: plan.version,
                createdAt: new Date().toISOString(),
                recoveryHint: `如需手动恢复此版本：npm install -g @deepseek-ai/dsh@${prev}`,
              });
            } catch (rpErr) {
              const message = `recovery point 写入失败，拒绝执行 program 步（fail-closed）：${rpErr instanceof Error ? rpErr.message : String(rpErr)}`;
              failed.push({ label: 'program recovery point', command: 'writeReinstallRecoveryPoint', reason: message });
              io.error(`✘ ${message}`);
              return;
            }
          }
          for (const step of plan.steps) {
            if (step.dangerous) {
              io.log(`⚠ 危险步骤 / dangerous step: ${step.label}`);
            }
            try {
              await exec(step.command);
              io.log(`✔ ${step.label}`);
            } catch (err) {
              const reason = err instanceof Error ? err.message : String(err);
              failed.push({ label: step.label, command: step.command, reason });
              io.error(`✘ ${step.label} — ${reason}`);
            }
          }
        };
        if (lockCtx !== null) {
          await recovery.runExternalIntent({ operationType: 'cli-reinstall', lockCtx, intent: { adapter: 'dsh', ref: 'program', kind: 'Reinstall' }, fn: runReinstall });
        } else {
          await runReinstall();
        }
      });
    } catch (err) {
      if (err instanceof EnvironmentLockUnavailableError) {
        io.error(`拒绝执行：${err.message}`)
        return 1;
      }
      throw err;
    }
    io.log(failed.length === 0 ? '重装完成 / reinstall done' : `重装完成但有 ${failed.length} 步失败 / done with ${failed.length} failed step(s)`);
    for (const f of failed) {
      io.error(`  - ${f.label}（${f.command}）: ${f.reason}`);
    }
    return failed.length > 0 ? 1 : 0;
  } finally {
    closeDefaultAsk();
  }
}

/* ------------------------------------------------------------ 执行 */

/**
 * CLI 主流程（io/env/deps 可注入供测试）：
 * snapshots → 列表；restore → dry-run 打印计划 / 执行并打印诚实报告；
 * reinstall → 交互多选 + 二次确认 + 跨平台执行。失败项存在时 exit 1，否则 0。
 */
export async function runCli(
  argv: readonly string[],
  io: CliIo = defaultIo,
  env: Record<string, string | undefined> = process.env,
  deps: CliDeps = {},
): Promise<number> {
  const parsed = parseCli(argv);
  if (!parsed.ok) {
    io.error(parsed.error);
    printUsage(io);
    return 1;
  }
  const { options } = parsed;
  if (options.command === 'help') {
    const topic = options.helpTopic;
    if (topic === undefined) {
      printUsage(io);
      return 0;
    }
    // 认不出的主题不静默回落：先说出来，再给速查页（否则用户以为拼错的名字是有效的）
    if (!printCommandUsage(topic, io)) {
      io.error('未知命令 / unknown command: ' + topic);
      printUsage(io);
      return 1;
    }
    return 0;
  }
  if (options.command === 'reinstall') {
    return runReinstall(options, io, env, deps);
  }
  // web：离线只读救急台（只绑 127.0.0.1 的本地网页；不写配置、不需要环境锁）
  if (options.command === 'web') {
    return runWeb(options, io, env);
  }
  // verify / backup 全程只读或只写导出目录：不碰 $DSH_HOME 配置、不需要环境锁
  if (options.command === 'verify') {
    return runVerify(options, io, env);
  }
  if (options.command === 'backup') {
    return runBackup(options, io, env);
  }
  // import：把外部 agent 配置翻译成标准 bundle（dry-run 零写入；只可能写导出目录，不碰 $DSH_HOME 配置）
  if (options.command === 'import') {
    return runImportSource(
      {
        from: options.from ?? '',
        dryRun: options.dryRun,
        exportsDir: resolveExportsDir(options.dataDir, env),
        exporterVersion: CLI_EXPORTER_VERSION,
        ...(options.out !== undefined ? { out: options.out } : {}),
        ...(options.cwd !== undefined ? { cwd: options.cwd } : {}),
      },
      io,
      env,
    );
  }
  if (options.command === 'sessions') {
    // 离线修复：只读写会话目录，默认 dry-run（零写入）。list/doctor 纯只读，连「DSH 在跑」都不用管。
    // **--fix 走与救急台完全相同的写入门**（actions.ts 的 checkWriteGates，顺序 SAFE MODE → 残留环境锁 → DSH 未运行）：
    // 此前这里只查「DSH 在跑」，于是 SAFE MODE 激活 / 残留环境锁时 CLI 仍能改写会话字节 —— 与救急台判据分叉（审计 P1）。
    const home = options.home ?? resolveDshHome(env);
    const action = options.positionals[0] ?? 'repair';
    // T6：list / doctor 是**只读**动作 —— 不检查「DSH 是否在跑」，因为读永远不会伤害运行中的实例。
    if (action === 'list' || action === 'doctor') {
      return runSessionsInspect(
        { home, action: action === 'doctor' ? 'doctor' : 'list', json: options.json },
        io,
      );
    }
    // T6：repair（含 --fix/--apply）先跑安全修复计划；写操作前三道门与救急台逐条同源。
    if (options.fix === true) {
      const controlOpts = { dataRoot: options.dataRoot, dataDir: options.dataDir };
      const gate = await checkWriteGates(resolveControlRoots(controlOpts, env), {
        needsDshStopped: true,
        locksDir: resolveRecoverLocksDir(controlOpts, env),
      });
      if (!gate.ok) {
        io.error('拒绝执行：' + gate.reason);
        if (gate.code === 'dsh-running') {
          io.error('DSH running: close DSH before repairing session bytes.');
        } else if (gate.code === SAFE_MODE_REFUSAL_CODE) {
          io.error('SAFE MODE is active: resolve the pending transaction before writing session bytes.');
        } else if (gate.code === 'stale-lock') {
          io.error('A stale environment lock is present: run "dsh-config-manager recover-stale-lock" first.');
        }
        return 1;
      }
    }
    return runSessionsRepair(
      {
        home,
        fix: options.fix === true,
        ...(options.keep !== undefined ? { keep: options.keep } : {}),
        maps: options.maps ?? [],
        json: options.json,
      },
      io,
    );
  }

  const lockDataDir = resolveDataDir(options.dataDir, env);

  // recover-stale-lock：独立显式 recovery（只 inspect + prove stale + 原子回收；不自动、无 --force）。
  if (options.command === 'recover-stale-lock') {
    // 锁目录按候选根定位（宿主 dataDir 可被配置成非缺省值，写死缺省根会「找不到锁」→ 用户只能手工删文件）。
    const lock = new EnvironmentLockManager({
      locksDir: resolveRecoverLocksDir({ dataRoot: options.dataRoot, dataDir: options.dataDir }, env),
      op: 'recover-stale-lock',
      target: lockDataDir,
      lockVersion: '0.1.0',
    });
    const insp = await lock.inspectLockState();
    if (insp.state !== 'STALE_LOCK_DETECTED' && !(insp.state === 'UNKNOWN_STATE' && insp.detail?.includes('无有效 owner'))) {
      // 非 stale 或无法证明 → 拒绝 recovery（owner healthy 的活锁绝不删）
      io.error(`环境锁未判定为 stale（state=${insp.state}），拒绝 recovery。不会触碰活锁。/ lock not stale, recovery refused`);
      return 1;
    }
    const result = await lock.recoverStaleLock();
    if (result.ok && result.removed) {
      io.log(`已回收 stale 环境锁 / stale lock recovered: ${result.detail ?? ''}`);
      return 0;
    }
    io.error(`recovery 失败：${result.detail ?? '未知原因'}（可能二次验证失败，已保留 quarantine 文件供诊断）`);
    return 1;
  }

  const dataDir = lockDataDir;

  if (options.command === 'snapshots') {
    // 「读不到」≠「没有快照」（core/restore.ts 的 listSnapshots 只有 ENOENT 才算没有）：
    // 目录存在却读不出来时必须把事实打到 stderr 并以非 0 退出，绝不显示成「无快照」。
    const probe: { unreadable?: string } = {};
    const metas = await listSnapshots(dataDir, probe);
    if (probe.unreadable !== undefined) {
      io.error(probe.unreadable);
      io.error('读不到 ≠ 没有快照：请检查该目录的权限/形态，或用 --data-dir 指定正确位置。/ unreadable is not the same as no snapshots');
      return 1;
    }
    printSnapshots(metas, io);
    return 0;
  }

  // restore
  let id = options.id;
  if (id === undefined) {
    // 与 snapshots 同一口径：读不出来时如实打印（restore 的退出语义不变 —— 拿不到候选快照即拒绝执行）。
    const probe: { unreadable?: string } = {};
    const picked = pickDefaultSnapshotId(await listSnapshots(dataDir, probe));
    if (probe.unreadable !== undefined) {
      io.error(probe.unreadable);
      io.error('读不到 ≠ 没有快照：恢复拒绝在「不知道有哪些快照」的状态下继续。/ unreadable is not the same as no snapshots; refusing to restore');
      return 1;
    }
    if (picked === null) {
      io.error('没有可用快照（无快照或全部已回滚）/ no usable snapshot (none or all rolled-back)');
      return 1;
    }
    id = picked;
  }
  try {
    validateSnapshotId(id);
  } catch (err) {
    io.error(err instanceof Error ? err.message : String(err));
    return 1;
  }

  const snapshotDir = path.join(dataDir, id);
  const restoreOptions = {
    snapshotDir,
    homeDir: resolveDshHome(env),
    profile: options.profile,
    settingsPath: options.settings,
    // Phase 4 统一恢复校验（与 Host/ModelTools 同强度：存在/READY/manifest/blob-hash/symlink/provenance）
    snapshotsRoot: dataDir,
  };
  if (options.dryRun) {
    printPlan(await planRestore(restoreOptions), io);
    return 0;
  }
  // Phase 3 SAFE MODE：存在未恢复 transaction → 拒绝 destructive（CLI 不旁路 SAFE MODE）。
  // 候选根与真实 restore 的锁目录/journal 根同源（均为 <root> = dirname(快照目录) 的那一族）。
  const controlRoots = resolveControlRoots({ dataRoot: options.dataRoot, dataDir: options.dataDir }, env);
  // Phase 3 P0-A：CLI restore 也建 durable journal；顺带做续跑探测（只读）——「同一个恢复崩在中途」正是 SAFE MODE 在等的结论。
  const recovery = new Phase3Recovery({ dataDir: path.dirname(dataDir), packageVersion: '0.1.0', fingerprintDataDir: path.dirname(dataDir) });
  const resumeProbe = await probeCliRestoreResume(recovery, restoreOptions);
  const safeMsg2 = checkSafeModeBlocked(controlRoots);
  if (safeMsg2 !== null && !resumeProbe.resumable) {
    io.error(`拒绝执行：${safeMsg2}${resumeProbe.reason === null ? '' : `（无法自动续跑：${resumeProbe.reason}）`}`); return 1;
  }
  // Phase 2 锁：真实 restore 是 destructive（覆盖/删除 $DSH_HOME + 卸载插件），必须成功获取
  // GLOBAL 环境锁；被另一 DSH 任务持有 → 明确报错退出（无 --force 旁路）。无锁目录 → 用默认 dataDir。
  const lock = new EnvironmentLockManager({
    locksDir: path.join(dataDir, '..', 'locks'),
    op: 'cli-restore',
    target: id,
    lockVersion: '0.1.0',
  });
  try {
    // Phase 3 P0-A：CLI restore 也创建 durable journal（关闭 bypass）。
    await recovery.initFingerprint().catch(() => undefined);
    const outcome = await runWithMutationLock(lock, { op: 'cli-restore', target: id }, async (lockCtx) => {
      // 第三道门（与救急台 actions.ts 的 checkWriteGates 同源、同序：SAFE MODE → 残留锁 → DSH 未运行）：
      // 恢复会覆盖/删除 $DSH_HOME 下**正在被实例使用**的文件。放在持有环境锁之后，于是「残留锁」仍先于它报出。
      const running = await readRunningInstances(controlRoots);
      if (running.length > 0) return { kind: 'dsh-running' as const, running };
      // 锁内统一入口：能续跑 → resumeJournaled（接着做），否则 → runJournaled（照常新建）
      const out = await runCliRestore(recovery, restoreOptions, lockCtx);
      if (out.resumed !== null) io.log(`自动续跑：已完成 ${String(out.resumed.done)} 项、待做 ${String(out.resumed.todo)} 项；SAFE MODE ${out.safeModeCleared === true ? '已解除' : '仍保持'}`);
      return { kind: 'restore' as const, report: out.report };
    });
    if (outcome.kind === 'dsh-running') {
      io.error('检测到 DSH 正在运行（' + outcome.running.map((i) => i.name + ' pid=' + String(i.pid)).join('、')
        + '）：请先关闭 DSH 再执行恢复 —— 恢复会覆盖/删除 $DSH_HOME 下正在使用的文件。');
      io.error('如 DSH 已起不来（无法正常关闭），改用本机救急台：dcm web（「恢复」页与 CLI 同一实现，可先停实例/回收残留锁）。');
      return 1;
    }
    const report = outcome.report;
    printReport(report, io);
    return report.failed.length > 0 ? 1 : 0;
  } catch (err) {
    if (err instanceof EnvironmentLockUnavailableError) {
      io.error(`拒绝执行：${err.message}`)
      return 1;
    }
    throw err;
  }
}

/* ------------------------------------------------------------ web：离线只读救急台 */

/** 救急台的目录事实（由 --data-dir / --data-root 统一派生；四处只认这一份）。 */
export interface WebPaths {
  /** 插件数据根（快照/导出/锁都挂在它下面） */
  root: string
  /** 与 root 同值（RescuePaths.dataDir 的语义） */
  dataDir: string
  snapshotsDir: string
  exportsDir: string
  locksDir: string
  controlRoots: string[]
}

/**
 * 派生救急台要用的四个目录 —— **root 只算一次**，再同时派生 snapshots / exports / locks / dataDir。
 *
 * 为什么必须统一：`--data-dir` 的历史语义是「快照目录 / 导出目录」，尾段命中 `snapshots`/`exports`
 * 时要**上溯一层**才是数据根。此前只对「那一条」取原值、另一条仍 `path.join(dataDir, ...)`，
 * 于是 `--data-dir <root>/snapshots` 会派生出 `<root>/snapshots/exports`（半上溯）——
 * 命令行与网页看到的目录事实立刻分叉。`--data-root` 恒为准。
 */
export function resolveWebPaths(
  opts: { dataRoot?: string; dataDir?: string } = {},
  env: Record<string, string | undefined> = process.env,
): WebPaths {
  const explicitRoot = opts.dataRoot !== undefined && opts.dataRoot !== '' ? path.resolve(opts.dataRoot) : undefined;
  const explicitDataDir = opts.dataDir !== undefined && opts.dataDir !== '' ? path.resolve(opts.dataDir) : undefined;
  const root = explicitRoot
    ?? (explicitDataDir === undefined
      ? path.join(resolveDshHome(env), 'dsh-config-manager')
      : ['snapshots', 'exports'].includes(path.basename(explicitDataDir))
        ? path.dirname(explicitDataDir)
        : explicitDataDir);
  return {
    root,
    dataDir: root,
    snapshotsDir: path.join(root, 'snapshots'),
    exportsDir: path.join(root, 'exports'),
    locksDir: path.join(root, 'locks'),
    controlRoots: resolveControlRoots({ dataRoot: explicitRoot, dataDir: explicitDataDir }, env),
  };
}

/**
 * 启动离线救急台（**只读**）。
 *
 * 为什么目录要在这一侧解析：`--data-dir / --data-root` 的既有语义只有本文件的 resolve* 系列说了算——
 * 网页与各子命令必须看到同一份目录事实，否则迟早出现「命令行说没有、网页说有一个」的分叉。
 * 目录派生统一走 `resolveWebPaths()`（`--data-dir` 尾段命中 snapshots/exports 时上溯一层；`--data-root` 恒为准）。
 *
 * 服务端只绑 127.0.0.1，端口缺省 0（内核分配）；启动后打印带一次性 token 的 URL 并打开浏览器。
 */
async function runWeb(
  options: CliOptions,
  io: CliIo,
  env: Record<string, string | undefined>,
): Promise<number> {
  const homeDir = options.home ?? resolveDshHome(env);
  const { dataDir, snapshotsDir, exportsDir, locksDir, controlRoots } =
    resolveWebPaths({ dataRoot: options.dataRoot, dataDir: options.dataDir }, env);
  // 懒加载：http 服务端代码不进其他子命令（尤其 reinstall/restore 的救急路径）的启动链路
  const { startConsoleServer } = await import('./web/server.ts');
  const server = await startConsoleServer({
    paths: {
      homeDir,
      dataDir,
      snapshotsDir,
      exportsDir,
      locksDir,
      controlRoots,
      profile: options.profile,
      // 离线导出的 manifest.exporter.version 用**真实 CLI 版本**（与 backup 同一口径），
      // 不再写死 'rescue-console' —— 那会让产物声称一个不存在的导出器版本。
      exporterVersion: CLI_EXPORTER_VERSION,
    },
    version: CLI_EXPORTER_VERSION,
    port: options.port ?? 0,
    openBrowser: options.noOpen !== true,
    idleTimeoutMs: (options.idleTimeoutMin ?? 30) * 60_000,
    io,
  });
  await server.closed;
  return 0;
}

/* ------------------------------------------------------------ verify：备份只读自检 */

/** verdict → 行首标记（人读摘要用；OK 才不显眼） */
function verdictTag(v: BackupVerifyVerdict): string {
  switch (v) {
    case 'OK': return '[OK]';
    case 'MISSING': return '[MISSING]';
    case 'CORRUPT': return '[CORRUPT]';
    case 'UNSUPPORTED': return '[UNSUPPORTED]';
    case 'VERIFY_ERROR': return '[VERIFY_ERROR]';
  }
}

/** 导出目录：--data-dir 覆盖优先，缺省 $DSH_HOME/dsh-config-manager/exports */
export function resolveExportsDir(flag: string | undefined, env: Record<string, string | undefined> = process.env): string {
  if (flag !== undefined && flag !== '') return flag;
  return path.join(resolveDshHome(env), 'dsh-config-manager', 'exports');
}


/** 打印单个校验结果（文件级一行摘要 + 详情缩进） */
function printVerifyResult(r: BackupVerifyResult, io: CliIo): void {
  const size = r.sizeBytes !== undefined ? ` ${r.sizeBytes}B` : '';
  const entries = r.entryCount !== undefined ? ` ${r.entryCount} entries` : '';
  io.log(`${verdictTag(r.verdict)} ${path.basename(r.file)}${size}${entries}`);
  for (const e of r.errors) io.log(`    ! ${e}`);
  for (const w of r.warnings) io.log(`    - ${w}`);
}

async function runVerify(
  options: CliOptions,
  io: CliIo,
  env: Record<string, string | undefined>,
): Promise<number> {
  const dataDir = resolveExportsDir(options.dataDir, env);
  const explicit = options.id ?? options.positionals[0];
  // 自检收集与救急台网页共用同一实现（阶段 0）—— 两处绝不允许给出不同结论
  const outcome = await collectVerifyResults(dataDir, explicit);
  if (!outcome.ok) {
    // --json：错误也走 JSON（否则 CI 会拿到空 stdout 导致 jq 解析失败）
    if (options.json) io.log(stringifyJsonSafe({ error: outcome.error }, { space: 2 }));
    else io.error(outcome.error);
    return 1;
  }
  const results: BackupVerifyResult[] = outcome.results;

  if (options.json) {
    // 机器可读：单目标 → 对象；多目标 → 数组（便于 CI 用 jq 直接取 verdict）
    const payload = results.length === 1 ? results[0]! : results;
    io.log(stringifyJsonSafe(payload, { space: 2 }));
  } else {
    for (const r of results) printVerifyResult(r, io);
  }

  const failed = results.filter((r) => r.verdict !== 'OK');
  if (!options.json) {
    const counts = new Map<BackupVerifyVerdict, number>();
    for (const r of results) counts.set(r.verdict, (counts.get(r.verdict) ?? 0) + 1);
    const parts = [...counts.entries()].map(([v, n]) => `${v} ${n}`);
    io.log(`汇总 / summary: ${results.length} 个备份 checked — ${parts.join(' · ')}`);
  }
  if (failed.length > 0) {
    if (!options.json) io.error(`${failed.length} 个备份未通过自检 / ${failed.length} backup(s) failed verification`);
    return 1;
  }
  return 0;
}

/* ------------------------------------------------------------ backup：离线文件级备份 */

/** 打印待打包清单（--dry-run 与真实执行前的预览共用） */
function printBackupPlan(col: BackupCollection, outPath: string, io: CliIo): void {
  io.log(`备份计划 / backup plan（${col.entries.length} 个文件 → ${outPath}）`);
  for (const s of col.sections) {
    io.log(`  ${s.label}（${s.sectionId}）: ${s.entryCount} 个文件${s.excludedCount > 0 ? `，已排除 ${s.excludedCount}` : ''}`);
    if (s.risk !== undefined) io.log(`      ⚠ ${s.risk}`);
  }
  for (const id of OFFLINE_UNAVAILABLE_SECTIONS) {
    io.log(`  （离线不可收集 / not offline-collectable）${id}`);
  }
  io.log('凭据类文件（.credentials.* / .env / *.pem 等）已显式排除，绝不进入备份。');
}

async function runBackup(
  options: CliOptions,
  io: CliIo,
  env: Record<string, string | undefined>,
): Promise<number> {
  const homeDir = resolveDshHome(env);
  const exportsDir = resolveExportsDir(options.dataDir, env);

  let only: SectionId[] = [];
  if (options.sections !== undefined && options.sections !== '') {
    const parsed = parseSectionsArg(options.sections);
    if (!parsed.ok) {
      io.error(parsed.error);
      return 1;
    }
    only = parsed.sections;
  }

  const collection = await collectBackupEntries(homeDir, only);
  if (collection.entries.length === 0) {
    io.error(`没有可打包的内容 / nothing to back up（${homeDir} 下未找到可离线收集的分区）`);
    return 1;
  }

  // 输出路径：--out 优先；否则导出目录内按时间自动命名，且绝不覆盖既有文件
  let outPath: string;
  if (options.out !== undefined && options.out !== '') {
    outPath = path.resolve(options.out);
    if (await pathExists(outPath)) {
      const base = outPath.endsWith('.zip') ? outPath.slice(0, -4) : outPath;
      let candidate = `${base}-1.zip`;
      for (let i = 2; await pathExists(candidate); i += 1) candidate = `${base}-${i}.zip`;
      outPath = candidate;
    }
  } else {
    // 注意：此处刻意不 mkdir —— dry-run 必须零写入，目录在真正落盘前才创建
    const now = new Date();
    const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`
      + `-${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;
    try {
      const rand = await randomHex4();
      outPath = await resolveNonCollidingName(exportsDir, `dsh-config-cli-${stamp}-${rand}.zip`);
    } catch (err) {
      io.error(`生成输出路径失败 / failed to build output path: ${err instanceof Error ? err.message : String(err)}`);
      return 1;
    }
  }

  if (options.dryRun) {
    printBackupPlan(collection, outPath, io);
    return 0;
  }

  // 组装 ZIP（manifest / checksums 复用 GUI 导出的同一构造方式）
  const sectionFlags = buildSectionFlags(collection.included);
  const checksums = buildChecksums(collection.entries);
  const manifest = buildManifest({
    exporterVersion: CLI_EXPORTER_VERSION,
    // 离线 CLI 探测不到真实 DSH 版本：如实标注（不谎报成某个版本号）
    dshVersion: 'cli-offline',
    platform: process.platform as Manifest['source']['platform'],
    arch: process.arch,
    sections: sectionFlags,
    containsSecrets: false, // 凭据文件已被显式排除，恒为 false
    encrypted: false,
    encryption: null,
  });
  const entries = [
    ...collection.entries,
    { name: CHECKSUMS_FILE, data: new TextEncoder().encode(stringifyJsonSafe(checksums, { space: 2 })) },
    { name: MANIFEST_FILE, data: new TextEncoder().encode(stringifyJsonSafe(manifest, { space: 2 })) },
  ];
  try {
    // 真正落盘前才创建导出目录（dry-run 已在上面提前返回，不产生任何写入）
    await fsp.mkdir(path.dirname(outPath), { recursive: true });
    await writeZip(outPath, entries);
  } catch (err) {
    io.error(`写入备份失败 / failed to write backup: ${err instanceof Error ? err.message : String(err)}`);
    return 1;
  }

  printBackupPlan(collection, outPath, io);
  io.log(`备份已创建 / backup created: ${outPath}`);
  for (const w of collection.warnings) io.error(`  - ${w}`);

  // 落盘后立即自检（与 verify 同一引擎）：只有自检通过才返回 0
  const check = await verifyBackupZip(outPath);
  printVerifyResult(check, io);
  if (check.verdict !== 'OK') {
    io.error('备份自检未通过（文件已保留，请复核）/ self-verification failed（file kept for inspection）');
    return 1;
  }
  io.log('自检通过 / self-verification OK');
  return 0;
}

/** 文件是否存在 */
async function pathExists(p: string): Promise<boolean> {
  try {
    await fsp.stat(p);
    return true;
  } catch {
    return false;
  }
}

/** 4 字节随机十六进制（与宿主导出命名风格一致，避免引入额外依赖） */
async function randomHex4(): Promise<string> {
  const { randomBytes } = await import('node:crypto');
  return randomBytes(4).toString('hex');
}

/** 导出目录内取不冲突的文件名（复用既有去重语义：foo.zip → foo-1.zip） */
async function resolveNonCollidingName(dir: string, desired: string): Promise<string> {
  let existing: string[] = [];
  try {
    existing = await fsp.readdir(dir);
  } catch {
    existing = [];
  }
  if (!existing.includes(desired)) return path.join(dir, desired);
  const base = desired.endsWith('.zip') ? desired.slice(0, -4) : desired;
  for (let i = 1; ; i += 1) {
    const candidate = `${base}-${i}.zip`;
    if (!existing.includes(candidate)) return path.join(dir, candidate);
  }
}

/* 直接运行（bin / node src/cli/index.ts）时进入主流程；被 import（测试）时不自动执行 */
const isDirectRun = process.argv[1] !== undefined
  && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isDirectRun) {
  runCli(process.argv.slice(2))
    .then((code) => {
      process.exitCode = code;
    })
    .catch((err) => {
      console.error(`dsh-config-manager 执行失败 / failed: ${err instanceof Error ? err.message : String(err)}`);
      process.exitCode = 1;
    });
}
