/**
 * m-market-ui：配置市场区块客户端渲染装配层单测（纯函数，node 可测，无需 DOM）。
 *
 * 共享渲染模型函数（marketStatusText / marketListSummary / computeItemBadge /
 * marketItemWarnings / needsReview / toMarketListItem）由本文件 **re-export** 自 Host 权威
 * src/market/view.ts —— 这里验证 re-export 可用 + 硬不变式；客户端专属辅助
 * （filterMarketItems / collectCategories / marketDetailView / marketWarningsLines / formatMarketTime）
 * 在此覆盖其逻辑。
 *
 * 硬约束（设计文档 §1 / §7.2）：供应链警示恒生成、needsReview 恒 true、canImport=valid 且 sections 非空。
 */
import test from 'node:test'
import assert from 'node:assert/strict'

import type { MarketItemDetail, MarketListItem } from '../../market/types.ts'
import { zhUiT } from '../../ui/i18n.ts'
import type { ImportPlan, PlanItem } from '../../core/types.ts'
import {
  collectCachedSections, collectCategories,
  computeItemBadge, filterBySource, filterMarketBySection, filterMarketItems,
  formatMarketTime, marketDetailView, marketImpactSummary, marketListSummary,
  marketStatusText, marketWarningsLines, marketItemWarnings, needsReview, sortMarketItems,
  sourceBadgeKind, isThirdPartyItem, toMarketListItem,
} from './market-view.ts'

/* ---------------------------------------------------------------- 共享渲染模型（re-export 权威） */

function item(overrides: Partial<MarketListItem> & { id: string }): MarketListItem {
  return { name: overrides.id, cacheState: 'none', ...overrides }
}

test('market-view: marketStatusText（共享权威）→ 未配置 / 已添加 N 个', () => {
  assert.match(marketStatusText({ count: 0 }, zhUiT), /尚未添加市场/)
  assert.match(marketStatusText({ count: 2 }, zhUiT), /已添加 2 个市场/)
  // 传入 MarketSummary[] 数组形态也能计数
  assert.match(marketStatusText([{ url: 'u', addedAt: '' }], zhUiT), /已添加 1 个市场/)
})

test('market-view: marketListSummary（共享权威）→ 总数 + 缓存计数', () => {
  const s = marketListSummary(
    [
      item({ id: 'a', cacheState: 'cached' }),
      item({ id: 'b', cacheState: 'fresh' }),
      item({ id: 'c', cacheState: 'none' }),
    ],
    zhUiT,
  )
  assert.equal(s.total, 3)
  assert.equal(s.cached, 1)
  assert.equal(s.fresh, 1)
  assert.equal(s.none, 1)
})

test('market-view: computeItemBadge（共享权威）→ valid/invalid + 分区文本', () => {
  const ok = computeItemBadge(detail({ status: 'valid', sections: ['settings', 'plugins'] }), zhUiT)
  assert.equal(ok.valid, true)
  assert.match(ok.statusText, /校验通过/)
  assert.match(ok.sectionsText, /settings/)
  const bad = computeItemBadge(detail({ status: 'invalid', sections: [] }), zhUiT)
  assert.equal(bad.valid, false)
  assert.match(bad.sectionsText, /未声明分区/)
})

test('market-view: marketItemWarnings（共享权威）恒生成「非官方审核」警示（无论 status）', () => {
  const valid = marketItemWarnings(undefined, 'https://github.com/u/m', '2026-08-16T10:30:00.000Z', zhUiT)
  assert.ok(valid.some((w) => w.includes('非官方审核')))
  const invalid = marketItemWarnings(
    { name: 'x', author: 'alice', provenance: { source: 'https://gh.com', note: '自述' } },
    'https://github.com/u/m',
    '2026-08-16T10:30:00.000Z',
    zhUiT,
  )
  assert.ok(invalid.some((w) => w.includes('非官方审核')))
  assert.ok(invalid.some((w) => w.includes('https://github.com/u/m')))
  assert.ok(invalid.some((w) => w.includes('alice')))
})

test('market-view: needsReview（共享权威）恒 true（供应链警示不让默认信任）', () => {
  assert.equal(needsReview(detail({ status: 'valid' })), true)
  assert.equal(needsReview(detail({ status: 'invalid' })), true)
})

test('market-view: toMarketListItem（共享权威）投影 MarketIndexItem → MarketListItem（带 cacheState）', () => {
  const out = toMarketListItem({ id: 'a', name: 'x', author: 'b', categories: ['c'] }, 'cached')
  assert.equal(out.id, 'a')
  assert.equal(out.name, 'x')
  assert.equal(out.cacheState, 'cached')
  assert.deepEqual(out.categories, ['c'])
})

/* ---------------------------------------------------------------- 客户端专属：来源徽章（阶段 1 条目级来源仓库） */

const OFFICIAL_URL = 'https://github.com/xiajiajun516/dsh-config-market.git'
const THIRD_PARTY_URL = 'https://github.com/alice/dsh-config-market-items.git'

test('market-view: sourceBadgeKind 无 repo（与市场同仓）→ 官方 ok', () => {
  assert.equal(sourceBadgeKind({}, OFFICIAL_URL), 'ok')
  assert.equal(sourceBadgeKind({ repo: undefined }, OFFICIAL_URL), 'ok')
  assert.equal(isThirdPartyItem({}, OFFICIAL_URL), false)
})

test('market-view: sourceBadgeKind repo 为官方默认地址 → 官方 ok', () => {
  assert.equal(sourceBadgeKind({ repo: OFFICIAL_URL }, OFFICIAL_URL), 'ok')
  assert.equal(isThirdPartyItem({ repo: OFFICIAL_URL }, OFFICIAL_URL), false)
})

test('market-view: sourceBadgeKind repo 为第三方仓库 → 第三方 warn', () => {
  assert.equal(sourceBadgeKind({ repo: THIRD_PARTY_URL }, OFFICIAL_URL), 'warn')
  assert.equal(isThirdPartyItem({ repo: THIRD_PARTY_URL }, OFFICIAL_URL), true)
})

test('market-view: sourceBadgeKind 市场被 env 覆盖为预览仓库时，无 repo 条目随市场显示第三方 warn（语义自洽）', () => {
  // 非官方默认地址的 builtinUrl（维护者预览仓库）：无 repo 条目与市场同仓 → 非官方
  assert.equal(sourceBadgeKind({}, THIRD_PARTY_URL), 'warn')
  assert.equal(isThirdPartyItem({}, THIRD_PARTY_URL), true)
})

test('market-view: sourceBadgeKind 有 repo 时 builtinUrl 不参与判定（repo 非官方即 warn）', () => {
  // 即便传入的 builtinUrl 与该 repo 相同，只要 repo 非官方默认地址 → 第三方 warn
  assert.equal(sourceBadgeKind({ repo: THIRD_PARTY_URL }, THIRD_PARTY_URL), 'warn')
})

/* ---------------------------------------------------------------- 客户端专属：搜索 / 类别 */

function detail(overrides: Partial<MarketItemDetail>): MarketItemDetail {
  return {
    id: 'i1', name: 'n', version: '1.0', status: 'valid',
    sections: ['settings'], downloadedAt: '2026-08-16T10:30:00.000Z', warnings: [],
    ...overrides,
  }
}

test('market-view: collectCategories 收集去重类别（含无类别条目）', () => {
  const cats = collectCategories([
    item({ id: 'a', categories: ['插件', '代理'] }),
    item({ id: 'b', categories: ['插件'] }),
    item({ id: 'c' }),
  ])
  assert.deepEqual([...cats].sort(), ['代理', '插件'])
})

test('market-view: filterMarketItems 按名称/作者/描述大小写不敏感匹配', () => {
  const items = [
    item({ id: 'a', name: 'My Plugin', author: 'alice', description: 'cool' }),
    item({ id: 'b', name: 'other', author: 'Bob', description: 'nope' }),
  ]
  assert.equal(filterMarketItems(items, 'plugin', '').length, 1)
  assert.equal(filterMarketItems(items, 'ALice', '').length, 1)
  assert.equal(filterMarketItems(items, 'cooL', '').length, 1)
  assert.equal(filterMarketItems(items, 'zzz', '').length, 0)
})

test('market-view: filterMarketItems 类别过滤 + 组合查询', () => {
  const items = [
    item({ id: 'a', name: 'x', categories: ['插件'] }),
    item({ id: 'b', name: 'x', categories: ['代理'] }),
  ]
  assert.equal(filterMarketItems(items, '', '插件').length, 1)
  assert.equal(filterMarketItems(items, '', '代理').length, 1)
  assert.equal(filterMarketItems(items, '', '不存在').length, 0)
  assert.equal(filterMarketItems(items, 'x', '插件').length, 1)
})

/* ---------------------------------------------------------------- 客户端专属：来源筛选 + 排序（2026-08-21） */

test('market-view: filterBySource all → 原样保留全部（含官方与个人）', () => {
  const items = [
    item({ id: 'a' }), // 无 repo = 官方
    item({ id: 'b', repo: THIRD_PARTY_URL }), // 个人
  ]
  assert.deepEqual(filterBySource(items, 'all', OFFICIAL_URL).map((i) => i.id), ['a', 'b'])
})

test('market-view: filterBySource official → 仅官方（无 repo / 官方 repo）', () => {
  const items = [
    item({ id: 'a' }),
    item({ id: 'b', repo: OFFICIAL_URL }),
    item({ id: 'c', repo: THIRD_PARTY_URL }),
  ]
  assert.deepEqual(filterBySource(items, 'official', OFFICIAL_URL).map((i) => i.id), ['a', 'b'])
})

test('market-view: filterBySource personal → 仅个人（非官方 repo）', () => {
  const items = [
    item({ id: 'a' }),
    item({ id: 'b', repo: OFFICIAL_URL }),
    item({ id: 'c', repo: THIRD_PARTY_URL }),
  ]
  assert.deepEqual(filterBySource(items, 'personal', OFFICIAL_URL).map((i) => i.id), ['c'])
})

test('market-view: sortMarketItems default → 保持原顺序（不改动数组）', () => {
  const items = [item({ id: 'b' }), item({ id: 'a' })]
  const out = sortMarketItems(items, 'default')
  assert.deepEqual(out.map((i) => i.id), ['b', 'a'])
  assert.notEqual(out, items, '返回新数组，不改原数组')
})

test('market-view: sortMarketItems updatedAt → 降序（最新在前），无 updatedAt 排最后', () => {
  const items = [
    item({ id: 'old', updatedAt: '2026-01-01T00:00:00.000Z' }),
    item({ id: 'none' }),
    item({ id: 'new', updatedAt: '2026-08-01T00:00:00.000Z' }),
  ]
  assert.deepEqual(sortMarketItems(items, 'updatedAt').map((i) => i.id), ['new', 'old', 'none'])
})

test('market-view: sortMarketItems stars → 降序（多在前），无 stars 排最后', () => {
  const items = [
    item({ id: 'two', stars: 2 }),
    item({ id: 'none' }),
    item({ id: 'nine', stars: 9 }),
  ]
  assert.deepEqual(sortMarketItems(items, 'stars').map((i) => i.id), ['nine', 'two', 'none'])
})

test('market-view: sortMarketItems name → 升序 A–Z（localeCompare）', () => {
  const items = [
    item({ id: 'z', name: 'Zebra' }),
    item({ id: 'a', name: 'Alpha' }),
    item({ id: 'm', name: 'bravo' }), // localeCompare 大小写感知，bravo 在 Alpha 后
  ]
  assert.deepEqual(sortMarketItems(items, 'name').map((i) => i.name), ['Alpha', 'bravo', 'Zebra'])
})

test('market-view: sortMarketItems 稳定性（同值保持原相对顺序）', () => {
  const items = [
    item({ id: 'a1', updatedAt: '2026-08-01T00:00:00.000Z' }),
    item({ id: 'b2', updatedAt: '2026-08-01T00:00:00.000Z' }),
    item({ id: 'c3', updatedAt: '2026-07-01T00:00:00.000Z' }),
  ]
  assert.deepEqual(sortMarketItems(items, 'updatedAt').map((i) => i.id), ['a1', 'b2', 'c3'], '同值保持原顺序')
})

/* ---------------------------------------------------------------- 客户端专属：供应链警示着色 + 详情聚合 */

test('market-view: marketWarningsLines 恒非空且首条为 warn（非官方审核）', () => {
  const valid = marketWarningsLines(detail({ status: 'valid' }), 'https://github.com/u/m', zhUiT)
  const invalid = marketWarningsLines(detail({ status: 'invalid', errors: ['x'] }), 'https://github.com/u/m', zhUiT)
  assert.ok(valid.length > 0)
  assert.equal(valid[0]?.kind, 'warn')
  assert.equal(invalid[0]?.kind, 'warn')
  assert.ok(valid.some((l) => l.text.includes('非官方审核')))
})

test('market-view: marketWarningsLines 含来源 URL / 作者 / provenance（着色 info）', () => {
  const lines = marketWarningsLines(
    detail({ author: 'alice', provenance: { source: 'https://gh.com/alice', note: '自述' } }),
    'https://github.com/u/m', zhUiT
  )
  const text = lines.map((l) => l.text).join('\n')
  assert.match(text, /https:\/\/github\.com\/u\/m/)
  assert.match(text, /alice/)
  assert.match(text, /https:\/\/gh\.com\/alice/)
  assert.ok(lines.some((l) => l.kind === 'info'))
})

test('market-view: marketDetailView valid + 有分区 → canImport 且带警示/空错误', () => {
  const v = marketDetailView(detail({ status: 'valid', sections: ['settings'] }), 'https://x', true, zhUiT)
  assert.equal(v.canImport, true)
  assert.deepEqual(v.errors, [])
  assert.ok(v.warnings.length > 0)
  assert.equal(v.badge.statusKind, 'ok')
  assert.equal(v.showBack, true)
})

test('market-view: marketDetailView invalid → canImport=false 且 errors 透传、badge error', () => {
  const v = marketDetailView(detail({ status: 'invalid', errors: ['zip 越界', 'checksum 不符'] }), 'https://x', false, zhUiT)
  assert.equal(v.canImport, false)
  assert.deepEqual(v.errors, ['zip 越界', 'checksum 不符'])
  assert.equal(v.badge.statusKind, 'error')
  assert.equal(v.showBack, false)
})

test('market-view: marketDetailView valid 但空分区 → 不可导入（无从导入）', () => {
  const v = marketDetailView(detail({ status: 'valid', sections: [] }), 'https://x', true, zhUiT)
  assert.equal(v.canImport, false)
})

/* ---------------------------------------------------------------- 时间格式化 */

test('market-view: formatMarketTime 合法 ISO → 本地可读；非法/空 → 原样', () => {
  assert.match(formatMarketTime('2026-08-16T10:30:00.000Z'), /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/)
  assert.equal(formatMarketTime(''), '')
  assert.equal(formatMarketTime('not-a-date'), 'not-a-date')
})

/* ----------------------------------------------------------------------------
 * 逐项内容选择（安全不变式 (c) 2026-09 改版：默认全选、高风险分区就地警示；旧「默认不勾」已移除）
 * -------------------------------------------------------------------------- */

function planItem(adapter: string, kind: PlanItem['kind'] = 'Create'): PlanItem {
  return { id: `${adapter}:x`, kind, adapter: adapter as never, description: `分区 ${adapter}`, severity: 'info' }
}

function samplePlan(): ImportPlan {
  return {
    items: [
      planItem('settings'),
      planItem('plugins', 'Install'),
      planItem('agentInstructions'),
      planItem('pluginFiles'),
      planItem('mcp'),
      planItem('skills'),
    ],
    globalStrategy: 'merge',
    pathMappings: [],
    missingSecrets: [],
    needsRestart: true,
    estimatedActions: { settings: 1, plugins: 1, agentInstructions: 1, pluginFiles: 1, mcp: 1, skills: 1 } as ImportPlan['estimatedActions'],
  }
}

/**
 * 2026-09：市场通道与导入页共用同一套 Selection 语义（默认全选、全选含高风险分区），
 * 原「逐分区批准」实现（`defaultApprovals` / `buildApprovedPlan` / `approvedAdapterSummary` /
 * `approvalRows`）已删除，其行为等价测试同步移除；选择语义本身在
 * `src/ui/selection-model.test.ts`，市场特有的逐项摘要/高风险清单在
 * `src/ui/market-import.test.ts`。
 */

test('market-view: filterMarketItems 搜索命中 name/author/description 与 categories（P2-⑭）', () => {
  const items = [
    item({ id: 'a', name: 'Model Pack', categories: ['providers', 'models'] }),
    item({ id: 'b', name: 'Prompt Kit', description: 'system prompts', categories: ['customization'] }),
    item({ id: 'c', name: 'Skill Set', author: 'alice', categories: ['skills'] }),
  ]
  // 描述命中
  assert.deepEqual(filterMarketItems(items, 'system', '').map((i) => i.id), ['b'])
  // 类别命中（P2-⑭ 增强：搜类别标签名命中带该类别标签的条目）
  assert.deepEqual(filterMarketItems(items, 'providers', '').map((i) => i.id), ['a'], '类别名参与搜索')
  assert.deepEqual(filterMarketItems(items, 'skills', '').map((i) => i.id), ['c'], '类别标签命中')
  // 类别下拉过滤仍独立生效
  assert.deepEqual(filterMarketItems(items, '', 'providers').map((i) => i.id), ['a'])
})

test('market-view: filterMarketBySection / collectCachedSections（P2-⑭ 分区筛选）', () => {
  const items = [
    item({ id: 'a', name: 'A', cacheState: 'cached', sections: ['settings', 'plugins'] }),
    item({ id: 'b', name: 'B', cacheState: 'cached', sections: ['settings'] }),
    item({ id: 'c', name: 'C', cacheState: 'none' }), // 未下载 → 分区未知
  ]
  // 空筛选 = 全部
  const all = filterMarketBySection(items, '')
  assert.equal(all.matched.length, 3)
  assert.equal(all.unknown, 0)
  // 按 plugins 筛：只有 A 命中；C 未知被排除
  const plugins = filterMarketBySection(items, 'plugins')
  assert.deepEqual(plugins.matched.map((i) => i.id), ['a'])
  assert.equal(plugins.unknown, 1, '未知分区条目计入 unknown 提示')
  // 按 settings 筛：A + B
  const settings = filterMarketBySection(items, 'settings')
  assert.deepEqual(settings.matched.map((i) => i.id), ['a', 'b'])
  // collectCachedSections：只收集已缓存条目的分区并集
  assert.deepEqual(collectCachedSections(items).sort(), ['plugins', 'settings'])
})

test('market-view: marketImpactSummary 装了这个会动你什么（P1-⑥）', () => {
  const impact = marketImpactSummary(samplePlan(), {
    valid: true,
    errors: [],
    warnings: [],
    compatibility: 'excellent',
    sectionsInZip: ['settings'],
    unsupportedSections: [],
    unsupportedVersions: [],
    pluginSummary: { installed: 0, toInstall: 0 },
    pathIssues: [],
    secretCount: 0,
    dependencyIssues: [],
    encrypted: false,
  })
  assert.equal(impact.willChange > 0, true, '有变更项')
  assert.ok(impact.sections.length > 0, '分区清单非空')
  const settingsRow = impact.sections.find((s) => s.section === 'settings')
  assert.ok(settingsRow && settingsRow.count >= 1)
})
