/**
 * `dsh-config-manager/schema` 的运行时入口（`exports["./schema"]`）。
 *
 * 定位：**零 DSH 依赖、零 `node:` 依赖**的 schema 公共面。第三方在不安装
 * 任何 `@deepseek-ai/*`、React 或 Node 内建模块的前提下，即可：
 *  - 判定 `manifest.schemaVersion` 的兼容性（`isCurrent` / `isSupported` / `needsMigration` /
 *    `isTooNew` / `canImport` / `describeVersion` / `UnsupportedSchemaError`）；
 *  - 取到 `SECTION_IDS` / `SECTION_JSON_PATHS` / `SECTION_FILE_PREFIXES` / `isFileSection`，
 *    据此实现自己的 importer / exporter（ZIP 内路径与文件类分区前缀的唯一权威）；
 *  - 取到**分区注册表**（`SECTION_REGISTRY` / `SectionMeta` / `sectionMeta` / `jsonPathOf` /
 *    `PORTABLE_SECTION_IDS` / `OPT_IN_SYNC_SECTION_IDS` / `DEFAULT_INCLUDED_SECTION_IDS` …）——
 *    「有哪些分区、各自什么形态/可移植性」的机器可读唯一来源，与 `docs/spec/` 的分区清单对应；
 *  - 引用 Bundle Format v1 的全部载荷类型。
 *
 * 为什么需要它：此前的 `exports["./schema"]` 指向 `./lib/schema/types.js`，而 `types.ts`
 * 是**纯类型文件**——编译产物是一个**空模块**（运行时零导出）。第三方
 * `import('dsh-config-manager/schema')` 只会拿到 `{}`，`CURRENT_SCHEMA_VERSION` 等
 * 版本工具**在包外无法导入**（它们定义在 `./versions.ts`，不在任何 exports 映射内）。
 * 本文件把 `./schema` 变成真实可用的运行时入口。
 *
 * 约束（勿破）：本文件只 import 同目录模块（`./config.ts` / `./section-registry.ts` / `./types.ts` /
 * `./versions.ts`）。`section-registry.ts` 自身仍然只 import 一个**类型**（`type { SectionId }`；
 * 未注册分区的错误文案 t7 起在 `config.ts`，见那里）。
 * 目标性质是**零 `node:` / 零 npm / 零 @deepseek-ai 依赖**（headless 消费：
 * `docs/spec/headless-consumption.md`；client bundle 自包含）。唯一的跨层依赖是本域消息目录
 * （`./messages.ts` → `../core/engine-locale.ts`，纯函数、零 node / 零 npm），不破坏该性质；
 * 除此之外不得 import `../core/*`、`node:*` 或任何 UI / DSH 包。
 */

/* —— 版本判定（唯一出口，业务代码零散落 `if (v === 1)`） —— */
export {
  CURRENT_SCHEMA_VERSION,
  MIN_SUPPORTED_SCHEMA_VERSION,
  UnsupportedSchemaError,
  isCurrent,
  isSupported,
  needsMigration,
  isTooNew,
  canImport,
  describeVersion,
} from './versions.ts';

/* —— 分区表（第三方实现 importer/exporter 的路径权威） —— */
export {
  SECTION_IDS,
  SECTION_JSON_PATHS,
  SECTION_FILE_PREFIXES,
  isFileSection,
  requireSectionMeta,
} from './config.ts';

/*
 * —— 分区注册表（`section-registry.ts` 是分区元数据的唯一权威，t29） ——
 * 上面的 `SECTION_IDS` / `SECTION_JSON_PATHS` / `SECTION_FILE_PREFIXES` / `isFileSection` 由 `./config.ts`
 * 转出，这里再补上注册表本体的其余符号（同一个源模块，故不重复导出那四个名字，避免 duplicate export）。
 * 对外意义：第三方实现者不必读源码即可枚举「有哪些分区、ZIP 内形态、可移植性、同步可选分区、默认勾选」。
 */
export {
  SECTION_REGISTRY,
  SECTION_DATA_VERSION,
  sectionMeta,
  sectionMetaOf,
  isSectionId,
  jsonPathOf,
  filePrefixOf,
  PORTABLE_SECTION_IDS,
  OPT_IN_SYNC_SECTION_IDS,
  DEFAULT_INCLUDED_SECTION_IDS,
} from './section-registry.ts';

export type {
  SectionMeta,
  SectionPayload,
  SectionPortability,
  SectionExportGroup,
} from './section-registry.ts';

/* —— 载荷类型（纯类型，运行时零开销） —— */
export type {
  Platform,
  SectionId,
  EncryptionInfo,
  Manifest,
  NamespaceRecord,
  SettingsSection,
  UiMigrationNote,
  UiSection,
  ProviderEntry,
  ProvidersSection,
  PluginEntry,
  PatchLine,
  LocalPluginTarball,
  PluginsSection,
  McpServerEntry,
  McpSection,
  PromptEntry,
  PromptsSection,
  WorkspaceRecord,
  WorkspacesSection,
  CredentialStatus,
  CredentialsSection,
  FileEntry,
  FilesSection,
  SectionData,
} from './types.ts';
